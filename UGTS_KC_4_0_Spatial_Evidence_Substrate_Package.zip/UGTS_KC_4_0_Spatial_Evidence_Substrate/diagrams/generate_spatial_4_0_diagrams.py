from __future__ import annotations

import json
from pathlib import Path
import sys

import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle, FancyArrowPatch, Circle

ROOT = Path(__file__).resolve().parents[1]
OUT = Path(__file__).resolve().parent
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from ugts_kc4.ledger import SpatialLedger

BG = "#07101f"
PANEL = "#101b31"
PANEL2 = "#152744"
TEXT = "#eef4ff"
MUTED = "#a9b9d5"
CYAN = "#4de1da"
BLUE = "#6d8cff"
GOLD = "#f5c95d"
GREEN = "#6be39d"
RED = "#ff7b7b"
PURPLE = "#b38cff"
LINE = "#334c78"


def setup(title: str, subtitle: str, size=(14, 8)):
    fig, ax = plt.subplots(figsize=size, dpi=180)
    fig.patch.set_facecolor(BG)
    ax.set_facecolor(BG)
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 100)
    ax.axis("off")
    ax.text(5, 95, title, color=TEXT, fontsize=20, fontweight="bold", va="top")
    ax.text(5, 90, subtitle, color=MUTED, fontsize=9, va="top")
    ax.plot([5, 95], [87, 87], color=LINE, lw=1)
    return fig, ax


def box(ax, x, y, w, h, title, detail="", color=CYAN, fontsize=9):
    patch = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.6,rounding_size=1.8", facecolor=PANEL2, edgecolor=color, linewidth=1.5)
    ax.add_patch(patch)
    ax.text(x + w/2, y + h*0.63, title, color=color, fontsize=fontsize, fontweight="bold", ha="center", va="center", wrap=True)
    if detail:
        ax.text(x + w/2, y + h*0.28, detail, color=MUTED, fontsize=max(6, fontsize-2), ha="center", va="center", wrap=True)
    return patch


def arrow(ax, x1, y1, x2, y2, color=GOLD, lw=1.5):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>", mutation_scale=12, color=color, linewidth=lw, connectionstyle="arc3"))


def save(fig, name):
    fig.savefig(OUT / name, facecolor=fig.get_facecolor(), bbox_inches="tight", pad_inches=0.12)
    plt.close(fig)


def architecture():
    fig, ax = setup("UGTS-KC 4.0 Spatial Evidence Architecture", "Scanner/model output remains a proposal; verified event commit remains the authority.")
    ax.text(6, 82, "CAPTURE AND MODEL SOURCES", color=TEXT, fontsize=10, fontweight="bold")
    xs = [6, 26, 46, 66, 82]
    labels = [
        ("Video frames", "camera + timestamps"),
        ("Optional IMU", "synchronized motion"),
        ("Calibration / scale", "metric, anchored, relative"),
        ("Model heads", "depth, topology, semantics"),
        ("Uncertainty", "error intervals"),
    ]
    widths = [16, 16, 16, 16, 12]
    for x, w, (t, d) in zip(xs, widths, labels):
        box(ax, x, 70, w, 9, t, d, BLUE, 8)
    ax.text(6, 63, "AUTHORITATIVE SPATIAL EVIDENCE SUBSTRATE", color=TEXT, fontsize=10, fontweight="bold")
    stages = [
        (6, 50, 13, "Capture profile", "hashes, scale, privacy", CYAN),
        (22, 50, 13, "Typed observation", "pose + uncertainty", CYAN),
        (38, 50, 13, "Support + compatibility", "local + semantic", GOLD),
        (54, 50, 13, "Guard verifier", "confidence + error", GOLD),
        (70, 50, 11, "Map patch", "stable IDs", GREEN),
        (84, 50, 11, "Ledger", "hashes + lineage", GREEN),
    ]
    for x, y, w, t, d, c in stages:
        box(ax, x, y, w, 10, t, d, c, 8)
    for (x, _, w, *_), (nx, _, *_2) in zip(stages, stages[1:]):
        arrow(ax, x+w, 55, nx, 55)
    for x in [14, 34, 54, 74, 88]:
        arrow(ax, x, 70, min(94, x+2), 60, color=BLUE, lw=1)
    ax.text(6, 42, "QUERY, CHANGE AND DELIVERY", color=TEXT, fontsize=10, fontweight="bold")
    outputs = [
        (6, 27, 18, "Route topology", "clearance, slope, status"),
        (28, 27, 18, "Repeat-scan change", "moved / added / state"),
        (50, 27, 18, "Checkpoint + replay", "pre/post divergence"),
        (72, 27, 22, "Offline field report", "JSON + GeoJSON + HTML"),
    ]
    for i, (x, y, w, t, d) in enumerate(outputs):
        box(ax, x, y, w, 10, t, d, [PURPLE, RED, BLUE, CYAN][i], 8)
        arrow(ax, 89, 50, x+w/2, 37, color=[PURPLE, RED, BLUE, CYAN][i], lw=1)
    box(ax, 28, 8, 44, 9, "Android 4.0 status: DEFERRED", "3.9.1 NativeActivity/GLES3 source retained unchanged as future implementation reference", RED, 9)
    arrow(ax, 83, 27, 70, 17, color=RED, lw=1.2)
    save(fig, "architecture_spatial_4_0.png")


def verification():
    fig, ax = setup("Verified Spatial Proposal Pipeline", "Every rejection is explicit; no model or sensor output writes authoritative map state directly.")
    stages = [
        ("1", "Resolve capture profile", "calibration, scale, model versions"),
        ("2", "Spatial support", "sphere / AABB / cone-frustum"),
        ("3", "Compatibility", "kind, floor, tags, motion class"),
        ("4", "Relation interval", "g +/- numeric error"),
        ("5", "Confidence + uncertainty", "floors and kind-specific limits"),
        ("6", "Metric/provenance gates", "scale and source hashes"),
        ("7", "Deterministic conflict policy", "time, priority, source, ID"),
        ("8", "Atomic patch + lineage", "pre/post hashes and evidence"),
    ]
    y = 78
    for idx, (num, title, detail) in enumerate(stages):
        x = 8 if idx % 2 == 0 else 54
        if idx % 2 == 0 and idx > 0:
            y -= 17
        c = [CYAN, CYAN, GOLD, GOLD, PURPLE, PURPLE, RED, GREEN][idx]
        ax.add_patch(Circle((x+3, y+5), 3.6, facecolor=c, edgecolor=TEXT, lw=0.6))
        ax.text(x+3, y+5, num, color=BG, fontsize=9, fontweight="bold", ha="center", va="center")
        box(ax, x+8, y, 36, 10, title, detail, c, 8)
        if idx < len(stages)-1:
            if idx % 2 == 0:
                arrow(ax, x+44, y+5, 54, y+5, c)
            else:
                arrow(ax, x+26, y, 31, y-7, c)
    box(ax, 22, 6, 56, 9, "Canonical result", "accepted event OR reason-coded rejection; never an unchecked state mutation", GREEN, 9)
    save(fig, "verification_pipeline_4_0.png")


def keys():
    fig, ax = setup("Two Explicit 64-bit Spatial Key Profiles", "Finite keys accelerate lookup; they do not replace continuous state, uncertainty, topology or lineage.")
    ax.text(8, 79, "Voxel key: level4 | x20 | y20 | z20", color=CYAN, fontsize=12, fontweight="bold")
    fields = [(8, 12, "level\n4 bits", RED), (20, 24, "signed x\n20 bits", CYAN), (44, 24, "signed y\n20 bits", BLUE), (68, 24, "signed z\n20 bits", GREEN)]
    for x,w,label,c in fields:
        ax.add_patch(Rectangle((x,65),w,10,facecolor=PANEL2,edgecolor=c,lw=1.8))
        ax.text(x+w/2,70,label,color=TEXT,fontsize=8,ha="center",va="center")
    ax.text(8, 60, "Exact pack/unpack. Base cell size and origin are profile data; level scales cell width by 2^level.", color=MUTED, fontsize=8)
    ax.text(8, 49, "Camera-ray key: log-depth20 | azimuth18 | elevation14 | modular-time12", color=GOLD, fontsize=12, fontweight="bold")
    fields2 = [(8, 29, "log depth\n20 bits", GOLD), (37, 25, "azimuth\n18 bits", PURPLE), (62, 19, "elevation\n14 bits", BLUE), (81, 11, "time\n12 bits", RED)]
    for x,w,label,c in fields2:
        ax.add_patch(Rectangle((x,35),w,10,facecolor=PANEL2,edgecolor=c,lw=1.8))
        ax.text(x+w/2,40,label,color=TEXT,fontsize=8,ha="center",va="center")
    ax.text(8, 30, "Depth is logarithmic over a finite declared range; azimuth/elevation are quantized; time remains modular metadata.", color=MUTED, fontsize=8)
    box(ax, 8, 10, 25, 10, "What the key retains", "finite cell / ray address", GREEN, 8)
    box(ax, 38, 10, 25, 10, "What stays separate", "residual + uncertainty + identity", RED, 8)
    box(ax, 68, 10, 24, 10, "Admission rule", "key lookup -> support -> compatibility -> guard", CYAN, 8)
    save(fig, "spatial_keys_4_0.png")


def _project_xy(state, node_id, bounds, boxxy):
    minx,maxx,minz,maxz=bounds; x0,y0,w,h=boxxy
    p=state.nodes[node_id].pose.position
    return x0+(p[0]-minx)/(maxx-minx)*w, y0+(p[2]-minz)/(maxz-minz)*h


def route_change():
    baseline=SpatialLedger.load(ROOT/'examples/safe_route_spatial_ledger/baseline_ledger.json').map_state
    changed=SpatialLedger.load(ROOT/'examples/safe_route_spatial_ledger/changed_ledger.json').map_state
    routes=json.loads((ROOT/'examples/safe_route_spatial_ledger/route_results.json').read_text())
    fig, ax = setup("SafeRoute + DamageDelta Reference Vertical Slice", "A repeat scan blocks the main passage, moves a cart, adds an obstacle and deterministically selects the alternate route.", size=(15,8))
    panels=[(5,20,43,60,'BASELINE',baseline,routes['before']['edge_path']),(52,20,43,60,'REPEAT SCAN',changed,routes['after']['edge_path'])]
    bounds=(-1,13,-1,5)
    for x,y,w,h,label,state,selected in panels:
        ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.6,rounding_size=2',facecolor=PANEL,edgecolor=LINE,lw=1.2))
        ax.text(x+3,y+h-4,label,color=CYAN if label=='BASELINE' else GOLD,fontsize=12,fontweight='bold')
        inner=(x+4,y+6,w-8,h-14)
        for eid in sorted(state.edges):
            e=state.edges[eid]
            if e.kind!='route': continue
            a=_project_xy(state,e.source,bounds,inner); b=_project_xy(state,e.target,bounds,inner)
            status=e.state.get('status','unknown')
            color=RED if status=='blocked' else (CYAN if eid in selected else '#7386aa')
            lw=4.5 if eid in selected else 2.8
            style='--' if status=='blocked' else '-'
            ax.plot([a[0],b[0]],[a[1],b[1]],style,color=color,lw=lw,solid_capstyle='round')
        for nid,node in sorted(state.nodes.items()):
            px,py=_project_xy(state,nid,bounds,inner)
            color=RED if node.state.get('blocked') else (GOLD if node.kind in {'object','obstacle'} else GREEN)
            ax.add_patch(Circle((px,py),1.2,facecolor=PANEL2,edgecolor=color,lw=1.8))
            if node.kind!='object' or label=='REPEAT SCAN':
                ax.text(px,py+2.1,node.semantic.get('label',nid),color=TEXT,fontsize=6.5,ha='center')
        if label=='BASELINE':
            ax.text(x+3,y+2,'Preferred: Entrance -> Junction -> Main door -> Exit',color=MUTED,fontsize=8)
        else:
            ax.text(x+3,y+2,'Reroute: Entrance -> Junction -> Ramp -> Alternate door -> Exit',color=MUTED,fontsize=8)
    box(ax, 20, 5, 60, 9, "Verified repeat-scan changes: 4", "main door state + route state + moved cart + added obstruction; replay reaches the identical state hash", GREEN, 9)
    save(fig, "route_change_demo_4_0.png")


def ledger_replay():
    fig, ax = setup("Proposal Deltas, Authoritative Commit and Replay", "Low-bandwidth collaboration exchanges proposals; only the verifier and deterministic commit mutate the map.")
    box(ax, 7, 66, 20, 11, "Phone A delta", "base hash + proposals + content hash", BLUE, 9)
    box(ax, 7, 46, 20, 11, "Phone B delta", "same base hash + proposals", PURPLE, 9)
    box(ax, 34, 56, 20, 12, "Deterministic merge", "de-duplicate + order + conflict keys", GOLD, 9)
    arrow(ax,27,71,34,63,BLUE); arrow(ax,27,51,34,61,PURPLE)
    box(ax, 61, 56, 18, 12, "Proposal verifier", "support + compatibility + guard + budgets", CYAN, 9)
    arrow(ax,54,62,61,62)
    box(ax, 84, 56, 11, 12, "Atomic patch", "stable IDs", GREEN, 8)
    arrow(ax,79,62,84,62)
    box(ax, 34, 31, 20, 11, "Conflict / rejection", "reason-coded; map unchanged", RED, 9)
    arrow(ax,44,56,44,42,RED)
    box(ax, 61, 31, 18, 11, "Ledger event", "sequence + evidence + Hpre/Hpost", GREEN, 9)
    arrow(ax,89,56,70,42,GREEN)
    box(ax, 84, 31, 11, 11, "Checkpoint", "map + hashes", BLUE, 8)
    arrow(ax,79,36,84,36,BLUE)
    box(ax, 61, 10, 34, 10, "Replay / divergence", "apply ordered patches; stop at first sequence or hash mismatch", PURPLE, 9)
    arrow(ax,89,31,80,20,PURPLE)
    box(ax, 7, 10, 43, 10, "Authoritative boundary", "detectors, GPU kernels and models may propose in parallel; none may bypass commit", RED, 9)
    save(fig, "ledger_replay_4_0.png")


def validation():
    fig, ax = setup("UGTS-KC 4.0 Validation Expansion", "Retained implementation remains executable; the spatial layer adds tested records, routes, changes and replay.")
    ax.text(8,79,'Automated tests',color=TEXT,fontsize=12,fontweight='bold')
    totalw=78
    retained=276/380*totalw; new=104/380*totalw
    ax.add_patch(FancyBboxPatch((8,67),retained,9,boxstyle='round,pad=0.3,rounding_size=1.5',facecolor=BLUE,edgecolor=BLUE))
    ax.add_patch(FancyBboxPatch((8+retained,67),new,9,boxstyle='round,pad=0.3,rounding_size=1.5',facecolor=GREEN,edgecolor=GREEN))
    ax.text(8+retained/2,71.5,'Retained 276',color=TEXT,fontsize=9,fontweight='bold',ha='center',va='center')
    ax.text(8+retained+new/2,71.5,'New 4.0: 104',color=BG,fontsize=9,fontweight='bold',ha='center',va='center')
    ax.text(90,71.5,'380',color=GOLD,fontsize=17,fontweight='bold',ha='center',va='center')
    ax.text(8,54,'Combined mechanism catalog',color=TEXT,fontsize=12,fontweight='bold')
    retainedm=449/509*totalw; newm=60/509*totalw
    ax.add_patch(FancyBboxPatch((8,42),retainedm,9,boxstyle='round,pad=0.3,rounding_size=1.5',facecolor=PURPLE,edgecolor=PURPLE))
    ax.add_patch(FancyBboxPatch((8+retainedm,42),newm,9,boxstyle='round,pad=0.3,rounding_size=1.5',facecolor=CYAN,edgecolor=CYAN))
    ax.text(8+retainedm/2,46.5,'Retained M001-M449',color=TEXT,fontsize=9,fontweight='bold',ha='center',va='center')
    ax.text(8+retainedm+newm/2,46.5,'M450-M509',color=BG,fontsize=8,fontweight='bold',ha='center',va='center')
    ax.text(90,46.5,'509',color=GOLD,fontsize=17,fontweight='bold',ha='center',va='center')
    metrics=[('Verified demo events','17',GREEN),('Repeat-scan changes','4',RED),('Replay state-hash match','PASS',CYAN),('Android reference freeze','PASS',BLUE)]
    for i,(label,value,color) in enumerate(metrics):
        x=8+i*22
        box(ax,x,16,19,14,label,value,color,8)
    save(fig, "validation_expansion_4_0.png")


def android_deferral():
    fig, ax = setup("Android Work Is Intentionally Deferred", "The attached working implementation is preserved; the 4.0 spatial interfaces are completed before new phone-specific engineering.")
    box(ax, 7, 58, 25, 18, "Frozen 3.9.1 reference", "NativeActivity + C++20 + EGL/GLES3\nscene pack + device policy\nbyte-identical tree hashes", BLUE, 9)
    box(ax, 38, 58, 25, 18, "Completed 4.0 substrate", "capture profiles + observations\nverifier + map + routes\nchange + ledger + export", GREEN, 9)
    box(ax, 69, 58, 25, 18, "Future native capture/viewer", "Camera/IMU + model inference\n4.0 schemas + offline report\nnamed-device measurement", GOLD, 9)
    arrow(ax,32,67,38,67,BLUE); arrow(ax,63,67,69,67,GREEN)
    box(ax, 22, 30, 56, 11, "Promotion gate", "signed build on named phone; p50/p95/p99, memory, thermal, battery, false/missed events and equal-error baseline", RED, 9)
    arrow(ax,81,58,50,41,RED)
    ax.text(50,18,'No APK/AAB, camera pipeline, on-device model or POCO X7 Pro performance result is claimed in 4.0.',color=TEXT,fontsize=10,fontweight='bold',ha='center')
    save(fig, "android_deferral_4_0.png")


if __name__ == '__main__':
    architecture(); verification(); keys(); route_change(); ledger_replay(); validation(); android_deferral()
    print('generated spatial 4.0 diagrams')
