# UGTS-KC 4.0 - Spatial Evidence Ledger
## Spatial evidence, route topology, uncertainty, change lineage and offline field reports

UGTS-KC 4.0 is an additive expansion over the retained UGTS-KC 3.9.1 Signature package. It does not
replace the 2D vector/browser stack, the 3D scene/game oracle, the Two Hands production layer, or the
3.9.1 Android source reference. It adds a separate `ugts_kc4` namespace for phone-originated spatial
evidence and repeat-scan mapping.

```text
video / still frames / optional IMU / declared scale anchor
-> typed observations + uncertainty + model provenance
-> local support + semantic compatibility
-> guard interval + confidence + numeric-error verification
-> deterministic map patch
-> stable node/edge identity + route topology
-> pre/post hashes + checkpoints + replay + change lineage
-> canonical JSON / GeoJSON / self-contained offline HTML
```

## Release result

The package turns scanner output into a replayable spatial evidence ledger rather than treating a point
cloud or render mesh as the sole authority. The reference vertical slice demonstrates:

- metric-ready capture profiles and explicit calibration/model hashes;
- AABB, sphere and finite cone-frustum support volumes;
- typed observations with 3-axis uncertainty and relation intervals;
- deterministic support/compatibility/guard verification;
- stable map nodes, route edges, revisions, evidence links and lineage;
- accessible-route constraints over status, clearance, slope, confidence and uncertainty;
- repeat-scan moved/added/state-change candidates;
- multi-source proposal deltas and deterministic conflict detection;
- canonical state/event hashes, checkpoints and replay divergence detection;
- GeoJSON and one-file offline HTML field reports.

The engineering mechanism catalog is extended by **M450-M509**, taking the retained combined range to
**M509**.

## Run the 4.0 workflow

```bash
# Release identity and boundary
PYTHONPATH=src python -m ugts_kc4 info

# Generate and run the complete SafeRoute + DamageDelta example
PYTHONPATH=src python -m ugts_kc4 demo build/spatial_demo --json

# Validate a project
PYTHONPATH=src python -m ugts_kc4 validate \
  examples/safe_route_spatial_ledger/project.json --json

# Query the changed route graph
PYTHONPATH=src python -m ugts_kc4 route \
  examples/safe_route_spatial_ledger/project.json \
  examples/safe_route_spatial_ledger/changed_ledger.json \
  N-ENTRANCE N-EXIT --policy wheelchair-reference --json
```

The generated `offline_report.html` contains no CDN, web font, package-manager or network dependency.

## Android deferral

No new phone-specific Android application is implemented or retuned in 4.0. The attached working 3.9.1
`NativeActivity` / C++20 / EGL / OpenGL ES 3.0 implementation remains unchanged under:

- `android/UGTSKC391Signature/`
- `src/ugts_kc3/android_template/`
- `src/ugts_kc3/mobile3d.py`
- `src/ugts_kc3/androidexport.py`

These files are a frozen implementation reference for the later native capture/viewer application. Future
POCO-specific work must begin from this retained source after the 4.0 observation, ledger and export
interfaces are frozen. See `docs/ANDROID_DEFERRED_4_0.md`.

## Validation status

- **380 Python tests pass** in the complete retained-plus-new suite: 276 retained and 104 new 4.0 tests.
- The 4.0 modules compile with `compileall`.
- The SafeRoute + DamageDelta example commits 17 verified events, reroutes around a blocked passage,
  emits four verified change candidates and replays to the identical state hash.
- The project JSON validates against the bundled JSON Schema using the release validation tooling.
- The offline HTML is self-contained and the GeoJSON/ledger/project round trips preserve hashes.
- The retained 3.9.1 Android source tree is hashed as an unchanged reference; no 4.0 APK/AAB or device
  performance claim is made.

Captured evidence is under `validation/`.

## Package layout

- `src/ugts_kc4/` - spatial records, keys, verifier, routes, ledger, change detection, export and CLI.
- `examples/safe_route_spatial_ledger/` - editable project, baseline/changed ledgers, routes, changes,
  GeoJSON, summary and offline report.
- `spec/spatial_evidence_schema_4_0.json` - project schema.
- `spec/kc40_mechanisms_M450_M509.*` - 60-entry 4.0 mechanism catalog.
- `docs/` - release notes, evidence boundary, migration, Android deferral and usage guide.
- `report/UGTS_KC_4_0_Spatial_Evidence_Ledger.pdf` - technical release report.
- `android/` and `src/ugts_kc3/android_template/` - frozen 3.9.1 implementation reference.
- `tests/` - retained and 4.0 test suites.
- `validation/` - captured build, schema, demo, manifest and hash evidence.

## Evidence boundary

This release is a technical specification and executable reference implementation. It does not claim a
complete SLAM front end, clinically validated measurements, structural-safety certification, guaranteed
emergency navigation, an APK/AAB, or measured performance on a physical phone. Scanner/transformer
outputs are proposals; only verified ledger commits are authoritative within the selected application
policy.

## Attribution

Prepared for Tom Klootwijk. Requester-supplied identifier, date of birth and substrate attribution are
preserved as supplied and are not independently verified. The package is not legal proof of identity,
authorship, ownership, priority or patentability.
