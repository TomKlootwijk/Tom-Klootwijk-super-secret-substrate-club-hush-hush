from setuptools import find_packages, setup

setup(
    name="ugts-kc-spatial",
    version="4.0.0",
    package_dir={"": "src"},
    packages=find_packages("src"),
    package_data={"ugts_kc3.android_template": ["project/**/*"], "": ["py.typed"]},
    include_package_data=True,
    description="UGTS-KC 4.0 spatial evidence, topological route and change-ledger substrate",
    python_requires=">=3.10",
    entry_points={
        "console_scripts": [
            "ugts-kc=ugts_kc3.cli:main",
            "ugts-spatial=ugts_kc4.cli:main",
        ]
    },
)
