# Production Release Definition - UGTS-KC 4.0

UGTS-KC 4.0 is complete as a reference substrate when all of the following hold:

1. Retained 3.9.1 source and tests remain available.
2. The `ugts_kc4` namespace compiles without external runtime dependencies.
3. Project, observation, map, event, ledger, delta and export records are versioned and deterministic.
4. Support, compatibility, guard, confidence, error, uncertainty, scale and provenance gates execute in
   the documented order.
5. Map mutation occurs only through deterministic verified commit.
6. Route, change, checkpoint and replay behavior is covered by executable tests.
7. The SafeRoute + DamageDelta example regenerates all checked-in outputs and replay state hash.
8. Mechanisms M450-M509 are contiguous and the combined engineering catalog reaches M509.
9. The PDF, schema, source basis, file manifest and validation evidence are included.
10. The 3.9.1 Android project/template remains unchanged and 4.0 Android status is explicitly deferred.

The release definition does not require or imply an Android APK/AAB, complete SLAM, transformer model,
physical-phone benchmark or application certification.
