# Android Deferred Implementation Contract - 4.0

- `android_implementation_status` must be `deferred` or `reference_only` in a 4.0 project.
- No 4.0 source may claim an APK/AAB, phone installation, camera capture or on-device model benchmark.
- The retained 3.9.1 Android project and packaged template are frozen implementation references.
- A later native app must ingest/emit the 4.0 canonical schemas and preserve proposal verification,
  deterministic commit, evidence references, uncertainty, pre/post hashes and lineage.
- Device-specific optimization may not bypass the verifier or write authoritative map state from a shader,
  model output or camera callback.
