# UGTS-KC 4.0 validation evidence

This directory contains the captured release evidence for the Spatial Evidence Ledger upgrade while retaining the earlier 3.0, 3.9 and 3.9.1 records.

Principal 4.0 records:

- `test_results_4_0.txt` and `test_summary_4_0.json`: complete 380-test run, 276 retained plus 104 new.
- `schema_validation_4_0.json`: Draft 2020-12 validation of the reference spatial project.
- `catalog_validation_4_0.json`: contiguous M450-M509 delta and extended total M509.
- `spatial_demo_validation_4_0.json`: 17-event SafeRoute + DamageDelta run, four change candidates and matching replay hash.
- `offline_html_validation_4_0.json`: self-contained field-report checks.
- `android_reference_freeze_4_0.json`: unchanged 3.9.1 Android project, template and exporter hashes.
- `compileall_4_0.txt`, `cli_info_4_0.txt`, `cli_validate_4_0.json` and `cli_route_4_0.json`: source and command-line captures.
- `package_build_4_0.txt`, `distribution_install_4_0.txt` and `distribution_validation_4_0.json`: wheel/sdist build, clean fresh install and entry-point checks.
- `pdf_preflight_4_0.json`, `pdf_inspect_4_0.json` and `pdf_render_validation_4_0.json`: release-report openability, structure and rendered-page review.
- `release_summary_4_0.json`: compact release-level result.

The legacy files remain in place so the additive release can be audited without presenting earlier evidence as new 4.0 work.
