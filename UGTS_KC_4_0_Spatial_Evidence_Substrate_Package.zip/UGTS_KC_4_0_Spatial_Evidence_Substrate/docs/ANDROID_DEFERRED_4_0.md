# Android Native Implementation Deferred in UGTS-KC 4.0

## Decision

The 4.0 release completes the spatial observation, verification, map, route, change, replay and export
interfaces before starting another phone-specific application. No new Android app, APK/AAB, camera
pipeline or POCO tuning is claimed.

## Frozen implementation reference

The attached 3.9.1 implementation is retained unchanged:

- `android/UGTSKC391Signature/` - generated Android Studio NativeActivity project;
- `src/ugts_kc3/android_template/` - packaged source template;
- `src/ugts_kc3/mobile3d.py` - validated mobile-3D records and deterministic oracle;
- `src/ugts_kc3/androidexport.py` - scene-pack and Android project exporter;
- `native/host_tests/` - host-native parser/device-policy validation.

The 4.0 validation report records exact tree hashes for the checked-in Android project and packaged
template and confirms they match the attached 3.9.1 baseline.

## Required future starting point

A later native capture/viewer must begin from that retained code, then add a separate module boundary for:

1. Camera2/CameraX or NDK camera capture and timestamped frame delivery.
2. Optional IMU synchronization and declared calibration records.
3. On-device model inference that produces `Observation` proposals, never unchecked map writes.
4. Native serialization of the 4.0 project, ledger, event and delta schemas.
5. Offline HTML/GeoJSON export and local evidence-file handling.
6. Named-device benchmarks for capture, inference, verification, storage, thermal behavior and battery use.

## Promotion gate

No device claim should be promoted until a signed build is installed on the named phone and reports model,
OS, driver, display mode, thermal state, p50/p95/p99 latency, memory, battery/energy, false/missed events,
route correctness and equal-error comparison with a conventional baseline.
