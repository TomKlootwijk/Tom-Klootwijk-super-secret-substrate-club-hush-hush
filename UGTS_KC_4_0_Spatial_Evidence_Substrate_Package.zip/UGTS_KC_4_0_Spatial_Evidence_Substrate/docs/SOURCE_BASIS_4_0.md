# Source Basis - UGTS-KC 4.0

The 4.0 release is a source-grounded engineering expansion. Exact file hashes and roles are recorded in
`spec/source_basis_4_0.json`.

- UGTS-KC 2.0 supplies pattern/field geometry, topology descriptors, SE(2)/SE(3) kinematics, bounded
  dynamics and the verified-event rule.
- KC Two Hands 3.0 supplies stable scene-node identity, geometry/presentation error separation, spatial
  indexing, deterministic proposal commit, replay/checkpoints and JSON/glTF/USDA/SVG interchange.
- UGTS-KC 3.6 supplies in-substrate content-addressed definitions, explicit dependencies and normative
  operation order.
- SCLP 3.6.2 supplies finite cone/sphere supports, log-polar calculus, bounded uncertainty intervals and
  explicit 64-bit packing discipline.
- KC Elizabeth 3.9 supplies a versioned project model, deterministic execution and self-contained offline
  HTML deployment.
- UGTS-GN 1.1 supplies the normalized baseline, precision rules, compact-record boundaries and the
  support -> compatibility -> guard -> event -> transition -> lineage sequence.
- The two attached 3.9.1 ZIP files supply the working mobile-3D and Android NativeActivity/GLES3 source
  baseline. The 4.0 Android project/template tree hashes match that baseline and are retained as reference.

The 4.0 spatial mapping product concepts and code are engineering-derived from these mechanisms. The
source documents do not claim that a complete SLAM, accessibility, disaster-response, clinical or
infrastructure product already exists.
