# Release Notes - UGTS-KC 4.0 Spatial Evidence Ledger

UGTS-KC 4.0 is an additive spatial-mapping release over the retained 3.9.1 Signature archive.

## Added

- versioned capture profiles with calibration, scale, model provenance and privacy policy;
- typed 3D observations with relation intervals, semantic tags and conservative uncertainty bounds;
- spherical, AABB and finite cone-frustum support volumes;
- semantic compatibility policies and the canonical support/compatibility/guard verifier;
- 64-bit voxel and camera-ray log-polar keys plus a deterministic spatial hash reference index;
- stable map-node and map-edge identity, revisions, evidence attachment and lineage;
- guarded accessibility routes with passability, clearance, slope, confidence and uncertainty;
- deterministic map patches, event conflict handling, pre/post hashes, checkpoints and replay;
- repeat-scan movement, state, metric, addition and removal candidates;
- content-addressed proposal deltas and deterministic multi-source merge;
- canonical spatial JSON, GeoJSON and a self-contained offline HTML report;
- mechanisms M450-M509, extending the retained combined catalog to M509;
- 104 new automated tests and a complete SafeRoute + DamageDelta vertical slice.

## Retained

All 2.0, 3.0, 3.9 and 3.9.1 Python APIs, 2D/browser examples, mobile-3D model, native scene pack,
Android source template and checked-in Android project remain present.

## Deliberately postponed

No new APK/AAB, camera capture pipeline, SLAM front end, distilled transformer deployment or
POCO-specific native application is implemented in 4.0. The attached 3.9.1 NativeActivity/GLES3 source
is retained byte-for-byte as a frozen reference for the later device phase.

## Validation result

The complete retained-plus-new suite contains 380 passing tests: 276 retained and 104 new. The synthetic
demonstration commits 17 events, changes the preferred route after a blockage, emits four verified change
candidates and replays to the same map state hash.
