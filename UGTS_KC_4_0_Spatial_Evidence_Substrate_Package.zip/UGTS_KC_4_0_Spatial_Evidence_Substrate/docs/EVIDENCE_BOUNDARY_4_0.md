# Evidence Boundary - UGTS-KC 4.0

## What the release establishes

- The bundled records, verifier, route graph, ledger, change detector, exporters and CLI execute under the
  documented Python reference environment.
- The project, ledger, GeoJSON and proposal-delta records have deterministic round trips and hashes.
- The SafeRoute + DamageDelta synthetic example produces the documented events, routes, changes and
  replay result.
- The retained 3.9.1 Android source and packaged Android template are unchanged by the 4.0 release.

## What it does not establish

- A complete visual-inertial SLAM or monocular reconstruction system.
- Metric accuracy from a phone without calibration or a scale anchor.
- Accessibility, evacuation, structural, clinical or legal certification.
- Automatic crack, leak, instability, fire, medical or material diagnosis.
- A production multi-user synchronization service or adversarially secure evidence chain.
- An Android APK/AAB, installation, camera capture, transformer inference, device profiling or POCO X7 Pro
  performance result.
- Universal bit-identical floating-point execution across every CPU, compiler or mobile GPU.

## Application rule

Derived meshes, plan views, GeoJSON and HTML are projections. The authoritative reference record is the
versioned project, committed event sequence, map state, evidence links, uncertainty and lineage under the
selected policy.

## Kill criteria

Simplify or reject the 4.0 layer for a target application when:

- capture scale or calibration cannot meet the measurement contract;
- observation uncertainty or numeric error exceeds the event margin;
- support and compatibility do not prune enough false associations;
- stable IDs cannot be maintained and nearest-neighbor ambiguity dominates;
- route unknowns, clearance or slope errors exceed the application tolerance;
- event conflicts or branch density outgrow the avoided materialization;
- replay diverges or evidence references cannot be preserved;
- the offline projection is mistaken for a safety or medical certificate;
- a conventional mapping/GIS/SLAM data model is simpler, faster or more accurate at equal evidence quality.
