# API Overview - UGTS-KC 4.0

| Module | Primary responsibility |
|---|---|
| `canonical.py` | Numeric normalization, canonical JSON, content addresses and file hashes. |
| `model.py` | Capture profiles, poses, uncertainty, observations, stable nodes/edges, map state and patches. |
| `support.py` | Sphere/AABB/cone-frustum supports, registry and semantic compatibility policies. |
| `index.py` | 64-bit voxel/ray keys and deterministic spatial hash indexing. |
| `verify.py` | Guard classification, verification policy, event proposals and proposal verifier. |
| `topology.py` | Route policies, edge guards, topology validation and deterministic path queries. |
| `ledger.py` | Atomic patch commit, conflict rejection, events, state hashes, checkpoints and replay. |
| `change.py` | Repeat-scan change candidates, proposal deltas and deterministic multi-source merge. |
| `project.py` | Versioned project container, validation, loading and project hashes. |
| `export.py` | Canonical GeoJSON and self-contained offline HTML report. |
| `templates.py` | SafeRoute + DamageDelta reference project, proposals and reproducible demo. |
| `cli.py` | `ugts-spatial` command-line workflow. |

## Core records

- `CaptureProfile`: acquisition/calibration/model/scale/privacy contract.
- `Observation`: typed, uncertainty-bearing model or sensor proposal.
- `EventProposal`: observation plus requested `MapPatch` and deterministic ordering fields.
- `MapNode` / `MapEdge`: stable spatial and topological identity.
- `SpatialLedger`: authoritative committed map and event history.
- `RouteResult`: path, cost and rejected-edge reasons under one `RoutePolicy`.
- `ChangeCandidate`: before/after repeat-scan evidence with interval and review status.
- `ProposalDelta`: content-addressed low-bandwidth proposal bundle.
