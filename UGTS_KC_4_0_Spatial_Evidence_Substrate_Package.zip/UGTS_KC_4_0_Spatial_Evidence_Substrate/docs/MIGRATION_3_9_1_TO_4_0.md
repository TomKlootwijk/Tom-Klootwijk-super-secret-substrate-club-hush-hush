# Migration - UGTS-KC 3.9.1 to 4.0

The migration is additive. Existing `ugts_kc` and `ugts_kc3` imports remain unchanged.

1. Keep 3.9.1 `Mobile3DProject`, scene packs and Android source for rendering/game reference work.
2. Create a new `SpatialEvidenceProject` under `ugts_kc4`.
3. Define one or more `CaptureProfile` records and explicit scale mode.
4. Define finite support volumes and compatibility policies.
5. Convert scanner/model output into `Observation` plus `EventProposal` records.
6. Commit only through `ProposalVerifier` and `SpatialLedger`.
7. Represent navigable topology as stable nodes and guarded route edges.
8. Use checkpoints and event hashes for repeatable state; use `detect_changes` for repeat scans.
9. Export canonical JSON first; treat GeoJSON and HTML as downstream projections.
10. Leave the 3.9.1 Android project unchanged until the 4.0 schema is frozen for native binding.
