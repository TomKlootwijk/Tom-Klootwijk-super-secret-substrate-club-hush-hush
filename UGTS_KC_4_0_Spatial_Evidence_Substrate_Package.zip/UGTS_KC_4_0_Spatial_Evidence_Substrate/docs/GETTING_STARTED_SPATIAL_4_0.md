# Getting Started - UGTS-KC 4.0 Spatial Evidence

## Run the reference demo

```bash
PYTHONPATH=src python -m ugts_kc4 demo build/spatial_demo --json
```

Open `build/spatial_demo/offline_report.html` directly in a browser. No server or network access is required.

## Validate the checked-in project

```bash
PYTHONPATH=src python -m ugts_kc4 validate \
  examples/safe_route_spatial_ledger/project.json --json
```

## Query a route

```bash
PYTHONPATH=src python -m ugts_kc4 route \
  examples/safe_route_spatial_ledger/project.json \
  examples/safe_route_spatial_ledger/changed_ledger.json \
  N-ENTRANCE N-EXIT --policy wheelchair-reference --json
```

The changed map rejects `E-MAIN-EXIT` as blocked and selects the longer alternate path through
`N-RAMP` and `N-DOOR-ALT`.

## Minimal Python use

```python
from ugts_kc4 import (
    RouteGraph,
    safe_route_baseline_proposals,
    safe_route_demo_project,
)

project = safe_route_demo_project()
ledger = project.instantiate_ledger()
ledger.commit(safe_route_baseline_proposals(), project.make_verifier())
result = RouteGraph(ledger.map_state).shortest_path(
    "N-ENTRANCE",
    "N-EXIT",
    project.route_policy_map["wheelchair-reference"],
)
print(result.node_path)
print(ledger.state_hash())
```

## Authoring rule

A vision model or scanner never edits the map directly. It emits an `Observation` and `EventProposal`.
`ProposalVerifier` checks the capture profile, support, compatibility, relation interval, confidence, error,
uncertainty, metric scale and provenance before `SpatialLedger.commit` applies the patch.
