from __future__ import annotations

from dataclasses import replace
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from ugts_kc4.canonical import canonical_json, content_address, content_hash, normalize_json_value, write_json
from ugts_kc4.change import ChangePolicy, ProposalDelta, detect_changes, merge_proposal_deltas
from ugts_kc4.export import build_offline_html, map_to_geojson
from ugts_kc4.index import RayKeyProfile, SpatialHashIndex, VoxelKeyProfile
from ugts_kc4.ledger import LedgerEvent, SpatialLedger
from ugts_kc4.model import (
    CaptureProfile, Interval, MapEdge, MapNode, MapPatch, MapState, Observation,
    Pose3D, Uncertainty3D,
)
from ugts_kc4.project import SpatialEvidenceProject
from ugts_kc4.support import (
    AABBSupport, CompatibilityPolicy, ConeFrustumSupport, SphereSupport,
    SupportRegistry, support_from_dict,
)
from ugts_kc4.templates import (
    run_safe_route_demo, safe_route_baseline_proposals, safe_route_change_proposals,
    safe_route_demo_project,
)
from ugts_kc4.topology import RouteGraph, RoutePolicy, evaluate_route_edge, validate_route_topology
from ugts_kc4.verify import EventProposal, ProposalVerifier, VerificationPolicy, classify_guard
from ugts_kc4.version import __version__, __android_status__


def built_baseline() -> tuple[SpatialEvidenceProject, SpatialLedger]:
    project = safe_route_demo_project()
    ledger = project.instantiate_ledger()
    result = ledger.commit(safe_route_baseline_proposals(), project.make_verifier())
    if result.rejected:
        raise AssertionError(result.rejected)
    return project, ledger


class Canonical40Tests(unittest.TestCase):
    def test_version_identity(self):
        self.assertEqual(__version__, "4.0.0")
        self.assertIn("deferred", __android_status__)

    def test_integral_float_normalization(self):
        self.assertEqual(normalize_json_value({"x": 1.0}), {"x": 1})

    def test_negative_zero_normalization(self):
        self.assertEqual(normalize_json_value(-0.0), 0)

    def test_key_order_stable(self):
        self.assertEqual(canonical_json({"b": 2, "a": 1}), canonical_json({"a": 1, "b": 2}))

    def test_nan_rejected(self):
        with self.assertRaises(ValueError):
            canonical_json({"bad": math.nan})

    def test_content_address(self):
        address = content_address("obs", {"x": 1})
        self.assertTrue(address.startswith("obs:"))
        self.assertEqual(len(address.split(":")[1]), 24)

    def test_content_hash_changes(self):
        self.assertNotEqual(content_hash({"x": 1}), content_hash({"x": 2}))

    def test_write_json(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = write_json(Path(tmp) / "x.json", {"b": 2, "a": 1.0})
            self.assertEqual(json.loads(path.read_text()), {"a": 1, "b": 2})


class Model40Tests(unittest.TestCase):
    def test_interval_validation(self):
        with self.assertRaises(ValueError):
            Interval(2, 1)

    def test_interval_operations(self):
        interval = Interval(-1, 2)
        self.assertEqual(interval.width, 3)
        self.assertTrue(interval.contains(0))
        self.assertTrue(interval.overlaps(Interval(1.5, 3)))
        self.assertEqual(interval.expand(1), Interval(-2, 3))

    def test_pose_normalizes_quaternion(self):
        pose = Pose3D((1, 2, 3), (0, 0, 0, 2))
        self.assertEqual(pose.orientation, (0.0, 0.0, 0.0, 1.0))

    def test_zero_quaternion_rejected(self):
        with self.assertRaises(ValueError):
            Pose3D((0, 0, 0), (0, 0, 0, 0))

    def test_anchored_profile_requires_anchor(self):
        with self.assertRaises(ValueError):
            CaptureProfile("p", "d", "c", "h", scale_mode="anchored")

    def test_profile_metric_ready(self):
        profile = safe_route_demo_project().capture_profiles[0]
        self.assertTrue(profile.metric_ready)
        self.assertEqual(CaptureProfile.from_dict(profile.to_dict()).content_hash(), profile.content_hash())

    def test_uncertainty_bound_explicit(self):
        self.assertEqual(Uncertainty3D((1, 2, 3), max_error=0.4).position_bound(), 0.4)

    def test_uncertainty_bound_derived(self):
        value = Uncertainty3D((1, 0, 0))
        self.assertAlmostEqual(value.position_bound(), 3.0)

    def test_observation_roundtrip_and_interval(self):
        observation = safe_route_baseline_proposals()[0].observation
        clone = Observation.from_dict(observation.to_dict())
        self.assertEqual(clone.id, observation.id)
        self.assertEqual(clone.relation_interval, Interval(-0.01, 0.01))
        self.assertEqual(tuple(sorted(clone.compatibility_tags)), clone.compatibility_tags)

    def test_observation_bad_confidence(self):
        base = safe_route_baseline_proposals()[0].observation
        with self.assertRaises(ValueError):
            replace(base, confidence=1.1)

    def test_node_revision(self):
        node = MapNode("n", "waypoint", Pose3D())
        updated = node.with_revision(evidence_id="o1", lineage_label="l1", state={"status": "open"})
        self.assertEqual(updated.revision, 1)
        self.assertEqual(updated.evidence_ids, ("o1",))
        self.assertEqual(updated.lineage, ("l1",))

    def test_edge_self_loop_rejected(self):
        with self.assertRaises(ValueError):
            MapEdge("e", "n", "n", "route")

    def test_map_unknown_edge_node_rejected(self):
        node = MapNode("n", "waypoint", Pose3D())
        edge = MapEdge("e", "n", "missing", "route")
        with self.assertRaises(ValueError):
            MapState({"n": node}, {"e": edge})

    def test_map_hash_roundtrip(self):
        _, ledger = built_baseline()
        clone = MapState.from_dict(ledger.map_state.to_dict())
        self.assertEqual(clone.state_hash(), ledger.map_state.state_hash())

    def test_map_bounds(self):
        _, ledger = built_baseline()
        minimum, maximum = ledger.map_state.node_bounds()
        self.assertLessEqual(minimum[0], 0)
        self.assertGreaterEqual(maximum[0], 12)


class Support40Tests(unittest.TestCase):
    def test_sphere_support(self):
        support = SphereSupport("s", (0, 0, 0), 1)
        self.assertTrue(support.contains((1.1, 0, 0), 0.1))
        self.assertFalse(support.contains((1.2, 0, 0), 0.1))

    def test_aabb_support(self):
        support = AABBSupport("a", (-1, -1, -1), (1, 1, 1))
        self.assertTrue(support.contains((1.05, 0, 0), 0.1))
        self.assertFalse(support.contains((2, 0, 0)))

    def test_cone_support(self):
        support = ConeFrustumSupport("c", (0, 0, 0), (1, 0, 0), 0.1, 10, math.cos(math.radians(30)))
        self.assertTrue(support.contains((2, 0.2, 0)))
        self.assertFalse(support.contains((-2, 0, 0)))

    def test_support_roundtrip(self):
        support = AABBSupport("a", (-1, -1, -1), (1, 1, 1))
        clone = support_from_dict(support.to_dict())
        self.assertEqual(clone.to_dict(), support.to_dict())

    def test_registry_duplicate(self):
        registry = SupportRegistry({"a": AABBSupport("a", (-1, -1, -1), (1, 1, 1))})
        with self.assertRaises(ValueError):
            registry.add(AABBSupport("a", (-2, -2, -2), (2, 2, 2)))

    def test_registry_unknown(self):
        with self.assertRaises(KeyError):
            SupportRegistry().require("missing")

    def test_compatibility_required_tag(self):
        observation = safe_route_baseline_proposals()[0].observation
        result = CompatibilityPolicy("x", required_tags=("missing",)).evaluate(observation)
        self.assertFalse(result.compatible)
        self.assertTrue(result.reasons[0].startswith("missing_tags"))

    def test_compatibility_forbidden_tag(self):
        observation = safe_route_baseline_proposals()[0].observation
        tag = observation.compatibility_tags[0]
        self.assertFalse(CompatibilityPolicy("x", forbidden_tags=(tag,)).evaluate(observation).compatible)

    def test_compatibility_kind_dynamic_floor_semantic(self):
        observation = safe_route_baseline_proposals()[0].observation
        policy = CompatibilityPolicy(
            "x", allowed_kinds=(observation.kind,), allowed_dynamic_states=(observation.dynamic_state,),
            floor_id="F0", semantic_equals=(("target_id", observation.semantic["target_id"]),),
        )
        self.assertTrue(policy.evaluate(observation).compatible)


class Index40Tests(unittest.TestCase):
    def test_voxel_roundtrip_positive(self):
        profile = VoxelKeyProfile(cell_size=0.5)
        key = profile.encode((1.2, 2.2, 3.2))
        self.assertEqual(profile.decode_indices(key), (2, 4, 6, 0))

    def test_voxel_roundtrip_negative(self):
        profile = VoxelKeyProfile(cell_size=1)
        key = profile.encode((-0.1, -1.1, -2.1))
        self.assertEqual(profile.decode_indices(key)[:3], (-1, -2, -3))

    def test_voxel_range_rejected(self):
        profile = VoxelKeyProfile()
        with self.assertRaises(ValueError):
            profile.encode_indices(profile.max_index + 1, 0, 0)

    def test_voxel_level_bounds(self):
        profile = VoxelKeyProfile(cell_size=1)
        key = profile.encode((3.1, 0, 0), level=2)
        minimum, maximum = profile.cell_bounds(key)
        self.assertEqual(minimum[0], 0)
        self.assertEqual(maximum[0], 4)

    def test_voxel_unsigned_key(self):
        profile = VoxelKeyProfile()
        key = profile.encode((0, 0, 0))
        self.assertGreaterEqual(key, 0)
        self.assertLess(key, 1 << 64)

    def test_ray_pack_unpack(self):
        profile = RayKeyProfile()
        fields = (123, 456, 789, 100)
        self.assertEqual(profile.unpack(profile.pack_quantized(*fields)), fields)

    def test_ray_encode_decode(self):
        profile = RayKeyProfile(min_depth=0.1, max_depth=20)
        key = profile.encode((2, 1, 3), 5000)
        depth, azimuth, elevation, tick = profile.decode_center(key)
        self.assertGreater(depth, 0)
        self.assertTrue(-math.pi <= azimuth <= math.pi)
        self.assertTrue(-math.pi / 2 <= elevation <= math.pi / 2)
        self.assertEqual(tick, 5000 % 4096)

    def test_ray_depth_rejected(self):
        with self.assertRaises(ValueError):
            RayKeyProfile().encode((0.01, 0, 0), 0)

    def test_ray_quantization_steps(self):
        steps = RayKeyProfile().quantization_steps(10)
        self.assertGreater(steps["approx_depth_m"], 0)
        self.assertLess(steps["azimuth_rad"], 0.001)

    def test_spatial_index_query(self):
        index = SpatialHashIndex(VoxelKeyProfile(cell_size=1))
        index.insert("a", (0, 0, 0))
        index.insert("b", (2, 0, 0))
        self.assertEqual(index.query_sphere((0, 0, 0), 1.1), ["a"])

    def test_spatial_index_update_remove_rebuild(self):
        index = SpatialHashIndex(VoxelKeyProfile(cell_size=1))
        index.insert("a", (0, 0, 0))
        index.insert("a", (3, 0, 0))
        self.assertEqual(index.query_sphere((0, 0, 0), 1), [])
        index.remove("a")
        self.assertFalse(index.positions)
        index.rebuild((("x", (1, 1, 1)), ("y", (1.5, 1, 1))))
        self.assertEqual(index.query_sphere((1, 1, 1), 0.6), ["x", "y"])


class Verify40Tests(unittest.TestCase):
    def test_guard_inside(self):
        self.assertEqual(classify_guard(-1, 0.1, 0.05).status, "inside")

    def test_guard_outside(self):
        self.assertEqual(classify_guard(1, 0.1, 0.05).status, "outside")

    def test_guard_guard(self):
        self.assertEqual(classify_guard(0, 0.01, 0.05).status, "guard")

    def test_guard_crossing(self):
        self.assertEqual(classify_guard(0, 0.1, 0.05).status, "crossing")

    def test_guard_ambiguous(self):
        self.assertEqual(classify_guard(0.08, 0.05, 0.05).status, "ambiguous")

    def test_verification_accepts_demo(self):
        project = safe_route_demo_project()
        decision = project.make_verifier().verify(safe_route_baseline_proposals()[0], project.capture_profile_map)
        self.assertTrue(decision.accepted, decision.reasons)

    def test_verification_low_confidence(self):
        project = safe_route_demo_project()
        proposal = safe_route_baseline_proposals()[0]
        proposal = replace(proposal, observation=replace(proposal.observation, confidence=0.1))
        decision = project.make_verifier().verify(proposal, project.capture_profile_map)
        self.assertIn("confidence_below_floor", decision.reasons)

    def test_verification_unknown_support(self):
        project = safe_route_demo_project()
        proposal = safe_route_baseline_proposals()[0]
        proposal = replace(proposal, observation=replace(proposal.observation, support_id="missing"))
        self.assertIn("support_unknown", project.make_verifier().verify(proposal, project.capture_profile_map).reasons)

    def test_verification_metric_required(self):
        project = safe_route_demo_project()
        profile = replace(project.capture_profiles[0], scale_mode="relative", scale_anchor_id=None)
        proposal = next(item for item in safe_route_baseline_proposals() if item.observation.kind == "doorway")
        decision = project.make_verifier().verify(proposal, {profile.id: profile})
        self.assertIn("metric_scale_required", decision.reasons)

    def test_verification_source_hash_required(self):
        project = safe_route_demo_project()
        proposal = safe_route_baseline_proposals()[0]
        proposal = replace(proposal, observation=replace(proposal.observation, source_hash="unverified"))
        self.assertIn("source_hash_required", project.make_verifier().verify(proposal, project.capture_profile_map).reasons)

    def test_verification_compatibility_rejects(self):
        project = safe_route_demo_project()
        proposal = safe_route_baseline_proposals()[0]
        policy = CompatibilityPolicy("default", required_tags=("impossible",))
        verifier = ProposalVerifier(project.supports, {"default": policy}, project.verification_policy)
        self.assertFalse(verifier.verify(proposal, project.capture_profile_map).compatibility_ok)

    def test_verification_numeric_error(self):
        project = safe_route_demo_project()
        proposal = safe_route_baseline_proposals()[0]
        proposal = replace(proposal, observation=replace(proposal.observation, numeric_error=0.2))
        reasons = project.make_verifier().verify(proposal, project.capture_profile_map).reasons
        self.assertIn("numeric_error_exceeds_policy", reasons)
        self.assertIn("numeric_error_exceeds_event_margin", reasons)


class Topology40Tests(unittest.TestCase):
    def test_edge_admission_pass(self):
        _, ledger = built_baseline()
        edge = ledger.map_state.edges["E-ENTRANCE-JUNCTION"]
        self.assertTrue(evaluate_route_edge(edge, RoutePolicy()).admitted)

    def test_edge_blocked(self):
        _, ledger = built_baseline()
        edge = ledger.map_state.edges["E-MAIN-EXIT"]
        edge = replace(edge, state={"status": "blocked", "confidence": 1})
        self.assertIn("status_not_allowed:blocked", evaluate_route_edge(edge, RoutePolicy()).reasons)

    def test_edge_clearance(self):
        _, ledger = built_baseline()
        edge = ledger.map_state.edges["E-MAIN-EXIT"]
        edge = replace(edge, metrics={**edge.metrics, "clearance_m": 0.8})
        self.assertIn("clearance_below_minimum", evaluate_route_edge(edge, RoutePolicy()).reasons)

    def test_edge_slope(self):
        _, ledger = built_baseline()
        edge = ledger.map_state.edges["E-MAIN-EXIT"]
        edge = replace(edge, metrics={**edge.metrics, "slope_deg": 20})
        self.assertIn("slope_above_maximum", evaluate_route_edge(edge, RoutePolicy()).reasons)

    def test_baseline_route_uses_main_door(self):
        project, ledger = built_baseline()
        result = RouteGraph(ledger.map_state).shortest_path("N-ENTRANCE", "N-EXIT", project.route_policy_map["wheelchair-reference"])
        self.assertTrue(result.found)
        self.assertIn("N-DOOR-MAIN", result.node_path)

    def test_changed_route_uses_alternate(self):
        project, ledger = built_baseline()
        ledger.commit(safe_route_change_proposals(), project.make_verifier())
        result = RouteGraph(ledger.map_state).shortest_path("N-ENTRANCE", "N-EXIT", project.route_policy_map["wheelchair-reference"])
        self.assertIn("N-DOOR-ALT", result.node_path)
        self.assertNotIn("N-DOOR-MAIN", result.node_path)

    def test_no_route(self):
        project, ledger = built_baseline()
        for edge_id in list(ledger.map_state.edges):
            edge = ledger.map_state.edges[edge_id]
            ledger.map_state.edges[edge_id] = replace(edge, state={"status": "blocked", "confidence": 1})
        result = RouteGraph(ledger.map_state).shortest_path("N-ENTRANCE", "N-EXIT", project.route_policy_map["wheelchair-reference"])
        self.assertFalse(result.found)
        self.assertEqual(result.reason, "no_admissible_route")

    def test_components(self):
        project, ledger = built_baseline()
        components = RouteGraph(ledger.map_state).connected_components(project.route_policy_map["wheelchair-reference"])
        self.assertEqual(len(components), 2)  # route graph plus the unconnected cart object

    def test_topology_validator(self):
        portal = MapNode("p", "portal", Pose3D())
        issues = validate_route_topology(MapState({"p": portal}))
        self.assertIn("portal:p:isolated", issues)

    def test_route_same_node(self):
        _, ledger = built_baseline()
        result = RouteGraph(ledger.map_state).shortest_path("N-ENTRANCE", "N-ENTRANCE")
        self.assertEqual(result.cost, 0)


class Ledger40Tests(unittest.TestCase):
    def test_baseline_commit_count_and_order(self):
        project = safe_route_demo_project()
        ledger = project.instantiate_ledger()
        result = ledger.commit(reversed(safe_route_baseline_proposals()), project.make_verifier())
        self.assertEqual(result.accepted_count, 13)
        self.assertEqual([event.sequence for event in ledger.events], list(range(1, 14)))
        self.assertEqual([event.event_time for event in ledger.events], sorted(event.event_time for event in ledger.events))

    def test_state_hash_changes(self):
        project = safe_route_demo_project()
        ledger = project.instantiate_ledger()
        before = ledger.state_hash()
        ledger.commit((safe_route_baseline_proposals()[0],), project.make_verifier())
        self.assertNotEqual(before, ledger.state_hash())

    def test_duplicate_proposal_rejected(self):
        project = safe_route_demo_project()
        ledger = project.instantiate_ledger()
        proposal = safe_route_baseline_proposals()[0]
        ledger.commit((proposal,), project.make_verifier())
        result = ledger.commit((proposal,), project.make_verifier())
        self.assertIn("proposal_id_duplicate", result.rejected[0].reasons)

    def test_same_time_conflict_rejected(self):
        project, ledger = built_baseline()
        base = safe_route_change_proposals()[0]
        other = replace(
            base,
            id="proposal:conflict",
            patch=MapPatch("update_node_state", "N-DOOR-MAIN", {"status": "open"}),
            observation=replace(base.observation, id="obs:conflict"),
            priority=1,
        )
        result = ledger.commit((base, other), project.make_verifier())
        self.assertEqual(result.accepted_count, 1)
        self.assertTrue(any(reason.startswith("conflict_with") for reason in result.rejected[0].reasons))

    def test_patch_error_is_transactional(self):
        project = safe_route_demo_project()
        ledger = project.instantiate_ledger()
        proposal = safe_route_baseline_proposals()[0]
        bad = replace(proposal, id="bad", target_id="missing", patch=MapPatch("update_node_state", "missing", {"x": 1}))
        before = ledger.state_hash()
        result = ledger.commit((bad,), project.make_verifier())
        self.assertEqual(before, ledger.state_hash())
        self.assertTrue(result.rejected[0].reasons[0].startswith("patch_error"))

    def test_node_state_revision(self):
        project, ledger = built_baseline()
        before = ledger.map_state.nodes["N-DOOR-MAIN"].revision
        ledger.commit((safe_route_change_proposals()[0],), project.make_verifier())
        self.assertEqual(ledger.map_state.nodes["N-DOOR-MAIN"].revision, before + 1)

    def test_remove_node_removes_edges(self):
        project, ledger = built_baseline()
        base = safe_route_change_proposals()[0]
        proposal = replace(
            base, id="remove-junction", target_id="N-JUNCTION", event_time=20,
            patch=MapPatch("remove_node", "N-JUNCTION"),
            observation=replace(base.observation, id="obs:remove", kind="waypoint", pose=Pose3D((4, 0, 0))),
        )
        result = ledger.commit((proposal,), project.make_verifier())
        self.assertEqual(result.accepted_count, 1)
        self.assertNotIn("N-JUNCTION", ledger.map_state.nodes)
        self.assertFalse(any("N-JUNCTION" in {edge.source, edge.target} for edge in ledger.map_state.edges.values()))

    def test_checkpoint_restore(self):
        project, ledger = built_baseline()
        checkpoint = ledger.checkpoint()
        baseline_hash = ledger.state_hash()
        ledger.commit(safe_route_change_proposals(), project.make_verifier())
        self.assertNotEqual(ledger.state_hash(), baseline_hash)
        ledger.restore(checkpoint)
        self.assertEqual(ledger.state_hash(), baseline_hash)
        self.assertEqual(ledger.sequence, 13)

    def test_event_pre_post_hash_chain(self):
        _, ledger = built_baseline()
        for left, right in zip(ledger.events, ledger.events[1:]):
            self.assertEqual(left.post_hash, right.pre_hash)

    def test_replay_success(self):
        project, ledger = built_baseline()
        ledger.commit(safe_route_change_proposals(), project.make_verifier())
        replay = SpatialLedger.replay(project.initial_map, ledger.events, project.capture_profile_map)
        self.assertTrue(replay.success)
        self.assertEqual(replay.state.state_hash(), ledger.state_hash())

    def test_replay_pre_hash_mismatch(self):
        project, ledger = built_baseline()
        first = ledger.events[0]
        bad = replace(first, pre_hash="0" * 64)
        replay = SpatialLedger.replay(project.initial_map, (bad,))
        self.assertFalse(replay.success)
        self.assertEqual(replay.reason, "pre_hash_mismatch")

    def test_write_load(self):
        _, ledger = built_baseline()
        with tempfile.TemporaryDirectory() as tmp:
            path = ledger.write(Path(tmp) / "ledger.json")
            clone = SpatialLedger.load(path)
            self.assertEqual(clone.state_hash(), ledger.state_hash())
            self.assertEqual(clone.event_stream_hash(), ledger.event_stream_hash())

    def test_bad_serialized_hash_rejected(self):
        _, ledger = built_baseline()
        value = ledger.to_dict()
        value["state_hash"] = "bad"
        with self.assertRaises(ValueError):
            SpatialLedger.from_dict(value)

    def test_append_evidence_patch(self):
        project, ledger = built_baseline()
        base = safe_route_change_proposals()[0]
        proposal = replace(
            base, id="append-evidence", target_id="N-ENTRANCE", event_time=30,
            patch=MapPatch("append_node_evidence", "N-ENTRANCE", {"evidence_ids": ["manual:note"]}),
            observation=replace(base.observation, id="obs:append", kind="waypoint", pose=Pose3D((0, 0, 0))),
        )
        ledger.commit((proposal,), project.make_verifier())
        self.assertIn("manual:note", ledger.map_state.nodes["N-ENTRANCE"].evidence_ids)

    def test_upsert_replacement_preserves_evidence(self):
        project, ledger = built_baseline()
        node = ledger.map_state.nodes["N-ENTRANCE"]
        replacement = replace(node, semantic={"label": "New label"}, evidence_ids=())
        base = safe_route_change_proposals()[0]
        proposal = replace(
            base, id="replace-node", target_id=node.id, event_time=31,
            patch=MapPatch("upsert_node", node.id, {"node": replacement.to_dict()}),
            observation=replace(base.observation, id="obs:replace", kind="waypoint", pose=node.pose),
        )
        old_evidence = set(node.evidence_ids)
        ledger.commit((proposal,), project.make_verifier())
        self.assertTrue(old_evidence.issubset(set(ledger.map_state.nodes[node.id].evidence_ids)))

    def test_remove_unknown_patch_rejected(self):
        project = safe_route_demo_project()
        ledger = project.instantiate_ledger()
        base = safe_route_baseline_proposals()[0]
        proposal = replace(base, id="remove-missing", target_id="missing", patch=MapPatch("remove_node", "missing"))
        result = ledger.commit((proposal,), project.make_verifier())
        self.assertEqual(result.rejected_count, 1)


class Change40Tests(unittest.TestCase):
    def test_detect_demo_changes(self):
        project, ledger = built_baseline()
        baseline = ledger.map_state.clone()
        ledger.commit(safe_route_change_proposals(), project.make_verifier())
        changes = detect_changes(baseline, ledger.map_state)
        kinds = {item.kind for item in changes}
        self.assertEqual(len(changes), 4)
        self.assertTrue({"moved", "state_changed", "added"}.issubset(kinds))
        self.assertTrue(all(item.verified for item in changes))

    def test_movement_ambiguous(self):
        node = MapNode("n", "object", Pose3D((0, 0, 0)), Uncertainty3D(max_error=0.2))
        moved = replace(node, pose=Pose3D((0.15, 0, 0)))
        changes = detect_changes(MapState({"n": node}), MapState({"n": moved}), ChangePolicy(movement_threshold_m=0.1))
        self.assertEqual(changes[0].kind, "movement_ambiguous")
        self.assertFalse(changes[0].verified)

    def test_removed_node(self):
        node = MapNode("n", "object", Pose3D(), state={"confidence": 1})
        changes = detect_changes(MapState({"n": node}), MapState())
        self.assertEqual(changes[0].kind, "removed")

    def test_metric_change(self):
        a = MapNode("a", "waypoint", Pose3D())
        b = MapNode("b", "waypoint", Pose3D((1, 0, 0)))
        e1 = MapEdge("e", "a", "b", "route", metrics={"length_m": 1, "clearance_m": 1.0}, state={"status": "passable", "confidence": 1})
        e2 = replace(e1, metrics={"length_m": 1, "clearance_m": 0.8})
        changes = detect_changes(MapState({"a": a, "b": b}, {"e": e1}), MapState({"a": a, "b": b}, {"e": e2}))
        self.assertTrue(any(item.kind == "metric_changed" for item in changes))

    def test_delta_content_hash_roundtrip(self):
        project = safe_route_demo_project()
        delta = ProposalDelta(project.initial_map.state_hash(), "phone-A", safe_route_baseline_proposals()[:2])
        clone = ProposalDelta.from_dict(delta.to_dict())
        self.assertEqual(clone.content_hash(), delta.content_hash())

    def test_delta_bad_hash(self):
        project = safe_route_demo_project()
        delta = ProposalDelta(project.initial_map.state_hash(), "phone-A", safe_route_baseline_proposals()[:1]).to_dict()
        delta["content_hash"] = "bad"
        with self.assertRaises(ValueError):
            ProposalDelta.from_dict(delta)

    def test_merge_base_mismatch(self):
        p = safe_route_baseline_proposals()[0]
        with self.assertRaises(ValueError):
            merge_proposal_deltas((ProposalDelta("a", "A", (p,)), ProposalDelta("b", "B", (p,))))

    def test_merge_deterministic(self):
        proposals = safe_route_baseline_proposals()[:4]
        result = merge_proposal_deltas((ProposalDelta("base", "B", proposals[2:]), ProposalDelta("base", "A", proposals[:2])))
        self.assertEqual([p.id for p in result.proposals], [p.id for p in sorted(proposals, key=EventProposal.sort_key)])

    def test_merge_patch_conflict(self):
        base = safe_route_change_proposals()[0]
        other = replace(base, id="other", source="phone-C", priority=1, patch=MapPatch("update_node_state", base.target_id, {"status": "open"}), observation=replace(base.observation, id="other-obs"))
        result = merge_proposal_deltas((ProposalDelta("base", "B", (base,)), ProposalDelta("base", "C", (other,))))
        self.assertEqual(len(result.proposals), 1)
        self.assertEqual(result.conflicts[0].reason, "same_time_patch_conflict")

    def test_merge_duplicate_identical_dedup(self):
        proposal = safe_route_baseline_proposals()[0]
        result = merge_proposal_deltas((ProposalDelta("base", "A", (proposal,)), ProposalDelta("base", "B", (proposal,))))
        self.assertEqual(len(result.proposals), 1)
        self.assertFalse(result.conflicts)


class ProjectExportCLI40Tests(unittest.TestCase):
    def test_project_validate(self):
        report = safe_route_demo_project().validate()
        self.assertTrue(report.passed, report.issues)
        self.assertEqual(report.metrics["android_implementation_status"], "deferred")

    def test_project_roundtrip(self):
        project = safe_route_demo_project()
        clone = SpatialEvidenceProject.from_dict(project.to_dict())
        self.assertEqual(clone.content_hash(), project.content_hash())

    def test_project_file_roundtrip(self):
        with tempfile.TemporaryDirectory() as tmp:
            project = safe_route_demo_project()
            path = project.write(Path(tmp) / "project.json")
            self.assertEqual(SpatialEvidenceProject.load(path).content_hash(), project.content_hash())

    def test_project_missing_default_policy(self):
        project = safe_route_demo_project()
        project.compatibility_policies = (CompatibilityPolicy("other"),)
        self.assertFalse(project.validate().passed)

    def test_geojson_counts(self):
        _, ledger = built_baseline()
        geo = map_to_geojson(ledger.map_state)
        self.assertEqual(len(geo["features"]), len(ledger.map_state.nodes) + len(ledger.map_state.edges))
        self.assertEqual(geo["type"], "FeatureCollection")

    def test_html_is_self_contained(self):
        project, ledger = built_baseline()
        with tempfile.TemporaryDirectory() as tmp:
            path = build_offline_html(project, ledger, Path(tmp) / "report.html")
            text = path.read_text(encoding="utf-8")
            self.assertIn("ugts-data", text)
            self.assertNotIn("https://", text)
            self.assertNotIn("<script src=", text)

    def test_demo_outputs(self):
        with tempfile.TemporaryDirectory() as tmp:
            summary = run_safe_route_demo(tmp)
            self.assertTrue(summary["replay_success"])
            self.assertEqual(summary["total_events"], 17)
            self.assertTrue((Path(tmp) / "offline_report.html").exists())

    def _run_cli(self, *args: str) -> subprocess.CompletedProcess[str]:
        env = dict(os.environ, PYTHONPATH=str(SRC))
        return subprocess.run([sys.executable, "-m", "ugts_kc4", *args], cwd=ROOT, env=env, text=True, capture_output=True)

    def test_cli_info(self):
        result = self._run_cli("info")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("UGTS-KC 4.0", result.stdout)
        self.assertIn("deferred", result.stdout)

    def test_cli_android_status(self):
        result = self._run_cli("android-status")
        self.assertEqual(result.returncode, 0)
        self.assertIn("does not implement", result.stdout)
        self.assertIn("3.9.1", result.stdout)

    def test_cli_validate(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = safe_route_demo_project().write(Path(tmp) / "project.json")
            result = self._run_cli("validate", str(path), "--json")
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertTrue(json.loads(result.stdout)["passed"])

    def test_cli_demo(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = self._run_cli("demo", tmp, "--json")
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(result.stdout)["total_events"], 17)

    def test_cli_route(self):
        with tempfile.TemporaryDirectory() as tmp:
            run_safe_route_demo(tmp)
            result = self._run_cli("route", str(Path(tmp) / "project.json"), str(Path(tmp) / "changed_ledger.json"), "N-ENTRANCE", "N-EXIT", "--json")
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("N-DOOR-ALT", json.loads(result.stdout)["node_path"])

    def test_schema_file_exists_and_has_id(self):
        path = ROOT / "spec" / "spatial_evidence_schema_4_0.json"
        self.assertTrue(path.exists())
        data = json.loads(path.read_text(encoding="utf-8"))
        self.assertEqual(data["$id"], "ugts-kc-spatial-evidence-project-4.0")


if __name__ == "__main__":
    unittest.main()
