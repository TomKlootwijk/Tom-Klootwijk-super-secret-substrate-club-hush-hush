# SafeRoute + DamageDelta spatial evidence vertical slice

This directory is generated from `ugts_kc4.templates.run_safe_route_demo` and contains one complete
project-to-ledger-to-report workflow.

- `project.json` - editable UGTS-KC 4.0 project.
- `baseline_ledger.json` - verified baseline map and checkpoint.
- `changed_ledger.json` - baseline plus blockage, moved cart and added obstacle events.
- `route_results.json` - accessible route before and after the blockage.
- `change_candidates.json` - four verified repeat-scan changes.
- `changed_map.geojson` - downstream GIS projection.
- `offline_report.html` - self-contained field report.
- `demo_summary.json` - deterministic counts and hashes.

Rebuild:

```bash
PYTHONPATH=src python -m ugts_kc4 demo examples/safe_route_spatial_ledger --json
```

The example is synthetic. It demonstrates data contracts and deterministic behavior, not a certified
building survey or emergency-navigation product.
