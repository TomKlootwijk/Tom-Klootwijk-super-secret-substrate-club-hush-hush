UGTOMS DOMAIN CARTRIDGES - BATCH 01
Release date: 30 August 2026

Order delivered:
1. UGTOMS REACT 1.0 - Typed Reaction, Conservation, Conditions and Evidence Cartridge
2. UGTOMS SONORA 1.0 - Pitch-Class, Rhythm, Voice-Leading and Executable Notation Cartridge
3. UGTOMS FORGE 1.0 - Parts, Interfaces, Tolerances, Assembly and Inspection Cartridge

Canonical identities:
- ugtoms.domain.react@1.0.0
- ugtoms.domain.sonora@1.0.0
- ugtoms.domain.forge@1.0.0

Evidence boundary:
These are formal engineering specifications grounded in the supplied UGTOMS/UGTS source architecture. The specialist chemistry, music and fabrication models are visibly identified as engineering-derived. Laboratory, cultural, standards, regulatory, structural and production validation are not claimed.

Each PDF includes:
- source register and evidence discipline
- shared open modular cartridge ABI
- typed domain state and operator order
- authority-chain mapping
- capability and certificate ladders
- deterministic demonstration
- 48-mechanism component-local catalog
- claims ledger, non-claims and kill criteria
- implementation sequence
