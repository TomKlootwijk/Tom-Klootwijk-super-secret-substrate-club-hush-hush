file(REMOVE_RECURSE
  "CMakeFiles/ugts_go19_smoke.dir/link.d"
  "CMakeFiles/ugts_go19_smoke.dir/src/main.cpp.o"
  "CMakeFiles/ugts_go19_smoke.dir/src/main.cpp.o.d"
  "ugts_go19_smoke"
  "ugts_go19_smoke.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/ugts_go19_smoke.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
