# Empty compiler generated dependencies file for ugts_go19_smoke.
# This may be replaced when dependencies are built.
