file(REMOVE_RECURSE
  "CMakeFiles/ugts_go_core.dir/src/go_state.cpp.o"
  "CMakeFiles/ugts_go_core.dir/src/go_state.cpp.o.d"
  "libugts_go_core.a"
  "libugts_go_core.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/ugts_go_core.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
