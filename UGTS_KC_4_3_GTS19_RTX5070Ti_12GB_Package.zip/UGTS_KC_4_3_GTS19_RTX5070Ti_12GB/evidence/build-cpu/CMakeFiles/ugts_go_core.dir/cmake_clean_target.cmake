file(REMOVE_RECURSE
  "libugts_go_core.a"
)
