# CMAKE generated file: DO NOT EDIT!
# Timestamp file for compiler generated dependencies management for ugts_go_core.
