# Empty compiler generated dependencies file for ugts_go_core.
# This may be replaced when dependencies are built.
