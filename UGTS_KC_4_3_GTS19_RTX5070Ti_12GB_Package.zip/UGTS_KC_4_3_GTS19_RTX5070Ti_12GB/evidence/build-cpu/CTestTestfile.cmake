# CMake generated Testfile for 
# Source directory: /mnt/data/UGTS_KC_4_3_GTS19_RTX5070Ti_12GB/cpp
# Build directory: /mnt/data/UGTS_KC_4_3_GTS19_RTX5070Ti_12GB/evidence/build-cpu
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test([=[ugts_go19_smoke]=] "/mnt/data/UGTS_KC_4_3_GTS19_RTX5070Ti_12GB/evidence/build-cpu/ugts_go19_smoke")
set_tests_properties([=[ugts_go19_smoke]=] PROPERTIES  _BACKTRACE_TRIPLES "/mnt/data/UGTS_KC_4_3_GTS19_RTX5070Ti_12GB/cpp/CMakeLists.txt;20;add_test;/mnt/data/UGTS_KC_4_3_GTS19_RTX5070Ti_12GB/cpp/CMakeLists.txt;0;")
