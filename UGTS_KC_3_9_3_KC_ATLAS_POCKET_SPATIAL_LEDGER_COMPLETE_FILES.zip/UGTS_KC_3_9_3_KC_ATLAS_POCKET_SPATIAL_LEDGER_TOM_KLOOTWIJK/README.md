# UGTS-KC 3.9.3 - KC Atlas Pocket Spatial Ledger

**Spatial evidence, accessibility, repeat-scan change and high-impact application profiles**

UGTS-KC 3.9.3 is an additive expansion of the attached working 3.9.2 K-Kij-T / Grove package. It keeps the complete retained geometry, topology, scene, 2D/3D runtime, browser export and Android Grove baseline, then adds a query-first spatial evidence and change-ledger substrate.

The 3.9.3 authority chain is:

```text
capture profile + typed observations
-> finite spatial support
-> semantic / route / policy compatibility
-> confidence + numerical-error guard
-> verified proposal
-> deterministic event commit
-> stable node / edge / measurement patch
-> lineage + checkpoint + replay
-> route, change and publication queries
```

A perception model, camera adapter or future Android capture application may propose observations. It does not directly mutate the map.

## What 3.9.3 adds

- A versioned spatial-ledger schema with stable map-node, route-edge, capture and observation identity.
- Interval-valued measurements, pose uncertainty and explicit support volumes.
- Deterministic proposal verification, conflict handling, event commit, checkpoints and hash-verified replay.
- Constrained route queries for walking and accessibility policies.
- Repeat-scan comparison that distinguishes confirmed change, review, within-tolerance, added and removed records.
- Seven content-addressed application profiles: SafeRoute, RescueTwin, DamageDelta, PipeGraph, FitScan, HeritageLedger and EcoScan.
- Privacy-aware publication views and self-contained offline HTML evidence bundles.
- A future perception-adapter contract and a finite SCLP-derived 64-bit local observation key.
- 60 cataloged mechanisms, M530-M589, bringing the combined mechanism namespace to M589.
- 71 new tests; the retained-plus-new Python suite contains 347 passing tests.

## Reference demonstration

`examples/kc_atlas_spatial_ledger/` is a synthetic SafeRoute + DamageDelta vertical slice. It contains:

- an accessible baseline route;
- a repeat scan with a blocked passage, beam-displacement candidate and doorway remeasurement;
- three deterministically committed map events;
- hash-verified replay;
- an uncertainty-aware change report; and
- a self-contained, no-network HTML evidence bundle.

```bash
PYTHONPATH=src python -m ugts_kc3 demo-ledger \
  examples/kc_atlas_spatial_ledger

PYTHONPATH=src python -m ugts_kc3 validate-ledger \
  examples/kc_atlas_spatial_ledger/baseline-ledger.json \
  --profile safe-route

PYTHONPATH=src python -m ugts_kc3 route-ledger \
  examples/kc_atlas_spatial_ledger/baseline-ledger.json \
  entrance-main exit-north --mode wheelchair \
  --minimum-clearance 0.80 --maximum-slope 8 --no-stairs --json
```

## Android decision

The new native Android spatial-capture application is deliberately postponed until the substrate contract is complete. The attached working Grove Android project and its supplied APK are preserved under `android/UGTSKCKKijTGrove/` as the implementation baseline. They were not modified, rebuilt, installed or profiled as part of 3.9.3.

The future app is required to translate camera/IMU/model output into `FrameObservationPacket` records and submit event proposals through the same verifier. See `spec/ANDROID_SPATIAL_LEDGER_BRIDGE_3_9_3.md`.

## Compatibility

- Existing imports under `ugts_kc` and `ugts_kc3` remain available.
- The existing 2D HTML5 and 3D/Grove workflows remain in place.
- The Python distribution name remains `ugts-kc-signature` for compatibility, while the runtime edition is KC Atlas 3.9.3.
- Spatial-ledger records use the new schema `ugts-kc-spatial-ledger-3.9.3` and are additive.
- Runtime `EventProposal` remains the retained game/runtime type; the spatial-ledger proposal is exported as `SpatialEventProposal` at package root.

## Package map

- `src/ugts_kc3/spatialledger.py` - spatial evidence, event authority, routes, change and publication.
- `src/ugts_kc3/spatialkey.py` - finite 64-bit local observation keys and prefix bounds.
- `src/ugts_kc3/ledgerprofiles.py` - seven versioned application profiles.
- `src/ugts_kc3/ledgerexport.py` - offline HTML evidence bundles and manifests.
- `src/ugts_kc3/templatesledger.py` - synthetic reference ledgers and demonstration.
- `spec/` - schemas, contracts and mechanism catalogs through M589.
- `docs/` - release, migration, application and Android-postponement guidance.
- `report/` - the 3.9.3 PDF/DOCX report plus retained legacy reports.
- `tests/` - 347 retained-plus-new unit tests.
- `validation/` - captured compile, test, schema, CLI, package and manifest evidence.
- `android/UGTSKCKKijTGrove/` - retained 3.9.2 native Android baseline and supplied APK.

## Evidence boundary

The bundled implementation establishes internal consistency of the records, event authority, route queries, change logic, exports and deterministic replay in the reference environment. It does not establish monocular metric accuracy, structural safety, medical fitness, emergency-operational certification, legal chain of custody, or measured performance on a physical phone. Application-specific calibration, independent validation, privacy review and named-device benchmarks remain required.
