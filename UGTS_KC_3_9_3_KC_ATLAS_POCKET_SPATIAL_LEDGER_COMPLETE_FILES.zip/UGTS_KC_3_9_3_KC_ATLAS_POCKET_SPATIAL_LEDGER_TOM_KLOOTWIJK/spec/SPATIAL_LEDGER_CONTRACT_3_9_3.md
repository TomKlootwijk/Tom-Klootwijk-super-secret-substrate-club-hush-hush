# Spatial ledger contract - UGTS-KC 3.9.3

## Authoritative object

`SpatialLedger` is a versioned document containing metadata, capture profiles, observations, stable map nodes, route edges, committed events and checkpoints.

```text
L = (metadata, captures, observations, nodes, route_edges, events, checkpoints)
```

Coordinates are not identity. Stable IDs, evidence references and lineage survive remeasurement and derived-geometry replacement.

## Core invariants

1. All IDs are unique within their record class.
2. Every observation references an existing capture.
3. Every route edge references two existing, distinct nodes.
4. Every evidence ID resolves to an observation.
5. Measurement value lies in its closed uncertainty interval.
6. Stored observation provenance hashes verify.
7. Accepted events have monotonic sequence numbers and valid pre/post hashes.
8. Ledger state hash excludes event history so replay and direct construction can compare authoritative state.
9. Unknown, blocked, restricted and hazard route states are not passable by default.
10. Raw media retention and privacy mode may not contradict each other.

## Verified proposal rule

```text
verified = support_ok
        and compatibility_ok
        and guard_status in accepted_statuses
        and confidence >= confidence_floor
        and numeric_error <= event_margin
```

A proposal contains a finite patch over nodes, route edges, metadata or observations. Deterministic ordering and conflict rejection occur before mutation. Accepted patches append lineage and state hashes.

## Error boundary

A rendered mesh, depth map or semantic label is a derived observation. It becomes authoritative only to the extent expressed by its stable target ID, uncertainty, source evidence and accepted event policy.
