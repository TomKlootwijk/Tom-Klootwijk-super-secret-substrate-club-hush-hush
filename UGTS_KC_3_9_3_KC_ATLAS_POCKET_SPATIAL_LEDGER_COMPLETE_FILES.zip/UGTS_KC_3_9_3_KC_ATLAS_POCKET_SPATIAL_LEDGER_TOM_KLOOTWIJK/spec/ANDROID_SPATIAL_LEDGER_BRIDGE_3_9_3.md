# Android spatial-ledger bridge contract - UGTS-KC 3.9.3

## Status

Specified for future implementation. No 3.9.3 Android capture APK is claimed.

## Adapter boundary

Android camera, IMU and model code must emit a `FrameObservationPacket` with:

- packet ID, capture ID and timestamp;
- frame IDs;
- model/calibration hashes;
- semantic class and optional target ID;
- pose estimate and uncertainty;
- finite support volume;
- confidence, numeric error and event margin;
- attributes and packet content hash.

The adapter may not write map nodes, edges or measurements directly. The packet converts to an `Observation`, then a policy layer creates a `SpatialEventProposal` for verifier/commit.

## Deterministic fixture requirement

Before live capture, the Android implementation must load a checked fixture packet sequence, reproduce Python-oracle acceptance/rejection decisions and produce the same canonical final ledger hash under the selected numerical profile.

## Retained baseline

`android/UGTSKCKKijTGrove/` is the supplied 3.9.2 native baseline. It is retained as provenance and as a source of lifecycle, input, rendering, device-profile and packaging patterns. Its scene/game loop is not automatically a camera-evidence pipeline.
