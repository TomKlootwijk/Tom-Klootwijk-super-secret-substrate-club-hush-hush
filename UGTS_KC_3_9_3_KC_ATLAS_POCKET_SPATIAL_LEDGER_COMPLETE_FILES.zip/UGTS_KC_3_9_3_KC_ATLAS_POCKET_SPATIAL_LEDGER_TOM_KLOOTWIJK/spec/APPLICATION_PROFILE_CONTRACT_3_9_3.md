# Application profile contract - UGTS-KC 3.9.3

Each profile is a content-addressed governance definition. It declares:

- profile ID and version;
- purpose;
- required node and route-edge classes;
- required measurements;
- minimum confidence;
- privacy mode;
- safety boundary;
- forbidden claims; and
- export expectations.

The shipped profiles are:

| Profile | Primary result | Mandatory boundary |
|---|---|---|
| SafeRoute | Accessible/evacuation route graph | Not a guarantee that a real route is safe or legally compliant. |
| RescueTwin | Mergeable offline incident map | Not structural-clearance or responder-safety certification. |
| DamageDelta | Repeat-scan change candidates | Not an engineering diagnosis. |
| PipeGraph | Utility centerline/junction graph | Not leak or pressure certification without additional sensors/models. |
| FitScan | Clinical/assistive pre-capture | Not diagnosis, prescription or fabrication authority. |
| HeritageLedger | Integrity-checkable documentation | Hashes are not legal chain of custody or ownership proof. |
| EcoScan | Repeated ecological geometry | Not species, yield or environmental-compliance certification. |

Readiness validation checks only the machine-readable contract. External standards, calibration and professional judgment remain separate.
