# Android spatial-ledger implementation decision - 3.9.3

## Decision

The native phone capture application is postponed until after the spatial-ledger substrate is frozen and validated. This prevents camera/model output formats from becoming accidental map authority.

## Retained working baseline

The attached 3.9.2 Grove project is preserved under `android/UGTSKCKKijTGrove/`, including the supplied POCO X7 Pro release APK artifact. Version 3.9.3 does not modify the project, rebuild the APK, sign a new package, install it, or claim a physical-device measurement.

## Required future architecture

```text
Android camera + optional IMU
-> frame/keyframe manager
-> on-device or delegated perception model
-> FrameObservationPacket
-> local support + compatibility + error/confidence guard
-> verified SpatialEventProposal
-> SpatialLedger commit + checkpoint
-> offline HTML / JSON evidence bundle
```

The first Android milestone should ingest prerecorded fixture packets before live camera capture. The same fixture must produce the same ordered proposal decisions and ledger hash as the Python oracle.

## Required future evidence

- Exact device model, Android build and SoC/GPU/NPU identifiers.
- Camera stream mode, resolution, frame cadence and stabilization state.
- Calibration and metric-scale protocol.
- Model file hash, quantization profile and delegate/backend.
- p50/p95/p99 capture-to-proposal and proposal-to-commit latency.
- Memory, thermal throttling, power and sustained-duration results.
- False/missed event and measurement-error results against an independent reference.
- Privacy behavior for raw frames, faces, documents and location data.

Until those gates pass, output is a candidate evidence map, not a certified safety, medical or engineering assessment.
