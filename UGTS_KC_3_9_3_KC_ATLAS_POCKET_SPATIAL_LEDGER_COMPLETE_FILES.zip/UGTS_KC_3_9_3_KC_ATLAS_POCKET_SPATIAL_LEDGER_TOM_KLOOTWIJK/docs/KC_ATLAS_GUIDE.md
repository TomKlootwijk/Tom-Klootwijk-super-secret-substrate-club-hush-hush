# KC Atlas guide

## 1. Create or load a ledger

```bash
PYTHONPATH=src python -m ugts_kc3 new-ledger work/site-a.json \
  --title "Site A" --author "field-team"
PYTHONPATH=src python -m ugts_kc3 validate-ledger work/site-a.json
```

## 2. Evidence records

A capture profile declares the device/model/calibration/privacy context. An observation carries semantic class, finite support, pose uncertainty, confidence, numeric error, event margin, source frames and a provenance hash.

The observation hash covers its content. The ledger validator rejects a mismatched stored provenance hash.

## 3. Authoritative change

A spatial proposal must pass:

```text
support_ok
and compatibility_ok
and guard_status in accepted_statuses
and confidence >= confidence_floor
and numeric_error <= event_margin
```

Verified proposals are sorted by event time, descending priority, source and proposal ID. Conflicting same-time patches receive explicit rejection records. Accepted events carry sequence number plus pre/post state hashes.

## 4. Route queries

```bash
PYTHONPATH=src python -m ugts_kc3 route-ledger ledger.json A B \
  --mode wheelchair --minimum-clearance 0.80 \
  --maximum-slope 8 --no-stairs --json
```

The route query evaluates explicit edge status, allowed mode, confidence, clearance interval, slope interval and route-class exclusions. Unknown or low-confidence edges are not silently treated as passable.

## 5. Repeat-scan comparison

```bash
PYTHONPATH=src python -m ugts_kc3 diff-ledger baseline.json current.json \
  --output change-report.json
```

Stable IDs are compared before coordinates. Interval overlap and measurement policy determine whether a difference is confirmed, within tolerance or requires review.

## 6. Application profiles

```bash
PYTHONPATH=src python -m ugts_kc3 validate-ledger ledger.json \
  --profile safe-route
```

Profiles define required node/edge types, measurements, confidence, privacy rules, safety boundary and forbidden claims. A readiness pass means the checked data meets that profile contract; it is not an external certification.

## 7. Publication

Publication policies can remove raw source URIs, pseudonymize authors and round coordinates. The exported evidence bundle contains canonical JSON, optional change report, one offline HTML report and a SHA-256 manifest.
