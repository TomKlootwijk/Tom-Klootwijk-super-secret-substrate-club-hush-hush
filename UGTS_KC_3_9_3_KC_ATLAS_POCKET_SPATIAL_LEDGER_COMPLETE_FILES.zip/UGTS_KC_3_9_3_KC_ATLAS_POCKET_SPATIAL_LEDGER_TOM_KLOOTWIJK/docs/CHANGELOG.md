# Changelog

## 3.9.3 - KC Atlas Pocket Spatial Ledger Edition

- Completes the substrate expansion before development of a new phone-native capture application.
- Adds a finite spatial evidence ledger for observations, stable map nodes, route edges, uncertainty intervals, guarded event proposals, deterministic commit, checkpoints and hash-verified replay.
- Adds SafeRoute, RescueTwin, DamageDelta, PipeGraph, FitScan, HeritageLedger and EcoScan as content-addressed application profiles with explicit readiness and evidence boundaries.
- Adds repeat-scan change classification, traversability routing, publication redaction, a self-contained offline evidence bundle and a SCLP-derived 64-bit local spatial key.
- Adds frame-observation packet and Android bridge contracts while deliberately postponing camera/IMU/model integration and device-specific performance claims.
- Retains the requester-supplied 3.9.2 Grove Android source and APK unchanged as the future native baseline.
- Adds M530-M589 and repairs the supplied machine-readable 3.9.2 catalog closure at M529, taking the combined engineering namespace to M589.
- Adds 71 tests; the complete retained-plus-new suite now runs 347 tests.

## 3.9.2 - K-Kij-T / Grove Native Android Edition

- Retains the 3.9.1 mobile-3D and native Android foundation.
- Adds the Grove game-feel controller, GLES post-composite path, shockwave/flash/bloom response, device tuning and KC3D392 assets.
- Includes a native-only Android target; HTML5 and procedural-content generation remain outside this release.

## 3.9.1 - Tom Klootwijk Signature Native Android and Mobile-3D Edition

- Preserves the complete 3.9 vector/2D/browser release and all retained APIs.
- Adds a serializable mobile-3D project schema, primitive meshes and deterministic arcade oracle.
- Adds POCO X7 Pro 12 GB, high, balanced and compatibility Android profiles.
- Adds ordered render tiers plus sustained FPS/thermal degradation and recovery.
- Adds KC3D391 binary compilation, inspection and independent C++ parsing.
- Adds a pure NativeActivity C++20 Android source project with EGL/OpenGL ES 3.0,
  dynamic resolution, touch/gamepad/keyboard input and high-refresh requests.
- Adds a 66-node signature arena, glTF output and Android source-generation CLI.
- Adds M390-M449, taking the extended engineering catalog to M449.
- Adds 51 tests; the complete package now runs 276 tests.
- Defines Vulkan and 4D as explicit future boundaries rather than implemented features.

## 3.9.0 - KC Elizabeth Vector Game-Creation Edition

- Preserves the complete KC 3.0 package and its 117 passing tests.
- Adds M330-M389, taking the combined engineering catalog to M389.
- Adds serializable vector paths, gradients, primitive factories, adaptive flattening and deterministic SVG export.
- Adds a dependency-free 2D collision and spatial-hash layer.
- Adds action-based keyboard, pointer, gamepad and touch input plus record/replay frames.
- Adds keyframe animation, easing, loops, ping-pong, crossfades and state machines.
- Adds layered tilemaps, ASCII import, A* pathfinding, flood search and merged collision boxes.
- Adds procedural sound cues, ADSR envelopes, note parsing and beat sequences.
- Adds a deterministic entity/component game world with fixed-step movement, collision lifecycle events, player dash, health, hazards, collectibles, bounds, cameras, snapshots, state hashes and saves.
- Adds a validated game-project model and schema shared across Python and browser output.
- Adds a self-contained Canvas/Web Audio HTML5 runtime with keyboard, gamepad, touch, HUD, particles, pause/restart, save/load, mute and diagnostics.
- Adds a CLI for project creation, validation, headless simulation, browser builds and SVG export.
- Adds Elizabeth's Vector Garden as a complete editable and browser-playable example.
- Adds 108 tests; the complete package now runs 225 tests.

## 3.0.0 - Interactive Graphics and Two-Hand Runtime Companion

- Retains M001-M257 by source/reference and appends M258-M329.
- Adds scene assets, nodes, layers, transforms, migration and content hashes.
- Adds adaptive curve compilation, strokes, swept tubes and marching tetrahedra.
- Adds AABB/BVH/frustum/ray/streaming/interest queries.
- Adds PBR preview materials, color transforms and a small material graph.
- Adds typed left/right hand input, pinch hysteresis, bimanual transforms and handover lineage.
- Adds deterministic event proposal commit, snapshots, checkpoints, replay and divergence detection.
- Adds SVG, glTF and USDA output adapters.
- Adds a complete runnable sandbox and 70 new tests; the package runs 117 tests total with the retained 2.0 suite.

## 2.0.0 - Pattern, Kinematic Calculus and Dynamics Expansion

- Added M198-M257 and 47 tests.
