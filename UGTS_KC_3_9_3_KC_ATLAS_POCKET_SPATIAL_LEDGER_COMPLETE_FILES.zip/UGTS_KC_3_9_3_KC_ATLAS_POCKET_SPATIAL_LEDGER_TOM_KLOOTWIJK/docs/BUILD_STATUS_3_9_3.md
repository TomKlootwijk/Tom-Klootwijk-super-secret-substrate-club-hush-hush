# Build status - UGTS-KC 3.9.3 KC Atlas

| Gate | Expected 3.9.3 result |
|---|---|
| `compileall` | All Python source modules compile. |
| Unit tests | 347/347 pass, including 71 new spatial-ledger tests. |
| Catalog | M198-M589 is contiguous; M530-M589 contains 60 additions. |
| JSON Schema | Spatial ledger and frame-observation examples validate. |
| Demo | Baseline/current ledgers, three accepted events, change report and replay hashes regenerate. |
| Route query | Baseline wheelchair route is reachable; the accepted blockage makes it unreachable in the synthetic current ledger. |
| Offline export | No external scripts, fonts, stylesheets, images or network assets are required. |
| Distribution | Wheel and source archive build and install into a clean target directory. |
| Android | Retained 3.9.2 Grove source/APK present; no new APK build or physical-device run claimed. |
| Manifest | Final release files receive SHA-256 entries. |

Captured command output and machine-readable summaries are stored under `validation/`.
