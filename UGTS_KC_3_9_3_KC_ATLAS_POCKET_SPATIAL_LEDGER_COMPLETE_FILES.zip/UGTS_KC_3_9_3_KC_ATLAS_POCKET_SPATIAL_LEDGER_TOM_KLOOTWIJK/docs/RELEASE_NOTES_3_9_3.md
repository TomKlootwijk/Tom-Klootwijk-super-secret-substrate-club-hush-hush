# Release notes - UGTS-KC 3.9.3 KC Atlas

## Release decision

3.9.3 completes the substrate expansion before beginning a new phone-native capture application. It converts the high-impact application analysis into a versioned, executable spatial evidence and change ledger while retaining the attached 3.9.2 Grove implementation as the Android baseline.

## New runtime modules

| Module | Role |
|---|---|
| `spatialledger.py` | Capture/observation records, stable nodes/edges, proposal verification, commit, checkpoints, replay, routes, change and publication. |
| `spatialkey.py` | SCLP-derived finite local log-polar key, contiguous/Morton codecs and prefix refinement. |
| `ledgerprofiles.py` | Seven content-addressed application profiles and readiness checks. |
| `ledgerexport.py` | Self-contained HTML evidence bundle and SHA-256 manifest. |
| `templatesledger.py` | Deterministic SafeRoute + DamageDelta reference data. |

## New command-line workflow

- `new-ledger`
- `validate-ledger`
- `route-ledger`
- `diff-ledger`
- `build-ledger-report`
- `demo-ledger`

## Mechanism catalog

M530-M589 adds 60 mechanisms across spatial-ledger core, capture/provenance, uncertainty/support, map authority, topology/navigation, repeat-scan change, application profiles, publication/exchange, finite indexing and the Android bridge boundary.

The supplied 3.9.2 catalog metadata declared M450-M529 but the machine-readable source ended at M528. Version 3.9.3 records one explicit catalog-closure row M529. This repairs continuity without inventing an unobserved Android feature.

## Validation result

- Python compile: PASS.
- Retained-plus-new unit suite: 347/347 PASS.
- New 3.9.3 tests: 71 PASS.
- Schemas and checked-in examples: PASS.
- Hash-verified demonstration replay: PASS.
- Self-contained evidence-bundle manifest: PASS.
- CLI smoke workflow: PASS.
- Python wheel/source distribution: built and install-tested.

## Explicitly postponed

A new camera/IMU/vision-model Android application is not part of this release. The retained Grove source and APK remain untouched. New device-specific claims require a named phone, build toolchain, calibration data, equal-error baseline and measured p50/p95/p99 latency, memory, thermal and power evidence.
