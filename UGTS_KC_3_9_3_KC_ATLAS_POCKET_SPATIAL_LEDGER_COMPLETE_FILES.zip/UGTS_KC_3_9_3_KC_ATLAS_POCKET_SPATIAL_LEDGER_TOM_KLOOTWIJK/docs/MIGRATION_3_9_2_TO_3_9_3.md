# Migration - UGTS-KC 3.9.2 Grove to 3.9.3 KC Atlas

3.9.3 is additive. Existing game, browser, scene, mobile-3D and Android paths remain available.

## What remains unchanged

- Existing package imports under `ugts_kc` and `ugts_kc3`.
- The game-project schema and HTML5 workflows.
- The mobile-3D/Grove source project and native scene pack.
- The retained runtime proposal, scene, geometry, replay and export APIs.

## What is new

Create a `SpatialLedger` when an application needs evidence-bearing map identity, route topology, repeat-scan change or publication controls.

```python
from ugts_kc3 import SpatialLedger, LedgerMetadata

ledger = SpatialLedger(metadata=LedgerMetadata(
    ledger_id="site-a",
    title="Site A evidence ledger",
    author="operator",
))
```

Perception or manual tools should create `Observation` records and submit `SpatialEventProposal` objects. They must not mutate nodes or route edges directly in an authoritative workflow.

## Type-name compatibility

The retained `ugts_kc3.runtime.EventProposal` remains exported as `EventProposal`. The spatial-ledger proposal is exported as `SpatialEventProposal` to prevent API shadowing.

## Data migration rule

Do not transform a 3.9.2 game/mobile project into a spatial ledger by renaming fields. Instead:

1. retain the original project as a source artifact;
2. create a 3.9.3 capture profile;
3. derive typed observations with hashes and uncertainty;
4. create stable map nodes and route edges;
5. commit state changes through proposals; and
6. preserve source references in observation provenance.
