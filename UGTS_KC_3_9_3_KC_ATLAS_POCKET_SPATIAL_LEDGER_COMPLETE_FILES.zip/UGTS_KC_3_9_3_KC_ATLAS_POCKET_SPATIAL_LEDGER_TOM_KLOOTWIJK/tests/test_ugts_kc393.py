from __future__ import annotations

import json
import math
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import jsonschema

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from ugts_kc3.ledgerexport import build_offline_html, verify_evidence_bundle, write_evidence_bundle
from ugts_kc3.ledgerprofiles import (
    APPLICATION_PROFILES,
    application_profile_registry,
    get_application_profile,
    validate_application_readiness,
)
from ugts_kc3.spatialkey import (
    RHO_BITS,
    decode_observation_key,
    iter_prefixes,
    morton_schedule,
    pack_contiguous,
    pack_morton,
    prefix_bounds,
    quantize_observation_key,
    unpack_contiguous,
    unpack_morton,
)
from ugts_kc3.spatialledger import (
    CaptureProfile,
    ChangePolicy,
    EventProposal,
    FrameObservationPacket,
    FrameObservationProposal,
    IntervalEstimate,
    LedgerMetadata,
    MapNode,
    Observation,
    PoseEstimate,
    PublicationPolicy,
    RouteEdge,
    RouteQuery,
    SpatialLedger,
    SupportVolume,
    compare_ledgers,
    content_hash,
    publication_view,
    reachable_nodes,
    shortest_route,
)
from ugts_kc3.templatesledger import build_atlas_demo, safe_route_baseline, safe_route_repeat_scan
from ugts_kc3.version import __spatial_ledger_schema__, __version__


class IntervalAndPose393Tests(unittest.TestCase):
    def test_interval_validation(self):
        IntervalEstimate(1.0, 0.9, 1.1, "meter", 0.9).validate()

    def test_interval_rejects_value_outside(self):
        with self.assertRaises(ValueError):
            IntervalEstimate(1.2, 0.9, 1.1, "meter").validate()

    def test_interval_overlap(self):
        a = IntervalEstimate(1, 0.9, 1.1, "m")
        b = IntervalEstimate(1.2, 1.05, 1.3, "m")
        self.assertTrue(a.overlaps(b))
        self.assertEqual(a.gap(b), 0)

    def test_interval_gap(self):
        a = IntervalEstimate(1, 0.9, 1.1, "m")
        b = IntervalEstimate(1.5, 1.4, 1.6, "m")
        self.assertAlmostEqual(a.gap(b), 0.3)

    def test_interval_units_must_match(self):
        with self.assertRaises(ValueError):
            IntervalEstimate(1, 1, 1, "m").overlaps(IntervalEstimate(1, 1, 1, "degree"))

    def test_pose_normalizes_quaternion(self):
        pose = PoseEstimate(rotation=(2, 0, 0, 0))
        pose.validate()
        self.assertEqual(pose.to_dict()["rotation"], [2, 0, 0, 0])
        self.assertEqual(PoseEstimate.from_dict(pose.to_dict()).rotation, (1.0, 0.0, 0.0, 0.0))

    def test_pose_rejects_negative_sigma(self):
        with self.assertRaises(ValueError):
            PoseEstimate(translation_sigma=(-1, 0, 0)).validate()


class SupportAndObservation393Tests(unittest.TestCase):
    def test_sphere_support(self):
        support = SupportVolume("sphere", (0, 0, 0), radius=2)
        self.assertTrue(support.contains((1, 0, 0)))
        self.assertFalse(support.contains((3, 0, 0)))

    def test_aabb_support(self):
        support = SupportVolume("aabb", (0, 0, 0), (1, 2, 3))
        self.assertTrue(support.contains((1, 2, 3)))
        self.assertFalse(support.contains((1.1, 0, 0)))

    def test_cone_support(self):
        support = SupportVolume("cone", (0, 0, 0), axis=(0, 0, 1), radius=4, cone_cos=0.8)
        self.assertTrue(support.contains((0, 0, 2)))
        self.assertFalse(support.contains((2, 0, 0)))

    def test_capture_privacy_conflict(self):
        with self.assertRaises(ValueError):
            CaptureProfile("c", privacy_mode="derived-only", raw_media_retained=True).validate()

    def test_capture_definition_hash_stable(self):
        a = CaptureProfile("c", sensor_mode="synthetic")
        b = CaptureProfile.from_dict(a.to_dict())
        self.assertEqual(a.definition_hash, b.definition_hash)

    def test_observation_hash_roundtrip(self):
        observation = Observation("o", "c", 1, "door", pose=PoseEstimate(), confidence=.9, event_margin=.1)
        data = observation.to_dict()
        clone = Observation.from_dict(data)
        self.assertEqual(data["provenance_hash"], clone.content_hash)

    def test_observation_hash_mismatch(self):
        data = Observation("o", "c", 1, "door", event_margin=.1).to_dict()
        data["provenance_hash"] = "0" * 64
        ledger = SpatialLedger(LedgerMetadata("l", "L"), {"c": CaptureProfile("c", sensor_mode="synthetic")}, {"o": Observation.from_dict({**data, "provenance_hash": ""})})
        ledger.observations["o"] = Observation.from_dict({**data, "provenance_hash": ""})
        # Frozen records prevent invalid hash construction through from_dict; mutate serialized input instead.
        raw = ledger.to_dict()
        raw["observations"][0]["provenance_hash"] = "0" * 64
        with self.assertRaises(ValueError):
            SpatialLedger.from_dict(raw)


class LedgerCore393Tests(unittest.TestCase):
    def test_baseline_validates(self):
        ledger = safe_route_baseline()
        self.assertTrue(ledger.validate().passed)

    def test_ledger_roundtrip_hash(self):
        ledger = safe_route_baseline()
        clone = SpatialLedger.from_dict(ledger.to_dict())
        self.assertEqual(ledger.state_hash(), clone.state_hash())

    def test_unknown_edge_endpoint(self):
        ledger = SpatialLedger(LedgerMetadata("l", "L"))
        with self.assertRaises(KeyError):
            ledger.add_edge(RouteEdge("e", "a", "b"))

    def test_node_identity_not_coordinate(self):
        ledger = SpatialLedger(LedgerMetadata("l", "L"))
        ledger.add_node(MapNode("a", "room", PoseEstimate((0, 0, 0))))
        ledger.add_node(MapNode("b", "room", PoseEstimate((0, 0, 0))))
        self.assertEqual(ledger.nodes["a"].position, ledger.nodes["b"].position)
        self.assertNotEqual(ledger.nodes["a"].id, ledger.nodes["b"].id)

    def test_state_hash_excludes_event_history(self):
        baseline, pre_event, current = safe_route_repeat_scan()
        clone = current.clone()
        clone.events = []
        clone.checkpoints = []
        self.assertEqual(current.state_hash(), clone.state_hash())

    def test_checkpoint_hash(self):
        ledger = safe_route_baseline()
        checkpoint = ledger.checkpoints[0]
        self.assertEqual(checkpoint.state_hash, content_hash(checkpoint.snapshot))

    def test_write_and_load(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = safe_route_baseline().write(Path(tmp) / "ledger.json")
            self.assertTrue(path.exists())
            self.assertTrue(SpatialLedger.load(path).validate().passed)


class EventAuthority393Tests(unittest.TestCase):
    def setUp(self):
        self.ledger = safe_route_baseline().clone(include_history=False)

    def test_error_guard_rejection(self):
        proposal = EventProposal("p", 1, "x", "edge", "edge-door-clinic", {"status": "blocked"}, numeric_error=.2, event_margin=.1)
        event = self.ledger.commit_proposals([proposal])[0]
        self.assertFalse(event.accepted)
        self.assertEqual(event.decision_reason, "numeric_error_exceeds_margin")

    def test_confidence_rejection(self):
        proposal = EventProposal("p", 1, "x", "edge", "edge-door-clinic", {"status": "blocked"}, confidence=.4, event_margin=.1)
        event = self.ledger.commit_proposals([proposal], confidence_floor=.5)[0]
        self.assertFalse(event.accepted)

    def test_support_rejection(self):
        proposal = EventProposal("p", 1, "x", "edge", "edge-door-clinic", {"status": "blocked"}, support_ok=False, event_margin=.1)
        self.assertFalse(self.ledger.commit_proposals([proposal])[0].accepted)

    def test_verified_commit(self):
        proposal = EventProposal("p", 1, "x", "edge", "edge-door-clinic", {"status": "blocked"}, event_margin=.1)
        event = self.ledger.commit_proposals([proposal])[0]
        self.assertTrue(event.accepted)
        self.assertEqual(self.ledger.edges["edge-door-clinic"].status, "blocked")
        self.assertNotEqual(event.pre_hash, event.post_hash)

    def test_deterministic_priority_conflict(self):
        low = EventProposal("low", 1, "x", "edge", "edge-door-clinic", {"status": "restricted"}, priority=1, event_margin=.1)
        high = EventProposal("high", 1, "x", "edge", "edge-door-clinic", {"status": "blocked"}, priority=2, event_margin=.1)
        events = self.ledger.commit_proposals([low, high])
        self.assertEqual([event.proposal.id for event in events], ["high", "low"])
        self.assertTrue(events[0].accepted)
        self.assertFalse(events[1].accepted)
        self.assertEqual(self.ledger.edges["edge-door-clinic"].status, "blocked")

    def test_nonconflicting_same_time_patches(self):
        a = EventProposal("a", 1, "x", "edge", "edge-door-clinic", {"status": "blocked"}, event_margin=.1)
        b = EventProposal("b", 1, "x", "edge", "edge-door-clinic", {"confidence": .8}, event_margin=.1)
        events = self.ledger.commit_proposals([a, b])
        self.assertTrue(all(event.accepted for event in events))

    def test_hash_verified_replay(self):
        _, pre_event, current = safe_route_repeat_scan()
        replay = SpatialLedger.replay(pre_event, current.events)
        self.assertEqual(replay.state_hash(), current.state_hash())

    def test_replay_divergence(self):
        _, pre_event, current = safe_route_repeat_scan()
        pre_event.nodes.pop("beam-b14")
        with self.assertRaises(ValueError):
            SpatialLedger.replay(pre_event, current.events)


class Route393Tests(unittest.TestCase):
    def setUp(self):
        self.baseline, _, self.current = safe_route_repeat_scan()
        self.wheelchair = RouteQuery("wheelchair", .8, 8, False, False, .65)

    def test_baseline_accessible_route(self):
        result = shortest_route(self.baseline, "entrance-main", "exit-north", self.wheelchair)
        self.assertEqual(result.status, "ok")
        self.assertIn("edge-door-clinic", result.edge_ids)

    def test_blocked_route_unreachable(self):
        result = shortest_route(self.current, "entrance-main", "exit-north", self.wheelchair)
        self.assertEqual(result.status, "unreachable")

    def test_walk_route_can_use_stairs(self):
        query = RouteQuery("walk", 0, 90, True, False, .5)
        result = shortest_route(self.current, "entrance-main", "exit-north", query)
        self.assertEqual(result.status, "ok")
        self.assertIn("edge-lobby-stairs", result.edge_ids)

    def test_no_stairs_blocks_alternate(self):
        query = RouteQuery("walk", 0, 90, False, False, .5)
        self.assertEqual(shortest_route(self.current, "entrance-main", "exit-north", query).status, "unreachable")

    def test_clearance_constraint(self):
        query = RouteQuery("wheelchair", 1.0, 8, False, False, .5)
        self.assertEqual(shortest_route(self.baseline, "entrance-main", "exit-north", query).status, "unreachable")

    def test_reachable_nodes(self):
        nodes = reachable_nodes(self.current, "entrance-main", self.wheelchair)
        self.assertIn("door-east", nodes)
        self.assertNotIn("exit-north", nodes)

    def test_unknown_start(self):
        result = shortest_route(self.baseline, "missing", "exit-north", self.wheelchair)
        self.assertEqual(result.status, "invalid")


class Change393Tests(unittest.TestCase):
    def setUp(self):
        self.baseline, _, self.current = safe_route_repeat_scan()
        self.policy = ChangePolicy({"displacement": .01, "doorway_width": .02}, position_threshold=.01, confidence_floor=.65)
        self.report = compare_ledgers(self.baseline, self.current, self.policy)

    def test_change_report_hashes(self):
        self.assertEqual(self.report.baseline_hash, self.baseline.state_hash())
        self.assertEqual(self.report.current_hash, self.current.state_hash())

    def test_blockage_confirmed(self):
        items = [c for c in self.report.candidates if c.target_id == "edge-door-clinic" and c.field == "status"]
        self.assertEqual(items[0].classification, "confirmed")

    def test_beam_displacement_confirmed(self):
        items = [c for c in self.report.candidates if c.target_id == "beam-b14" and c.field == "measurements.displacement"]
        self.assertEqual(items[0].classification, "confirmed")

    def test_door_width_within_tolerance_or_review(self):
        items = [c for c in self.report.candidates if c.target_id == "door-east" and c.field == "measurements.doorway_width"]
        self.assertIn(items[0].classification, {"within_tolerance", "review"})

    def test_change_report_roundtrip(self):
        from ugts_kc3.spatialledger import ChangeReport
        clone = ChangeReport.from_dict(self.report.to_dict())
        self.assertEqual(clone.summary, self.report.summary)

    def test_added_node(self):
        clone = self.current.clone()
        clone.add_node(MapNode("new-object", "component"))
        report = compare_ledgers(self.baseline, clone, self.policy)
        self.assertTrue(any(c.target_id == "new-object" and c.classification == "added" for c in report.candidates))

    def test_removed_edge(self):
        clone = self.current.clone()
        clone.edges.pop("edge-stairs-exit")
        report = compare_ledgers(self.baseline, clone, self.policy)
        self.assertTrue(any(c.target_id == "edge-stairs-exit" and c.classification == "removed" for c in report.candidates))


class ProfilesAndPublication393Tests(unittest.TestCase):
    def test_profile_registry_has_seven(self):
        self.assertEqual(len(APPLICATION_PROFILES), 7)

    def test_profile_hashes_verify(self):
        registry = application_profile_registry()
        self.assertEqual(len(registry["registry_hash"]), 64)
        for item in registry["profiles"]:
            self.assertEqual(get_application_profile(item["id"]).definition_hash, item["definition_hash"])

    def test_safe_route_ready(self):
        report = validate_application_readiness(safe_route_baseline(), "safe-route")
        self.assertTrue(report.passed)

    def test_pipe_graph_not_ready(self):
        report = validate_application_readiness(safe_route_baseline(), "pipe-graph")
        self.assertFalse(report.passed)

    def test_publication_redacts_source_uri(self):
        ledger = safe_route_baseline()
        obs = ledger.observations["obs-door-east"]
        ledger.observations[obs.id] = Observation.from_dict({**obs.to_dict(), "source_uri": "file:///private/video.mp4", "provenance_hash": ""})
        view = publication_view(ledger)
        item = next(o for o in view["observations"] if o["id"] == obs.id)
        self.assertIsNone(item["source_uri"])

    def test_publication_pseudonymizes_author(self):
        view = publication_view(safe_route_baseline(), PublicationPolicy(pseudonymize_author=True))
        self.assertEqual(view["metadata"]["author"], "field-operator")

    def test_publication_rounds_coordinates(self):
        ledger = safe_route_baseline()
        view = publication_view(ledger, PublicationPolicy(coordinate_decimals=1))
        beam = next(n for n in view["nodes"] if n["id"] == "beam-b14")
        self.assertEqual(beam["pose"]["translation"][0], 7.5)


class PacketAndKey393Tests(unittest.TestCase):
    def _packet(self):
        proposal = FrameObservationProposal("fp1", "doorway", "door", PoseEstimate((1, 0, 2)), .9, .01, .05, "door-x")
        return FrameObservationPacket("capture-x", 12, 1.5, PoseEstimate(), (800, 800, 400, 300), "sha256:model", True, (proposal,), True)

    def test_packet_hash_roundtrip(self):
        packet = self._packet()
        data = packet.to_dict()
        clone = FrameObservationPacket.from_dict(data)
        self.assertEqual(clone.content_hash, data["packet_hash"])

    def test_packet_rejects_bad_hash(self):
        data = self._packet().to_dict()
        data["packet_hash"] = "0" * 64
        with self.assertRaises(ValueError):
            FrameObservationPacket.from_dict(data)

    def test_packet_to_observation(self):
        observations = self._packet().observations()
        self.assertEqual(observations[0].capture_id, "capture-x")
        self.assertEqual(observations[0].target_id, "door-x")

    def test_key_contiguous_roundtrip(self):
        key = quantize_observation_key(-2.3, 1.2, 120, 0.4)
        self.assertEqual(unpack_contiguous(pack_contiguous(key)), key)

    def test_key_morton_roundtrip(self):
        key = quantize_observation_key(-10, 5.2, 1200, 4.2)
        self.assertEqual(unpack_morton(pack_morton(key)), key)

    def test_key_layouts_distinct(self):
        key = quantize_observation_key(-2.3, 1.2, 120, 0.4)
        self.assertNotEqual(pack_contiguous(key), pack_morton(key))

    def test_key_decode_bounds(self):
        key = quantize_observation_key(-2.3, 1.2, 120, 0.4)
        decoded = decode_observation_key(key)
        self.assertLess(abs(decoded.rho + 2.3), 0.001)

    def test_morton_schedule_length(self):
        self.assertEqual(len(morton_schedule()), 64)
        self.assertEqual(morton_schedule()[0], ("rho", RHO_BITS - 1))

    def test_prefix_bounds_narrow(self):
        key = quantize_observation_key(-2.3, 1.2, 120, 0.4)
        word = pack_morton(key)
        widths = []
        for length, prefix, bounds in iter_prefixes(word):
            widths.append(sum(hi - lo for lo, hi in bounds.values()))
        self.assertTrue(all(b <= a for a, b in zip(widths, widths[1:])))
        final = prefix_bounds(word, 64)
        self.assertEqual(final["frame"], (key.frame, key.frame))


class ExportSchemaCli393Tests(unittest.TestCase):
    def test_offline_html_self_contained(self):
        baseline, _, current = safe_route_repeat_scan()
        report = compare_ledgers(baseline, current)
        text = build_offline_html(current, report)
        self.assertIn("<!doctype html>", text.lower())
        self.assertNotIn("https://", text)
        self.assertIn(current.state_hash(), text)

    def test_evidence_bundle_verifies(self):
        baseline, _, current = safe_route_repeat_scan()
        with tempfile.TemporaryDirectory() as tmp:
            result = write_evidence_bundle(current, tmp, compare_ledgers(baseline, current))
            self.assertTrue(result.report.exists())
            self.assertTrue(verify_evidence_bundle(tmp)["passed"])

    def test_evidence_bundle_tamper(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = write_evidence_bundle(safe_route_baseline(), tmp)
            result.ledger.write_text("{}", encoding="utf-8")
            self.assertFalse(verify_evidence_bundle(tmp)["passed"])

    def test_ledger_json_schema(self):
        schema = json.loads((ROOT / "spec/spatial_ledger_schema_3_9_3.json").read_text())
        jsonschema.validate(safe_route_baseline().to_dict(), schema)

    def test_packet_json_schema(self):
        schema = json.loads((ROOT / "spec/frame_observation_packet_schema_3_9_3.json").read_text())
        packet = FrameObservationPacket("c", 0, 0, PoseEstimate(), (1, 1, 0, 0), "m", True, ())
        jsonschema.validate(packet.to_dict(), schema)

    def test_catalog_contiguous(self):
        data = json.loads((ROOT / "spec/engineering_catalog_M198_M589.json").read_text())
        ids = [int(item["id"][1:]) for item in data["mechanisms"]]
        self.assertEqual(ids, list(range(198, 590)))
        self.assertEqual(data["extended_total"], 589)

    def test_release_catalog_count(self):
        data = json.loads((ROOT / "spec/kc393_mechanisms_M530_M589.json").read_text())
        self.assertEqual(data["count"], 60)
        self.assertEqual(data["mechanisms"][0]["id"], "M530")
        self.assertEqual(data["mechanisms"][-1]["id"], "M589")

    def test_demo_build(self):
        with tempfile.TemporaryDirectory() as tmp:
            summary = build_atlas_demo(tmp)
            self.assertEqual(summary["current_hash"], summary["replay_hash"])
            self.assertEqual(summary["accepted_events"], 3)

    def test_cli_info(self):
        env = dict(os.environ, PYTHONPATH=str(SRC))
        result = subprocess.run([sys.executable, "-m", "ugts_kc3", "info"], cwd=ROOT, env=env, text=True, capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("KC Atlas", result.stdout)

    def test_cli_validate_ledger(self):
        env = dict(os.environ, PYTHONPATH=str(SRC))
        with tempfile.TemporaryDirectory() as tmp:
            path = safe_route_baseline().write(Path(tmp) / "ledger.json")
            result = subprocess.run([sys.executable, "-m", "ugts_kc3", "validate-ledger", str(path), "--profile", "safe-route"], cwd=ROOT, env=env, text=True, capture_output=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("PASS", result.stdout)

    def test_cli_route_ledger(self):
        env = dict(os.environ, PYTHONPATH=str(SRC))
        with tempfile.TemporaryDirectory() as tmp:
            path = safe_route_baseline().write(Path(tmp) / "ledger.json")
            result = subprocess.run([sys.executable, "-m", "ugts_kc3", "route-ledger", str(path), "entrance-main", "exit-north", "--mode", "wheelchair", "--minimum-clearance", ".8", "--maximum-slope", "8", "--no-stairs", "--json"], cwd=ROOT, env=env, text=True, capture_output=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(result.stdout)["status"], "ok")

    def test_version_and_schema(self):
        self.assertEqual(__version__, "3.9.3")
        self.assertEqual(__spatial_ledger_schema__, "ugts-kc-spatial-ledger-3.9.3")


if __name__ == "__main__":
    unittest.main(verbosity=2)
