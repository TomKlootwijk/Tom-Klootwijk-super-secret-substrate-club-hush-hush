# Source integration notes - 3.9.3

## UGTS-KC 3.9 KC Elizabeth Vector Game Runtime
- File: `UGTS_KC_3_9_KC_Elizabeth_Vector_Game_Runtime.pdf`
- SHA-256: `d7ee3c91abf60e35b4b15fb296477974e45802c24e1fde618d683949bc1c7df2`
- 3.9.3 role: Retained project model, fixed-step runtime, self-contained HTML5 export and validation discipline.

## UGTS-KC 3.6.2 SCLP
- File: `UGTS_KC_3_6_2_SCLP_Tom_Klootwijk.pdf`
- SHA-256: `6987490a0a7b7ed76b0091057a2e69ab831fee786434a0b4219782923f5ea580`
- 3.9.3 role: Finite cone/sphere supports, log-polar calculus, bounded jitter, 64-bit layouts and prefix refinement.

## UGTS-KC 2.0 Expanded Substrate
- File: `UGTS_KC_2_0_Tom_Klootwijk_Expanded_Substrate.pdf`
- SHA-256: `a29dd9959ebd300c32d0e1df8fa2c0d4ee15f428892557b98b5f18cd3e878399`
- 3.9.3 role: Pattern/field calculus, route identity, SE(3), bounded dynamics, event degeneracy and error contracts.

## UGTS-KC Two Hands 3.0
- File: `UGTS_KC_Two_Hands_3_0_Interactive_Graphics_Runtime.pdf`
- SHA-256: `183ffa4e2bf29cfa0308687cd221529321598dbd69ef75c150abc0c64810f214`
- 3.9.3 role: Stable scene/node identity, geometry compiler, BVH, independent error budgets, proposal commit, replay and interchange.

## UGTS-GN 1.1 GPU-native Addendum
- File: `Unified_Geometric_Topological_Substrate_GPU_Native_Addendum.pdf`
- SHA-256: `3a6b6c57118ca4e2d7d7e577508c3477a095d133791f3708cb56a054285225d2`
- 3.9.3 role: Canonical query-first sequence, packed ABI, measured-performance boundaries and narrow one-bit semantics.

## UGTS-KC 3.6 Literal Referential Substrate
- File: `UGTS_KC_3_6_Tom_Klootwijk.pdf`
- SHA-256: `e21433cd8378368dafe4ae278d3c9c364725e45ae7fd75b743328bd2d6003a46`
- 3.9.3 role: Content-addressed definitions, explicit dependency graph, operation order and provenance.

## UGTS-KC 3.9.2 K-Kij-T / Grove complete files
- File: `UGTS_KC_K_Kij_T_Grove_3_9_2_COMPLETE_ALL_FILES - Tom Klootwijk(1).zip`
- SHA-256: `2d0197bb4526ca994eb67f68985ebd349fb91f52f562870b97f01d03023f8944`
- 3.9.3 role: Immediate implementation baseline, retained Android source and supplied APK.

## Engineering delta

KC Atlas M530-M589 is an engineering addition derived from the retained architecture. The project sources do not claim that the seven high-impact applications or a phone capture model were already implemented. Version 3.9.3 supplies the common evidence, event, route, change, export and future-adapter substrate; real-world calibration and deployment remain future work.
