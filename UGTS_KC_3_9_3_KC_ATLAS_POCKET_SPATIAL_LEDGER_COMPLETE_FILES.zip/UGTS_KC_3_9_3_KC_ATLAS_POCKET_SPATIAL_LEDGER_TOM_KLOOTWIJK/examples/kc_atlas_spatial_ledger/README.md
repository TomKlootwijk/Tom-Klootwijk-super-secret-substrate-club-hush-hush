# KC Atlas SafeRoute + DamageDelta reference demonstration

This synthetic, deterministic fixture contains no real building, incident, patient or phone capture. It demonstrates typed observations, verified map events, route topology, repeat-scan change, replay and an offline bundle.

Rebuild from the package root:

```bash
PYTHONPATH=src python -m ugts_kc3 demo-ledger examples/kc_atlas_spatial_ledger
PYTHONPATH=src python -m ugts_kc3 validate-ledger examples/kc_atlas_spatial_ledger/baseline-ledger.json --profile safe-route
```

The baseline wheelchair route is reachable. After the accepted blockage event, the same constrained route is unreachable. This is a synthetic topology result, not real-site safety certification.
