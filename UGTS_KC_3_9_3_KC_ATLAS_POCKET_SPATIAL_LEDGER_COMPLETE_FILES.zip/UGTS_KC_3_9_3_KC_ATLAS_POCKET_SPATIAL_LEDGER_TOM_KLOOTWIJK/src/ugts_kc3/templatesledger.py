"""Deterministic KC Atlas reference ledgers and repeat-scan demonstration."""
from __future__ import annotations

from dataclasses import replace
from pathlib import Path
from typing import Any

from .ledgerexport import write_evidence_bundle
from .ledgerprofiles import APPLICATION_PROFILES
from .spatialledger import (
    CaptureProfile,
    ChangePolicy,
    EventProposal,
    IntervalEstimate,
    LedgerMetadata,
    MapNode,
    Observation,
    PoseEstimate,
    RouteEdge,
    SpatialLedger,
    SupportVolume,
    compare_ledgers,
)


def _estimate(
    value: float,
    error: float,
    unit: str,
    confidence: float,
    method: str,
    *sources: str,
) -> IntervalEstimate:
    return IntervalEstimate(
        value,
        value - error,
        value + error,
        unit,
        confidence,
        method,
        tuple(sources),
    )


def _pose(x: float, y: float, z: float, sigma: float = 0.01) -> PoseEstimate:
    return PoseEstimate(
        (x, y, z),
        (1.0, 0.0, 0.0, 0.0),
        (sigma, sigma, sigma),
        (0.5, 0.5, 0.5),
        "building-local",
    )


def safe_route_baseline(author: str = "Tom Klootwijk") -> SpatialLedger:
    profile_hashes = {
        profile_id: APPLICATION_PROFILES[profile_id].definition_hash
        for profile_id in ("safe-route", "damage-delta")
    }
    ledger = SpatialLedger(
        LedgerMetadata(
            "kc-atlas-demo-baseline",
            "KC Atlas SafeRoute and DamageDelta Baseline",
            author,
            1787932800.0,
            "right-handed-y-up",
            "meter",
            ("safe-route", "damage-delta"),
            "UGTS-KC 3.9.2 K-Kij-T Grove baseline",
            "Synthetic reference map. No real building, patient or incident data.",
            definition_hashes=profile_hashes,
        )
    )
    capture = CaptureProfile(
        "capture-baseline",
        "reference-phone-profile",
        "monocular_video_imu",
        "right-handed-y-up",
        1.0,
        "sha256:reference-calibration-baseline",
        "sha256:reference-distilled-model",
        {"kind": "doorway_width_anchor", "value": 0.92, "unit": "meter"},
        "derived-only",
        False,
        1787932800.0,
        {"operator": "field-operator-a", "site": "synthetic-training-map"},
    )
    ledger.add_capture(capture)

    observations = [
        Observation(
            "obs-entrance",
            capture.id,
            0.0,
            "entrance",
            "entrance-main",
            (0, 1, 2),
            _pose(0, 0, 0),
            SupportVolume("cone", (0, 1.5, -1), axis=(0, -0.1, 1), radius=8.0, cone_cos=0.4),
            0.97,
            0.01,
            0.05,
            attributes={"source": "synthetic"},
        ),
        Observation(
            "obs-lobby",
            capture.id,
            1.0,
            "room",
            "room-lobby",
            (15, 16, 17),
            _pose(3, 0, 0),
            SupportVolume("sphere", (3, 1, 0), radius=4.0),
            0.95,
            0.02,
            0.06,
            attributes={"walkable_floor": True},
        ),
        Observation(
            "obs-door-east",
            capture.id,
            2.0,
            "doorway",
            "door-east",
            (30, 31, 32, 33),
            _pose(6, 0, 0),
            SupportVolume("aabb", (6, 1, 0), half_extents=(1.2, 1.5, 1.0)),
            0.94,
            0.008,
            0.04,
            attributes={"width": 0.92},
        ),
        Observation(
            "obs-clinic",
            capture.id,
            3.0,
            "room",
            "room-clinic",
            (45, 46, 47),
            _pose(9, 0, 0),
            SupportVolume("sphere", (9, 1, 0), radius=4.0),
            0.93,
            0.025,
            0.07,
            attributes={"walkable_floor": True},
        ),
        Observation(
            "obs-exit",
            capture.id,
            4.0,
            "exit",
            "exit-north",
            (60, 61, 62),
            _pose(9, 0, 4),
            SupportVolume("aabb", (9, 1, 4), half_extents=(1.5, 1.5, 1.0)),
            0.96,
            0.01,
            0.05,
            attributes={"egress_marker": True},
        ),
        Observation(
            "obs-stairs",
            capture.id,
            5.0,
            "stairs",
            "stairs-west",
            (75, 76),
            _pose(3, 0, -4),
            SupportVolume("aabb", (3, 1, -4), half_extents=(1.5, 1.5, 2.0)),
            0.91,
            0.025,
            0.08,
            attributes={"step_count": 8},
        ),
        Observation(
            "obs-beam",
            capture.id,
            6.0,
            "component",
            "beam-b14",
            (90, 91, 92),
            _pose(7.5, 2.8, 1.5, 0.003),
            SupportVolume("aabb", (7.5, 2.8, 1.5), half_extents=(1.5, 0.25, 0.25)),
            0.92,
            0.003,
            0.01,
            attributes={"component_class": "beam"},
        ),
    ]
    for observation in observations:
        ledger.add_observation(observation)

    ledger.add_node(MapNode("entrance-main", "entrance", _pose(0, 0, 0), evidence_ids=("obs-entrance",), lineage=("seed:entrance",)))
    ledger.add_node(MapNode("room-lobby", "room", _pose(3, 0, 0), evidence_ids=("obs-lobby",), lineage=("seed:lobby",)))
    ledger.add_node(
        MapNode(
            "door-east",
            "door",
            _pose(6, 0, 0),
            measurements={
                "doorway_width": _estimate(0.92, 0.015, "meter", 0.94, "multi-keyframe", "obs-door-east")
            },
            evidence_ids=("obs-door-east",),
            lineage=("seed:door-east",),
        )
    )
    ledger.add_node(MapNode("room-clinic", "room", _pose(9, 0, 0), evidence_ids=("obs-clinic",), lineage=("seed:clinic",)))
    ledger.add_node(MapNode("exit-north", "exit", _pose(9, 0, 4), evidence_ids=("obs-exit",), lineage=("seed:exit",)))
    ledger.add_node(MapNode("stairs-west", "stairs", _pose(3, 0, -4), tags=("stairs",), evidence_ids=("obs-stairs",), lineage=("seed:stairs",)))
    ledger.add_node(
        MapNode(
            "beam-b14",
            "component",
            _pose(7.5, 2.8, 1.5, 0.003),
            measurements={
                "displacement": _estimate(0.0, 0.003, "meter", 0.92, "aligned-baseline", "obs-beam")
            },
            evidence_ids=("obs-beam",),
            lineage=("seed:beam-b14",),
            attributes={"inspection_role": "reference-component"},
        )
    )

    edge_specs = [
        ("edge-entry-lobby", "entrance-main", "room-lobby", "walk", 3.0, 1.30, 0.0, "passable", ("walk", "wheelchair", "responder"), "obs-entrance"),
        ("edge-lobby-door", "room-lobby", "door-east", "walk", 3.0, 0.92, 0.0, "passable", ("walk", "wheelchair", "responder"), "obs-door-east"),
        ("edge-door-clinic", "door-east", "room-clinic", "walk", 3.0, 0.90, 0.0, "passable", ("walk", "wheelchair", "responder"), "obs-clinic"),
        ("edge-clinic-exit", "room-clinic", "exit-north", "ramp", 4.0, 1.10, 4.0, "passable", ("walk", "wheelchair", "responder"), "obs-exit"),
        ("edge-lobby-stairs", "room-lobby", "stairs-west", "stairs", 4.0, 1.00, 28.0, "passable", ("walk", "responder"), "obs-stairs"),
        ("edge-stairs-exit", "stairs-west", "exit-north", "stairs", 7.2, 0.95, 31.0, "passable", ("walk", "responder"), "obs-stairs"),
    ]
    for edge_id, source, target, route_class, length, clearance, slope, status, modes, evidence in edge_specs:
        ledger.add_edge(
            RouteEdge(
                edge_id,
                source,
                target,
                route_class,
                length,
                _estimate(clearance, 0.015, "meter", 0.93, "route-clearance", evidence),
                _estimate(slope, 1.0, "degree", 0.90, "route-slope", evidence),
                status,
                modes,
                0.92,
                (),
                (evidence,),
                (f"seed:{edge_id}",),
            )
        )
    ledger.validate(raise_on_error=True)
    ledger.checkpoint()
    return ledger


def safe_route_repeat_scan(author: str = "Tom Klootwijk") -> tuple[SpatialLedger, SpatialLedger, SpatialLedger]:
    """Return ``(baseline, pre_event_current, committed_current)``."""
    baseline = safe_route_baseline(author)
    pre_event = baseline.clone(include_history=False)
    pre_event.metadata = replace(
        pre_event.metadata,
        id="kc-atlas-demo-current",
        title="KC Atlas SafeRoute and DamageDelta Repeat Scan",
        created_at=1788019200.0,
        notes="Synthetic repeat scan with a blocked passage and component displacement candidate.",
    )
    repeat_capture = CaptureProfile(
        "capture-repeat",
        "reference-phone-profile",
        "monocular_video_imu",
        "right-handed-y-up",
        1.0,
        "sha256:reference-calibration-repeat",
        "sha256:reference-distilled-model",
        {"kind": "doorway_width_anchor", "value": 0.91, "unit": "meter"},
        "derived-only",
        False,
        1788019200.0,
        {"operator": "field-operator-a", "site": "synthetic-training-map"},
    )
    pre_event.add_capture(repeat_capture)
    repeat_observations = [
        Observation(
            "obs-repeat-blockage",
            repeat_capture.id,
            10.0,
            "blocked_passage",
            "edge-door-clinic",
            (120, 121, 122, 123),
            _pose(7.5, 0, 0),
            SupportVolume("aabb", (7.5, 1, 0), half_extents=(1.3, 1.2, 1.1)),
            0.96,
            0.006,
            0.04,
            attributes={"cause": "synthetic-debris", "dynamic": False},
        ),
        Observation(
            "obs-repeat-beam",
            repeat_capture.id,
            11.0,
            "component",
            "beam-b14",
            (140, 141, 142, 143),
            _pose(7.518, 2.8, 1.5, 0.004),
            SupportVolume("aabb", (7.5, 2.8, 1.5), half_extents=(1.5, 0.25, 0.25)),
            0.91,
            0.004,
            0.012,
            attributes={"alignment_residual": 0.004},
        ),
        Observation(
            "obs-repeat-door",
            repeat_capture.id,
            12.0,
            "doorway",
            "door-east",
            (155, 156, 157),
            _pose(6, 0, 0),
            SupportVolume("aabb", (6, 1, 0), half_extents=(1.2, 1.5, 1.0)),
            0.93,
            0.009,
            0.04,
            attributes={"width": 0.91},
        ),
    ]
    for observation in repeat_observations:
        pre_event.add_observation(observation)
    current = pre_event.clone(include_history=False)
    proposals = [
        EventProposal(
            "proposal-block-edge",
            10.0,
            "route_blocked",
            "edge",
            "edge-door-clinic",
            {
                "status": "blocked",
                "evidence_ids": ["obs-clinic", "obs-repeat-blockage"],
                "lineage": ["seed:edge-door-clinic", "event:route-blocked"],
                "attributes": {"blockage": "synthetic-debris", "review_status": "field-confirmed"},
            },
            source="repeat-scan-verifier",
            priority=100,
            confidence=0.96,
            numeric_error=0.006,
            event_margin=0.04,
            evidence_ids=("obs-repeat-blockage",),
            lineage_label="route passable -> blocked",
        ),
        EventProposal(
            "proposal-beam-displacement",
            11.0,
            "measurement_update",
            "node",
            "beam-b14",
            {
                "pose": _pose(7.518, 2.8, 1.5, 0.004).to_dict(),
                "measurements": {
                    "displacement": _estimate(
                        0.018,
                        0.004,
                        "meter",
                        0.91,
                        "repeat-scan-alignment",
                        "obs-repeat-beam",
                    ).to_dict()
                },
                "evidence_ids": ["obs-beam", "obs-repeat-beam"],
                "lineage": ["seed:beam-b14", "event:repeat-displacement"],
            },
            source="repeat-scan-verifier",
            priority=80,
            confidence=0.91,
            numeric_error=0.004,
            event_margin=0.012,
            evidence_ids=("obs-repeat-beam",),
            lineage_label="baseline -> displacement candidate",
        ),
        EventProposal(
            "proposal-door-width",
            12.0,
            "measurement_update",
            "node",
            "door-east",
            {
                "measurements": {
                    "doorway_width": _estimate(
                        0.91,
                        0.018,
                        "meter",
                        0.93,
                        "repeat-multi-keyframe",
                        "obs-repeat-door",
                    ).to_dict()
                },
                "evidence_ids": ["obs-door-east", "obs-repeat-door"],
                "lineage": ["seed:door-east", "event:repeat-width"],
            },
            source="repeat-scan-verifier",
            priority=60,
            confidence=0.93,
            numeric_error=0.009,
            event_margin=0.04,
            evidence_ids=("obs-repeat-door",),
            lineage_label="doorway repeat measurement",
        ),
    ]
    decisions = current.commit_proposals(proposals, confidence_floor=0.65)
    if not all(event.accepted for event in decisions):
        raise AssertionError("reference proposals must commit")
    current.checkpoint()
    current.validate(raise_on_error=True)
    return baseline, pre_event, current


def build_atlas_demo(directory: str | Path, author: str = "Tom Klootwijk") -> dict[str, Any]:
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    baseline, pre_event, current = safe_route_repeat_scan(author)
    policy = ChangePolicy(
        {
            "displacement": 0.01,
            "doorway_width": 0.02,
            "slope_degrees": 2.0,
        },
        position_threshold=0.01,
        confidence_floor=0.65,
        interval_margin=0.0,
        missing_is_change=True,
    )
    report = compare_ledgers(baseline, current, policy)
    baseline_path = baseline.write(directory / "baseline-ledger.json")
    pre_event_path = pre_event.write(directory / "pre-event-current-ledger.json")
    current_path = current.write(directory / "current-ledger.json")
    change_path = directory / "change-report.json"
    change_path.write_text(
        __import__("json").dumps(report.to_dict(), indent=2, sort_keys=True),
        encoding="utf-8",
    )
    replay = SpatialLedger.replay(pre_event, current.events)
    if replay.state_hash() != current.state_hash():
        raise AssertionError("reference replay diverged")
    bundle = write_evidence_bundle(current, directory / "offline-bundle", report)
    summary = {
        "schema": "ugts-kc-atlas-demo-summary-3.9.3",
        "baseline": str(baseline_path),
        "pre_event": str(pre_event_path),
        "current": str(current_path),
        "change_report": str(change_path),
        "offline_report": str(bundle.report),
        "baseline_hash": baseline.state_hash(),
        "current_hash": current.state_hash(),
        "replay_hash": replay.state_hash(),
        "events": len(current.events),
        "accepted_events": sum(event.accepted for event in current.events),
        "change_summary": report.summary,
        "bundle_bytes": bundle.total_bytes,
    }
    summary_path = directory / "demo-summary.json"
    summary["summary_file"] = str(summary_path)
    summary_path.write_text(
        __import__("json").dumps(summary, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    (directory / "README.md").write_text(
        "# KC Atlas SafeRoute + DamageDelta reference demonstration\n\n"
        "This synthetic, deterministic fixture contains no real building, incident, patient or phone capture. "
        "It demonstrates typed observations, verified map events, route topology, repeat-scan change, replay and an offline bundle.\n\n"
        "Rebuild from the package root:\n\n"
        "```bash\n"
        "PYTHONPATH=src python -m ugts_kc3 demo-ledger examples/kc_atlas_spatial_ledger\n"
        "PYTHONPATH=src python -m ugts_kc3 validate-ledger examples/kc_atlas_spatial_ledger/baseline-ledger.json --profile safe-route\n"
        "```\n\n"
        "The baseline wheelchair route is reachable. After the accepted blockage event, the same constrained route is unreachable. "
        "This is a synthetic topology result, not real-site safety certification.\n",
        encoding="utf-8",
    )
    return summary


__all__ = [
    "safe_route_baseline",
    "safe_route_repeat_scan",
    "build_atlas_demo",
]
