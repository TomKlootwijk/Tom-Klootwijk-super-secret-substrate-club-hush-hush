"""UGTS-KC 3.9.3 - KC Atlas spatial-evidence and retained game/mobile runtime.

The 3.9.2 Android/Grove implementation remains available as an unchanged downstream baseline.
The 3.9.3 addition is the query-first spatial ledger, application profiles, uncertainty-aware
change comparison and self-contained evidence export.
"""
from .math3d import *
from .geometry import *
from .spatial import *
from .materials import *
from .scene import *
from .hands import *
from .runtime import *
from .replay import *
from .render import *
from .export import *
from .diagnostics import *

from .vector2d import *
from .collision2d import *
from .game_input import *
from .animation import *
from .tilemap import *
from .audio import *
from .game import *
from .project import *
from .webexport import *
from .templates import *
from .mobile3d import *
from .templates3d import *
from .androidexport import *
from .spatialkey import *
from .spatialledger import (
    LEDGER_SCHEMA, CHANGE_REPORT_SCHEMA, EVIDENCE_BUNDLE_SCHEMA,
    canonical_json_bytes, content_hash, IntervalEstimate, PoseEstimate, SupportVolume,
    CaptureProfile, Observation, MapNode, RouteEdge, LedgerMetadata,
    EventProposal as SpatialEventProposal, LedgerEvent as SpatialLedgerEvent,
    Checkpoint as SpatialCheckpoint, ValidationIssue as SpatialValidationIssue,
    LedgerValidationReport, SpatialLedger, RouteQuery, RouteResult, shortest_route,
    reachable_nodes, ChangePolicy, ChangeCandidate, ChangeReport as SpatialChangeReport,
    compare_ledgers, PublicationPolicy, publication_view, FrameObservationProposal,
    FrameObservationPacket,
)
from .ledgerprofiles import *
from .ledgerexport import *
from .templatesledger import *
from .version import (__version__, __codename__, __edition__, __game_project_schema__,
    __mobile3d_schema__, __native_scene_pack__, __spatial_ledger_schema__)
