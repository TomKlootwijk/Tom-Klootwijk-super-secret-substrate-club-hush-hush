"""Versioned high-impact application profiles for the KC Atlas spatial ledger."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping

from .spatialledger import (
    LedgerValidationReport,
    RouteQuery,
    SpatialLedger,
    ValidationIssue,
    content_hash,
)


@dataclass(frozen=True)
class ApplicationProfile:
    id: str
    title: str
    purpose: str
    required_node_kinds: tuple[str, ...] = ()
    required_measurements: tuple[str, ...] = ()
    minimum_observation_confidence: float = 0.5
    route_query: RouteQuery | None = None
    privacy_requirements: tuple[str, ...] = ()
    safety_boundary: str = ""
    forbidden_claims: tuple[str, ...] = ()
    implementation_status: str = "reference-profile"
    metadata: dict[str, Any] = field(default_factory=dict)

    def validate(self) -> None:
        if not self.id or not self.title or not self.purpose:
            raise ValueError("application profile id, title and purpose are required")
        if not 0 <= self.minimum_observation_confidence <= 1:
            raise ValueError("minimum observation confidence must be in [0,1]")
        if self.route_query is not None:
            self.route_query.validate()
        if self.implementation_status not in {
            "reference-profile",
            "demonstrated",
            "specified",
            "validation-required",
        }:
            raise ValueError("unknown application profile status")

    @property
    def definition_hash(self) -> str:
        return content_hash(self.to_dict(include_hash=False))

    def to_dict(self, include_hash: bool = True) -> dict[str, Any]:
        self.validate()
        data = {
            "id": self.id,
            "title": self.title,
            "purpose": self.purpose,
            "required_node_kinds": list(self.required_node_kinds),
            "required_measurements": list(self.required_measurements),
            "minimum_observation_confidence": self.minimum_observation_confidence,
            "route_query": None if self.route_query is None else {
                "mode": self.route_query.mode,
                "minimum_clearance": self.route_query.minimum_clearance,
                "maximum_slope_degrees": self.route_query.maximum_slope_degrees,
                "allow_stairs": self.route_query.allow_stairs,
                "allow_unknown": self.route_query.allow_unknown,
                "confidence_floor": self.route_query.confidence_floor,
                "avoid_tags": list(self.route_query.avoid_tags),
            },
            "privacy_requirements": list(self.privacy_requirements),
            "safety_boundary": self.safety_boundary,
            "forbidden_claims": list(self.forbidden_claims),
            "implementation_status": self.implementation_status,
            "metadata": self.metadata,
        }
        if include_hash:
            data["definition_hash"] = content_hash(data)
        return data

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "ApplicationProfile":
        query_data = data.get("route_query")
        query = None
        if query_data:
            query = RouteQuery(
                str(query_data.get("mode", "walk")),
                float(query_data.get("minimum_clearance", 0.0)),
                float(query_data.get("maximum_slope_degrees", 90.0)),
                bool(query_data.get("allow_stairs", True)),
                bool(query_data.get("allow_unknown", False)),
                float(query_data.get("confidence_floor", 0.0)),
                tuple(str(v) for v in query_data.get("avoid_tags", ())),
            )
        result = cls(
            str(data["id"]),
            str(data["title"]),
            str(data["purpose"]),
            tuple(str(v) for v in data.get("required_node_kinds", ())),
            tuple(str(v) for v in data.get("required_measurements", ())),
            float(data.get("minimum_observation_confidence", 0.5)),
            query,
            tuple(str(v) for v in data.get("privacy_requirements", ())),
            str(data.get("safety_boundary", "")),
            tuple(str(v) for v in data.get("forbidden_claims", ())),
            str(data.get("implementation_status", "reference-profile")),
            dict(data.get("metadata", {})),
        )
        result.validate()
        expected = data.get("definition_hash")
        if expected and str(expected) != result.definition_hash:
            raise ValueError(f"application profile hash mismatch for {result.id}")
        return result


SAFE_ROUTE = ApplicationProfile(
    "safe-route",
    "SafeRoute accessibility and evacuation map",
    "Build an uncertainty-aware indoor route graph containing rooms, doors, exits, stairs, ramps and obstacles.",
    ("room", "door", "exit"),
    ("doorway_width",),
    0.65,
    RouteQuery(
        mode="wheelchair",
        minimum_clearance=0.80,
        maximum_slope_degrees=8.0,
        allow_stairs=False,
        allow_unknown=False,
        confidence_floor=0.65,
        avoid_tags=("hazard",),
    ),
    ("derived-only publication supported", "unknown areas remain explicit"),
    "The profile can report observed accessibility constraints; it does not certify code compliance, fire safety or guaranteed navigation.",
    ("building is safe", "route is legally compliant", "unobserved space is clear"),
    "demonstrated",
    {"priority": 1, "primary_outputs": ["route graph", "clearance report", "change ledger"]},
)

RESCUE_TWIN = ApplicationProfile(
    "rescue-twin",
    "RescueTwin disaster-site spatial evidence",
    "Merge low-bandwidth verified route and hazard deltas from multiple field devices.",
    ("entrance", "exit", "room"),
    (),
    0.70,
    RouteQuery(
        mode="responder",
        minimum_clearance=0.55,
        maximum_slope_degrees=35.0,
        allow_stairs=True,
        allow_unknown=True,
        confidence_floor=0.60,
        avoid_tags=("collapse", "fire", "flood"),
    ),
    ("operator/source lineage retained", "raw media optional", "conflicts remain reviewable"),
    "The ledger may describe observed passability and hazards; it cannot certify structural stability, atmosphere, fire behavior or rescue safety.",
    ("structure is safe", "corridor will remain passable", "victim location confirmed without direct evidence"),
    "validation-required",
    {"priority": 2, "primary_outputs": ["verified deltas", "route reachability", "conflict queue"]},
)

DAMAGE_DELTA = ApplicationProfile(
    "damage-delta",
    "DamageDelta repeat-scan inspection ledger",
    "Compare stable components and uncertainty intervals across repeated scans to triage meaningful change.",
    ("component",),
    ("displacement",),
    0.70,
    None,
    ("capture/model hashes retained", "raw media retention is policy-controlled"),
    "Results are change candidates for professional review, not structural engineering certification or failure prediction.",
    ("component is structurally safe", "crack is harmless", "failure is imminent"),
    "demonstrated",
    {
        "priority": 3,
        "default_thresholds": {
            "displacement": 0.01,
            "clearance": 0.01,
            "surface_loss": 0.005,
        },
    },
)

PIPE_GRAPH = ApplicationProfile(
    "pipe-graph",
    "PipeGraph utility and duct topology",
    "Represent visible pipes, cables and ducts as centerline/radius graphs with junction and clearance lineage.",
    ("pipe_segment", "junction"),
    ("diameter",),
    0.60,
    None,
    ("occluded segments remain unknown",),
    "Geometry alone does not diagnose leaks, pressure, material condition, electrical safety or system capacity.",
    ("no leak", "pipe is safe", "utility identity inferred from appearance alone"),
    "reference-profile",
    {"priority": 4, "primary_outputs": ["centerline graph", "diameter intervals", "junction changes"]},
)

FIT_SCAN = ApplicationProfile(
    "fit-scan",
    "FitScan rehabilitation and orthotic pre-capture",
    "Capture bounded body/environment geometry with calibration and privacy metadata for professional review.",
    ("body_surface", "anatomical_landmark"),
    ("circumference", "length"),
    0.80,
    None,
    ("derived-only default", "personal identifiers excluded from public bundle", "explicit consent required"),
    "The profile is pre-capture and communication support. Clinical diagnosis, prescription and fabrication require validated medical workflows.",
    ("diagnosis", "clinical fit guaranteed", "device fabrication ready without validation"),
    "validation-required",
    {"priority": 5, "sensitivity": "health-data"},
)

HERITAGE_LEDGER = ApplicationProfile(
    "heritage-ledger",
    "HeritageLedger emergency documentation",
    "Record stable site/component identity, geometry, capture provenance and before/after events for conservation review.",
    ("site", "heritage_component"),
    (),
    0.60,
    None,
    ("capture and definition hashes retained", "location precision may be reduced for sensitive sites"),
    "Content hashes aid integrity checking but do not establish legal chain of custody, ownership, attribution or authenticity by themselves.",
    ("legal ownership proven", "authenticity proven", "chain of custody complete"),
    "reference-profile",
    {"priority": 6, "primary_outputs": ["evidence bundle", "change chronology", "offline viewer"]},
)

ECO_SCAN = ApplicationProfile(
    "eco-scan",
    "EcoScan crop, tree and environmental change map",
    "Build repeated spatial records of plants, trunks, canopy regions, banks or restoration plots.",
    ("plot", "plant"),
    ("diameter",),
    0.55,
    None,
    ("sensitive species/location tags may be redacted",),
    "The reference profile supports geometric change measurement; species, disease, yield and ecological condition require validated models and field protocols.",
    ("species confirmed from geometry alone", "disease diagnosed", "yield guaranteed"),
    "reference-profile",
    {"priority": 7, "primary_outputs": ["count", "growth intervals", "erosion/vegetation change"]},
)

APPLICATION_PROFILES: dict[str, ApplicationProfile] = {
    profile.id: profile
    for profile in (
        SAFE_ROUTE,
        RESCUE_TWIN,
        DAMAGE_DELTA,
        PIPE_GRAPH,
        FIT_SCAN,
        HERITAGE_LEDGER,
        ECO_SCAN,
    )
}


def get_application_profile(profile_id: str) -> ApplicationProfile:
    try:
        return APPLICATION_PROFILES[profile_id]
    except KeyError as exc:
        raise KeyError(f"unknown application profile {profile_id!r}") from exc


def validate_application_readiness(
    ledger: SpatialLedger,
    profile: str | ApplicationProfile,
) -> LedgerValidationReport:
    profile = get_application_profile(profile) if isinstance(profile, str) else profile
    profile.validate()
    issues: list[ValidationIssue] = []

    def error(code: str, path: str, message: str) -> None:
        issues.append(ValidationIssue("error", code, path, message))

    def warning(code: str, path: str, message: str) -> None:
        issues.append(ValidationIssue("warning", code, path, message))

    base = ledger.validate(raise_on_error=False)
    issues.extend(base.issues)
    if profile.id not in ledger.metadata.application_profiles:
        warning(
            "profile_not_declared",
            "metadata.application_profiles",
            f"ledger does not declare {profile.id}",
        )
    kinds = {node.kind for node in ledger.nodes.values()}
    for kind in profile.required_node_kinds:
        if kind not in kinds:
            error("required_node_kind_missing", "nodes", kind)
    measurement_names = {
        name for node in ledger.nodes.values() for name in node.measurements
    }
    measurement_names.update(
        name
        for edge in ledger.edges.values()
        for name, value in (
            ("doorway_width", edge.clearance),
            ("slope_degrees", edge.slope_degrees),
        )
        if value is not None
    )
    for measurement in profile.required_measurements:
        if measurement not in measurement_names:
            error("required_measurement_missing", "measurements", measurement)
    low_confidence = [
        observation.id
        for observation in ledger.observations.values()
        if observation.confidence < profile.minimum_observation_confidence
    ]
    if low_confidence:
        warning(
            "low_confidence_observations",
            "observations",
            f"{len(low_confidence)} observation(s) below profile floor",
        )
    if profile.route_query is not None:
        route_edges = [
            edge for edge in ledger.edges.values()
            if profile.route_query.mode in edge.allowed_modes
        ]
        if not route_edges:
            error(
                "route_mode_missing",
                "edges.allowed_modes",
                profile.route_query.mode,
            )
        unknown = [edge.id for edge in route_edges if edge.status == "unknown"]
        if unknown and not profile.route_query.allow_unknown:
            warning(
                "unknown_route_edges",
                "edges.status",
                f"{len(unknown)} edge(s) are unknown and excluded by the profile",
            )
    if profile.id == "fit-scan":
        raw = [capture.id for capture in ledger.captures.values() if capture.raw_media_retained]
        if raw:
            warning(
                "sensitive_raw_media",
                "captures",
                f"raw media retained for {len(raw)} capture(s); explicit health-data controls required",
            )
    metrics = dict(base.metrics)
    metrics.update(
        {
            "application_profile": profile.id,
            "profile_definition_hash": profile.definition_hash,
            "required_node_kinds": list(profile.required_node_kinds),
            "required_measurements": list(profile.required_measurements),
            "observations_below_profile_floor": len(low_confidence),
            "safety_boundary": profile.safety_boundary,
        }
    )
    return LedgerValidationReport(tuple(issues), metrics)


def application_profile_registry() -> dict[str, Any]:
    records = [APPLICATION_PROFILES[key].to_dict() for key in sorted(APPLICATION_PROFILES)]
    return {
        "schema": "ugts-kc-application-profile-registry-3.9.3",
        "profiles": records,
        "registry_hash": content_hash(records),
    }


__all__ = [
    "ApplicationProfile",
    "SAFE_ROUTE",
    "RESCUE_TWIN",
    "DAMAGE_DELTA",
    "PIPE_GRAPH",
    "FIT_SCAN",
    "HERITAGE_LEDGER",
    "ECO_SCAN",
    "APPLICATION_PROFILES",
    "get_application_profile",
    "validate_application_readiness",
    "application_profile_registry",
]
