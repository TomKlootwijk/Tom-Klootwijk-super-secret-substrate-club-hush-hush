"""Release identity for UGTS-KC 3.9.3 - KC Atlas Spatial Ledger Edition."""

__version__ = "3.9.3"
__codename__ = "KC Atlas"
__edition__ = "3.9.3 - KC Atlas Pocket Spatial Ledger Edition"
__game_project_schema__ = "ugts-kc-game-project-3.9"
__mobile3d_schema__ = "ugts-kc-mobile-3d-project-3.9.1"
__native_scene_pack__ = "KC3D392 / format 1 (retained Android baseline)"
__spatial_ledger_schema__ = "ugts-kc-spatial-ledger-3.9.3"
