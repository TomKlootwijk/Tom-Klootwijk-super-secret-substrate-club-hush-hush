"""Finite 64-bit local observation keys derived from the SCLP 3.6.2 profile.

The key is intentionally *not* a complete 3-D world identity.  It is a compact local
ray/time/phase address that can be used for candidate grouping, prefix refinement and
stable replay diagnostics.  Durable object identity remains a node ID plus lineage.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Iterable, Iterator, Mapping

RHO_BITS = 20
THETA_BITS = 18
FRAME_BITS = 14
PHASE_BITS = 12
TOTAL_BITS = RHO_BITS + THETA_BITS + FRAME_BITS + PHASE_BITS

RHO_MIN = -20.0
RHO_MAX = 0.0
TAU = math.tau

FIELD_WIDTHS: tuple[tuple[str, int], ...] = (
    ("rho", RHO_BITS),
    ("theta", THETA_BITS),
    ("frame", FRAME_BITS),
    ("phase", PHASE_BITS),
)


def _require_int(value: int, bits: int, label: str) -> int:
    value = int(value)
    if value < 0 or value >= (1 << bits):
        raise ValueError(f"{label} outside unsigned {bits}-bit range")
    return value


def _quantize_closed(value: float, lo: float, hi: float, bits: int, label: str) -> int:
    value = float(value)
    if not math.isfinite(value) or value < lo or value > hi:
        raise ValueError(f"{label} outside [{lo}, {hi}]")
    levels = (1 << bits) - 1
    if hi == lo:
        return 0
    return int(round((value - lo) * levels / (hi - lo)))


def _dequantize_closed(code: int, lo: float, hi: float, bits: int) -> float:
    code = _require_int(code, bits, "code")
    return lo + (hi - lo) * code / ((1 << bits) - 1)


def _quantize_periodic(value: float, period: float, bits: int, label: str) -> int:
    value = float(value)
    if not math.isfinite(value):
        raise ValueError(f"{label} must be finite")
    value %= period
    return min((1 << bits) - 1, int(math.floor(value * (1 << bits) / period)))


def _dequantize_periodic(code: int, period: float, bits: int) -> float:
    code = _require_int(code, bits, "code")
    return period * code / (1 << bits)


@dataclass(frozen=True, order=True)
class QuantizedObservationKey:
    """Exact integer tuple represented by either supported 64-bit layout."""

    rho: int
    theta: int
    frame: int
    phase: int

    def validate(self) -> None:
        _require_int(self.rho, RHO_BITS, "rho")
        _require_int(self.theta, THETA_BITS, "theta")
        _require_int(self.frame, FRAME_BITS, "frame")
        _require_int(self.phase, PHASE_BITS, "phase")

    def to_dict(self) -> dict[str, int]:
        self.validate()
        return {
            "rho": self.rho,
            "theta": self.theta,
            "frame": self.frame,
            "phase": self.phase,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, int]) -> "QuantizedObservationKey":
        result = cls(
            int(value["rho"]),
            int(value["theta"]),
            int(value["frame"]),
            int(value["phase"]),
        )
        result.validate()
        return result


@dataclass(frozen=True)
class ObservationKeySample:
    """Decoded local observation coordinate and its quantized tuple."""

    rho: float
    theta: float
    frame: int
    phase: float
    quantized: QuantizedObservationKey

    @property
    def radius_ratio(self) -> float:
        """Return r/r0.  The caller supplies the actual reference radius r0."""
        return math.exp(self.rho)


def quantize_observation_key(
    rho: float,
    theta: float,
    frame: int,
    phase: float,
) -> QuantizedObservationKey:
    result = QuantizedObservationKey(
        _quantize_closed(rho, RHO_MIN, RHO_MAX, RHO_BITS, "rho"),
        _quantize_periodic(theta, TAU, THETA_BITS, "theta"),
        _require_int(frame, FRAME_BITS, "frame"),
        _quantize_periodic(phase, TAU, PHASE_BITS, "phase"),
    )
    result.validate()
    return result


def decode_observation_key(value: QuantizedObservationKey) -> ObservationKeySample:
    value.validate()
    return ObservationKeySample(
        _dequantize_closed(value.rho, RHO_MIN, RHO_MAX, RHO_BITS),
        _dequantize_periodic(value.theta, TAU, THETA_BITS),
        value.frame,
        _dequantize_periodic(value.phase, TAU, PHASE_BITS),
        value,
    )


def pack_contiguous(value: QuantizedObservationKey) -> int:
    """Pack fields in SCLP contiguous ranges [63:44],[43:26],[25:12],[11:0]."""
    value.validate()
    return (
        (value.rho << 44)
        | (value.theta << 26)
        | (value.frame << 12)
        | value.phase
    )


def unpack_contiguous(word: int) -> QuantizedObservationKey:
    word = _require_int(word, 64, "word")
    return QuantizedObservationKey(
        (word >> 44) & ((1 << RHO_BITS) - 1),
        (word >> 26) & ((1 << THETA_BITS) - 1),
        (word >> 12) & ((1 << FRAME_BITS) - 1),
        word & ((1 << PHASE_BITS) - 1),
    )


def morton_schedule() -> tuple[tuple[str, int], ...]:
    """Return the exact 64-row MSB round-robin field schedule."""
    remaining = {name: width for name, width in FIELD_WIDTHS}
    result: list[tuple[str, int]] = []
    while any(remaining.values()):
        for name, _ in FIELD_WIDTHS:
            if remaining[name] > 0:
                remaining[name] -= 1
                result.append((name, remaining[name]))
    if len(result) != TOTAL_BITS:
        raise AssertionError("invalid Morton schedule")
    return tuple(result)


_MORTON_SCHEDULE = morton_schedule()


def pack_morton(value: QuantizedObservationKey) -> int:
    """Pack the tuple with the MSB round-robin schedule defined by SCLP 3.6.2."""
    value.validate()
    fields = value.to_dict()
    word = 0
    for name, source_bit in _MORTON_SCHEDULE:
        word = (word << 1) | ((fields[name] >> source_bit) & 1)
    return word


def unpack_morton(word: int) -> QuantizedObservationKey:
    word = _require_int(word, 64, "word")
    fields = {name: 0 for name, _ in FIELD_WIDTHS}
    for output_index, (name, source_bit) in enumerate(_MORTON_SCHEDULE):
        bit = (word >> (63 - output_index)) & 1
        fields[name] |= bit << source_bit
    return QuantizedObservationKey(
        fields["rho"], fields["theta"], fields["frame"], fields["phase"]
    )


def prefix_bounds(prefix: int, length: int) -> dict[str, tuple[int, int]]:
    """Return inclusive integer field bounds for a Morton prefix.

    The bounds are useful for deterministic candidate refinement.  They never imply
    Euclidean octree cells: the fields have different meanings and quantizers.
    """
    if length < 0 or length > 64:
        raise ValueError("prefix length must be in [0,64]")
    prefix = _require_int(prefix, length or 1, "prefix") if length else 0
    fixed: dict[str, dict[int, int]] = {name: {} for name, _ in FIELD_WIDTHS}
    for output_index, (name, source_bit) in enumerate(_MORTON_SCHEDULE[:length]):
        bit = (prefix >> (length - 1 - output_index)) & 1
        fixed[name][source_bit] = bit
    bounds: dict[str, tuple[int, int]] = {}
    for name, width in FIELD_WIDTHS:
        lo = 0
        hi = (1 << width) - 1
        for source_bit, bit in fixed[name].items():
            if bit:
                lo |= 1 << source_bit
            else:
                hi &= ~(1 << source_bit)
        bounds[name] = (lo, hi)
    return bounds


def iter_prefixes(word: int) -> Iterator[tuple[int, int, dict[str, tuple[int, int]]]]:
    """Yield ``(length, prefix, bounds)`` for all 64 refinements."""
    word = _require_int(word, 64, "word")
    prefix = 0
    for length in range(1, 65):
        prefix = (prefix << 1) | ((word >> (64 - length)) & 1)
        yield length, prefix, prefix_bounds(prefix, length)


__all__ = [
    "RHO_BITS",
    "THETA_BITS",
    "FRAME_BITS",
    "PHASE_BITS",
    "RHO_MIN",
    "RHO_MAX",
    "QuantizedObservationKey",
    "ObservationKeySample",
    "quantize_observation_key",
    "decode_observation_key",
    "pack_contiguous",
    "unpack_contiguous",
    "pack_morton",
    "unpack_morton",
    "morton_schedule",
    "prefix_bounds",
    "iter_prefixes",
]
