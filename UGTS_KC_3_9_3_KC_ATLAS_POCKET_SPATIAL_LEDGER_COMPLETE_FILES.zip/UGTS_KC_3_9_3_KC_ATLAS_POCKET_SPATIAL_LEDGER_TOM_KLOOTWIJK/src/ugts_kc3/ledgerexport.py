"""Self-contained offline HTML and evidence-bundle export for KC Atlas ledgers."""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import html
import json
import math
from pathlib import Path
from typing import Any, Mapping

from .spatialledger import (
    CHANGE_REPORT_SCHEMA,
    EVIDENCE_BUNDLE_SCHEMA,
    ChangeReport,
    PublicationPolicy,
    SpatialLedger,
    publication_view,
)


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _json_script(value: Any) -> str:
    # Prevent accidental closing of the script tag without changing JSON semantics.
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True).replace("</", "<\\/")


def _map_svg(ledger: SpatialLedger, width: int = 960, height: int = 520) -> str:
    if not ledger.nodes:
        return '<svg viewBox="0 0 960 240" role="img" aria-label="Empty spatial map"><text x="30" y="70">No map nodes</text></svg>'
    positions = {node.id: (node.position[0], node.position[2]) for node in ledger.nodes.values()}
    xs = [value[0] for value in positions.values()]
    ys = [value[1] for value in positions.values()]
    min_x, max_x = min(xs), max(xs)
    min_y, max_y = min(ys), max(ys)
    if math.isclose(min_x, max_x):
        min_x -= 1
        max_x += 1
    if math.isclose(min_y, max_y):
        min_y -= 1
        max_y += 1
    margin = 55

    def project(point: tuple[float, float]) -> tuple[float, float]:
        x = margin + (point[0] - min_x) / (max_x - min_x) * (width - 2 * margin)
        y = height - margin - (point[1] - min_y) / (max_y - min_y) * (height - 2 * margin)
        return x, y

    parts = [
        f'<svg class="map" viewBox="0 0 {width} {height}" role="img" aria-label="Spatial route graph">',
        '<defs><marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z"/></marker></defs>',
        f'<rect x="1" y="1" width="{width-2}" height="{height-2}" rx="18" class="map-bg"/>',
    ]
    for edge in sorted(ledger.edges.values(), key=lambda item: item.id):
        if edge.source not in positions or edge.target not in positions:
            continue
        x1, y1 = project(positions[edge.source])
        x2, y2 = project(positions[edge.target])
        label_x, label_y = (x1 + x2) / 2, (y1 + y2) / 2
        status = html.escape(edge.status)
        title = html.escape(
            f"{edge.id}: {edge.status}; {edge.length:.2f} m; confidence {edge.confidence:.2f}"
        )
        parts.append(
            f'<g class="edge edge-{status}"><title>{title}</title><line x1="{x1:.2f}" y1="{y1:.2f}" x2="{x2:.2f}" y2="{y2:.2f}" marker-end="url(#arrow)"/><text x="{label_x:.2f}" y="{label_y-7:.2f}">{html.escape(edge.id)}</text></g>'
        )
    for node in sorted(ledger.nodes.values(), key=lambda item: item.id):
        x, y = project(positions[node.id])
        label = html.escape(node.id)
        kind = html.escape(node.kind)
        title = html.escape(f"{node.id}: {node.kind}; state {node.state}; floor {node.floor_id}")
        if node.kind in {"door", "exit", "entrance"}:
            shape = f'<rect x="{x-10:.2f}" y="{y-10:.2f}" width="20" height="20" rx="3"/>'
        elif node.kind in {"hazard", "obstacle"}:
            shape = f'<path d="M {x:.2f} {y-13:.2f} L {x+12:.2f} {y+10:.2f} L {x-12:.2f} {y+10:.2f} Z"/>'
        else:
            shape = f'<circle cx="{x:.2f}" cy="{y:.2f}" r="11"/>'
        parts.append(
            f'<g class="node node-{kind}"><title>{title}</title>{shape}<text x="{x+15:.2f}" y="{y+4:.2f}">{label}</text></g>'
        )
    parts.append("</svg>")
    return "".join(parts)


def _change_rows(report: ChangeReport | None) -> str:
    if report is None:
        return '<p class="muted">No repeat-scan change report was supplied.</p>'
    rows = []
    for candidate in report.candidates:
        magnitude = "" if candidate.magnitude is None else f"{candidate.magnitude:.6g}"
        threshold = "" if candidate.threshold is None else f"{candidate.threshold:.6g}"
        rows.append(
            "<tr>"
            f'<td><span class="badge badge-{html.escape(candidate.classification)}">{html.escape(candidate.classification)}</span></td>'
            f"<td>{html.escape(candidate.target_type)}:{html.escape(candidate.target_id)}</td>"
            f"<td>{html.escape(candidate.field)}</td>"
            f"<td>{magnitude}</td>"
            f"<td>{threshold}</td>"
            f"<td>{candidate.confidence:.2f}</td>"
            f"<td>{html.escape(candidate.rationale)}</td>"
            "</tr>"
        )
    if not rows:
        rows.append('<tr><td colspan="7">No change candidates.</td></tr>')
    return (
        '<div class="table-wrap"><table><thead><tr><th>Class</th><th>Target</th><th>Field</th><th>Magnitude</th><th>Threshold</th><th>Confidence</th><th>Rationale</th></tr></thead><tbody>'
        + "".join(rows)
        + "</tbody></table></div>"
    )


def build_offline_html(
    ledger: SpatialLedger,
    change_report: ChangeReport | None = None,
    *,
    publication_policy: PublicationPolicy = PublicationPolicy(),
    title: str | None = None,
) -> str:
    """Return one network-independent HTML document."""
    validation = ledger.validate(raise_on_error=False)
    public_data = publication_view(ledger, publication_policy)
    report_data = None if change_report is None else change_report.to_dict()
    profiles = ", ".join(ledger.metadata.application_profiles) or "none declared"
    title = title or f"{ledger.metadata.title} - KC Atlas Offline Report"
    status = "PASS" if validation.passed else "REVIEW"
    issue_rows = "".join(
        f'<tr><td>{html.escape(issue.severity)}</td><td>{html.escape(issue.code)}</td><td>{html.escape(issue.path)}</td><td>{html.escape(issue.message)}</td></tr>'
        for issue in validation.issues
    ) or '<tr><td colspan="4">No validation issues.</td></tr>'
    change_summary = ""
    if change_report is not None:
        change_summary = " ".join(
            f'<span class="chip">{html.escape(name)}: {count}</span>'
            for name, count in sorted(change_report.summary.items())
        ) or '<span class="chip">no changes</span>'
    map_svg = _map_svg(ledger)
    ledger_hash = ledger.state_hash()
    return f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{html.escape(title)}</title>
<style>
:root{{--ink:#10243a;--muted:#5f6f7f;--panel:#f5f8fb;--line:#ccd7e1;--accent:#147d82;--gold:#d5a31b;--danger:#ba4a45;--ok:#2e7d55;--unknown:#77818c}}
*{{box-sizing:border-box}} body{{margin:0;font:15px/1.5 system-ui,-apple-system,Segoe UI,sans-serif;color:var(--ink);background:#edf2f6}}
header{{padding:40px max(24px,6vw);background:linear-gradient(135deg,#0c243a,#16465a);color:white}} header h1{{margin:0 0 8px;font-size:clamp(28px,5vw,52px);line-height:1.05}} header p{{margin:5px 0;color:#d6e5ee}}
main{{max-width:1220px;margin:auto;padding:28px}} section{{background:white;border:1px solid var(--line);border-radius:16px;padding:24px;margin:0 0 22px;box-shadow:0 4px 18px #17344d12}}
h2{{margin-top:0}} .grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px}} .card{{padding:15px;border-radius:12px;background:var(--panel);border:1px solid var(--line)}} .card strong{{font-size:24px;display:block}}
.status{{display:inline-block;padding:5px 10px;border-radius:999px;font-weight:700;background:#e8f4ee;color:var(--ok)}} .status.review{{background:#fff1e8;color:var(--danger)}}
.map{{width:100%;height:auto}} .map-bg{{fill:#f8fbfd;stroke:#d0dce5}} .edge line{{stroke-width:5;fill:none}} .edge text{{font-size:11px;fill:#42576b}} .edge-passable line,.edge-open line{{stroke:#2e7d55}} .edge-blocked line,.edge-closed line,.edge-hazard line{{stroke:#ba4a45;stroke-dasharray:12 7}} .edge-unknown line,.edge-restricted line{{stroke:#77818c;stroke-dasharray:6 6}} .node circle,.node rect,.node path{{fill:#147d82;stroke:white;stroke-width:3}} .node-door rect,.node-exit rect,.node-entrance rect{{fill:#d5a31b}} .node text{{font-size:12px;font-weight:650;fill:#10243a}}
.table-wrap{{overflow:auto}} table{{border-collapse:collapse;width:100%;min-width:720px}} th,td{{border-bottom:1px solid var(--line);padding:9px;text-align:left;vertical-align:top}} th{{background:#eef4f7}} code{{font-family:ui-monospace,SFMono-Regular,Consolas,monospace;word-break:break-all}}
.badge,.chip{{display:inline-block;border-radius:999px;padding:3px 8px;font-size:12px;background:#eaf0f4;margin:2px}} .badge-confirmed{{background:#ffe8e4;color:#8e302d}} .badge-review{{background:#fff4d6;color:#765800}} .badge-within_tolerance{{background:#e8f4ee;color:#245c42}} .badge-added,.badge-removed{{background:#e9e9ff;color:#3e3b81}}
.muted{{color:var(--muted)}} details{{margin-top:12px}} pre{{white-space:pre-wrap;max-height:420px;overflow:auto;background:#0d1f30;color:#d8e6ef;padding:18px;border-radius:12px}}
footer{{max-width:1220px;margin:auto;padding:0 28px 38px;color:var(--muted)}}
@media print{{body{{background:white}} section{{box-shadow:none;break-inside:avoid}} header{{background:#16384c!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}}}}
</style>
</head>
<body>
<header>
<h1>{html.escape(title)}</h1>
<p>UGTS-KC 3.9.3 KC Atlas - spatial evidence, topology, uncertainty and deterministic change lineage</p>
<p>Ledger <code>{html.escape(ledger.metadata.id)}</code> | State hash <code>{ledger_hash}</code></p>
</header>
<main>
<section>
<h2>Release view</h2>
<p><span class="status{' review' if not validation.passed else ''}">{status}</span> Application profiles: {html.escape(profiles)}</p>
<div class="grid">
<div class="card"><strong>{len(ledger.captures)}</strong>captures</div>
<div class="card"><strong>{len(ledger.observations)}</strong>observations</div>
<div class="card"><strong>{len(ledger.nodes)}</strong>stable nodes</div>
<div class="card"><strong>{len(ledger.edges)}</strong>route edges</div>
<div class="card"><strong>{sum(event.accepted for event in ledger.events)}</strong>accepted events</div>
<div class="card"><strong>{len(ledger.checkpoints)}</strong>checkpoints</div>
</div>
</section>
<section><h2>Spatial topology</h2>{map_svg}<p class="muted">The diagram is a downstream projection. Stable IDs, route status, measurements, evidence references and lineage remain authoritative in the ledger JSON.</p></section>
<section><h2>Repeat-scan change candidates</h2><p>{change_summary}</p>{_change_rows(change_report)}</section>
<section><h2>Validation</h2><div class="table-wrap"><table><thead><tr><th>Severity</th><th>Code</th><th>Path</th><th>Message</th></tr></thead><tbody>{issue_rows}</tbody></table></div></section>
<section><h2>Evidence and limitations</h2>
<p>The authoritative sequence is local support -&gt; compatibility -&gt; guard/error classification -&gt; verified proposal -&gt; deterministic commit -&gt; lineage and replay. Unknown or unobserved space is not promoted to clear space.</p>
<p>This report does not certify structural safety, regulatory compliance, medical diagnosis, legal chain of custody, leak absence, species identity or future passability. Application-specific validation remains required.</p>
<details><summary>Embedded publication ledger JSON</summary><pre id="ledger-json"></pre></details>
<details><summary>Embedded change report JSON</summary><pre id="change-json"></pre></details>
</section>
</main>
<footer>Self-contained offline output. No CDN, remote font, package manager or network asset is required.</footer>
<script type="application/json" id="ledger-data">{_json_script(public_data)}</script>
<script type="application/json" id="change-data">{_json_script(report_data)}</script>
<script>
for (const pair of [['ledger-data','ledger-json'],['change-data','change-json']]) {{
  const source=document.getElementById(pair[0]); const target=document.getElementById(pair[1]);
  try {{ target.textContent=JSON.stringify(JSON.parse(source.textContent),null,2); }} catch(e) {{ target.textContent='Unavailable'; }}
}}
</script>
</body></html>"""


@dataclass(frozen=True)
class EvidenceBundleResult:
    output_dir: Path
    report: Path
    ledger: Path
    change_report: Path | None
    manifest: Path
    files: tuple[Path, ...]

    @property
    def total_bytes(self) -> int:
        return sum(path.stat().st_size for path in self.files)


def write_evidence_bundle(
    ledger: SpatialLedger,
    output_dir: str | Path,
    change_report: ChangeReport | None = None,
    *,
    publication_policy: PublicationPolicy = PublicationPolicy(),
    clean: bool = True,
) -> EvidenceBundleResult:
    output_dir = Path(output_dir)
    if clean and output_dir.exists():
        for path in sorted(output_dir.rglob("*"), reverse=True):
            if path.is_file() or path.is_symlink():
                path.unlink()
            elif path.is_dir():
                path.rmdir()
    output_dir.mkdir(parents=True, exist_ok=True)
    ledger_path = output_dir / "ledger.json"
    ledger_path.write_text(
        json.dumps(publication_view(ledger, publication_policy), indent=2, sort_keys=True),
        encoding="utf-8",
    )
    change_path = None
    if change_report is not None:
        change_path = output_dir / "change-report.json"
        change_path.write_text(json.dumps(change_report.to_dict(), indent=2, sort_keys=True), encoding="utf-8")
    report_path = output_dir / "index.html"
    report_path.write_text(
        build_offline_html(ledger, change_report, publication_policy=publication_policy),
        encoding="utf-8",
    )
    data_files = [ledger_path, report_path] + ([] if change_path is None else [change_path])
    manifest_data = {
        "schema": EVIDENCE_BUNDLE_SCHEMA,
        "ledger_id": ledger.metadata.id,
        "ledger_state_hash": ledger.state_hash(),
        "publication_policy": {
            "include_raw_source_uris": publication_policy.include_raw_source_uris,
            "include_device_model": publication_policy.include_device_model,
            "coordinate_decimals": publication_policy.coordinate_decimals,
            "pseudonymize_author": publication_policy.pseudonymize_author,
            "include_private_attributes": publication_policy.include_private_attributes,
        },
        "files": [
            {"path": path.name, "bytes": path.stat().st_size, "sha256": _sha256_file(path)}
            for path in sorted(data_files, key=lambda p: p.name)
        ],
    }
    manifest_path = output_dir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest_data, indent=2, sort_keys=True), encoding="utf-8")
    files = tuple(sorted((*data_files, manifest_path), key=lambda p: p.name))
    return EvidenceBundleResult(output_dir, report_path, ledger_path, change_path, manifest_path, files)


def verify_evidence_bundle(output_dir: str | Path) -> dict[str, Any]:
    output_dir = Path(output_dir)
    manifest_path = output_dir / "manifest.json"
    data = json.loads(manifest_path.read_text(encoding="utf-8"))
    if data.get("schema") != EVIDENCE_BUNDLE_SCHEMA:
        raise ValueError("unsupported evidence-bundle schema")
    results = []
    passed = True
    for item in data.get("files", []):
        path = output_dir / str(item["path"])
        exists = path.is_file()
        actual = _sha256_file(path) if exists else None
        ok = exists and path.stat().st_size == int(item["bytes"]) and actual == item["sha256"]
        results.append({"path": item["path"], "exists": exists, "actual_sha256": actual, "passed": ok})
        passed = passed and ok
    return {
        "schema": "ugts-kc-spatial-evidence-bundle-verification-3.9.3",
        "passed": passed,
        "ledger_id": data.get("ledger_id"),
        "ledger_state_hash": data.get("ledger_state_hash"),
        "files": results,
    }


__all__ = [
    "build_offline_html",
    "EvidenceBundleResult",
    "write_evidence_bundle",
    "verify_evidence_bundle",
]
