"""UGTS-KC 3.9.3 KC Atlas spatial evidence and change-ledger substrate.

The module is deliberately query-first.  Perception systems emit typed observations and event
proposals; only support-, compatibility-, confidence- and error-gated proposals may mutate the
ledger.  Stable node/edge identity, uncertainty intervals, deterministic ordering and lineage are
kept separate from rendered meshes, raw video and downstream application reports.
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace
import copy
import hashlib
import heapq
import json
import math
from pathlib import Path
from typing import Any, Iterable, Mapping, MutableMapping, Sequence

from .math3d import quat_normalize

LEDGER_SCHEMA = "ugts-kc-spatial-ledger-3.9.3"
CHANGE_REPORT_SCHEMA = "ugts-kc-spatial-change-report-3.9.3"
EVIDENCE_BUNDLE_SCHEMA = "ugts-kc-spatial-evidence-bundle-3.9.3"

Vec3 = tuple[float, float, float]
Quat = tuple[float, float, float, float]

PASSABLE_STATUSES = {"passable", "open"}
KNOWN_EDGE_STATUSES = {
    "passable",
    "open",
    "blocked",
    "restricted",
    "unknown",
    "closed",
    "hazard",
}
KNOWN_GUARD_STATUSES = {"crossing", "touch", "tangency", "coincident", "inside", "outside"}


def _finite(value: float, label: str) -> float:
    value = float(value)
    if not math.isfinite(value):
        raise ValueError(f"{label} must be finite")
    return value


def _nonnegative(value: float, label: str) -> float:
    value = _finite(value, label)
    if value < 0:
        raise ValueError(f"{label} must be nonnegative")
    return value


def _probability(value: float, label: str = "confidence") -> float:
    value = _finite(value, label)
    if value < 0 or value > 1:
        raise ValueError(f"{label} must be in [0,1]")
    return value


def _vec3(value: Sequence[float], label: str) -> Vec3:
    if len(value) != 3:
        raise ValueError(f"{label} requires three values")
    return tuple(_finite(v, label) for v in value)  # type: ignore[return-value]


def _quat(value: Sequence[float], label: str = "rotation") -> Quat:
    if len(value) != 4:
        raise ValueError(f"{label} requires four values")
    q = tuple(_finite(v, label) for v in value)
    return tuple(quat_normalize(q))  # type: ignore[return-value]


def _normalized_json(value: Any) -> Any:
    if value is None or isinstance(value, (str, bool)):
        return value
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("non-finite number in canonical JSON")
        return int(value) if value.is_integer() else value
    if isinstance(value, Mapping):
        return {str(k): _normalized_json(v) for k, v in value.items()}
    if isinstance(value, (tuple, list, set)):
        values = list(value)
        if isinstance(value, set):
            values = sorted(values, key=str)
        return [_normalized_json(v) for v in values]
    if hasattr(value, "to_dict"):
        return _normalized_json(value.to_dict())
    raise TypeError(f"unsupported canonical JSON value: {type(value)!r}")


def canonical_json_bytes(value: Any) -> bytes:
    return json.dumps(
        _normalized_json(value),
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    ).encode("utf-8")


def content_hash(value: Any) -> str:
    return hashlib.sha256(canonical_json_bytes(value)).hexdigest()


def _sorted_records(records: Mapping[str, Any]) -> list[dict[str, Any]]:
    return [records[key].to_dict() for key in sorted(records)]


def _require_id(value: str, label: str = "id") -> str:
    value = str(value).strip()
    if not value:
        raise ValueError(f"{label} required")
    if any(ord(ch) < 32 for ch in value):
        raise ValueError(f"{label} contains control characters")
    return value


@dataclass(frozen=True)
class IntervalEstimate:
    """A scalar estimate with an explicit closed uncertainty interval."""

    value: float
    lower: float
    upper: float
    unit: str
    confidence: float = 1.0
    method: str = "declared"
    source_ids: tuple[str, ...] = ()

    def validate(self) -> None:
        value = _finite(self.value, "estimate value")
        lower = _finite(self.lower, "estimate lower")
        upper = _finite(self.upper, "estimate upper")
        if lower > value or value > upper:
            raise ValueError("estimate must lie inside [lower, upper]")
        if not self.unit:
            raise ValueError("estimate unit required")
        _probability(self.confidence)
        for source_id in self.source_ids:
            _require_id(source_id, "source id")

    @property
    def width(self) -> float:
        return self.upper - self.lower

    def overlaps(self, other: "IntervalEstimate", margin: float = 0.0) -> bool:
        if self.unit != other.unit:
            raise ValueError("cannot compare different units")
        margin = _nonnegative(margin, "margin")
        return not (self.upper + margin < other.lower or other.upper + margin < self.lower)

    def gap(self, other: "IntervalEstimate") -> float:
        if self.unit != other.unit:
            raise ValueError("cannot compare different units")
        if self.overlaps(other):
            return 0.0
        return max(other.lower - self.upper, self.lower - other.upper)

    def to_dict(self) -> dict[str, Any]:
        self.validate()
        return {
            "value": self.value,
            "lower": self.lower,
            "upper": self.upper,
            "unit": self.unit,
            "confidence": self.confidence,
            "method": self.method,
            "source_ids": list(self.source_ids),
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "IntervalEstimate":
        result = cls(
            float(data["value"]),
            float(data.get("lower", data["value"])),
            float(data.get("upper", data["value"])),
            str(data.get("unit", "unitless")),
            float(data.get("confidence", 1.0)),
            str(data.get("method", "declared")),
            tuple(str(v) for v in data.get("source_ids", ())),
        )
        result.validate()
        return result


@dataclass(frozen=True)
class PoseEstimate:
    translation: Vec3 = (0.0, 0.0, 0.0)
    rotation: Quat = (1.0, 0.0, 0.0, 0.0)
    translation_sigma: Vec3 = (0.0, 0.0, 0.0)
    rotation_sigma_degrees: Vec3 = (0.0, 0.0, 0.0)
    reference_frame: str = "world"

    def validate(self) -> None:
        _vec3(self.translation, "translation")
        _quat(self.rotation)
        if any(v < 0 for v in _vec3(self.translation_sigma, "translation sigma")):
            raise ValueError("translation sigma must be nonnegative")
        if any(v < 0 for v in _vec3(self.rotation_sigma_degrees, "rotation sigma")):
            raise ValueError("rotation sigma must be nonnegative")
        _require_id(self.reference_frame, "reference frame")

    @property
    def max_translation_sigma(self) -> float:
        return max(self.translation_sigma)

    def to_dict(self) -> dict[str, Any]:
        self.validate()
        return {
            "translation": list(self.translation),
            "rotation": list(self.rotation),
            "translation_sigma": list(self.translation_sigma),
            "rotation_sigma_degrees": list(self.rotation_sigma_degrees),
            "reference_frame": self.reference_frame,
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any] | None) -> "PoseEstimate":
        data = data or {}
        result = cls(
            _vec3(data.get("translation", (0, 0, 0)), "translation"),
            _quat(data.get("rotation", (1, 0, 0, 0))),
            _vec3(data.get("translation_sigma", (0, 0, 0)), "translation sigma"),
            _vec3(data.get("rotation_sigma_degrees", (0, 0, 0)), "rotation sigma"),
            str(data.get("reference_frame", "world")),
        )
        result.validate()
        return result


@dataclass(frozen=True)
class SupportVolume:
    """Finite local support used before semantic compatibility and event guards."""

    kind: str = "none"
    center: Vec3 = (0.0, 0.0, 0.0)
    half_extents: Vec3 = (0.0, 0.0, 0.0)
    axis: Vec3 = (0.0, 0.0, 1.0)
    radius: float = 0.0
    cone_cos: float = -1.0

    def validate(self) -> None:
        if self.kind not in {"none", "aabb", "sphere", "cone", "frustum"}:
            raise ValueError("unsupported support volume kind")
        _vec3(self.center, "support center")
        _vec3(self.axis, "support axis")
        if self.kind in {"aabb", "frustum"} and any(
            v < 0 for v in _vec3(self.half_extents, "support half extents")
        ):
            raise ValueError("support half extents must be nonnegative")
        if self.kind in {"sphere", "cone"}:
            _nonnegative(self.radius, "support radius")
        if self.kind == "cone" and not -1 <= self.cone_cos <= 1:
            raise ValueError("cone_cos must be in [-1,1]")

    def contains(self, point: Sequence[float]) -> bool:
        self.validate()
        p = _vec3(point, "point")
        if self.kind == "none":
            return True
        delta = tuple(p[i] - self.center[i] for i in range(3))
        if self.kind in {"aabb", "frustum"}:
            return all(abs(delta[i]) <= self.half_extents[i] for i in range(3))
        distance = math.sqrt(sum(v * v for v in delta))
        if distance > self.radius:
            return False
        if self.kind == "sphere" or distance == 0:
            return True
        axis_norm = math.sqrt(sum(v * v for v in self.axis))
        if axis_norm == 0:
            return False
        cosine = sum(delta[i] * self.axis[i] for i in range(3)) / (distance * axis_norm)
        return cosine >= self.cone_cos

    def to_dict(self) -> dict[str, Any]:
        self.validate()
        return {
            "kind": self.kind,
            "center": list(self.center),
            "half_extents": list(self.half_extents),
            "axis": list(self.axis),
            "radius": self.radius,
            "cone_cos": self.cone_cos,
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any] | None) -> "SupportVolume":
        data = data or {}
        result = cls(
            str(data.get("kind", "none")),
            _vec3(data.get("center", (0, 0, 0)), "support center"),
            _vec3(data.get("half_extents", (0, 0, 0)), "support half extents"),
            _vec3(data.get("axis", (0, 0, 1)), "support axis"),
            float(data.get("radius", 0.0)),
            float(data.get("cone_cos", -1.0)),
        )
        result.validate()
        return result


@dataclass(frozen=True)
class CaptureProfile:
    id: str
    device_model: str = "unspecified"
    sensor_mode: str = "monocular_video"
    coordinate_system: str = "right-handed-y-up"
    units_per_meter: float = 1.0
    calibration_hash: str = "unavailable"
    model_hash: str = "unavailable"
    metric_anchor: dict[str, Any] = field(default_factory=dict)
    privacy_mode: str = "derived-only"
    raw_media_retained: bool = False
    started_at: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)

    def validate(self) -> None:
        _require_id(self.id, "capture id")
        if self.sensor_mode not in {
            "monocular_video",
            "monocular_video_imu",
            "stereo_video",
            "rgbd",
            "manual_import",
            "synthetic",
        }:
            raise ValueError("unsupported sensor mode")
        if self.privacy_mode not in {"raw-retained", "derived-only", "redacted", "ephemeral"}:
            raise ValueError("unsupported privacy mode")
        if self.privacy_mode != "raw-retained" and self.raw_media_retained:
            raise ValueError("raw_media_retained conflicts with privacy_mode")
        if _finite(self.units_per_meter, "units_per_meter") <= 0:
            raise ValueError("units_per_meter must be positive")
        _finite(self.started_at, "started_at")
        canonical_json_bytes(self.metric_anchor)
        canonical_json_bytes(self.metadata)

    @property
    def definition_hash(self) -> str:
        return content_hash(self.to_dict())

    def to_dict(self) -> dict[str, Any]:
        self.validate()
        return {
            "id": self.id,
            "device_model": self.device_model,
            "sensor_mode": self.sensor_mode,
            "coordinate_system": self.coordinate_system,
            "units_per_meter": self.units_per_meter,
            "calibration_hash": self.calibration_hash,
            "model_hash": self.model_hash,
            "metric_anchor": self.metric_anchor,
            "privacy_mode": self.privacy_mode,
            "raw_media_retained": self.raw_media_retained,
            "started_at": self.started_at,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "CaptureProfile":
        result = cls(
            str(data["id"]),
            str(data.get("device_model", "unspecified")),
            str(data.get("sensor_mode", "monocular_video")),
            str(data.get("coordinate_system", "right-handed-y-up")),
            float(data.get("units_per_meter", 1.0)),
            str(data.get("calibration_hash", "unavailable")),
            str(data.get("model_hash", "unavailable")),
            dict(data.get("metric_anchor", {})),
            str(data.get("privacy_mode", "derived-only")),
            bool(data.get("raw_media_retained", False)),
            float(data.get("started_at", 0.0)),
            dict(data.get("metadata", {})),
        )
        result.validate()
        return result


@dataclass(frozen=True)
class Observation:
    id: str
    capture_id: str
    timestamp: float
    semantic_class: str
    target_id: str | None = None
    frame_ids: tuple[int, ...] = ()
    pose: PoseEstimate = PoseEstimate()
    support: SupportVolume = SupportVolume()
    confidence: float = 1.0
    numeric_error: float = 0.0
    event_margin: float = 0.0
    dynamic: bool = False
    attributes: dict[str, Any] = field(default_factory=dict)
    source_uri: str | None = None
    provenance_hash: str = ""

    def validate(self) -> None:
        _require_id(self.id, "observation id")
        _require_id(self.capture_id, "capture id")
        _finite(self.timestamp, "observation timestamp")
        _require_id(self.semantic_class, "semantic class")
        if self.target_id is not None:
            _require_id(self.target_id, "target id")
        if any(int(frame) < 0 for frame in self.frame_ids):
            raise ValueError("frame ids must be nonnegative")
        self.pose.validate()
        self.support.validate()
        _probability(self.confidence)
        _nonnegative(self.numeric_error, "numeric error")
        _nonnegative(self.event_margin, "event margin")
        canonical_json_bytes(self.attributes)

    def _payload_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "capture_id": self.capture_id,
            "timestamp": self.timestamp,
            "semantic_class": self.semantic_class,
            "target_id": self.target_id,
            "frame_ids": list(self.frame_ids),
            "pose": self.pose.to_dict(),
            "support": self.support.to_dict(),
            "confidence": self.confidence,
            "numeric_error": self.numeric_error,
            "event_margin": self.event_margin,
            "dynamic": self.dynamic,
            "attributes": self.attributes,
            "source_uri": self.source_uri,
        }

    @property
    def content_hash(self) -> str:
        return content_hash(self._payload_dict())

    @property
    def error_within_margin(self) -> bool:
        return self.numeric_error <= self.event_margin

    def to_dict(self) -> dict[str, Any]:
        self.validate()
        result = self._payload_dict()
        result["provenance_hash"] = self.provenance_hash or self.content_hash
        return result

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "Observation":
        result = cls(
            str(data["id"]),
            str(data["capture_id"]),
            float(data.get("timestamp", 0.0)),
            str(data.get("semantic_class", "unknown")),
            None if data.get("target_id") is None else str(data.get("target_id")),
            tuple(int(v) for v in data.get("frame_ids", ())),
            PoseEstimate.from_dict(data.get("pose")),
            SupportVolume.from_dict(data.get("support")),
            float(data.get("confidence", 1.0)),
            float(data.get("numeric_error", 0.0)),
            float(data.get("event_margin", 0.0)),
            bool(data.get("dynamic", False)),
            dict(data.get("attributes", {})),
            None if data.get("source_uri") is None else str(data.get("source_uri")),
            str(data.get("provenance_hash", "")),
        )
        result.validate()
        return result


@dataclass(frozen=True)
class MapNode:
    id: str
    kind: str
    pose: PoseEstimate = PoseEstimate()
    floor_id: str = "default"
    state: str = "observed"
    geometry_ref: str | None = None
    tags: tuple[str, ...] = ()
    measurements: dict[str, IntervalEstimate] = field(default_factory=dict)
    attributes: dict[str, Any] = field(default_factory=dict)
    evidence_ids: tuple[str, ...] = ()
    lineage: tuple[str, ...] = ()

    def validate(self) -> None:
        _require_id(self.id, "node id")
        _require_id(self.kind, "node kind")
        _require_id(self.floor_id, "floor id")
        self.pose.validate()
        for key, estimate in self.measurements.items():
            _require_id(key, "measurement id")
            estimate.validate()
        for value in (*self.evidence_ids, *self.lineage):
            _require_id(value, "node reference")
        canonical_json_bytes(self.attributes)

    @property
    def position(self) -> Vec3:
        return self.pose.translation

    def to_dict(self) -> dict[str, Any]:
        self.validate()
        return {
            "id": self.id,
            "kind": self.kind,
            "pose": self.pose.to_dict(),
            "floor_id": self.floor_id,
            "state": self.state,
            "geometry_ref": self.geometry_ref,
            "tags": list(self.tags),
            "measurements": {k: self.measurements[k].to_dict() for k in sorted(self.measurements)},
            "attributes": self.attributes,
            "evidence_ids": list(self.evidence_ids),
            "lineage": list(self.lineage),
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "MapNode":
        result = cls(
            str(data["id"]),
            str(data.get("kind", "unknown")),
            PoseEstimate.from_dict(data.get("pose")),
            str(data.get("floor_id", "default")),
            str(data.get("state", "observed")),
            None if data.get("geometry_ref") is None else str(data.get("geometry_ref")),
            tuple(str(v) for v in data.get("tags", ())),
            {
                str(k): IntervalEstimate.from_dict(v)
                for k, v in dict(data.get("measurements", {})).items()
            },
            dict(data.get("attributes", {})),
            tuple(str(v) for v in data.get("evidence_ids", ())),
            tuple(str(v) for v in data.get("lineage", ())),
        )
        result.validate()
        return result


@dataclass(frozen=True)
class RouteEdge:
    id: str
    source: str
    target: str
    route_class: str = "walk"
    length: float = 1.0
    clearance: IntervalEstimate | None = None
    slope_degrees: IntervalEstimate | None = None
    status: str = "unknown"
    allowed_modes: tuple[str, ...] = ("walk",)
    confidence: float = 1.0
    tags: tuple[str, ...] = ()
    evidence_ids: tuple[str, ...] = ()
    lineage: tuple[str, ...] = ()
    attributes: dict[str, Any] = field(default_factory=dict)

    def validate(self) -> None:
        _require_id(self.id, "edge id")
        _require_id(self.source, "edge source")
        _require_id(self.target, "edge target")
        if self.source == self.target:
            raise ValueError("route edge may not be a self-loop")
        _require_id(self.route_class, "route class")
        if _finite(self.length, "edge length") <= 0:
            raise ValueError("edge length must be positive")
        if self.clearance is not None:
            self.clearance.validate()
        if self.slope_degrees is not None:
            self.slope_degrees.validate()
        if self.status not in KNOWN_EDGE_STATUSES:
            raise ValueError("unknown route-edge status")
        if not self.allowed_modes:
            raise ValueError("route edge requires at least one allowed mode")
        _probability(self.confidence)
        for value in (*self.evidence_ids, *self.lineage):
            _require_id(value, "edge reference")
        canonical_json_bytes(self.attributes)

    def other(self, node_id: str) -> str:
        if node_id == self.source:
            return self.target
        if node_id == self.target:
            return self.source
        raise KeyError(node_id)

    def to_dict(self) -> dict[str, Any]:
        self.validate()
        return {
            "id": self.id,
            "source": self.source,
            "target": self.target,
            "route_class": self.route_class,
            "length": self.length,
            "clearance": None if self.clearance is None else self.clearance.to_dict(),
            "slope_degrees": None if self.slope_degrees is None else self.slope_degrees.to_dict(),
            "status": self.status,
            "allowed_modes": list(self.allowed_modes),
            "confidence": self.confidence,
            "tags": list(self.tags),
            "evidence_ids": list(self.evidence_ids),
            "lineage": list(self.lineage),
            "attributes": self.attributes,
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "RouteEdge":
        result = cls(
            str(data["id"]),
            str(data["source"]),
            str(data["target"]),
            str(data.get("route_class", "walk")),
            float(data.get("length", 1.0)),
            None if data.get("clearance") is None else IntervalEstimate.from_dict(data["clearance"]),
            None if data.get("slope_degrees") is None else IntervalEstimate.from_dict(data["slope_degrees"]),
            str(data.get("status", "unknown")),
            tuple(str(v) for v in data.get("allowed_modes", ("walk",))),
            float(data.get("confidence", 1.0)),
            tuple(str(v) for v in data.get("tags", ())),
            tuple(str(v) for v in data.get("evidence_ids", ())),
            tuple(str(v) for v in data.get("lineage", ())),
            dict(data.get("attributes", {})),
        )
        result.validate()
        return result


@dataclass(frozen=True)
class LedgerMetadata:
    id: str
    title: str
    author: str = ""
    created_at: float = 0.0
    coordinate_system: str = "right-handed-y-up"
    units: str = "meter"
    application_profiles: tuple[str, ...] = ()
    source_release: str = "UGTS-KC 3.9.2"
    notes: str = ""
    schema_version: str = LEDGER_SCHEMA
    definition_hashes: dict[str, str] = field(default_factory=dict)

    def validate(self) -> None:
        _require_id(self.id, "ledger id")
        if not self.title:
            raise ValueError("ledger title required")
        _finite(self.created_at, "created_at")
        if self.schema_version != LEDGER_SCHEMA:
            raise ValueError(f"unsupported ledger schema {self.schema_version!r}")
        canonical_json_bytes(self.definition_hashes)

    def to_dict(self) -> dict[str, Any]:
        self.validate()
        return {
            "id": self.id,
            "title": self.title,
            "author": self.author,
            "created_at": self.created_at,
            "coordinate_system": self.coordinate_system,
            "units": self.units,
            "application_profiles": list(self.application_profiles),
            "source_release": self.source_release,
            "notes": self.notes,
            "schema_version": self.schema_version,
            "definition_hashes": self.definition_hashes,
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "LedgerMetadata":
        result = cls(
            str(data["id"]),
            str(data.get("title", data["id"])),
            str(data.get("author", "")),
            float(data.get("created_at", 0.0)),
            str(data.get("coordinate_system", "right-handed-y-up")),
            str(data.get("units", "meter")),
            tuple(str(v) for v in data.get("application_profiles", ())),
            str(data.get("source_release", "UGTS-KC 3.9.2")),
            str(data.get("notes", "")),
            str(data.get("schema_version", LEDGER_SCHEMA)),
            {str(k): str(v) for k, v in dict(data.get("definition_hashes", {})).items()},
        )
        result.validate()
        return result


@dataclass(frozen=True)
class EventProposal:
    id: str
    event_time: float
    event_type: str
    target_type: str
    target_id: str
    patch: dict[str, Any] = field(default_factory=dict)
    operation: str = "update"
    source: str = "unknown"
    priority: int = 0
    confidence: float = 1.0
    guard_status: str = "crossing"
    numeric_error: float = 0.0
    event_margin: float = 0.0
    support_ok: bool = True
    compatibility_ok: bool = True
    evidence_ids: tuple[str, ...] = ()
    lineage_label: str = ""

    def validate(self) -> None:
        _require_id(self.id, "proposal id")
        _finite(self.event_time, "event time")
        _require_id(self.event_type, "event type")
        if self.target_type not in {"node", "edge", "ledger"}:
            raise ValueError("unsupported proposal target type")
        _require_id(self.target_id, "target id")
        if self.operation not in {"update", "add", "remove"}:
            raise ValueError("unsupported proposal operation")
        _probability(self.confidence)
        if self.guard_status not in KNOWN_GUARD_STATUSES:
            raise ValueError("unknown guard status")
        _nonnegative(self.numeric_error, "numeric error")
        _nonnegative(self.event_margin, "event margin")
        canonical_json_bytes(self.patch)
        for evidence_id in self.evidence_ids:
            _require_id(evidence_id, "evidence id")

    def verified(
        self,
        confidence_floor: float = 0.0,
        accepted_statuses: Sequence[str] = ("crossing", "touch", "inside"),
    ) -> tuple[bool, str]:
        self.validate()
        if not self.support_ok:
            return False, "outside_support"
        if not self.compatibility_ok:
            return False, "incompatible"
        if self.guard_status not in accepted_statuses:
            return False, f"guard_{self.guard_status}_not_accepted"
        if self.confidence < confidence_floor:
            return False, "confidence_below_floor"
        if self.numeric_error > self.event_margin:
            return False, "numeric_error_exceeds_margin"
        return True, "verified"

    @property
    def conflict_fields(self) -> frozenset[str]:
        if self.operation != "update":
            return frozenset({"*"})
        return frozenset(str(key) for key in self.patch)

    def to_dict(self) -> dict[str, Any]:
        self.validate()
        return {
            "id": self.id,
            "event_time": self.event_time,
            "event_type": self.event_type,
            "target_type": self.target_type,
            "target_id": self.target_id,
            "patch": self.patch,
            "operation": self.operation,
            "source": self.source,
            "priority": self.priority,
            "confidence": self.confidence,
            "guard_status": self.guard_status,
            "numeric_error": self.numeric_error,
            "event_margin": self.event_margin,
            "support_ok": self.support_ok,
            "compatibility_ok": self.compatibility_ok,
            "evidence_ids": list(self.evidence_ids),
            "lineage_label": self.lineage_label,
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "EventProposal":
        result = cls(
            str(data["id"]),
            float(data.get("event_time", 0.0)),
            str(data.get("event_type", "update")),
            str(data.get("target_type", "node")),
            str(data.get("target_id", "")),
            dict(data.get("patch", {})),
            str(data.get("operation", "update")),
            str(data.get("source", "unknown")),
            int(data.get("priority", 0)),
            float(data.get("confidence", 1.0)),
            str(data.get("guard_status", "crossing")),
            float(data.get("numeric_error", 0.0)),
            float(data.get("event_margin", 0.0)),
            bool(data.get("support_ok", True)),
            bool(data.get("compatibility_ok", True)),
            tuple(str(v) for v in data.get("evidence_ids", ())),
            str(data.get("lineage_label", "")),
        )
        result.validate()
        return result


@dataclass(frozen=True)
class LedgerEvent:
    sequence: int
    proposal: EventProposal
    accepted: bool
    decision_reason: str
    pre_hash: str
    post_hash: str

    def validate(self) -> None:
        if self.sequence < 1:
            raise ValueError("event sequence must be positive")
        self.proposal.validate()
        if len(self.pre_hash) != 64 or len(self.post_hash) != 64:
            raise ValueError("event hashes must be SHA-256 hex digests")
        if not self.accepted and self.pre_hash != self.post_hash:
            raise ValueError("rejected event may not change state")

    def to_dict(self) -> dict[str, Any]:
        self.validate()
        return {
            "sequence": self.sequence,
            "proposal": self.proposal.to_dict(),
            "accepted": self.accepted,
            "decision_reason": self.decision_reason,
            "pre_hash": self.pre_hash,
            "post_hash": self.post_hash,
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "LedgerEvent":
        result = cls(
            int(data["sequence"]),
            EventProposal.from_dict(data["proposal"]),
            bool(data.get("accepted", False)),
            str(data.get("decision_reason", "")),
            str(data.get("pre_hash", "")),
            str(data.get("post_hash", "")),
        )
        result.validate()
        return result


@dataclass(frozen=True)
class Checkpoint:
    sequence: int
    state_hash: str
    snapshot: dict[str, Any]

    def validate(self) -> None:
        if self.sequence < 0:
            raise ValueError("checkpoint sequence must be nonnegative")
        if len(self.state_hash) != 64:
            raise ValueError("checkpoint requires SHA-256 hash")
        canonical_json_bytes(self.snapshot)

    def to_dict(self) -> dict[str, Any]:
        self.validate()
        return {"sequence": self.sequence, "state_hash": self.state_hash, "snapshot": self.snapshot}

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "Checkpoint":
        result = cls(int(data["sequence"]), str(data["state_hash"]), dict(data["snapshot"]))
        result.validate()
        return result


@dataclass(frozen=True)
class ValidationIssue:
    severity: str
    code: str
    path: str
    message: str

    def to_dict(self) -> dict[str, str]:
        return {
            "severity": self.severity,
            "code": self.code,
            "path": self.path,
            "message": self.message,
        }


@dataclass(frozen=True)
class LedgerValidationReport:
    issues: tuple[ValidationIssue, ...]
    metrics: dict[str, Any]

    @property
    def passed(self) -> bool:
        return not any(issue.severity == "error" for issue in self.issues)

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": "ugts-kc-spatial-ledger-validation-3.9.3",
            "passed": self.passed,
            "issues": [issue.to_dict() for issue in self.issues],
            "metrics": self.metrics,
        }


@dataclass
class SpatialLedger:
    metadata: LedgerMetadata
    captures: dict[str, CaptureProfile] = field(default_factory=dict)
    observations: dict[str, Observation] = field(default_factory=dict)
    nodes: dict[str, MapNode] = field(default_factory=dict)
    edges: dict[str, RouteEdge] = field(default_factory=dict)
    events: list[LedgerEvent] = field(default_factory=list)
    checkpoints: list[Checkpoint] = field(default_factory=list)

    def clone(self, include_history: bool = True) -> "SpatialLedger":
        result = copy.deepcopy(self)
        if not include_history:
            result.events = []
            result.checkpoints = []
        return result

    def add_capture(self, capture: CaptureProfile) -> None:
        capture.validate()
        if capture.id in self.captures:
            raise KeyError(f"duplicate capture {capture.id}")
        self.captures[capture.id] = capture

    def add_observation(self, observation: Observation) -> None:
        observation.validate()
        if observation.id in self.observations:
            raise KeyError(f"duplicate observation {observation.id}")
        if observation.capture_id not in self.captures:
            raise KeyError(f"unknown capture {observation.capture_id}")
        self.observations[observation.id] = observation

    def add_node(self, node: MapNode) -> None:
        node.validate()
        if node.id in self.nodes:
            raise KeyError(f"duplicate node {node.id}")
        self.nodes[node.id] = node

    def add_edge(self, edge: RouteEdge) -> None:
        edge.validate()
        if edge.id in self.edges:
            raise KeyError(f"duplicate edge {edge.id}")
        if edge.source not in self.nodes or edge.target not in self.nodes:
            raise KeyError("edge endpoint missing")
        self.edges[edge.id] = edge

    def state_dict(self) -> dict[str, Any]:
        return {
            "schema": LEDGER_SCHEMA,
            "metadata": self.metadata.to_dict(),
            "captures": _sorted_records(self.captures),
            "observations": _sorted_records(self.observations),
            "nodes": _sorted_records(self.nodes),
            "edges": _sorted_records(self.edges),
        }

    def state_hash(self) -> str:
        return content_hash(self.state_dict())

    def to_dict(self, include_history: bool = True) -> dict[str, Any]:
        result = self.state_dict()
        if include_history:
            result["events"] = [event.to_dict() for event in self.events]
            result["checkpoints"] = [checkpoint.to_dict() for checkpoint in self.checkpoints]
        return result

    @classmethod
    def from_dict(cls, data: Mapping[str, Any], validate: bool = True) -> "SpatialLedger":
        schema = str(data.get("schema", data.get("metadata", {}).get("schema_version", LEDGER_SCHEMA)))
        if schema != LEDGER_SCHEMA:
            raise ValueError(f"unsupported ledger schema {schema!r}")
        ledger = cls(LedgerMetadata.from_dict(data["metadata"]))
        for item in data.get("captures", []):
            record = CaptureProfile.from_dict(item)
            if record.id in ledger.captures:
                raise ValueError(f"duplicate capture {record.id}")
            ledger.captures[record.id] = record
        for item in data.get("observations", []):
            record = Observation.from_dict(item)
            if record.id in ledger.observations:
                raise ValueError(f"duplicate observation {record.id}")
            ledger.observations[record.id] = record
        for item in data.get("nodes", []):
            record = MapNode.from_dict(item)
            if record.id in ledger.nodes:
                raise ValueError(f"duplicate node {record.id}")
            ledger.nodes[record.id] = record
        for item in data.get("edges", []):
            record = RouteEdge.from_dict(item)
            if record.id in ledger.edges:
                raise ValueError(f"duplicate edge {record.id}")
            ledger.edges[record.id] = record
        ledger.events = [LedgerEvent.from_dict(item) for item in data.get("events", [])]
        ledger.checkpoints = [Checkpoint.from_dict(item) for item in data.get("checkpoints", [])]
        if validate:
            ledger.validate(raise_on_error=True)
        return ledger

    @classmethod
    def load(cls, path: str | Path, validate: bool = True) -> "SpatialLedger":
        return cls.from_dict(json.loads(Path(path).read_text(encoding="utf-8")), validate=validate)

    def write(self, path: str | Path, include_history: bool = True) -> Path:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(self.to_dict(include_history), indent=2, sort_keys=True), encoding="utf-8")
        return path

    def validate(self, raise_on_error: bool = False) -> LedgerValidationReport:
        issues: list[ValidationIssue] = []

        def error(code: str, path: str, message: str) -> None:
            issues.append(ValidationIssue("error", code, path, message))

        def warning(code: str, path: str, message: str) -> None:
            issues.append(ValidationIssue("warning", code, path, message))

        try:
            self.metadata.validate()
        except (ValueError, TypeError) as exc:
            error("metadata_invalid", "metadata", str(exc))
        for capture_id, capture in sorted(self.captures.items()):
            try:
                capture.validate()
            except (ValueError, TypeError) as exc:
                error("capture_invalid", f"captures.{capture_id}", str(exc))
        for observation_id, observation in sorted(self.observations.items()):
            try:
                observation.validate()
            except (ValueError, TypeError) as exc:
                error("observation_invalid", f"observations.{observation_id}", str(exc))
            if observation.capture_id not in self.captures:
                error("capture_missing", f"observations.{observation_id}.capture_id", observation.capture_id)
            if observation.target_id and observation.target_id not in self.nodes and observation.target_id not in self.edges:
                warning("target_unresolved", f"observations.{observation_id}.target_id", observation.target_id)
            if observation.provenance_hash and observation.provenance_hash != observation.content_hash:
                error("observation_hash_mismatch", f"observations.{observation_id}.provenance_hash", "content hash does not verify")
        for node_id, node in sorted(self.nodes.items()):
            try:
                node.validate()
            except (ValueError, TypeError) as exc:
                error("node_invalid", f"nodes.{node_id}", str(exc))
            for evidence_id in node.evidence_ids:
                if evidence_id not in self.observations:
                    error("evidence_missing", f"nodes.{node_id}.evidence_ids", evidence_id)
        for edge_id, edge in sorted(self.edges.items()):
            try:
                edge.validate()
            except (ValueError, TypeError) as exc:
                error("edge_invalid", f"edges.{edge_id}", str(exc))
            if edge.source not in self.nodes:
                error("endpoint_missing", f"edges.{edge_id}.source", edge.source)
            if edge.target not in self.nodes:
                error("endpoint_missing", f"edges.{edge_id}.target", edge.target)
            for evidence_id in edge.evidence_ids:
                if evidence_id not in self.observations:
                    error("evidence_missing", f"edges.{edge_id}.evidence_ids", evidence_id)
        expected_sequence = 1
        last_post: str | None = None
        for index, event in enumerate(self.events):
            try:
                event.validate()
            except (ValueError, TypeError) as exc:
                error("event_invalid", f"events.{index}", str(exc))
            if event.sequence != expected_sequence:
                error("event_sequence_gap", f"events.{index}.sequence", f"expected {expected_sequence}")
            expected_sequence += 1
            if last_post is not None and event.pre_hash != last_post:
                error("event_hash_chain", f"events.{index}.pre_hash", "does not match prior post hash")
            last_post = event.post_hash
        for index, checkpoint in enumerate(self.checkpoints):
            try:
                checkpoint.validate()
            except (ValueError, TypeError) as exc:
                error("checkpoint_invalid", f"checkpoints.{index}", str(exc))
            if content_hash(checkpoint.snapshot) != checkpoint.state_hash:
                error("checkpoint_hash_mismatch", f"checkpoints.{index}.state_hash", "snapshot hash mismatch")
        if not self.nodes:
            warning("empty_map", "nodes", "ledger contains no map nodes")
        if self.edges and not self.nodes:
            error("edges_without_nodes", "edges", "route edges require nodes")
        unknown_edges = sum(edge.status == "unknown" for edge in self.edges.values())
        metrics = {
            "captures": len(self.captures),
            "observations": len(self.observations),
            "nodes": len(self.nodes),
            "edges": len(self.edges),
            "unknown_edges": unknown_edges,
            "events": len(self.events),
            "accepted_events": sum(event.accepted for event in self.events),
            "checkpoints": len(self.checkpoints),
            "state_hash": self.state_hash(),
            "application_profiles": list(self.metadata.application_profiles),
        }
        report = LedgerValidationReport(tuple(issues), metrics)
        if raise_on_error and not report.passed:
            messages = "; ".join(f"{i.path}: {i.message}" for i in issues if i.severity == "error")
            raise ValueError(messages)
        return report

    def _replace_target(self, target_type: str, target_id: str, data: Mapping[str, Any]) -> None:
        if target_type == "node":
            self.nodes[target_id] = MapNode.from_dict(data)
        elif target_type == "edge":
            self.edges[target_id] = RouteEdge.from_dict(data)
        elif target_type == "ledger":
            if target_id != self.metadata.id:
                raise KeyError(target_id)
            self.metadata = LedgerMetadata.from_dict(data)
        else:
            raise ValueError(target_type)

    def _target_dict(self, target_type: str, target_id: str) -> dict[str, Any]:
        if target_type == "node":
            return self.nodes[target_id].to_dict()
        if target_type == "edge":
            return self.edges[target_id].to_dict()
        if target_type == "ledger" and target_id == self.metadata.id:
            return self.metadata.to_dict()
        raise KeyError(target_id)

    def _apply_proposal(self, proposal: EventProposal) -> None:
        proposal.validate()
        if proposal.operation == "update":
            current = self._target_dict(proposal.target_type, proposal.target_id)
            unknown = set(proposal.patch) - set(current)
            if unknown:
                raise KeyError(f"unknown patch fields: {sorted(unknown)}")
            current.update(copy.deepcopy(proposal.patch))
            self._replace_target(proposal.target_type, proposal.target_id, current)
            return
        if proposal.operation == "add":
            if proposal.target_type == "ledger":
                raise ValueError("cannot add ledger metadata")
            if proposal.target_type == "node":
                if proposal.target_id in self.nodes:
                    raise KeyError(f"node exists: {proposal.target_id}")
                data = dict(proposal.patch)
                data.setdefault("id", proposal.target_id)
                self.add_node(MapNode.from_dict(data))
            else:
                if proposal.target_id in self.edges:
                    raise KeyError(f"edge exists: {proposal.target_id}")
                data = dict(proposal.patch)
                data.setdefault("id", proposal.target_id)
                self.add_edge(RouteEdge.from_dict(data))
            return
        if proposal.operation == "remove":
            if proposal.target_type == "node":
                if any(proposal.target_id in {edge.source, edge.target} for edge in self.edges.values()):
                    raise ValueError("cannot remove node while route edges reference it")
                del self.nodes[proposal.target_id]
            elif proposal.target_type == "edge":
                del self.edges[proposal.target_id]
            else:
                raise ValueError("cannot remove ledger metadata")
            return
        raise ValueError(proposal.operation)

    def commit_proposals(
        self,
        proposals: Iterable[EventProposal],
        *,
        confidence_floor: float = 0.0,
        accepted_statuses: Sequence[str] = ("crossing", "touch", "inside"),
    ) -> tuple[LedgerEvent, ...]:
        """Verify, order, resolve conflicts and apply proposals deterministically."""
        _probability(confidence_floor, "confidence floor")
        ordered = sorted(
            proposals,
            key=lambda p: (p.event_time, -p.priority, p.source, p.id),
        )
        decisions: list[LedgerEvent] = []
        claimed: dict[tuple[float, str, str], set[str]] = {}
        for proposal in ordered:
            pre_hash = self.state_hash()
            accepted, reason = proposal.verified(confidence_floor, accepted_statuses)
            key = (proposal.event_time, proposal.target_type, proposal.target_id)
            fields = proposal.conflict_fields
            existing = claimed.setdefault(key, set())
            if accepted and ("*" in existing or "*" in fields or existing.intersection(fields)):
                accepted = False
                reason = "conflict_rejected"
            if accepted:
                try:
                    self._apply_proposal(proposal)
                    existing.update(fields)
                except (KeyError, ValueError, TypeError) as exc:
                    accepted = False
                    reason = f"patch_rejected:{exc}"
            post_hash = self.state_hash()
            if not accepted and post_hash != pre_hash:
                raise AssertionError("rejected proposal mutated the ledger")
            event = LedgerEvent(
                len(self.events) + 1,
                proposal,
                accepted,
                reason,
                pre_hash,
                post_hash,
            )
            self.events.append(event)
            decisions.append(event)
        return tuple(decisions)

    def checkpoint(self) -> Checkpoint:
        snapshot = self.state_dict()
        checkpoint = Checkpoint(len(self.events), content_hash(snapshot), snapshot)
        self.checkpoints.append(checkpoint)
        return checkpoint

    @classmethod
    def replay(cls, base: "SpatialLedger", events: Sequence[LedgerEvent]) -> "SpatialLedger":
        result = base.clone(include_history=False)
        for event in events:
            event.validate()
            if result.state_hash() != event.pre_hash:
                raise ValueError(f"replay divergence before sequence {event.sequence}")
            if event.accepted:
                result._apply_proposal(event.proposal)
            if result.state_hash() != event.post_hash:
                raise ValueError(f"replay divergence after sequence {event.sequence}")
            result.events.append(event)
        return result


@dataclass(frozen=True)
class RouteQuery:
    mode: str = "walk"
    minimum_clearance: float = 0.0
    maximum_slope_degrees: float = 90.0
    allow_stairs: bool = True
    allow_unknown: bool = False
    confidence_floor: float = 0.0
    avoid_tags: tuple[str, ...] = ()

    def validate(self) -> None:
        _require_id(self.mode, "route mode")
        _nonnegative(self.minimum_clearance, "minimum clearance")
        _nonnegative(self.maximum_slope_degrees, "maximum slope")
        _probability(self.confidence_floor)


@dataclass(frozen=True)
class RouteResult:
    status: str
    node_ids: tuple[str, ...] = ()
    edge_ids: tuple[str, ...] = ()
    distance: float = math.inf
    bottleneck_clearance: float | None = None
    maximum_slope_degrees: float | None = None
    confidence: float = 0.0
    reason: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "node_ids": list(self.node_ids),
            "edge_ids": list(self.edge_ids),
            "distance": None if not math.isfinite(self.distance) else self.distance,
            "bottleneck_clearance": self.bottleneck_clearance,
            "maximum_slope_degrees": self.maximum_slope_degrees,
            "confidence": self.confidence,
            "reason": self.reason,
        }


def _edge_allowed(edge: RouteEdge, query: RouteQuery) -> tuple[bool, str]:
    if query.mode not in edge.allowed_modes:
        return False, "mode_not_allowed"
    if edge.status not in PASSABLE_STATUSES:
        if not (query.allow_unknown and edge.status == "unknown"):
            return False, f"status_{edge.status}"
    if not query.allow_stairs and edge.route_class in {"stairs", "ladder"}:
        return False, "stairs_not_allowed"
    if edge.confidence < query.confidence_floor:
        return False, "confidence_below_floor"
    if set(edge.tags).intersection(query.avoid_tags):
        return False, "avoided_tag"
    if edge.clearance is not None and edge.clearance.lower < query.minimum_clearance:
        return False, "clearance_below_requirement"
    if edge.slope_degrees is not None and edge.slope_degrees.upper > query.maximum_slope_degrees:
        return False, "slope_above_requirement"
    return True, "allowed"


def shortest_route(
    ledger: SpatialLedger,
    start: str,
    goal: str,
    query: RouteQuery = RouteQuery(),
) -> RouteResult:
    """Return a deterministic Dijkstra route over verified route edges."""
    query.validate()
    if start not in ledger.nodes:
        return RouteResult("invalid", reason=f"unknown start node {start}")
    if goal not in ledger.nodes:
        return RouteResult("invalid", reason=f"unknown goal node {goal}")
    if start == goal:
        return RouteResult("ok", (start,), (), 0.0, None, None, 1.0, "already at goal")
    adjacency: dict[str, list[RouteEdge]] = {node_id: [] for node_id in ledger.nodes}
    for edge in ledger.edges.values():
        allowed, _ = _edge_allowed(edge, query)
        if allowed:
            adjacency[edge.source].append(edge)
            adjacency[edge.target].append(edge)
    for edges in adjacency.values():
        edges.sort(key=lambda edge: edge.id)
    queue: list[tuple[float, tuple[str, ...], str]] = [(0.0, (), start)]
    best: dict[str, tuple[float, tuple[str, ...]]] = {start: (0.0, ())}
    previous: dict[str, tuple[str, str]] = {}
    while queue:
        distance, path_key, node_id = heapq.heappop(queue)
        if best.get(node_id) != (distance, path_key):
            continue
        if node_id == goal:
            break
        for edge in adjacency.get(node_id, ()):
            other = edge.other(node_id)
            penalty = 1.25 if edge.status == "unknown" else 1.0
            penalty *= 1.0 + max(0.0, 1.0 - edge.confidence)
            candidate = distance + edge.length * penalty
            candidate_key = path_key + (edge.id,)
            if other not in best or (candidate, candidate_key) < best[other]:
                best[other] = (candidate, candidate_key)
                previous[other] = (node_id, edge.id)
                heapq.heappush(queue, (candidate, candidate_key, other))
    if goal not in best:
        return RouteResult("unreachable", reason="no route satisfies the declared constraints")
    nodes = [goal]
    edges = []
    cursor = goal
    while cursor != start:
        prev, edge_id = previous[cursor]
        edges.append(edge_id)
        nodes.append(prev)
        cursor = prev
    nodes.reverse()
    edges.reverse()
    selected = [ledger.edges[edge_id] for edge_id in edges]
    clearance_values = [edge.clearance.lower for edge in selected if edge.clearance is not None]
    slope_values = [edge.slope_degrees.upper for edge in selected if edge.slope_degrees is not None]
    confidence = min((edge.confidence for edge in selected), default=1.0)
    return RouteResult(
        "ok",
        tuple(nodes),
        tuple(edges),
        sum(edge.length for edge in selected),
        min(clearance_values) if clearance_values else None,
        max(slope_values) if slope_values else None,
        confidence,
        "verified route",
    )


def reachable_nodes(ledger: SpatialLedger, start: str, query: RouteQuery = RouteQuery()) -> tuple[str, ...]:
    query.validate()
    if start not in ledger.nodes:
        raise KeyError(start)
    visited = {start}
    frontier = [start]
    while frontier:
        node_id = frontier.pop()
        for edge in sorted(ledger.edges.values(), key=lambda item: item.id):
            if node_id not in {edge.source, edge.target}:
                continue
            allowed, _ = _edge_allowed(edge, query)
            if not allowed:
                continue
            other = edge.other(node_id)
            if other not in visited:
                visited.add(other)
                frontier.append(other)
    return tuple(sorted(visited))


@dataclass(frozen=True)
class ChangePolicy:
    measurement_thresholds: dict[str, float] = field(default_factory=dict)
    position_threshold: float = 0.05
    confidence_floor: float = 0.5
    interval_margin: float = 0.0
    missing_is_change: bool = True

    def validate(self) -> None:
        _nonnegative(self.position_threshold, "position threshold")
        _probability(self.confidence_floor)
        _nonnegative(self.interval_margin, "interval margin")
        for name, value in self.measurement_thresholds.items():
            _require_id(name, "measurement threshold name")
            _nonnegative(value, f"threshold {name}")


@dataclass(frozen=True)
class ChangeCandidate:
    id: str
    target_type: str
    target_id: str
    field: str
    classification: str
    before: Any
    after: Any
    magnitude: float | None
    threshold: float | None
    confidence: float
    rationale: str
    evidence_ids: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "target_type": self.target_type,
            "target_id": self.target_id,
            "field": self.field,
            "classification": self.classification,
            "before": _normalized_json(self.before),
            "after": _normalized_json(self.after),
            "magnitude": self.magnitude,
            "threshold": self.threshold,
            "confidence": self.confidence,
            "rationale": self.rationale,
            "evidence_ids": list(self.evidence_ids),
        }


@dataclass(frozen=True)
class ChangeReport:
    baseline_ledger_id: str
    current_ledger_id: str
    baseline_hash: str
    current_hash: str
    candidates: tuple[ChangeCandidate, ...]
    policy: ChangePolicy

    @property
    def summary(self) -> dict[str, int]:
        result: dict[str, int] = {}
        for candidate in self.candidates:
            result[candidate.classification] = result.get(candidate.classification, 0) + 1
        return result

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": CHANGE_REPORT_SCHEMA,
            "baseline_ledger_id": self.baseline_ledger_id,
            "current_ledger_id": self.current_ledger_id,
            "baseline_hash": self.baseline_hash,
            "current_hash": self.current_hash,
            "summary": self.summary,
            "policy": {
                "measurement_thresholds": self.policy.measurement_thresholds,
                "position_threshold": self.policy.position_threshold,
                "confidence_floor": self.policy.confidence_floor,
                "interval_margin": self.policy.interval_margin,
                "missing_is_change": self.policy.missing_is_change,
            },
            "candidates": [candidate.to_dict() for candidate in self.candidates],
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "ChangeReport":
        if data.get("schema") != CHANGE_REPORT_SCHEMA:
            raise ValueError("unsupported change-report schema")
        policy_data = data.get("policy", {})
        policy = ChangePolicy(
            {str(k): float(v) for k, v in dict(policy_data.get("measurement_thresholds", {})).items()},
            float(policy_data.get("position_threshold", 0.05)),
            float(policy_data.get("confidence_floor", 0.5)),
            float(policy_data.get("interval_margin", 0.0)),
            bool(policy_data.get("missing_is_change", True)),
        )
        policy.validate()
        candidates = tuple(
            ChangeCandidate(
                str(item["id"]),
                str(item["target_type"]),
                str(item["target_id"]),
                str(item["field"]),
                str(item["classification"]),
                item.get("before"),
                item.get("after"),
                None if item.get("magnitude") is None else float(item["magnitude"]),
                None if item.get("threshold") is None else float(item["threshold"]),
                float(item.get("confidence", 0.0)),
                str(item.get("rationale", "")),
                tuple(str(v) for v in item.get("evidence_ids", ())),
            )
            for item in data.get("candidates", [])
        )
        return cls(
            str(data["baseline_ledger_id"]),
            str(data["current_ledger_id"]),
            str(data["baseline_hash"]),
            str(data["current_hash"]),
            candidates,
            policy,
        )


def _candidate_id(target_type: str, target_id: str, field_name: str, index: int) -> str:
    digest = hashlib.sha256(f"{target_type}|{target_id}|{field_name}|{index}".encode()).hexdigest()[:12]
    return f"change:{digest}"


def compare_ledgers(
    baseline: SpatialLedger,
    current: SpatialLedger,
    policy: ChangePolicy = ChangePolicy(),
) -> ChangeReport:
    """Compare stable node/edge identities and uncertainty-aware measurements."""
    policy.validate()
    candidates: list[ChangeCandidate] = []

    def add(
        target_type: str,
        target_id: str,
        field_name: str,
        classification: str,
        before: Any,
        after: Any,
        magnitude: float | None,
        threshold: float | None,
        confidence: float,
        rationale: str,
        evidence_ids: Sequence[str] = (),
    ) -> None:
        candidates.append(
            ChangeCandidate(
                _candidate_id(target_type, target_id, field_name, len(candidates)),
                target_type,
                target_id,
                field_name,
                classification,
                before,
                after,
                magnitude,
                threshold,
                confidence,
                rationale,
                tuple(evidence_ids),
            )
        )

    baseline_nodes = set(baseline.nodes)
    current_nodes = set(current.nodes)
    if policy.missing_is_change:
        for node_id in sorted(baseline_nodes - current_nodes):
            node = baseline.nodes[node_id]
            add("node", node_id, "presence", "removed", node.to_dict(), None, None, None, 1.0, "stable node absent in current ledger", node.evidence_ids)
        for node_id in sorted(current_nodes - baseline_nodes):
            node = current.nodes[node_id]
            add("node", node_id, "presence", "added", None, node.to_dict(), None, None, 1.0, "new stable node in current ledger", node.evidence_ids)
    for node_id in sorted(baseline_nodes & current_nodes):
        before = baseline.nodes[node_id]
        after = current.nodes[node_id]
        if before.state != after.state:
            confidence = min(
                [estimate.confidence for estimate in after.measurements.values()] or [1.0]
            )
            classification = "confirmed" if confidence >= policy.confidence_floor else "review"
            add("node", node_id, "state", classification, before.state, after.state, None, None, confidence, "node state changed", after.evidence_ids)
        displacement = math.sqrt(sum((after.position[i] - before.position[i]) ** 2 for i in range(3)))
        if displacement > 0:
            pose_error = before.pose.max_translation_sigma + after.pose.max_translation_sigma
            if displacement - pose_error > policy.position_threshold:
                classification = "confirmed"
                rationale = "displacement exceeds pose uncertainty and threshold"
            elif displacement > policy.position_threshold:
                classification = "review"
                rationale = "displacement estimate exceeds threshold but overlaps pose uncertainty"
            else:
                classification = "within_tolerance"
                rationale = "displacement remains within threshold"
            add("node", node_id, "pose.translation", classification, list(before.position), list(after.position), displacement, policy.position_threshold, min(1.0, 1.0 / (1.0 + pose_error)), rationale, after.evidence_ids)
        measurement_names = set(before.measurements) | set(after.measurements)
        for name in sorted(measurement_names):
            b = before.measurements.get(name)
            a = after.measurements.get(name)
            if b is None or a is None:
                if policy.missing_is_change:
                    add("node", node_id, f"measurements.{name}", "added" if b is None else "removed", None if b is None else b.to_dict(), None if a is None else a.to_dict(), None, policy.measurement_thresholds.get(name), 1.0, "measurement presence changed", after.evidence_ids)
                continue
            if b.unit != a.unit:
                add("node", node_id, f"measurements.{name}", "review", b.to_dict(), a.to_dict(), None, None, min(b.confidence, a.confidence), "measurement units differ", after.evidence_ids)
                continue
            threshold = policy.measurement_thresholds.get(name, 0.0)
            magnitude = abs(a.value - b.value)
            confidence = min(b.confidence, a.confidence)
            if magnitude <= threshold:
                classification = "within_tolerance"
                rationale = "estimate delta is at or below threshold"
            elif not b.overlaps(a, policy.interval_margin) and b.gap(a) > threshold:
                classification = "confirmed" if confidence >= policy.confidence_floor else "review"
                rationale = "uncertainty intervals are separated beyond threshold"
            else:
                classification = "review"
                rationale = "estimate delta exceeds threshold but uncertainty intervals overlap"
            add("node", node_id, f"measurements.{name}", classification, b.to_dict(), a.to_dict(), magnitude, threshold, confidence, rationale, after.evidence_ids)

    baseline_edges = set(baseline.edges)
    current_edges = set(current.edges)
    if policy.missing_is_change:
        for edge_id in sorted(baseline_edges - current_edges):
            edge = baseline.edges[edge_id]
            add("edge", edge_id, "presence", "removed", edge.to_dict(), None, None, None, 1.0, "stable route edge absent", edge.evidence_ids)
        for edge_id in sorted(current_edges - baseline_edges):
            edge = current.edges[edge_id]
            add("edge", edge_id, "presence", "added", None, edge.to_dict(), None, None, 1.0, "new route edge", edge.evidence_ids)
    for edge_id in sorted(baseline_edges & current_edges):
        before = baseline.edges[edge_id]
        after = current.edges[edge_id]
        if before.status != after.status:
            confidence = min(before.confidence, after.confidence)
            classification = "confirmed" if confidence >= policy.confidence_floor else "review"
            add("edge", edge_id, "status", classification, before.status, after.status, None, None, confidence, "route status changed", after.evidence_ids)
        for name in ("clearance", "slope_degrees"):
            b = getattr(before, name)
            a = getattr(after, name)
            if b is None or a is None:
                continue
            threshold_key = "doorway_width" if name == "clearance" else "slope_degrees"
            threshold = policy.measurement_thresholds.get(threshold_key, 0.0)
            magnitude = abs(a.value - b.value)
            if magnitude <= threshold:
                classification = "within_tolerance"
                rationale = "edge measurement within threshold"
            elif not b.overlaps(a, policy.interval_margin) and b.gap(a) > threshold:
                classification = "confirmed" if min(a.confidence, b.confidence) >= policy.confidence_floor else "review"
                rationale = "edge measurement intervals separated beyond threshold"
            else:
                classification = "review"
                rationale = "edge measurement requires review"
            add("edge", edge_id, name, classification, b.to_dict(), a.to_dict(), magnitude, threshold, min(a.confidence, b.confidence), rationale, after.evidence_ids)

    return ChangeReport(
        baseline.metadata.id,
        current.metadata.id,
        baseline.state_hash(),
        current.state_hash(),
        tuple(candidates),
        policy,
    )


@dataclass(frozen=True)
class PublicationPolicy:
    include_raw_source_uris: bool = False
    include_device_model: bool = True
    coordinate_decimals: int = 3
    pseudonymize_author: bool = False
    include_private_attributes: bool = False

    def validate(self) -> None:
        if self.coordinate_decimals < 0 or self.coordinate_decimals > 9:
            raise ValueError("coordinate_decimals must be in [0,9]")


def _round_recursive(value: Any, decimals: int) -> Any:
    if isinstance(value, float):
        return round(value, decimals)
    if isinstance(value, list):
        return [_round_recursive(v, decimals) for v in value]
    if isinstance(value, dict):
        return {k: _round_recursive(v, decimals) for k, v in value.items()}
    return value


def publication_view(ledger: SpatialLedger, policy: PublicationPolicy = PublicationPolicy()) -> dict[str, Any]:
    """Return a privacy-filtered, precision-bounded publication record."""
    policy.validate()
    data = ledger.to_dict(include_history=True)
    if policy.pseudonymize_author:
        data["metadata"]["author"] = "field-operator"
    for capture in data.get("captures", []):
        if not policy.include_device_model:
            capture["device_model"] = "redacted"
        if not policy.include_private_attributes:
            capture["metadata"] = {
                key: value for key, value in capture.get("metadata", {}).items()
                if not str(key).startswith("private_")
            }
    for observation in data.get("observations", []):
        if not policy.include_raw_source_uris:
            observation["source_uri"] = None
        if not policy.include_private_attributes:
            observation["attributes"] = {
                key: value for key, value in observation.get("attributes", {}).items()
                if not str(key).startswith("private_")
            }
    for collection in ("nodes", "edges"):
        for item in data.get(collection, []):
            if not policy.include_private_attributes:
                item["attributes"] = {
                    key: value for key, value in item.get("attributes", {}).items()
                    if not str(key).startswith("private_")
                }
    return _round_recursive(data, policy.coordinate_decimals)


@dataclass(frozen=True)
class FrameObservationProposal:
    id: str
    kind: str
    semantic_class: str
    pose: PoseEstimate
    confidence: float
    numeric_error: float
    event_margin: float
    target_id: str | None = None
    attributes: dict[str, Any] = field(default_factory=dict)

    def validate(self) -> None:
        _require_id(self.id, "frame proposal id")
        _require_id(self.kind, "frame proposal kind")
        _require_id(self.semantic_class, "semantic class")
        self.pose.validate()
        _probability(self.confidence)
        _nonnegative(self.numeric_error, "numeric error")
        _nonnegative(self.event_margin, "event margin")
        canonical_json_bytes(self.attributes)

    def to_dict(self) -> dict[str, Any]:
        self.validate()
        return {
            "id": self.id,
            "kind": self.kind,
            "semantic_class": self.semantic_class,
            "pose": self.pose.to_dict(),
            "confidence": self.confidence,
            "numeric_error": self.numeric_error,
            "event_margin": self.event_margin,
            "target_id": self.target_id,
            "attributes": self.attributes,
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "FrameObservationProposal":
        result = cls(
            str(data["id"]),
            str(data["kind"]),
            str(data.get("semantic_class", "unknown")),
            PoseEstimate.from_dict(data.get("pose")),
            float(data.get("confidence", 1.0)),
            float(data.get("numeric_error", 0.0)),
            float(data.get("event_margin", 0.0)),
            None if data.get("target_id") is None else str(data.get("target_id")),
            dict(data.get("attributes", {})),
        )
        result.validate()
        return result


@dataclass(frozen=True)
class FrameObservationPacket:
    """Adapter boundary for a future mobile perception front end.

    The packet contains proposals only.  A camera, transformer or SLAM system is not allowed to
    mutate ledger state directly.
    """

    capture_id: str
    frame_index: int
    timestamp: float
    camera_pose: PoseEstimate
    intrinsics: tuple[float, float, float, float]
    model_hash: str
    keyframe: bool
    proposals: tuple[FrameObservationProposal, ...]
    dynamic_mask_present: bool = False
    packet_hash: str = ""

    def validate(self) -> None:
        _require_id(self.capture_id, "capture id")
        if self.frame_index < 0:
            raise ValueError("frame index must be nonnegative")
        _finite(self.timestamp, "frame timestamp")
        self.camera_pose.validate()
        if len(self.intrinsics) != 4 or not all(math.isfinite(float(v)) for v in self.intrinsics):
            raise ValueError("intrinsics must be finite fx,fy,cx,cy")
        if self.intrinsics[0] <= 0 or self.intrinsics[1] <= 0:
            raise ValueError("focal lengths must be positive")
        for proposal in self.proposals:
            proposal.validate()
        if self.packet_hash and self.packet_hash != self.content_hash:
            raise ValueError("packet hash mismatch")

    @property
    def content_hash(self) -> str:
        data = self.to_dict(include_hash=False)
        return content_hash(data)

    def to_dict(self, include_hash: bool = True) -> dict[str, Any]:
        result = {
            "schema": "ugts-kc-frame-observation-packet-3.9.3",
            "capture_id": self.capture_id,
            "frame_index": self.frame_index,
            "timestamp": self.timestamp,
            "camera_pose": self.camera_pose.to_dict(),
            "intrinsics": list(self.intrinsics),
            "model_hash": self.model_hash,
            "keyframe": self.keyframe,
            "dynamic_mask_present": self.dynamic_mask_present,
            "proposals": [proposal.to_dict() for proposal in self.proposals],
        }
        if include_hash:
            result["packet_hash"] = self.packet_hash or content_hash(result)
        return result

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "FrameObservationPacket":
        if data.get("schema") not in {None, "ugts-kc-frame-observation-packet-3.9.3"}:
            raise ValueError("unsupported frame packet schema")
        result = cls(
            str(data["capture_id"]),
            int(data["frame_index"]),
            float(data["timestamp"]),
            PoseEstimate.from_dict(data.get("camera_pose")),
            tuple(float(v) for v in data["intrinsics"]),  # type: ignore[arg-type]
            str(data.get("model_hash", "unavailable")),
            bool(data.get("keyframe", False)),
            tuple(FrameObservationProposal.from_dict(v) for v in data.get("proposals", [])),
            bool(data.get("dynamic_mask_present", False)),
            str(data.get("packet_hash", "")),
        )
        result.validate()
        return result

    def observations(self, support: SupportVolume | None = None) -> tuple[Observation, ...]:
        result = []
        for proposal in self.proposals:
            result.append(
                Observation(
                    proposal.id,
                    self.capture_id,
                    self.timestamp,
                    proposal.semantic_class,
                    proposal.target_id,
                    (self.frame_index,),
                    proposal.pose,
                    support or SupportVolume("cone", self.camera_pose.translation, axis=(0, 0, 1), radius=20.0, cone_cos=0.4),
                    proposal.confidence,
                    proposal.numeric_error,
                    proposal.event_margin,
                    proposal.kind == "dynamic_object",
                    dict(proposal.attributes),
                    None,
                    "",
                )
            )
        return tuple(result)


__all__ = [
    "LEDGER_SCHEMA",
    "CHANGE_REPORT_SCHEMA",
    "EVIDENCE_BUNDLE_SCHEMA",
    "canonical_json_bytes",
    "content_hash",
    "IntervalEstimate",
    "PoseEstimate",
    "SupportVolume",
    "CaptureProfile",
    "Observation",
    "MapNode",
    "RouteEdge",
    "LedgerMetadata",
    "EventProposal",
    "LedgerEvent",
    "Checkpoint",
    "ValidationIssue",
    "LedgerValidationReport",
    "SpatialLedger",
    "RouteQuery",
    "RouteResult",
    "shortest_route",
    "reachable_nodes",
    "ChangePolicy",
    "ChangeCandidate",
    "ChangeReport",
    "compare_ledgers",
    "PublicationPolicy",
    "publication_view",
    "FrameObservationProposal",
    "FrameObservationPacket",
]
