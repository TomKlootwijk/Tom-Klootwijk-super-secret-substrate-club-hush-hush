# Notice and Evidence Boundary

Prepared for Tom Klootwijk. The name is requester-supplied project attribution and is not independently verified.

This package is a technical design artifact and reference implementation. It is not legal proof of authorship, ownership, patentability, priority or exclusive rights. The supplied UGTS PDFs are referenced by filename and SHA-256 in `spec/source_register.json` and are not redistributed inside this package.

The implementation is intended for education, research, testing and bounded solver development. It does not claim a full game-theoretic solution of standard chess, commercial engine strength, cross-platform bit identity, or external certification. The bundled KQK/KRK tablebases and mate proofs are exact only under the declared rules and state models.

FIDE and Syzygy names identify external rules or tablebase context. They do not imply endorsement.
