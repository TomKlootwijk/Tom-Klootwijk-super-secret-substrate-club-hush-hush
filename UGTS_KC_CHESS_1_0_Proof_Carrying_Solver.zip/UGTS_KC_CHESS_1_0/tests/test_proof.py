from __future__ import annotations

import copy
import unittest

from ugts_chess.position import Position
from ugts_chess.proof import MateProver, verify_mate_certificate


class MateProofTests(unittest.TestCase):
    FEN = "8/8/8/8/8/k7/8/1QK5 w - - 0 1"

    def test_01_proves_mate_within_three_plies(self) -> None:
        result = MateProver().prove(Position.from_fen(self.FEN), max_plies=3)
        self.assertEqual(result.status, "proved")
        self.assertEqual(result.certificate["tree"]["move"], "b1b5")

    def test_02_independent_verifier_accepts(self) -> None:
        cert = MateProver().prove(Position.from_fen(self.FEN), max_plies=3).certificate
        verified = verify_mate_certificate(cert)
        self.assertTrue(verified["valid"])
        self.assertGreaterEqual(verified["verified_nodes"], 4)

    def test_03_short_horizon_is_not_proved(self) -> None:
        result = MateProver().prove(Position.from_fen(self.FEN), max_plies=1)
        self.assertEqual(result.status, "not_forced_within_horizon")

    def test_04_tampered_move_fails(self) -> None:
        cert = MateProver().prove(Position.from_fen(self.FEN), max_plies=3).certificate
        tampered = copy.deepcopy(cert)
        tampered["tree"]["move"] = "b1b2"
        with self.assertRaises(ValueError):
            verify_mate_certificate(tampered)

    def test_05_missing_defender_reply_fails(self) -> None:
        # Use a position whose first defender node has one reply, then remove it.
        cert = MateProver().prove(Position.from_fen(self.FEN), max_plies=3).certificate
        tampered = copy.deepcopy(cert)
        tampered["tree"]["child"]["replies"] = []
        with self.assertRaises(ValueError):
            verify_mate_certificate(tampered)

    def test_06_root_hash_tamper_fails(self) -> None:
        cert = MateProver().prove(Position.from_fen(self.FEN), max_plies=3).certificate
        cert = copy.deepcopy(cert)
        cert["root_hash"] = "f" * 64
        with self.assertRaises(ValueError):
            verify_mate_certificate(cert)


if __name__ == "__main__":
    unittest.main()
