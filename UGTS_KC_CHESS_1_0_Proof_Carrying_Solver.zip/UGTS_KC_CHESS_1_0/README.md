# UGTS-KC Chess 1.0

A dependency-free Python reference package that maps standard chess into the UGTS support -> compatibility -> guard -> verified event -> deterministic transition -> lineage sequence.

## What is exact

- FEN parsing and legal move generation, including castling, en-passant and promotion.
- Check, checkmate, stalemate, a conservative exact dead-position subset, and move-count/repetition draw policies.
- Hash-chained move events and replay.
- Forced-mate certificates within a declared finite ply horizon, with an independent verifier.
- Complete KQK and KRK win/draw/loss plus depth-to-mate tablebases over every legal cell in their three-piece state spaces.
- 65 automated tests, including the standard six perft regression positions through depth 3 and the initial position through depth 4.

## What is heuristic

The general alpha-beta engine uses a transparent material/piece-square evaluation, quiescence, iterative deepening and a transposition table. Its non-mate scores are search estimates, not proofs.

## Evidence boundary

This package does **not** claim that the standard initial chess position has been weakly or strongly solved. It provides a proof-carrying solver substrate, exact bounded results and a distributed proof architecture that could be expanded with more tablebases and compute.

## Quick start

```bash
cd UGTS_KC_CHESS_1_0
PYTHONPATH=src python -m unittest discover -s tests -v
PYTHONPATH=src python -m ugts_chess info
PYTHONPATH=src python -m ugts_chess perft --depth 4
PYTHONPATH=src python -m ugts_chess solve --depth 4 \
  --fen "8/8/8/8/8/k7/8/1QK5 w - - 0 1"
PYTHONPATH=src python -m ugts_chess prove-mate --plies 3 \
  --fen "8/8/8/8/8/k7/8/1QK5 w - - 0 1" \
  --out examples/mate_in_two_proof.json
PYTHONPATH=src python -m ugts_chess verify-proof examples/mate_in_two_proof.json
PYTHONPATH=src python -m ugts_chess probe \
  --fen "8/8/8/8/8/k7/8/1QK5 w - - 0 1"
```

An installed package exposes the same interface as `ugts-chess`.

## Package map

- `src/ugts_chess/` - rule kernel, search, proofs, tablebases, UGTS events and CLI.
- `data/` - exact compressed KQK and KRK tablebases plus metadata.
- `examples/` - project JSON, mate proof, search result, tablebase probes and replay evidence.
- `spec/` - formal definition, 64-mechanism catalog, schemas and source register.
- `web/proof_viewer.html` - self-contained proof-tree board viewer.
- `tests/` - 65 tests.
- `validation/` - captured compile, test, benchmark, hash and release evidence.
- `report/` - PDF report and editable DOCX source.

## Rebuild tablebases

```bash
PYTHONPATH=src python -m ugts_chess generate-tablebase --piece Q --out data/kqk.tb.gz
PYTHONPATH=src python -m ugts_chess generate-tablebase --piece R --out data/krk.tb.gz
```

The dense key is 19 bits. Each raw table stores one outcome byte and one DTM byte per address; gzip is only a transport compression layer.
