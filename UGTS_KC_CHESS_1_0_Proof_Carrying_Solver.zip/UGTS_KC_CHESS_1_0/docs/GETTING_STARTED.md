# Getting Started

The runtime requires Python 3.11 or newer and no third-party packages.

## Validate a position

```bash
PYTHONPATH=src python -m ugts_chess validate --fen "<FEN>"
```

## Count legal paths

```bash
PYTHONPATH=src python -m ugts_chess perft --fen "<FEN>" --depth 3 --divide
```

## Bounded search

```bash
PYTHONPATH=src python -m ugts_chess solve --fen "<FEN>" --depth 5 --time 10
```

A positive centipawn score favors the side to move. `mate +N` and `mate -N` are mate-distance results.

## Proof mode

```bash
PYTHONPATH=src python -m ugts_chess prove-mate --fen "<FEN>" --plies 7 --out proof.json
PYTHONPATH=src python -m ugts_chess verify-proof proof.json
```

Proof mode is exhaustive within the declared horizon. OR nodes select one attacker move; AND nodes include every defender reply.

## Exact three-piece probing

```bash
PYTHONPATH=src python -m ugts_chess probe --fen "<KQK-or-KRK-FEN>"
```

Outcome is from the side-to-move perspective. DTM is measured in plies.
