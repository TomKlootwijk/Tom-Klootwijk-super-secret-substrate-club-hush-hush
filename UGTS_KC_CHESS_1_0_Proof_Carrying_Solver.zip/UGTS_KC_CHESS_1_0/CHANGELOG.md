# Changelog

## 1.0.0 - 2026-08-29

- Added strict standard-chess state and legal move kernel.
- Added UGTS move proposals, deterministic commits, hash lineage and replay.
- Added alpha-beta, iterative deepening, quiescence and transposition records.
- Added finite-horizon forced-mate certificates and an independent verifier.
- Added exact KQK and KRK retrograde DTM tablebases with 19-bit dense keys.
- Added CLI, JSON schemas, 64-mechanism catalog, offline proof viewer and validation evidence.
- Added 65 automated tests.
