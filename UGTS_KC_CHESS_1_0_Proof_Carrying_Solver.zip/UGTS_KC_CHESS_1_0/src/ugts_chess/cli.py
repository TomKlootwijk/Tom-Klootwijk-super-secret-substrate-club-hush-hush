"""Command-line interface for the UGTS-KC Chess solver profile."""
from __future__ import annotations

import argparse
import json
import sys
from importlib import resources
from pathlib import Path
from typing import Any

from . import __version__
from .constants import BLACK, WHITE, color_name
from .hashing import compact_key64, state_sha256
from .position import Position, START_FEN
from .proof import MateProver, verify_mate_certificate
from .rules import legal_moves, move_to_san, perft, perft_divide, position_status
from .search import Searcher
from .tablebase import KXKTablebase, generate_tablebase, normalize_kxk_position


def _json_dump(value: object, path: str | None = None) -> None:
    text = json.dumps(value, indent=2, sort_keys=True) + "\n"
    if path:
        Path(path).write_text(text, encoding="utf-8")
    else:
        sys.stdout.write(text)


def _load_position(fen: str) -> Position:
    return Position.from_fen(fen)


def _resource_tablebase(piece: str) -> KXKTablebase:
    name = "kqk.tb.gz" if piece.upper() == "Q" else "krk.tb.gz"
    ref = resources.files("ugts_chess.resources").joinpath(name)
    with resources.as_file(ref) as path:
        return KXKTablebase.load(path)


def cmd_info(_: argparse.Namespace) -> int:
    data = {
        "name": "UGTS-KC Chess",
        "version": __version__,
        "schema": "ugts-kc-chess-solver-1.0",
        "capabilities": [
            "strict FEN and legal move kernel",
            "castling, en-passant and promotion",
            "FIDE-style checkmate/stalemate/dead-position and draw counters",
            "deterministic alpha-beta plus quiescence",
            "proof-carrying bounded mate solver",
            "exact compressed KQK and KRK DTM tablebases",
            "UGTS proposal/guard/commit/hash/replay records",
        ],
        "evidence_boundary": "This package is an exact rules kernel and bounded solver, not a game-theoretic solution of the standard initial position.",
    }
    _json_dump(data)
    return 0


def cmd_validate(args: argparse.Namespace) -> int:
    position = _load_position(args.fen)
    status = position_status(position)
    moves = legal_moves(position)
    data = {
        "valid": True,
        "fen": position.to_fen(),
        "state_sha256": state_sha256(position),
        "compact_key64": f"0x{compact_key64(position):016x}",
        "status": status.to_dict(),
        "legal_move_count": len(moves),
        "legal_moves": [{"uci": move.uci(), "san": move_to_san(position, move)} for move in moves],
    }
    _json_dump(data)
    return 0


def cmd_perft(args: argparse.Namespace) -> int:
    position = _load_position(args.fen)
    if args.divide:
        result: object = {
            "fen": position.to_fen(),
            "depth": args.depth,
            "divide": perft_divide(position, args.depth),
        }
    else:
        result = {"fen": position.to_fen(), "depth": args.depth, "nodes": perft(position, args.depth)}
    _json_dump(result)
    return 0


def cmd_solve(args: argparse.Namespace) -> int:
    position = _load_position(args.fen)
    result = Searcher(claim_draws=not args.ignore_claimable_draws, tt_capacity=args.tt_capacity).search(
        position,
        max_depth=args.depth,
        time_limit=args.time,
    )
    _json_dump(result.to_dict(position), args.out)
    return 0


def cmd_prove_mate(args: argparse.Namespace) -> int:
    position = _load_position(args.fen)
    attacker = None
    if args.attacker:
        attacker = WHITE if args.attacker == "white" else BLACK
    result = MateProver(node_budget=args.node_budget).prove(position, max_plies=args.plies, attacker=attacker)
    _json_dump(result.to_dict(), args.out)
    return 0 if result.status == "proved" else 2


def cmd_verify_proof(args: argparse.Namespace) -> int:
    certificate = json.loads(Path(args.proof).read_text(encoding="utf-8"))
    result = verify_mate_certificate(certificate)
    _json_dump(result)
    return 0


def _detect_piece(position: Position) -> str:
    for piece in ("Q", "R"):
        if normalize_kxk_position(position, piece) is not None:
            return piece
    raise ValueError("position is not a supported KQK or KRK tablebase position")


def cmd_probe(args: argparse.Namespace) -> int:
    position = _load_position(args.fen)
    piece = args.piece or _detect_piece(position)
    tablebase = KXKTablebase.load(args.tablebase) if args.tablebase else _resource_tablebase(piece)
    probe = tablebase.probe(position)
    data = probe.to_dict()
    data["best_moves"] = tablebase.best_moves(position)
    _json_dump(data)
    return 0


def cmd_generate_tablebase(args: argparse.Namespace) -> int:
    metadata = generate_tablebase(args.piece, args.out)
    _json_dump(metadata)
    return 0


def cmd_demo(args: argparse.Namespace) -> int:
    examples: list[dict[str, Any]] = []
    positions = [
        ("initial", START_FEN, 3),
        ("mate_in_two", "8/8/8/8/8/k7/8/1QK5 w - - 0 1", 3),
        ("kqk_probe", "8/8/8/8/8/k7/8/1QK5 w - - 0 1", 1),
    ]
    for name, fen, depth in positions:
        position = Position.from_fen(fen)
        item: dict[str, Any] = {
            "name": name,
            "fen": fen,
            "hash": state_sha256(position),
            "legal_moves": len(legal_moves(position)),
        }
        if name == "initial":
            item["perft_depth_3"] = perft(position, depth)
        elif name == "mate_in_two":
            proof = MateProver(node_budget=100_000).prove(position, max_plies=depth)
            item["mate_proof_status"] = proof.status
            item["mate_proof_nodes"] = proof.explored_nodes
        else:
            tb = _resource_tablebase("Q")
            item["tablebase"] = tb.probe(position).to_dict()
            item["best_moves"] = tb.best_moves(position)
        examples.append(item)
    _json_dump({"version": __version__, "examples": examples}, args.out)
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="ugts-chess", description="UGTS-KC Chess deterministic solver profile")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("info", help="print version, capabilities and evidence boundary")
    p.set_defaults(func=cmd_info)

    p = sub.add_parser("validate", help="validate a FEN and enumerate legal moves")
    p.add_argument("--fen", default=START_FEN)
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("perft", help="count legal move paths")
    p.add_argument("--fen", default=START_FEN)
    p.add_argument("--depth", type=int, required=True)
    p.add_argument("--divide", action="store_true")
    p.set_defaults(func=cmd_perft)

    p = sub.add_parser("solve", help="run bounded deterministic alpha-beta search")
    p.add_argument("--fen", default=START_FEN)
    p.add_argument("--depth", type=int, default=5)
    p.add_argument("--time", type=float)
    p.add_argument("--tt-capacity", type=int, default=500_000)
    p.add_argument("--ignore-claimable-draws", action="store_true")
    p.add_argument("--out")
    p.set_defaults(func=cmd_solve)

    p = sub.add_parser("prove-mate", help="prove a forced mate within a finite ply horizon")
    p.add_argument("--fen", required=True)
    p.add_argument("--plies", type=int, required=True)
    p.add_argument("--attacker", choices=("white", "black"))
    p.add_argument("--node-budget", type=int, default=2_000_000)
    p.add_argument("--out")
    p.set_defaults(func=cmd_prove_mate)

    p = sub.add_parser("verify-proof", help="independently verify a mate proof JSON")
    p.add_argument("proof")
    p.set_defaults(func=cmd_verify_proof)

    p = sub.add_parser("probe", help="probe the bundled exact KQK/KRK tablebase")
    p.add_argument("--fen", required=True)
    p.add_argument("--piece", choices=("Q", "R"))
    p.add_argument("--tablebase")
    p.set_defaults(func=cmd_probe)

    p = sub.add_parser("generate-tablebase", help="rebuild a KQK or KRK tablebase")
    p.add_argument("--piece", choices=("Q", "R"), required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_generate_tablebase)

    p = sub.add_parser("demo", help="run deterministic built-in evidence examples")
    p.add_argument("--out")
    p.set_defaults(func=cmd_demo)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.func(args))
    except (ValueError, RuntimeError) as exc:
        parser.exit(1, f"error: {exc}\n")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
