"""Proof-carrying bounded mate solver and independent verifier."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .constants import WHITE, color_name, opposite
from .hashing import repetition_key, state_sha256
from .position import Position
from .rules import apply_move, in_check, legal_moves, move_gives_check, move_to_san, parse_uci_move, position_status


@dataclass(frozen=True, slots=True)
class MateProofResult:
    status: str
    attacker: int
    max_plies: int
    explored_nodes: int
    certificate: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return self.certificate


class MateProver:
    def __init__(self, *, node_budget: int = 2_000_000) -> None:
        self.node_budget = node_budget
        self.nodes = 0
        self.memo: dict[tuple[str, int, int], tuple[bool, dict[str, Any] | None]] = {}

    def _order(self, position: Position, moves: list[Any]) -> list[Any]:
        def key(move: Any) -> tuple[int, int, int, str]:
            child = apply_move(position, move)
            child_legal = legal_moves(child)
            mate = int(in_check(child) and not child_legal)
            check = int(in_check(child))
            return (mate, check, int(move.is_capture or bool(move.promotion)), move.uci())

        return sorted(moves, key=key, reverse=True)

    def _prove(
        self,
        position: Position,
        attacker: int,
        plies_left: int,
        path_counts: dict[str, int],
    ) -> tuple[bool, dict[str, Any] | None]:
        self.nodes += 1
        if self.nodes > self.node_budget:
            raise RuntimeError("mate proof node budget exceeded")

        pos_hash = state_sha256(position)
        legal = legal_moves(position)
        if not legal:
            if in_check(position) and opposite(position.turn) == attacker:
                return True, {
                    "role": "terminal",
                    "fen": position.to_fen(),
                    "hash": pos_hash,
                    "result": "checkmate",
                    "winner": color_name(attacker),
                }
            return False, None

        if plies_left <= 0:
            return False, None
        if position.halfmove_clock >= 100:
            return False, None
        rep_key = repetition_key(position)
        if path_counts.get(rep_key, 0) >= 3:
            return False, None

        memo_key = (pos_hash, plies_left, attacker)
        if path_counts.get(rep_key, 0) <= 1 and memo_key in self.memo:
            return self.memo[memo_key]

        role = "OR" if position.turn == attacker else "AND"
        ordered = self._order(position, legal)
        if role == "OR":
            for move in ordered:
                child = apply_move(position, move)
                child_key = repetition_key(child)
                path_counts[child_key] = path_counts.get(child_key, 0) + 1
                ok, child_node = self._prove(child, attacker, plies_left - 1, path_counts)
                path_counts[child_key] -= 1
                if path_counts[child_key] == 0:
                    del path_counts[child_key]
                if ok and child_node is not None:
                    node = {
                        "role": "OR",
                        "fen": position.to_fen(),
                        "hash": pos_hash,
                        "side": color_name(position.turn),
                        "move": move.uci(),
                        "san": move_to_san(position, move),
                        "child": child_node,
                    }
                    result = (True, node)
                    if path_counts.get(rep_key, 0) <= 1:
                        self.memo[memo_key] = result
                    return result
            result = (False, None)
        else:
            replies: list[dict[str, Any]] = []
            for move in ordered:
                child = apply_move(position, move)
                child_key = repetition_key(child)
                path_counts[child_key] = path_counts.get(child_key, 0) + 1
                ok, child_node = self._prove(child, attacker, plies_left - 1, path_counts)
                path_counts[child_key] -= 1
                if path_counts[child_key] == 0:
                    del path_counts[child_key]
                if not ok or child_node is None:
                    result = (False, None)
                    if path_counts.get(rep_key, 0) <= 1:
                        self.memo[memo_key] = result
                    return result
                replies.append({
                    "move": move.uci(),
                    "san": move_to_san(position, move),
                    "child": child_node,
                })
            result = (
                True,
                {
                    "role": "AND",
                    "fen": position.to_fen(),
                    "hash": pos_hash,
                    "side": color_name(position.turn),
                    "replies": replies,
                },
            )
        if path_counts.get(rep_key, 0) <= 1:
            self.memo[memo_key] = result
        return result

    def prove(self, position: Position, *, max_plies: int, attacker: int | None = None) -> MateProofResult:
        if max_plies < 1:
            raise ValueError("max_plies must be at least 1")
        attacker = position.turn if attacker is None else attacker
        self.nodes = 0
        self.memo.clear()
        root_rep = repetition_key(position)
        ok, tree = self._prove(position, attacker, max_plies, {root_rep: 1})
        status = "proved" if ok else "not_forced_within_horizon"
        certificate: dict[str, Any] = {
            "$schema": "ugts-kc-chess-mate-proof-1.0",
            "schema_version": "1.0.0",
            "status": status,
            "root_fen": position.to_fen(),
            "root_hash": state_sha256(position),
            "attacker": color_name(attacker),
            "max_plies": max_plies,
            "explored_nodes": self.nodes,
            "proof_semantics": "OR nodes choose one legal attacker move; AND nodes enumerate every legal defender reply; leaves are checkmate.",
            "tree": tree,
        }
        return MateProofResult(status, attacker, max_plies, self.nodes, certificate)


def _verify_node(position: Position, node: dict[str, Any], attacker: int, depth: int, max_plies: int) -> int:
    if depth > max_plies:
        raise ValueError("proof exceeds declared ply horizon")
    if node.get("fen") != position.to_fen():
        raise ValueError(f"FEN mismatch at depth {depth}")
    if node.get("hash") != state_sha256(position):
        raise ValueError(f"state hash mismatch at depth {depth}")
    role = node.get("role")
    legal = legal_moves(position)
    if role == "terminal":
        if legal or not in_check(position):
            raise ValueError("terminal node is not checkmate")
        if opposite(position.turn) != attacker:
            raise ValueError("terminal mate winner is not the declared attacker")
        if node.get("result") != "checkmate":
            raise ValueError("terminal result must be checkmate")
        return 1
    if not legal:
        raise ValueError("non-terminal proof node has no legal moves")
    expected_role = "OR" if position.turn == attacker else "AND"
    if role != expected_role:
        raise ValueError(f"expected {expected_role} node, got {role}")
    if role == "OR":
        move_text = node.get("move")
        if not isinstance(move_text, str):
            raise ValueError("OR node lacks selected move")
        move = parse_uci_move(position, move_text)
        child = node.get("child")
        if not isinstance(child, dict):
            raise ValueError("OR node lacks child")
        return 1 + _verify_node(apply_move(position, move), child, attacker, depth + 1, max_plies)

    replies = node.get("replies")
    if not isinstance(replies, list):
        raise ValueError("AND node lacks replies")
    supplied = [item.get("move") for item in replies if isinstance(item, dict)]
    legal_uci = sorted(move.uci() for move in legal)
    if sorted(supplied) != legal_uci:
        missing = sorted(set(legal_uci) - set(supplied))
        extra = sorted(set(supplied) - set(legal_uci))
        raise ValueError(f"AND node reply coverage mismatch; missing={missing}, extra={extra}")
    count = 1
    by_uci = {move.uci(): move for move in legal}
    for item in replies:
        if not isinstance(item, dict) or not isinstance(item.get("child"), dict):
            raise ValueError("malformed AND reply")
        move = by_uci[str(item["move"])]
        count += _verify_node(apply_move(position, move), item["child"], attacker, depth + 1, max_plies)
    return count


def verify_mate_certificate(certificate: dict[str, Any]) -> dict[str, Any]:
    if certificate.get("status") != "proved":
        raise ValueError("only proved certificates can be verified")
    root = Position.from_fen(str(certificate["root_fen"]))
    if certificate.get("root_hash") != state_sha256(root):
        raise ValueError("root hash mismatch")
    attacker_name = certificate.get("attacker")
    attacker = WHITE if attacker_name == "white" else 1 if attacker_name == "black" else -1
    if attacker not in (0, 1):
        raise ValueError("invalid attacker")
    max_plies = int(certificate["max_plies"])
    tree = certificate.get("tree")
    if not isinstance(tree, dict):
        raise ValueError("certificate lacks proof tree")
    nodes = _verify_node(root, tree, attacker, 0, max_plies)
    return {
        "valid": True,
        "verified_nodes": nodes,
        "root_hash": state_sha256(root),
        "attacker": color_name(attacker),
        "max_plies": max_plies,
    }
