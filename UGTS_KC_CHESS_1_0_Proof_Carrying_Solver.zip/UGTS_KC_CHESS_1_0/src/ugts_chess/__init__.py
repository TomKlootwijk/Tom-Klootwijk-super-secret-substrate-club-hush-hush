"""UGTS-KC Chess 1.0: deterministic, proof-carrying chess solver profile."""
from .constants import BLACK, WHITE
from .move import Move
from .position import Position, START_FEN
from .proof import MateProver, verify_mate_certificate
from .rules import apply_move, legal_moves, move_to_san, parse_uci_move, perft, position_status
from .search import Searcher

__all__ = [
    "BLACK",
    "WHITE",
    "Move",
    "Position",
    "START_FEN",
    "MateProver",
    "verify_mate_certificate",
    "apply_move",
    "legal_moves",
    "move_to_san",
    "parse_uci_move",
    "perft",
    "position_status",
    "Searcher",
]

__version__ = "1.0.0"
