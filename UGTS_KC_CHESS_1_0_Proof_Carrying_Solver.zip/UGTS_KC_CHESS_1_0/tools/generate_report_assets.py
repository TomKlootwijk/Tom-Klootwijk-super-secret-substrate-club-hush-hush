from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle, Circle
from matplotlib.lines import Line2D

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'report' / 'assets'
OUT.mkdir(parents=True, exist_ok=True)

NAVY = '#0B132B'
INK = '#12223B'
BLUE = '#4C78FF'
CYAN = '#26C6DA'
TEAL = '#2CB67D'
GOLD = '#F2C14E'
ORANGE = '#F28E2B'
MAGENTA = '#D65DB1'
RED = '#D85C5C'
PURPLE = '#7A67D8'
LIGHT = '#F4F7FB'
MID = '#D8E1EF'
GRAY = '#62718A'
DARKGRAY = '#34465F'
WHITE = '#FFFFFF'

plt.rcParams.update({
    'font.family': 'DejaVu Sans',
    'font.size': 10,
    'axes.titlesize': 15,
    'axes.titleweight': 'bold',
    'axes.labelsize': 10,
    'figure.facecolor': 'white',
    'axes.facecolor': 'white',
})


def save(fig: plt.Figure, name: str, dpi: int = 220) -> None:
    fig.savefig(OUT / name, dpi=dpi, bbox_inches='tight', facecolor='white')
    plt.close(fig)


def box(ax, x, y, w, h, text, face, edge=None, color=WHITE, fontsize=10, weight='bold', radius=0.025, lw=1.5):
    edge = edge or face
    p = FancyBboxPatch((x, y), w, h,
                       boxstyle=f'round,pad=0.012,rounding_size={radius}',
                       facecolor=face, edgecolor=edge, linewidth=lw)
    ax.add_patch(p)
    ax.text(x + w/2, y + h/2, text, ha='center', va='center', color=color,
            fontsize=fontsize, fontweight=weight, wrap=True)
    return p


def arrow(ax, x1, y1, x2, y2, color=GRAY, lw=1.5, mutation=12, style='-|>'):
    a = FancyArrowPatch((x1, y1), (x2, y2), arrowstyle=style,
                        mutation_scale=mutation, linewidth=lw, color=color,
                        connectionstyle='arc3')
    ax.add_patch(a)
    return a


def architecture():
    fig, ax = plt.subplots(figsize=(12.5, 6.8))
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis('off')
    ax.text(0.03, 0.95, 'UGTS-KC CHESS 1.0 - PROOF-CARRYING SOLVER ARCHITECTURE',
            fontsize=19, fontweight='bold', color=NAVY, va='top')
    ax.text(0.03, 0.905, 'Authoritative chess state and verified moves remain upstream of search, proofs and presentation.',
            fontsize=10.5, color=GRAY, va='top')

    # source layer
    ax.text(0.03, 0.83, 'SUPPLIED SUBSTRATE PRINCIPLES', fontsize=10.5, fontweight='bold', color=DARKGRAY)
    source_labels = [
        ('UGTS-GN 1.1', 'authority chain\nprecision bounds'),
        ('KC 2.0', 'kinematics\nhybrid events'),
        ('Two Hands 3.0', 'proposals\ncommit + replay'),
        ('KC 3.6', 'definitions\nhashes + order'),
        ('SCLP 3.6.2', 'finite keys\nguard intervals'),
        ('KC 3.9', 'deterministic\nruntime + HTML5'),
    ]
    sx = 0.035
    sw = 0.145
    for i, (a, b) in enumerate(source_labels):
        face = [BLUE, TEAL, GOLD, PURPLE, MAGENTA, CYAN][i]
        box(ax, sx + i*0.158, 0.69, sw, 0.105, f'{a}\n{b}', face, fontsize=8.5)
    ax.plot([0.04, 0.96], [0.655, 0.655], color=MID, lw=2)

    # authoritative chain
    ax.text(0.03, 0.61, 'AUTHORITATIVE CHESS SUBSTRATE', fontsize=10.5, fontweight='bold', color=DARKGRAY)
    stages = [
        ('Typed position', BLUE),
        ('Move support', CYAN),
        ('Compatibility', PURPLE),
        ('King-safety guard', GOLD),
        ('Verified event', TEAL),
        ('Atomic patch', ORANGE),
        ('Hash lineage', MAGENTA),
    ]
    x0, y0, w, h, gap = 0.035, 0.46, 0.12, 0.095, 0.013
    for i, (t, c) in enumerate(stages):
        x = x0 + i*(w+gap)
        box(ax, x, y0, w, h, t, c, fontsize=8.7)
        if i < len(stages)-1:
            arrow(ax, x+w, y0+h/2, x+w+gap, y0+h/2, color=GRAY, mutation=10)

    # downstream engines
    ax.text(0.03, 0.39, 'EXACT / HEURISTIC / DEPLOYMENT LAYERS', fontsize=10.5, fontweight='bold', color=DARKGRAY)
    cards = [
        (0.035, 'Exact rule kernel', 'FEN - legal moves - check/mate\ncastling - en-passant - promotion', NAVY),
        (0.275, 'Proof layer', 'OR/AND finite-horizon mate certificates\nindependent verifier', TEAL),
        (0.515, 'Search layer', 'iterative deepening alpha-beta\nquiescence - transposition table', PURPLE),
        (0.755, 'Exact endgames', 'complete KQK and KRK\nWDL + DTM retrograde tables', ORANGE),
    ]
    for x, title, body, c in cards:
        box(ax, x, 0.195, 0.21, 0.135, title, c, fontsize=10)
        ax.text(x+0.105, 0.158, body, ha='center', va='top', color=DARKGRAY, fontsize=8.4)
        arrow(ax, x+0.105, 0.46, x+0.105, 0.34, color=MID, lw=1.4)

    ax.text(0.03, 0.075, 'OUTPUTS', fontsize=9.5, fontweight='bold', color=DARKGRAY)
    out = ['CLI + wheel', 'JSON proofs', 'replay logs', 'compressed tablebases', 'offline proof viewer', 'validation evidence']
    for i, t in enumerate(out):
        x = 0.03 + i*0.158
        box(ax, x, 0.015, 0.145, 0.05, t, LIGHT, edge=MID, color=INK, fontsize=8.3, weight='normal', radius=0.015, lw=1)
    save(fig, 'architecture.png')


def authority_chain():
    fig, ax = plt.subplots(figsize=(12.5, 3.2))
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis('off')
    ax.text(0.02, 0.9, 'Canonical UGTS Chess Move Authority', fontsize=17, fontweight='bold', color=NAVY)
    ax.text(0.02, 0.81, 'Search may propose. Only this ordered verifier changes authoritative state.', fontsize=10.5, color=GRAY)
    stages = [
        ('1', 'Local move support', 'piece movement\nboard bounds', BLUE),
        ('2', 'Compatibility', 'side to move\noccupancy + type', CYAN),
        ('3', 'Special-rule guards', 'castle / en-passant\npromotion', PURPLE),
        ('4', 'King-safety guard', 'apply full patch\nking not attacked', GOLD),
        ('5', 'Verified event', 'exact legal move\nreason codes', TEAL),
        ('6', 'Deterministic patch', 'board + rights\nclocks + EP', ORANGE),
        ('7', 'Lineage / replay', 'pre/post SHA-256\nordered event log', MAGENTA),
    ]
    x0=0.018; w=0.125; gap=0.016; y=0.25; h=0.42
    for i,(num,title,body,c) in enumerate(stages):
        x=x0+i*(w+gap)
        p=FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.012,rounding_size=0.025',facecolor=LIGHT,edgecolor=c,linewidth=2)
        ax.add_patch(p)
        ax.add_patch(Circle((x+0.025,y+h-0.055),0.025,facecolor=c,edgecolor='none'))
        ax.text(x+0.025,y+h-0.055,num,ha='center',va='center',color=WHITE,fontweight='bold',fontsize=9)
        ax.text(x+w/2,y+h-0.12,title,ha='center',va='top',color=INK,fontweight='bold',fontsize=9.2,wrap=True)
        ax.text(x+w/2,y+0.08,body,ha='center',va='bottom',color=GRAY,fontsize=8.2,wrap=True)
        if i < len(stages)-1:
            arrow(ax,x+w,y+h/2,x+w+gap,y+h/2,color=GRAY,mutation=11)
    save(fig,'authority_chain.png')


def source_grounding():
    fig, ax = plt.subplots(figsize=(11.5, 6.6))
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis('off')
    ax.text(0.04,0.94,'Source Grounding: Suitable UGTS Contributions',fontsize=18,fontweight='bold',color=NAVY)
    rows=[
        ('UGTS-GN 1.1','CORE','support -> compatibility -> guard -> event -> transition -> lineage; packed-state and evidence boundaries',BLUE),
        ('UGTS-KC 2.0','CORE','typed patterns and kinematics; hybrid event degeneracy and explicit error contracts',TEAL),
        ('KC Two Hands 3.0','CORE','stable identity; proposal verification; deterministic commit; checkpoints and replay',GOLD),
        ('UGTS-KC 3.6','CORE','definitions as content-addressed data; dependency closure and explicit operation order',PURPLE),
        ('UGTS-KC 3.6.2 SCLP','CORE+','finite key layouts; guard intervals; bounded grammar and storage audits',MAGENTA),
        ('UGTS-KC 3.9','ADDITIVE','deterministic game runtime; browser-facing proof viewer and compact project records',CYAN),
        ('UGTS-KC 3.6.3 SARA','EXCLUDED','wallet-specific public/secret and authorization profile; not needed for chess mechanics',RED),
    ]
    y=0.84
    for name,status,role,c in rows:
        ax.add_patch(FancyBboxPatch((0.04,y-0.095),0.92,0.082,boxstyle='round,pad=0.01,rounding_size=0.015',facecolor=LIGHT,edgecolor=MID,linewidth=1))
        ax.add_patch(Rectangle((0.04,y-0.095),0.012,0.082,facecolor=c,edgecolor='none'))
        ax.text(0.07,y-0.035,name,ha='left',va='center',fontweight='bold',color=INK,fontsize=10.5)
        box(ax,0.30,y-0.075,0.10,0.04,status,c,fontsize=7.5,radius=0.01,lw=0)
        ax.text(0.43,y-0.035,role,ha='left',va='center',color=DARKGRAY,fontsize=9.3,wrap=True)
        y-=0.112
    ax.text(0.04,0.03,'Engineering decision: preserve terminology and boundaries; do not import claims that the sources do not establish.',fontsize=9.5,color=GRAY)
    save(fig,'source_grounding.png')


def board(ax, fen: str, title: str, last_move: tuple[str,str] | None=None):
    boardpart=fen.split()[0]
    ranks=boardpart.split('/')
    pieces={}
    for r_idx,row in enumerate(ranks):
        file=0
        for ch in row:
            if ch.isdigit(): file += int(ch)
            else:
                pieces[(file,7-r_idx)] = ch
                file += 1
    light='#F0D9B5'; dark='#B58863'; highlight='#F7EC6E'
    for x in range(8):
        for y in range(8):
            c=light if (x+y)%2==0 else dark
            if last_move:
                def sq_to_xy(s): return (ord(s[0])-97, int(s[1])-1)
                if (x,y) in [sq_to_xy(last_move[0]),sq_to_xy(last_move[1])]: c=highlight
            ax.add_patch(Rectangle((x,y),1,1,facecolor=c,edgecolor='none'))
    for (x,y),p in pieces.items():
        white=p.isupper()
        face=WHITE if white else NAVY
        edge=NAVY if white else WHITE
        ax.add_patch(Circle((x+0.5,y+0.5),0.31,facecolor=face,edgecolor=edge,linewidth=1.5))
        ax.text(x+0.5,y+0.5,p.upper(),ha='center',va='center',fontweight='bold',fontsize=14,color=NAVY if white else WHITE)
    for i,ch in enumerate('abcdefgh'):
        ax.text(i+0.5,-0.22,ch,ha='center',va='center',fontsize=8,color=GRAY)
    for i in range(8):
        ax.text(-0.22,i+0.5,str(i+1),ha='center',va='center',fontsize=8,color=GRAY)
    ax.set_xlim(-0.45,8.05); ax.set_ylim(-0.45,8.4); ax.set_aspect('equal'); ax.axis('off')
    ax.set_title(title,fontsize=11,fontweight='bold',color=INK,pad=5)


def mate_sequence():
    fig, axes = plt.subplots(1,3,figsize=(12.5,4.4))
    board(axes[0],'8/8/8/8/8/k7/8/1QK5 w - - 0 1','Root: White to move')
    board(axes[1],'8/8/8/1Q6/8/k7/8/2K5 b - - 1 1','1. Qb5 - only tablebase-optimal move',('b1','b5'))
    board(axes[2],'8/8/8/8/8/8/kQ6/2K5 b - - 3 2','1...Ka2 2. Qb2#',('b5','b2'))
    fig.suptitle('Worked Exact Result: Mate in Two',fontsize=17,fontweight='bold',color=NAVY,y=1.02)
    fig.text(0.5,-0.01,'FEN root: 8/8/8/8/8/k7/8/1QK5 w - - 0 1  |  KQK tablebase DTM = 3 plies',ha='center',color=GRAY,fontsize=9.5)
    save(fig,'mate_sequence.png')


def proof_tree():
    fig, ax=plt.subplots(figsize=(11.5,5.2))
    ax.set_xlim(0,1); ax.set_ylim(0,1); ax.axis('off')
    ax.text(0.03,0.93,'Proof Certificate Semantics',fontsize=18,fontweight='bold',color=NAVY)
    ax.text(0.03,0.86,'OR nodes choose one proved attacker move; AND nodes enumerate every legal defender reply; leaves must verify as checkmate.',fontsize=9.8,color=GRAY)
    # nodes
    nodes={
        'root':(0.12,0.55,0.20,0.17,'OR - White','Qb5\nroot hash 64500465...',BLUE),
        'and':(0.41,0.55,0.20,0.17,'AND - Black','all legal replies\n1...Ka2',PURPLE),
        'or2':(0.69,0.55,0.18,0.17,'OR - White','Qb2#',TEAL),
        'leaf':(0.86,0.17,0.12,0.15,'Terminal','checkmate\nwinner White',ORANGE),
    }
    for _,(x,y,w,h,t,b,c) in nodes.items():
        box(ax,x,y,w,h,t,c,fontsize=10)
        ax.text(x+w/2,y-0.025,b,ha='center',va='top',fontsize=8.8,color=DARKGRAY)
    arrow(ax,0.32,0.635,0.41,0.635,color=GRAY,lw=2)
    arrow(ax,0.61,0.635,0.69,0.635,color=GRAY,lw=2)
    arrow(ax,0.78,0.55,0.90,0.32,color=GRAY,lw=2)
    # invariant panel
    ax.add_patch(FancyBboxPatch((0.06,0.11),0.67,0.27,boxstyle='round,pad=0.015,rounding_size=0.02',facecolor=LIGHT,edgecolor=MID,linewidth=1.2))
    ax.text(0.085,0.335,'Independent verifier checks',fontweight='bold',color=INK,fontsize=11)
    bullets=[
        'each FEN parses and its SHA-256 state hash matches',
        'every listed move is legal in the parent position',
        'OR child is exactly the position after its chosen move',
        'AND reply set equals the full legal defender move set',
        'terminal leaf is checkmate for the declared attacker',
    ]
    for i,b in enumerate(bullets):
        ax.text(0.09,0.29-i*0.044,'• '+b,fontsize=9,color=DARKGRAY,va='top')
    ax.text(0.03,0.03,'Reference certificate: 418 nodes explored by the prover; 4 certificate nodes independently verified.',fontsize=9.3,color=GRAY)
    save(fig,'proof_tree.png')


def tablebase_counts():
    kq=json.load(open(ROOT/'data/kqk.tb.json'))
    kr=json.load(open(ROOT/'data/krk.tb.json'))
    labels=['invalid','win','loss','draw']
    vals=[[kq['outcome_counts'][x] for x in labels],[kr['outcome_counts'][x] for x in labels]]
    colors=[MID,TEAL,ORANGE,BLUE]
    fig, ax=plt.subplots(figsize=(10.8,5.7))
    x=[0,1]
    bottoms=[0,0]
    for j,label in enumerate(labels):
        heights=[vals[0][j],vals[1][j]]
        bars=ax.bar(x,heights,bottom=bottoms,label=label.title(),color=colors[j],width=0.58,edgecolor='white')
        for i,b in enumerate(bars):
            if heights[i] > 18000:
                ax.text(b.get_x()+b.get_width()/2,bottoms[i]+heights[i]/2,f'{heights[i]:,}',ha='center',va='center',fontsize=8.5,color=INK,fontweight='bold')
        bottoms=[bottoms[i]+heights[i] for i in range(2)]
    ax.set_xticks(x,['KQK','KRK'],fontsize=11,fontweight='bold')
    ax.set_ylabel('Dense address cells')
    ax.set_title('Complete 19-bit Three-Piece Tablebases',loc='left',color=NAVY,pad=14)
    ax.text(-0.46,553000,'Each table covers all 524,288 addresses; invalid encodings remain explicit.',fontsize=9.5,color=GRAY)
    ax.set_ylim(0,570000)
    ax.grid(axis='y',alpha=0.18)
    ax.legend(ncol=4,loc='upper center',bbox_to_anchor=(0.5,-0.10),frameon=False)
    for i,d in enumerate([kq,kr]):
        ax.text(i,535000,f"valid {d['valid_positions']:,}\nmax DTM {d['max_dtm_plies']} plies\ntransport {d['file_bytes']:,} bytes",ha='center',va='bottom',fontsize=8.8,color=DARKGRAY)
    fig.tight_layout()
    save(fig,'tablebase_counts.png')


def perft_chart():
    data=json.load(open(ROOT/'validation/perft_results.json'))
    # max depth record per fixture
    recs={}
    for r in data:
        if r['depth'] > recs.get(r['fixture'],{}).get('depth',-1): recs[r['fixture']]=r
    names=list(recs)
    values=[recs[n]['actual'] for n in names]
    depths=[recs[n]['depth'] for n in names]
    fig, ax=plt.subplots(figsize=(11.2,5.7))
    bars=ax.bar(range(len(names)),values,color=[BLUE,TEAL,GOLD,PURPLE,MAGENTA,ORANGE],width=0.68)
    ax.set_yscale('log')
    ax.set_xticks(range(len(names)),[n.replace('_','\n') for n in names],fontsize=9)
    ax.set_ylabel('Leaf nodes (log scale)')
    ax.set_title('Legal-Move Regression: All 19 Perft Checks Match',loc='left',color=NAVY,pad=14)
    ax.text(-0.55,max(values)*2.3,'Six standard stress positions through depth 3; initial position additionally through depth 4.',fontsize=9.5,color=GRAY)
    ax.grid(axis='y',which='both',alpha=0.18)
    for i,(b,v,d) in enumerate(zip(bars,values,depths)):
        ax.text(b.get_x()+b.get_width()/2,v*1.18,f'{v:,}\nd={d} ✓',ha='center',va='bottom',fontsize=8.6,color=INK,fontweight='bold')
    ax.set_ylim(1,max(values)*5)
    fig.tight_layout()
    save(fig,'perft_chart.png')


def validation_dashboard():
    s=json.load(open(ROOT/'validation/summary.json'))
    fig, ax=plt.subplots(figsize=(11.8,5.2))
    ax.set_xlim(0,1); ax.set_ylim(0,1); ax.axis('off')
    ax.text(0.03,0.93,'Release Validation Dashboard',fontsize=18,fontweight='bold',color=NAVY)
    ax.text(0.03,0.86,'Captured on Python 3.13.5 in the reference environment; timings are not cross-device performance claims.',fontsize=9.5,color=GRAY)
    cards=[
        ('65 / 65','tests passed',TEAL),
        ('19 / 19','perft checks',BLUE),
        ('2 / 2','JSON schemas',PURPLE),
        ('4 nodes','proof verified',GOLD),
        ('2 exact','tablebases',ORANGE),
        ('1 wheel','package built',MAGENTA),
    ]
    for i,(big,small,c) in enumerate(cards):
        col=i%3; row=i//3
        x=0.04+col*0.315; y=0.52-row*0.31
        ax.add_patch(FancyBboxPatch((x,y),0.275,0.22,boxstyle='round,pad=0.015,rounding_size=0.025',facecolor=LIGHT,edgecolor=MID,linewidth=1.2))
        ax.add_patch(Rectangle((x,y),0.012,0.22,facecolor=c,edgecolor='none'))
        ax.text(x+0.035,y+0.135,big,fontsize=21,fontweight='bold',color=NAVY,va='center')
        ax.text(x+0.035,y+0.062,small,fontsize=10.3,color=DARKGRAY,va='center')
    ax.text(0.04,0.055,f"Mate benchmark: {s['benchmark']['mate_score']}  |  {s['benchmark']['nodes']:,} total nodes (including quiescence)  |  {s['benchmark']['seconds']:.3f} s",fontsize=9.3,color=GRAY)
    save(fig,'validation_dashboard.png')


def solver_layers():
    fig, ax=plt.subplots(figsize=(11.5,5.4))
    ax.set_xlim(0,1); ax.set_ylim(0,1); ax.axis('off')
    ax.text(0.03,0.93,'Three Meanings of “Solve” in This Package',fontsize=18,fontweight='bold',color=NAVY)
    cols=[
        (0.04,'Exact now',TEAL,[
            'legal move relation',
            'mate/stalemate and bounded draw policy',
            'finite-horizon forced-mate certificates',
            'complete KQK/KRK WDL + DTM',
            'hash-checked replay',
        ]),
        (0.355,'Heuristic now',PURPLE,[
            'iterative-deepening alpha-beta',
            'quiescence search',
            'material and piece-square evaluation',
            'transposition table',
            'principal-variation reporting',
        ]),
        (0.67,'Global solve architecture',ORANGE,[
            'content-addressed position shards',
            'certificate-first worker outputs',
            'retrograde / proof frontier expansion',
            'conflict and hash reconciliation',
            'future compute, not claimed complete',
        ]),
    ]
    for x,title,c,items in cols:
        ax.add_patch(FancyBboxPatch((x,0.16),0.285,0.64,boxstyle='round,pad=0.018,rounding_size=0.025',facecolor=LIGHT,edgecolor=c,linewidth=2))
        box(ax,x+0.02,0.70,0.245,0.075,title,c,fontsize=11)
        yy=0.62
        for item in items:
            ax.text(x+0.035,yy,'✓ ' + item,fontsize=9.2,color=DARKGRAY,va='top',wrap=True)
            yy-=0.095
    ax.text(0.04,0.075,'Non-negotiable boundary: a search score is not a proof; an unfinished global architecture is not a solution of the initial position.',fontsize=9.3,color=RED,fontweight='bold')
    save(fig,'solver_layers.png')


def global_solve():
    fig, ax=plt.subplots(figsize=(12.2,6.2))
    ax.set_xlim(0,1); ax.set_ylim(0,1); ax.axis('off')
    ax.text(0.03,0.94,'Scalable Global-Solve Architecture (Specified, Not Completed)',fontsize=18,fontweight='bold',color=NAVY)
    ax.text(0.03,0.87,'All work products are immutable, content-addressed claims with independently checkable evidence.',fontsize=9.8,color=GRAY)
    # top row
    top=[
        (0.04,'Position canonicalizer','FEN/state tuple\nSHA-256 identity',BLUE),
        (0.29,'Shard planner','material / depth /\ntransposition frontier',CYAN),
        (0.54,'Worker pool','forward proof search\nretrograde propagation',PURPLE),
        (0.79,'Certificate store','proof DAGs\nWDL/DTM slices',ORANGE),
    ]
    for x,t,b,c in top:
        box(ax,x,0.64,0.17,0.12,t,c,fontsize=10)
        ax.text(x+0.085,0.605,b,ha='center',va='top',fontsize=8.5,color=DARKGRAY)
    for i in range(3): arrow(ax,top[i][0]+0.17,0.70,top[i+1][0],0.70,color=GRAY,lw=1.7)
    # bottom row
    bottom=[
        (0.08,'Independent verifiers','legal kernel\nproof/table invariants',TEAL),
        (0.35,'Conflict resolver','same hash -> same claim\nelse quarantine',GOLD),
        (0.62,'Merkle manifest','shard hashes\ncoverage metrics',MAGENTA),
        (0.82,'Root status','proved / refuted /\nunknown frontier',NAVY),
    ]
    for x,t,b,c in bottom:
        box(ax,x,0.25,0.16,0.12,t,c,fontsize=9.5)
        ax.text(x+0.08,0.215,b,ha='center',va='top',fontsize=8.3,color=DARKGRAY)
    arrow(ax,0.875,0.64,0.90,0.37,color=GRAY,lw=1.7)
    for i in range(3): arrow(ax,bottom[i][0]+0.16,0.31,bottom[i+1][0],0.31,color=GRAY,lw=1.7)
    arrow(ax,0.62,0.31,0.54,0.64,color=GRAY,lw=1.2,style='<|-')
    ax.add_patch(FancyBboxPatch((0.04,0.045),0.91,0.095,boxstyle='round,pad=0.012,rounding_size=0.018',facecolor='#FFF7E8',edgecolor=GOLD,linewidth=1.3))
    ax.text(0.06,0.092,'Promotion gate:',fontweight='bold',color=INK,fontsize=10,va='center')
    ax.text(0.17,0.092,'No shard or claim is authoritative until exact legality, completeness conditions, hashes and proof invariants independently pass.',color=DARKGRAY,fontsize=9.3,va='center')
    save(fig,'global_solve.png')


def package_map():
    fig, ax=plt.subplots(figsize=(11.7,5.7))
    ax.set_xlim(0,1); ax.set_ylim(0,1); ax.axis('off')
    ax.text(0.03,0.94,'Accompanying Package Map',fontsize=18,fontweight='bold',color=NAVY)
    root=(0.42,0.77,0.18,0.09)
    box(ax,*root,'UGTS_KC_CHESS_1_0',NAVY,fontsize=10.5)
    branches=[
        (0.04,0.53,'src/ugts_chess','rules - search - proofs\ntablebases - UGTS events',BLUE),
        (0.24,0.28,'data/','KQK + KRK compressed\nexact tables + metadata',ORANGE),
        (0.42,0.45,'spec/','formal definition\n64 mechanisms + schemas',PURPLE),
        (0.61,0.28,'examples/','mate certificate\nreplay + project JSON',TEAL),
        (0.78,0.53,'validation/','tests - perft - hashes\nbenchmark + wheel',MAGENTA),
        (0.61,0.63,'web/','self-contained\nproof viewer',CYAN),
        (0.24,0.63,'report/','PDF + editable DOCX\nfigures + source notes',GOLD),
    ]
    cx=root[0]+root[2]/2; cy=root[1]
    for x,y,t,b,c in branches:
        box(ax,x,y,0.18,0.105,t,c,fontsize=9.5)
        ax.text(x+0.09,y-0.023,b,ha='center',va='top',fontsize=8.1,color=DARKGRAY)
        arrow(ax,cx,cy,x+0.09,y+0.105,color=MID,lw=1.3)
    ax.text(0.03,0.05,'Dependency-free runtime; the generated wheel contains code and the two tablebase resources. No uploaded source PDFs are redistributed.',fontsize=9.3,color=GRAY)
    save(fig,'package_map.png')


def main():
    architecture(); authority_chain(); source_grounding(); mate_sequence(); proof_tree(); tablebase_counts(); perft_chart(); validation_dashboard(); solver_layers(); global_solve(); package_map()
    print(json.dumps({'generated': sorted(p.name for p in OUT.glob('*.png'))}, indent=2))

if __name__ == '__main__':
    main()
