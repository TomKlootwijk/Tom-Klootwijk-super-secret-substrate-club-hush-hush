from __future__ import annotations

import csv
import json
from collections import Counter
from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_ROW_HEIGHT_RULE, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_LINE_SPACING
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Inches, Mm, Pt, RGBColor

ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / 'report'
ASSETS = REPORT / 'assets'
OUT = REPORT / 'UGTS_KC_CHESS_1_0_Proof_Carrying_Solver.docx'

NAVY = '0B132B'
INK = '12223B'
BLUE = '4C78FF'
CYAN = '26C6DA'
TEAL = '2CB67D'
GOLD = 'F2C14E'
ORANGE = 'F28E2B'
MAGENTA = 'D65DB1'
RED = 'D85C5C'
PURPLE = '7A67D8'
LIGHT = 'F4F7FB'
MID = 'D8E1EF'
GRAY = '62718A'
DARKGRAY = '34465F'
WHITE = 'FFFFFF'

validation = json.loads((ROOT / 'validation/summary.json').read_text())
kq = json.loads((ROOT / 'data/kqk.tb.json').read_text())
kr = json.loads((ROOT / 'data/krk.tb.json').read_text())
source_reg = json.loads((ROOT / 'spec/source_register.json').read_text())
mechanisms = json.loads((ROOT / 'spec/chess_mechanisms.json').read_text())


def set_cell_shading(cell, fill: str):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = tcPr.find(qn('w:shd'))
    if shd is None:
        shd = OxmlElement('w:shd')
        tcPr.append(shd)
    shd.set(qn('w:fill'), fill)


def set_cell_border(cell, **kwargs):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcBorders = tcPr.first_child_found_in('w:tcBorders')
    if tcBorders is None:
        tcBorders = OxmlElement('w:tcBorders')
        tcPr.append(tcBorders)
    for edge in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        if edge in kwargs:
            edge_data = kwargs.get(edge)
            tag = 'w:{}'.format(edge)
            element = tcBorders.find(qn(tag))
            if element is None:
                element = OxmlElement(tag)
                tcBorders.append(element)
            for key in ['val', 'sz', 'space', 'color']:
                if key in edge_data:
                    element.set(qn('w:{}'.format(key)), str(edge_data[key]))


def set_cell_margins(cell, top=60, start=80, bottom=60, end=80):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcMar = tcPr.first_child_found_in('w:tcMar')
    if tcMar is None:
        tcMar = OxmlElement('w:tcMar')
        tcPr.append(tcMar)
    for m, v in [('top', top), ('start', start), ('bottom', bottom), ('end', end)]:
        node = tcMar.find(qn(f'w:{m}'))
        if node is None:
            node = OxmlElement(f'w:{m}')
            tcMar.append(node)
        node.set(qn('w:w'), str(v))
        node.set(qn('w:type'), 'dxa')


def set_repeat_table_header(row):
    trPr = row._tr.get_or_add_trPr()
    tblHeader = OxmlElement('w:tblHeader')
    tblHeader.set(qn('w:val'), 'true')
    trPr.append(tblHeader)


def set_paragraph_bottom_border(paragraph, color=NAVY, size='8'):
    p = paragraph._p
    pPr = p.get_or_add_pPr()
    pBdr = pPr.find(qn('w:pBdr'))
    if pBdr is None:
        pBdr = OxmlElement('w:pBdr')
        pPr.append(pBdr)
    bottom = OxmlElement('w:bottom')
    bottom.set(qn('w:val'), 'single')
    bottom.set(qn('w:sz'), size)
    bottom.set(qn('w:space'), '1')
    bottom.set(qn('w:color'), color)
    pBdr.append(bottom)


def set_keep_with_next(paragraph):
    pPr = paragraph._p.get_or_add_pPr()
    keepNext = OxmlElement('w:keepNext')
    pPr.append(keepNext)


def set_keep_lines(paragraph):
    pPr = paragraph._p.get_or_add_pPr()
    keepLines = OxmlElement('w:keepLines')
    pPr.append(keepLines)


def add_page_field(paragraph):
    run = paragraph.add_run()
    fldChar1 = OxmlElement('w:fldChar')
    fldChar1.set(qn('w:fldCharType'), 'begin')
    instrText = OxmlElement('w:instrText')
    instrText.set(qn('xml:space'), 'preserve')
    instrText.text = ' PAGE '
    fldChar2 = OxmlElement('w:fldChar')
    fldChar2.set(qn('w:fldCharType'), 'separate')
    t = OxmlElement('w:t')
    t.text = '1'
    fldChar3 = OxmlElement('w:fldChar')
    fldChar3.set(qn('w:fldCharType'), 'end')
    run._r.extend([fldChar1, instrText, fldChar2, t, fldChar3])


def add_pic(doc, filename: str, width=6.8, alt=''):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run()
    shape = r.add_picture(str(ASSETS / filename), width=Inches(width))
    if alt:
        shape._inline.docPr.set('descr', alt)
        shape._inline.docPr.set('title', filename)
    p.paragraph_format.space_after = Pt(3)
    return p


fig_no = 0

def caption(doc, text: str):
    global fig_no
    fig_no += 1
    p = doc.add_paragraph(style='Figure Caption')
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(f'Figure {fig_no}. ')
    r.bold = True
    p.add_run(text)
    return p


def table_caption(doc, text: str, num: int):
    p = doc.add_paragraph(style='Table Caption')
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    r = p.add_run(f'Table {num}. ')
    r.bold = True
    p.add_run(text)
    return p


def add_callout(doc, title: str, body: str, fill='EAF7F3', accent=TEAL, icon=None):
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    trPr = table.rows[0]._tr.get_or_add_trPr()
    cant_split = OxmlElement('w:cantSplit')
    trPr.append(cant_split)
    cell = table.cell(0, 0)
    cell.width = Inches(6.75)
    set_cell_shading(cell, fill)
    set_cell_border(cell,
                    top={'val': 'single', 'sz': '12', 'color': accent},
                    bottom={'val': 'single', 'sz': '12', 'color': accent},
                    left={'val': 'single', 'sz': '18', 'color': accent},
                    right={'val': 'single', 'sz': '12', 'color': accent})
    set_cell_margins(cell, top=100, start=130, bottom=100, end=130)
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(2)
    r = p.add_run((icon + ' ' if icon else '') + title.upper())
    r.bold = True; r.font.size = Pt(9.2); r.font.color.rgb = RGBColor.from_string(accent)
    p2 = cell.add_paragraph(body)
    p2.style = doc.styles['Normal']
    p2.paragraph_format.space_after = Pt(0)
    return table


def add_table(doc, headers, rows, widths=None, header_fill=NAVY, font_size=8.3, first_col_bold=False):
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    hdr = table.rows[0]
    set_repeat_table_header(hdr)
    for j, h in enumerate(headers):
        c = hdr.cells[j]
        set_cell_shading(c, header_fill)
        set_cell_margins(c, top=60, start=70, bottom=60, end=70)
        p = c.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.LEFT
        r = p.add_run(str(h))
        r.bold = True; r.font.color.rgb = RGBColor(255,255,255); r.font.size = Pt(font_size)
        c.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        if widths: c.width = Inches(widths[j])
    for i, row in enumerate(rows):
        cells = table.add_row().cells
        fill = WHITE if i % 2 == 0 else LIGHT
        for j, value in enumerate(row):
            c = cells[j]
            set_cell_shading(c, fill)
            set_cell_margins(c, top=55, start=70, bottom=55, end=70)
            p = c.paragraphs[0]
            p.paragraph_format.space_after = Pt(0)
            r = p.add_run(str(value))
            r.font.size = Pt(font_size)
            r.font.color.rgb = RGBColor.from_string(INK)
            if first_col_bold and j == 0: r.bold = True
            c.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            if widths: c.width = Inches(widths[j])
            border = {'val':'single','sz':'4','color':MID}
            set_cell_border(c, top=border, bottom=border, left=border, right=border)
    return table


def add_bullets(doc, items, level=0, compact=True, color=INK):
    for item in items:
        p = doc.add_paragraph(style='Bullet')
        p.paragraph_format.left_indent = Inches(0.24 + level*0.2)
        p.paragraph_format.first_line_indent = Inches(-0.15)
        p.paragraph_format.space_after = Pt(1 if compact else 3)
        r = p.add_run('• ')
        r.bold = True; r.font.color.rgb = RGBColor.from_string(TEAL)
        r = p.add_run(item)
        r.font.color.rgb = RGBColor.from_string(color)


def add_numbered(doc, items):
    for i, item in enumerate(items,1):
        p=doc.add_paragraph(style='Bullet')
        p.paragraph_format.left_indent=Inches(0.28)
        p.paragraph_format.first_line_indent=Inches(-0.22)
        p.paragraph_format.space_after=Pt(2)
        r=p.add_run(f'{i}. '); r.bold=True; r.font.color.rgb=RGBColor.from_string(BLUE)
        p.add_run(item)


def add_code(doc, text: str):
    table=doc.add_table(rows=1,cols=1)
    table.autofit=False; table.alignment=WD_TABLE_ALIGNMENT.CENTER
    cell=table.cell(0,0); cell.width=Inches(6.75)
    set_cell_shading(cell,'111C35')
    set_cell_border(cell,top={'val':'single','sz':'6','color':'111C35'},bottom={'val':'single','sz':'6','color':'111C35'},left={'val':'single','sz':'6','color':'111C35'},right={'val':'single','sz':'6','color':'111C35'})
    set_cell_margins(cell,top=100,start=130,bottom=100,end=130)
    p=cell.paragraphs[0]
    p.paragraph_format.space_after=Pt(0)
    r=p.add_run(text)
    r.font.name='Liberation Mono'; r.font.size=Pt(8.2); r.font.color.rgb=RGBColor.from_string('EAF2FF')


def add_section_title(doc, number: str, title: str, subtitle: str | None=None):
    p=doc.add_paragraph(style='Heading 1')
    p.add_run(f'{number}. {title}')
    if subtitle:
        p2=doc.add_paragraph(style='Section Lead')
        p2.add_run(subtitle)
    return p


def add_source_note(doc, text: str):
    p=doc.add_paragraph(style='Source Note')
    p.add_run('Source grounding: ').bold=True
    p.add_run(text)


def make_styles(doc: Document):
    styles=doc.styles
    normal=styles['Normal']
    normal.font.name='Aptos'; normal.font.size=Pt(9.5); normal.font.color.rgb=RGBColor.from_string(INK)
    normal.paragraph_format.space_after=Pt(4); normal.paragraph_format.line_spacing=1.05

    for sname,size,color,space_before,space_after in [
        ('Title',29,NAVY,0,8),('Subtitle',15,BLUE,0,8),
        ('Heading 1',20,NAVY,10,6),('Heading 2',13.5,TEAL,8,4),('Heading 3',11.5,BLUE,6,3),
    ]:
        st=styles[sname]; st.font.name='Aptos Display' if 'Heading' in sname or sname in ('Title','Subtitle') else 'Aptos'
        st.font.size=Pt(size); st.font.color.rgb=RGBColor.from_string(color); st.font.bold=True
        st.paragraph_format.space_before=Pt(space_before); st.paragraph_format.space_after=Pt(space_after)
        st.paragraph_format.keep_with_next=True

    custom=[
        ('Cover Kicker',WD_STYLE_TYPE.PARAGRAPH,9.5,GRAY,True),
        ('Cover Meta',WD_STYLE_TYPE.PARAGRAPH,9.2,DARKGRAY,False),
        ('Section Lead',WD_STYLE_TYPE.PARAGRAPH,10.5,GRAY,False),
        ('Figure Caption',WD_STYLE_TYPE.PARAGRAPH,8.2,GRAY,False),
        ('Table Caption',WD_STYLE_TYPE.PARAGRAPH,8.2,GRAY,False),
        ('Bullet',WD_STYLE_TYPE.PARAGRAPH,9.2,INK,False),
        ('Code Inline',WD_STYLE_TYPE.CHARACTER,8.8,PURPLE,False),
        ('Source Note',WD_STYLE_TYPE.PARAGRAPH,8.2,GRAY,False),
        ('Small',WD_STYLE_TYPE.PARAGRAPH,8.0,GRAY,False),
    ]
    for name,typ,size,color,bold in custom:
        if name in styles: st=styles[name]
        else: st=styles.add_style(name,typ)
        st.font.name='Aptos'; st.font.size=Pt(size); st.font.color.rgb=RGBColor.from_string(color); st.font.bold=bold
        if typ==WD_STYLE_TYPE.PARAGRAPH:
            st.paragraph_format.space_after=Pt(2)
            st.paragraph_format.line_spacing=1.0
            if name in ('Figure Caption','Table Caption'): st.font.italic=True
    styles['Figure Caption'].paragraph_format.keep_with_next=False
    styles['Section Lead'].font.italic=True


def setup_document() -> Document:
    doc=Document()
    make_styles(doc)
    sec=doc.sections[0]
    sec.page_width=Mm(210); sec.page_height=Mm(297)
    sec.top_margin=Mm(15); sec.bottom_margin=Mm(15); sec.left_margin=Mm(17); sec.right_margin=Mm(17)
    sec.header_distance=Mm(6); sec.footer_distance=Mm(7)
    sec.different_first_page_header_footer=True

    header=sec.header
    p=header.paragraphs[0]
    p.text='UGTS-KC CHESS 1.0  |  PROOF-CARRYING DETERMINISTIC SOLVER'
    p.style=doc.styles['Small']
    p.alignment=WD_ALIGN_PARAGRAPH.RIGHT
    set_paragraph_bottom_border(p,color=MID,size='6')

    footer=sec.footer
    p=footer.paragraphs[0]
    p.alignment=WD_ALIGN_PARAGRAPH.RIGHT
    r=p.add_run('Prepared for Tom Klootwijk  |  Page ')
    r.font.size=Pt(8); r.font.color.rgb=RGBColor.from_string(GRAY)
    add_page_field(p)

    props=doc.core_properties
    props.title='UGTS-KC Chess 1.0 - Proof-Carrying Deterministic Solver'
    props.subject='UGTS application profile for standard chess: exact rules, proofs, tablebases, deterministic search and replay'
    props.author='OpenAI, prepared for Tom Klootwijk'
    props.keywords='UGTS, chess, deterministic solver, mate proof, tablebase, replay, alpha-beta'
    props.comments='Requester attribution recorded as supplied and not independently verified.'
    return doc


def cover(doc):
    p=doc.add_paragraph(style='Cover Kicker')
    p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    p.add_run('UGTS-KC APPLICATION PROFILE')
    p.paragraph_format.space_before=Pt(4); p.paragraph_format.space_after=Pt(8)

    p=doc.add_paragraph(style='Title')
    p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    p.add_run('UGTS-KC CHESS 1.0')
    p=doc.add_paragraph(style='Subtitle')
    p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    p.add_run('Proof-Carrying Deterministic Solver')
    p=doc.add_paragraph()
    p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    r=p.add_run('Exact rule kernel, hash-chained replay, finite-horizon mate certificates,\nalpha-beta search and complete KQK/KRK tablebases')
    r.font.size=Pt(11.5); r.font.color.rgb=RGBColor.from_string(DARKGRAY)

    add_pic(doc,'architecture.png',width=6.85,alt='Architecture showing supplied UGTS principles feeding the authoritative chess state, move verification, proofs, search, tablebases and outputs.')

    table=doc.add_table(rows=4,cols=2)
    table.alignment=WD_TABLE_ALIGNMENT.CENTER; table.autofit=False
    data=[
        ('Prepared for','Tom Klootwijk'),
        ('Document date','29 August 2026'),
        ('Version / schema','1.0.0 / ugts-kc-chess-solver-1.0'),
        ('Release status','Exact bounded solver substrate with executable validation'),
    ]
    for i,(a,b) in enumerate(data):
        c1,c2=table.rows[i].cells
        for c in (c1,c2):
            set_cell_margins(c,top=45,start=80,bottom=45,end=80)
            set_cell_border(c,top={'val':'single','sz':'4','color':MID},bottom={'val':'single','sz':'4','color':MID},left={'val':'single','sz':'4','color':MID},right={'val':'single','sz':'4','color':MID})
        set_cell_shading(c1,'EAF3FA'); set_cell_shading(c2,WHITE)
        c1.width=Inches(1.6); c2.width=Inches(5.0)
        r=c1.paragraphs[0].add_run(a); r.bold=True; r.font.size=Pt(8.7); r.font.color.rgb=RGBColor.from_string(NAVY)
        r=c2.paragraphs[0].add_run(b); r.font.size=Pt(8.7); r.font.color.rgb=RGBColor.from_string(INK)
    doc.add_paragraph().paragraph_format.space_after=Pt(0)

    add_callout(doc,'Evidence boundary','The package does not claim a weak or strong game-theoretic solution of the standard initial position. It supplies an exact rules kernel, exact bounded proofs, exact three-piece tablebases and a specified architecture for expansion.',fill='FFF4F2',accent=RED)
    doc.add_page_break()


def contents_exec(doc):
    add_section_title(doc,'0','Contents and Executive Decision','The word “solve” is split into exact rules, exact bounded claims, heuristic search and an uncompleted global proof program.')
    entries=[
        ('1','Source grounding and scope'),('2','What “solve chess” means'),('3','Formal state and move authority'),
        ('4','Rule kernel and terminal semantics'),('5','Deterministic events, hashes and replay'),('6','Heuristic search layer'),
        ('7','Proof-carrying bounded mate solver'),('8','Complete KQK/KRK tablebases'),('9','Global-solve architecture'),
        ('10','Implementation and command line'),('11','Validation and release evidence'),('12','Mechanism catalog'),
        ('13','Boundaries, kill criteria and final definition'),('Appendix A','Package map and reproduction'),('Appendix B','Source register and references'),
    ]
    table=doc.add_table(rows=0,cols=2); table.alignment=WD_TABLE_ALIGNMENT.CENTER; table.autofit=False
    for i in range(0,len(entries),2):
        row=table.add_row().cells
        for j in range(2):
            idx=i+j
            if idx>=len(entries): continue
            num,title=entries[idx]
            c=row[j]; set_cell_shading(c,LIGHT if (i//2)%2==0 else WHITE); set_cell_margins(c,top=65,start=85,bottom=65,end=85)
            set_cell_border(c,bottom={'val':'single','sz':'3','color':MID})
            p=c.paragraphs[0]; p.paragraph_format.space_after=Pt(0)
            r=p.add_run(f'{num}  '); r.bold=True; r.font.color.rgb=RGBColor.from_string(BLUE); r.font.size=Pt(8.7)
            r=p.add_run(title); r.font.size=Pt(8.7); r.font.color.rgb=RGBColor.from_string(INK)
    doc.add_paragraph()

    doc.add_heading('Executive decision',level=2)
    p=doc.add_paragraph()
    p.add_run('GO - as a bounded proof-carrying solver substrate. ').bold=True
    p.add_run('Standard chess can be represented cleanly in the UGTS chain because every move is a finite proposal with explicit support, compatibility, guard and transition conditions. The implementation is intentionally split so that legality and proof verification remain exact, while general position scoring remains visibly heuristic.')

    rows=[
        ('Exact rule authority','FEN parsing; legal move generation; check, checkmate, stalemate; castling, en-passant and promotion; deterministic transitions.'),
        ('Exact bounded solving','OR/AND forced-mate certificates within a declared ply horizon, independently replayed and verified.'),
        ('Exact finite state spaces','Complete KQK and KRK win/draw/loss plus depth-to-mate over all 2^19 dense addresses per material class.'),
        ('Heuristic search','Iterative deepening alpha-beta, quiescence and a transposition table. Non-mate scores are estimates.'),
        ('Global chess solution','A certificate-sharded architecture is specified. The standard initial position is not claimed solved.'),
    ]
    table_caption(doc,'Release interpretation',1)
    add_table(doc,['Layer','Status / meaning'],rows,widths=[1.55,5.05],font_size=8.7,first_col_bold=True)

    add_callout(doc,'Release result',f"65 automated tests pass; 19 perft checks match; two JSON schemas validate; the mate certificate verifies; two exact tablebases load with matching SHA-256 hashes; and the installable wheel builds successfully.",fill='EAF7F3',accent=TEAL)
    doc.add_page_break()


def source_section(doc):
    add_section_title(doc,'1','Source Grounding and Scope','The chess profile preserves the supplied documents’ terminology, operation order and evidence boundaries; it does not silently import unsupported claims.')
    add_pic(doc,'source_grounding.png',width=6.75,alt='Table-like diagram of the suitable supplied UGTS versions and the contribution each makes to the chess solver.')
    caption(doc,'Suitable source contributions. SARA is reviewed but excluded as domain-specific rather than forced into chess mechanics.')

    source_rows=[]
    for s in source_reg['sources']:
        status='EXCLUDED' if 'SARA' in s['title'] else ('ADDITIVE' if s['title']=='UGTS-KC 3.9' else 'CORE')
        source_rows.append((s['title'],status,s['role']))
    table_caption(doc,'Source-role register',2)
    add_table(doc,['Supplied source','Status','Chess-profile contribution'],source_rows,widths=[1.45,0.85,4.25],font_size=8.0,first_col_bold=True)

    add_source_note(doc,'UGTS-GN 1.1 supplies the canonical support -> compatibility -> guard -> event -> transition -> lineage order and the rule that compression/one-bit records never imply complete state. KC 2.0 contributes typed kinematics and hybrid event discipline. Two Hands 3.0 contributes proposal verification, deterministic commit and replay. KC 3.6 contributes content-addressed definitions and explicit dependency order. SCLP 3.6.2 contributes finite key and guard-interval discipline. KC 3.9 contributes deterministic runtime and self-contained browser-delivery patterns.')

    doc.add_page_break()


def solve_meaning(doc):
    add_section_title(doc,'2','What “Solve Chess” Means','A precise release must separate complete claims from estimates and future architecture.')
    add_pic(doc,'solver_layers.png',width=6.75,alt='Three columns separating exact features, heuristic features, and the specified but incomplete global solution architecture.')
    caption(doc,'Three meanings of solve. Only the left column is exact in the current release; the middle is heuristic; the right is a future proof program.')

    doc.add_heading('2.1 Exactness classes',level=2)
    add_bullets(doc,[
        'Rule exactness: a legal-move answer is binary and independently reproducible from the same position and history context.',
        'Certificate exactness: a proved mate requires one attacker choice at every OR node, full defender coverage at every AND node and a verified checkmate leaf.',
        'Tablebase exactness: every legal state in the declared KQK or KRK material class receives a WDL and, for decisive states, a depth-to-mate value.',
        'Search estimate: a centipawn score is a bounded computation result, not a theorem about perfect play.',
        'Unknown is valid: failure to find a proof within a horizon means only not_forced_within_horizon.',
    ],compact=False)

    doc.add_heading('2.2 Relation to public tablebase context',level=2)
    p=doc.add_paragraph()
    p.add_run('The public Syzygy ecosystem currently provides exact play for positions with up to seven pieces. ').bold=True
    p.add_run('This package does not reproduce that corpus. It deliberately implements two compact three-piece DTM tables so that the complete generation, storage, probing, hashing and validation path is inspectable inside the accompanying ZIP.')

    add_callout(doc,'Non-claim','The standard 32-piece initial position is not weakly solved, strongly solved or ultra-weakly solved by this package. “UGTS Chess 1.0” names a solver substrate and release profile, not a declaration that all chess has been computed.',fill='FFF4F2',accent=RED)
    doc.add_page_break()


def formal_state(doc):
    add_section_title(doc,'3','Formal State and Move Authority','The authoritative object is a typed position plus history and lineage, not an image of a board and not a search score.')
    doc.add_heading('3.1 Typed position',level=2)
    add_code(doc,'q = (B, s, C, e, h, n, H, L)\n\nB : 64 typed board cells\ns : side to move\nC : four castling-right flags\ne : optional en-passant target\nh : halfmove clock\nn : fullmove number\nH : repetition-history context\nL : ordered event lineage')
    p=doc.add_paragraph()
    p.add_run('Identity split. ').bold=True
    p.add_run('Board coordinate, piece type, side-to-move, castling rights, en-passant target, clocks and lineage remain distinct. The one-bit side field has a narrow selector role; it never replaces the rest of the state. FEN is the portable position spelling, while history is supplied separately when repetition adjudication is required.')

    add_pic(doc,'authority_chain.png',width=6.85,alt='Seven-stage authority chain from local move support through compatibility, special rules, king safety, verified event, deterministic patch and lineage.')
    caption(doc,'The exact move-authority sequence. Search and user input can propose moves, but neither may bypass the verifier.')

    doc.add_heading('3.2 Verified move condition',level=2)
    add_code(doc,'legal(q, m) = in_support(q, m)\n             and compatible(q, m)\n             and special_guards(q, m)\n             and not king_attacked(apply(q, m), mover)')
    p=doc.add_paragraph()
    p.add_run('The king is never captured. ').bold=True
    p.add_run('A checkmate terminal is defined as check plus zero legal replies. This keeps the transition semantics aligned with the rule system instead of allowing an illegal king-capture patch.')
    doc.add_page_break()


def rule_kernel(doc):
    add_section_title(doc,'4','Rule Kernel and Terminal Semantics','The dependency-free move generator implements standard piece movement and the full state patches needed by special moves.')
    doc.add_heading('4.1 Movement support and compatibility',level=2)
    rows=[
        ('Pawn','One step; optional initial two-step; diagonal capture; four promotion choices; en-passant target test.','Direction, occupancy, promotion rank, captured pawn and king safety.'),
        ('Knight','Eight finite leaper offsets.','Board bounds, own occupancy and king safety.'),
        ('Bishop','Four diagonal rays until first blocker.','Ray occupancy, enemy non-king capture and king safety.'),
        ('Rook','Four orthogonal rays until first blocker.','Ray occupancy, enemy non-king capture and king safety.'),
        ('Queen','Bishop plus rook rays.','Same ray and king-safety rules.'),
        ('King','Eight adjacent offsets plus castling proposals.','No king adjacency, no attacked destination; castling path and rights guards.'),
    ]
    table_caption(doc,'Piece support and guards',3)
    add_table(doc,['Piece','Finite support','Compatibility / guard'],rows,widths=[0.65,2.75,3.2],font_size=7.8,first_col_bold=True)

    doc.add_heading('4.2 Special move patches',level=2)
    add_bullets(doc,[
        'Castling: the rook must exist on its home square; the path must be empty; the king may not start in, pass through or finish in check; the king and rook are patched atomically.',
        'En-passant: the target square is transient; the captured pawn is removed from a different square; legality is tested after the full patch so discovered attacks on the king are rejected.',
        'Promotion: four typed outcomes (queen, rook, bishop or knight) are emitted as distinct moves; capture and promotion flags may coexist.',
        'Rights and clocks: king/rook movement and home-rook capture clear the appropriate castling flags; pawn moves and captures reset the halfmove clock; Black moves advance the fullmove number.',
    ],compact=False)

    doc.add_heading('4.3 Terminal and draw status',level=2)
    rows=[
        ('Checkmate','Terminal, decisive','Side to move is in check and has zero legal moves.'),
        ('Stalemate','Terminal draw','Side to move is not in check and has zero legal moves.'),
        ('Dead-position subset','Terminal draw','Exact conservative subset: kings only; king plus one bishop/knight; bishops only on one square color.'),
        ('Fivefold repetition','Automatic draw','History key occurs at least five times.'),
        ('75-move rule','Automatic draw','Halfmove clock reaches 150 plies.'),
        ('Threefold repetition','Claimable draw','History key occurs at least three times when claim policy is enabled.'),
        ('50-move rule','Claimable draw','Halfmove clock reaches 100 plies when claim policy is enabled.'),
    ]
    table_caption(doc,'Implemented terminal and draw policy',4)
    add_table(doc,['Status','Authority','Implementation condition'],rows,widths=[1.35,1.25,4.05],font_size=7.7,first_col_bold=True)

    add_callout(doc,'Boundary','The dead-position detector is deliberately conservative and exact for its implemented subset; it is not advertised as a complete theorem prover for every possible no-mate material configuration.',fill='FFF9E8',accent=GOLD)
    doc.add_page_break()


def events_replay(doc):
    add_section_title(doc,'5','Deterministic Events, Hashes and Replay','Moves are proposed in parallel or by any front end, but state mutation occurs through one ordered commit boundary.')
    doc.add_heading('5.1 Proposal record',level=2)
    add_code(doc,'MoveProposal = {\n  proposal_id, source, parent_hash, move_uci,\n  support_ok, compatibility_ok, guard_ok,\n  reason_codes, requested_patch\n}')
    p=doc.add_paragraph()
    p.add_run('A legal proposal carries evidence; an illegal proposal carries reasons. ').bold=True
    p.add_run('The commit path recomputes legality rather than trusting a caller-provided flag. The event writes an ordered sequence number, the move, SAN, pre-state hash, post-state hash, resulting FEN and lineage label.')

    doc.add_heading('5.2 Canonical identities',level=2)
    rows=[
        ('State SHA-256','Canonical full-position dictionary. Used in proofs, replay and release evidence.'),
        ('Repetition key','Board, side, castling and legally relevant en-passant state. Used with an external history counter.'),
        ('Compact 64-bit key','Deterministic search-table checksum. Useful for a transposition table; not treated as collision-free durable identity.'),
        ('Tablebase 19-bit key','Bijective dense address inside one declared KQK/KRK profile.'),
    ]
    add_table(doc,['Identity','Role and boundary'],rows,widths=[1.55,5.05],font_size=8.4,first_col_bold=True)

    doc.add_heading('5.3 Replay invariant',level=2)
    add_numbered(doc,[
        'Load the exact initial FEN and compute its state hash.',
        'For each event in sequence, confirm the stored pre-hash equals the current hash.',
        'Parse the stored UCI move against the current legal move set.',
        'Apply the deterministic transition and confirm the stored post-hash.',
        'Stop at the first mismatch and report divergence rather than inventing continuity.',
    ])
    p=doc.add_paragraph()
    p.add_run('Captured demonstration. ').bold=True
    p.add_run('The included Ruy Lopez replay JSON reconstructs the same final state from its initial FEN and hash-chained events. A test flips an event field and confirms that replay rejects the tampered lineage.')

    add_source_note(doc,'This layer directly follows the Two Hands 3.0 proposal/commit/checkpoint model and the KC 3.9 canonical snapshot/hash/save discipline, while keeping the chess rule kernel authoritative.')
    doc.add_page_break()


def search_section(doc):
    add_section_title(doc,'6','Heuristic Search Layer','The general engine is deterministic and inspectable, but only mate scores supported by terminal search or separate certificates receive proof meaning.')
    doc.add_heading('6.1 Search stack',level=2)
    rows=[
        ('Iterative deepening','Search depth 1..N; retain the last fully completed result under an optional time limit.'),
        ('Negamax alpha-beta','Symmetric minimax recursion with alpha/beta bounds and deterministic move ordering.'),
        ('Quiescence','At depth zero, extend captures and promotions; when in check, search all legal evasions.'),
        ('Transposition table','64-bit position key; exact/lower/upper bounds; mate-distance normalization; deterministic shallow-entry eviction.'),
        ('Evaluation','Material plus transparent piece-square terms. Returned in centipawns from the side-to-move view.'),
        ('Draw context','Halfmove and repetition history passed to terminal status; configured claim policy determines claimable draws.'),
    ]
    add_table(doc,['Mechanism','Implementation'],rows,widths=[1.45,5.15],font_size=8.2,first_col_bold=True)

    doc.add_heading('6.2 Worked search result',level=2)
    b=json.loads((ROOT/'validation/benchmark.json').read_text())['mate_search']
    add_code(doc,json.dumps({
        'root_fen':'8/8/8/8/8/k7/8/1QK5 w - - 0 1',
        'depth':b['depth'],
        'score_text':b['score_text'],
        'best_move':b['best_move'],
        'principal_variation_san':b['principal_variation_san'],
        'nodes':b['nodes'],
        'qnodes':b['qnodes'],
        'tt_hits':b['tt_hits'],
    },indent=2))
    p=doc.add_paragraph()
    p.add_run('Interpretation. ').bold=True
    p.add_run('The engine finds Qb5, Ka2, Qb2# and reports mate +2. The release does not promote the measured seconds or nodes per second as a general performance claim; they describe one reference run. More importantly, the same line is independently supported by the proof certificate and KQK tablebase.')

    add_callout(doc,'Search boundary','A centipawn score and principal variation may change with depth, evaluator or time limit. They are decision aids. The exact proof and tablebase interfaces use separate types and reason codes so a heuristic result cannot masquerade as a theorem.',fill='FFF4F2',accent=RED)
    doc.add_page_break()


def proof_section(doc):
    add_section_title(doc,'7','Proof-Carrying Bounded Mate Solver','The certificate encodes the game-tree quantifiers, not merely one cooperative line.')
    add_pic(doc,'proof_tree.png',width=6.75,alt='OR and AND proof tree showing Qb5, all Black replies, Qb2 mate, and the independent verifier checks.')
    caption(doc,'Finite-horizon mate certificate and independent verification conditions.')

    doc.add_heading('7.1 Formal quantifiers',level=2)
    add_code(doc,'prove(q, attacker, p) =\n  OR  over legal attacker moves when side(q) = attacker\n  AND over every legal defender reply otherwise\n\nleaf success = checkmate(q) and winner(q) = attacker')
    add_bullets(doc,[
        'Each node stores its exact FEN and 64-hex SHA-256 state identity.',
        'An OR node stores exactly one legal attacker move and its proved child.',
        'An AND node stores a reply list whose UCI set must equal the complete legal defender move set.',
        'A terminal node must independently reconstruct as checkmate for the declared attacker.',
        'The verifier enforces the declared maximum ply horizon and rejects extra, missing or malformed branches.',
        'Repetition and the 50-move threshold are treated as proof-failure boundaries inside the path search.',
    ],compact=False)

    doc.add_heading('7.2 Certificate result',level=2)
    rows=[
        ('Root FEN','8/8/8/8/8/k7/8/1QK5 w - - 0 1'),
        ('Attacker / horizon','White / 3 plies'),
        ('Prover result','proved'),
        ('Prover nodes explored','418'),
        ('Certificate nodes verified','4'),
        ('Forced line','1. Qb5 Ka2 2. Qb2#'),
        ('Root SHA-256','64500465593f60fd69f567e84cd79634d272857edd9aad90b056123f04270b16'),
    ]
    add_table(doc,['Field','Captured result'],rows,widths=[1.7,4.9],font_size=8.3,first_col_bold=True)
    doc.add_page_break()


def worked_proof(doc):
    add_section_title(doc,'7.3','Worked Exact Mate in Two','Three independent mechanisms agree: legal search, the proof certificate and the KQK DTM tablebase.')
    add_pic(doc,'mate_sequence.png',width=6.85,alt='Three chessboards showing the initial KQK position, Qb5, and Ka2 Qb2 checkmate.')
    caption(doc,'Exact sequence from root to mate. Highlighted squares show the queen move on each transition.')

    doc.add_heading('Cross-checks',level=2)
    rows=[
        ('Legal kernel','Qb5, Ka2 and Qb2# parse as unique legal moves; each intermediate FEN and state hash is reproduced.'),
        ('Mate prover','White has one selected winning OR branch; Black’s AND node enumerates its complete legal reply set.'),
        ('Proof verifier','All four certificate nodes pass FEN, hash, legal transition, reply-coverage and terminal-mate checks.'),
        ('KQK tablebase','Root is exact win with DTM 3; Qb5 leads to exact loss with DTM 2 for Black; Qb2 ends in checkmate.'),
        ('Alpha-beta search','Depth 4 reports mate +2 with the same SAN principal variation.'),
    ]
    add_table(doc,['Independent path','Agreement'],rows,widths=[1.5,5.1],font_size=8.2,first_col_bold=True)

    add_callout(doc,'Why this is stronger than a line','A displayed move sequence alone could assume cooperation. The AND certificate records every legal defender reply at each defender node. In this root there is one such reply, but the verifier checks completeness from the rule kernel rather than trusting that claim.',fill='EAF7F3',accent=TEAL)
    doc.add_page_break()


def tablebase_section(doc):
    add_section_title(doc,'8','Complete KQK and KRK Tablebases','Retrograde analysis exactly classifies every valid state in each declared three-piece material space.')
    add_pic(doc,'tablebase_counts.png',width=6.65,alt='Stacked bars for all 524,288 KQK and KRK addresses showing invalid, win, loss and draw counts, plus max DTM and compressed size.')
    caption(doc,'Dense outcome accounting. Counts sum exactly to 524,288 cells for each 19-bit table.')

    doc.add_heading('8.1 Dense key and normalization',level=2)
    add_code(doc,'K = (((Ks * 64) + X) * 64 + Kw) * 2 + side\n\nKs   strong king square 0..63\nX    strong queen or rook square 0..63\nKw   weak king square 0..63\nside side to move, normalized to strong-side White\n\naddress capacity = 64 * 64 * 64 * 2 = 2^19 = 524,288')
    p=doc.add_paragraph()
    p.add_run('Invalid cells remain explicit. ').bold=True
    p.add_run('Overlapping pieces, adjacent kings and unreachable “strong side to move while the weak king is already left in check” encodings are marked invalid instead of being silently compacted away. Black-strong positions are normalized by a 180-degree rotation and color swap.')

    doc.add_heading('8.2 Retrograde relation',level=2)
    add_numbered(doc,[
        'Enumerate all valid cells and legal successors.',
        'Seed checkmated weak-to-move states as LOSS with DTM 0 and no-move non-check states as DRAW.',
        'A predecessor is WIN when it has at least one successor classified LOSS.',
        'A predecessor is LOSS when every legal successor is WIN.',
        'Unresolved valid cells after propagation are DRAW.',
        'For WIN choose the shortest loss child; for LOSS retain the longest delaying win child.',
    ])
    doc.add_page_break()


def tablebase_metrics(doc):
    add_section_title(doc,'8.3','Tablebase Metrics, Packing and Probe Contract','The compact files are finite, typed and auditable; transport compression is not confused with semantic compression.')
    rows=[
        ('Metric','KQK','KRK'),
        ('Address cells',f"{kq['address_count']:,}",f"{kr['address_count']:,}"),
        ('Valid positions',f"{kq['valid_positions']:,}",f"{kr['valid_positions']:,}"),
        ('Win / loss / draw',f"{kq['outcome_counts']['win']:,} / {kq['outcome_counts']['loss']:,} / {kq['outcome_counts']['draw']:,}",f"{kr['outcome_counts']['win']:,} / {kr['outcome_counts']['loss']:,} / {kr['outcome_counts']['draw']:,}"),
        ('Initial mates / stalemates',f"{kq['initial_checkmates']:,} / {kq['initial_stalemates']:,}",f"{kr['initial_checkmates']:,} / {kr['initial_stalemates']:,}"),
        ('Maximum DTM',f"{kq['max_dtm_plies']} plies",f"{kr['max_dtm_plies']} plies"),
        ('Raw payload',f"{kq['raw_payload_bytes']:,} bytes",f"{kr['raw_payload_bytes']:,} bytes"),
        ('Gzip transport',f"{kq['file_bytes']:,} bytes",f"{kr['file_bytes']:,} bytes"),
        ('SHA-256',kq['sha256'][:16]+'...',kr['sha256'][:16]+'...'),
    ]
    # custom remove first row because add_table supplies header
    add_table(doc,rows[0],rows[1:],widths=[2.05,2.25,2.25],font_size=8.2,first_col_bold=True)

    doc.add_heading('Probe semantics',level=2)
    add_code(doc,'{\n  "material": "KQK",\n  "outcome": "win",\n  "dtm_plies": 3,\n  "side_to_move": "white",\n  "strong_side": "white",\n  "exact": true,\n  "best_moves": [{"move": "b1b5", "san": "Qb5"}]\n}')
    add_bullets(doc,[
        'WDL is from the side-to-move perspective.',
        'DTM counts plies to checkmate under optimal play.',
        'All decisive KQK/KRK states in these tables finish within the observed maxima, below the 100-ply claim boundary.',
        'Each raw address stores one outcome byte and one DTM byte; gzip is only a deterministic distribution layer.',
        'The release stores exact SHA-256 transport hashes and tests sampled retrograde invariants.',
    ],compact=False)

    add_source_note(doc,'This follows SCLP 3.6.2’s rule that a finite key is an address into a declared profile, not the whole world, and that nominal bit-width gains are never promoted without reconstruction semantics.')
    doc.add_page_break()


def global_arch(doc):
    add_section_title(doc,'9','Global-Solve Architecture','The package specifies how exact claims could scale without turning distributed search output into unchecked authority.')
    add_pic(doc,'global_solve.png',width=6.8,alt='Distributed solve architecture with canonicalizer, shard planner, worker pool, certificate store, verifiers, conflict resolver, Merkle manifest and root status.')
    caption(doc,'Certificate-first shard architecture. It is a roadmap and data contract, not evidence that the initial position is solved.')

    doc.add_heading('9.1 Work-unit contract',level=2)
    rows=[
        ('Input','Canonical position identity; ruleset/profile hash; requested proof relation; resource budget; dependency shard hashes.'),
        ('Worker output','Immutable claim: proved win/loss/draw, bounded non-proof, or frontier; proof DAG/table slice; metrics; content hash.'),
        ('Verification','Recompute legality, terminal status, branch coverage, retrograde relations and all transport hashes in an independent process.'),
        ('Conflict policy','Equal position hash and profile must yield compatible claims; contradictions are quarantined and never merged silently.'),
        ('Coverage','Merkle manifest records which state sectors are exact, rejected, duplicate, missing or awaiting dependencies.'),
        ('Root decision','Only a fully verified dependency closure can promote the initial position from unknown to a game-theoretic result.'),
    ]
    add_table(doc,['Record','Contract'],rows,widths=[1.35,5.25],font_size=8.2,first_col_bold=True)

    doc.add_heading('9.2 Why UGTS helps',level=2)
    add_bullets(doc,[
        'Stable state and definition hashes make duplicated work and contradictory claims visible.',
        'Support and compatibility remove out-of-profile relations before expensive proof work.',
        'Guard and event semantics make terminal/draw conditions explicit rather than hidden in worker code.',
        'Lineage preserves the exact dependency path used to promote a root claim.',
        'Unknown and rejected are first-class statuses, preventing “not found” from being misreported as “false.”',
    ],compact=False)

    add_callout(doc,'Promotion gate','A larger compute cluster does not weaken the proof standard. Throughput, cache size or branch count can never replace completeness, independent verification and a closed dependency manifest.',fill='FFF9E8',accent=GOLD)
    doc.add_page_break()


def implementation(doc):
    add_section_title(doc,'10','Implementation and Command Line','The accompanying ZIP is self-contained, dependency-free at runtime and designed for inspection before optimization.')
    add_pic(doc,'package_map.png',width=6.75,alt='Package tree showing source, data, spec, examples, validation, web and report folders.')
    caption(doc,'Accompanying package map. The two compressed tablebases are included both as data files and wheel resources.')

    doc.add_heading('10.1 Python modules',level=2)
    rows=[
        ('position.py','Strict FEN parser/serializer and immutable position record.'),
        ('rules.py','Attack detection, pseudo/legal moves, state transitions, SAN, terminal/draw status and perft.'),
        ('hashing.py','Canonical state hash, repetition key and compact transposition key.'),
        ('ugts.py','Move proposals, guard evidence, authoritative commit and hash-checked replay.'),
        ('evaluate.py','Transparent material and piece-square evaluation.'),
        ('search.py','Iterative-deepening alpha-beta, quiescence and deterministic transposition table.'),
        ('proof.py','Finite-horizon OR/AND mate prover and independent verifier.'),
        ('tablebase.py','KQK/KRK dense encoding, retrograde generation, probing and best moves.'),
        ('cli.py','info, validate, perft, solve, prove-mate, verify-proof, probe, generate-tablebase and demo.'),
    ]
    add_table(doc,['Module','Responsibility'],rows,widths=[1.35,5.25],font_size=8.0,first_col_bold=True)
    doc.add_page_break()


def cli_section(doc):
    add_section_title(doc,'10.2','Reproduction and Examples','Every result used by this report is stored as a machine-readable artifact and can be regenerated from the package root.')
    doc.add_heading('Core commands',level=2)
    add_code(doc,'PYTHONPATH=src python -m unittest discover -s tests -v\nPYTHONPATH=src python -m ugts_chess info\nPYTHONPATH=src python -m ugts_chess perft --depth 4\nPYTHONPATH=src python -m ugts_chess solve --depth 4 --fen "8/8/8/8/8/k7/8/1QK5 w - - 0 1"\nPYTHONPATH=src python -m ugts_chess prove-mate --plies 3 --fen "8/8/8/8/8/k7/8/1QK5 w - - 0 1" --out examples/mate_in_two_proof.json\nPYTHONPATH=src python -m ugts_chess verify-proof examples/mate_in_two_proof.json\nPYTHONPATH=src python -m ugts_chess probe --fen "8/8/8/8/8/k7/8/1QK5 w - - 0 1"')

    doc.add_heading('Included examples',level=2)
    rows=[
        ('mate_in_two_proof.json','Complete proof certificate with FEN/hash at every node.'),
        ('mate_in_two_search.json','Heuristic search result with PV, counts and timing.'),
        ('kqk_probe.json','Exact tablebase WDL/DTM probe and best move.'),
        ('ruy_lopez_replay.json','Initial state plus deterministic hash-chained move events.'),
        ('project.json','Versioned batch project containing perft, proof, tablebase and search tasks.'),
        ('proof_viewer.html','Single-file offline viewer for a pasted or built-in proof certificate.'),
        ('ugts_kc_chess-1.0.0-py3-none-any.whl','Installable wheel containing runtime and tablebase resources.'),
    ]
    add_table(doc,['Artifact','Purpose'],rows,widths=[2.25,4.35],font_size=8.2,first_col_bold=True)

    doc.add_heading('Regenerating the exact tables',level=2)
    add_code(doc,'PYTHONPATH=src python -m ugts_chess generate-tablebase --piece Q --out data/kqk.tb.gz\nPYTHONPATH=src python -m ugts_chess generate-tablebase --piece R --out data/krk.tb.gz')
    p=doc.add_paragraph(style='Small')
    p.add_run('Generation is deterministic: the gzip header uses mtime=0 and an empty filename; metadata stores the resulting SHA-256. Full regeneration is computationally heavier than probing but remains practical for these three-piece spaces.')
    doc.add_page_break()


def validation_section(doc):
    add_section_title(doc,'11','Validation and Release Evidence','The release gates test legality, proof structure, exact state-space accounting, schemas, packaging and deterministic artifacts.')
    add_pic(doc,'perft_chart.png',width=6.55,alt='Log-scale bar chart showing the largest tested perft count for six fixtures, all matching expected values.')
    caption(doc,'Legal-move regression. All 19 expected perft counts match exactly.')

    doc.add_heading('11.1 Perft coverage',level=2)
    rows=[
        ('Initial position','Depth 1-4','20; 400; 8,902; 197,281'),
        ('Kiwipete','Depth 1-3','48; 2,039; 97,862'),
        ('Position 3','Depth 1-3','14; 191; 2,812'),
        ('Position 4','Depth 1-3','6; 264; 9,467'),
        ('Position 5','Depth 1-3','44; 1,486; 62,379'),
        ('Position 6','Depth 1-3','46; 2,079; 89,890'),
    ]
    add_table(doc,['Fixture','Depths','Expected = actual nodes'],rows,widths=[1.4,1.15,4.05],font_size=8.2,first_col_bold=True)
    p=doc.add_paragraph()
    p.add_run('Why perft matters. ').bold=True
    p.add_run('Perft does not test playing strength, but it is a high-value structural oracle for move generation. These fixtures stress castling, en-passant, promotions, pins, checks and complex occupancy interactions.')
    doc.add_page_break()


def validation_dashboard_section(doc):
    add_section_title(doc,'11.2','Release Gates and Captured Metrics','Passing tests establish internal consistency of this package; they do not establish full-game solution or cross-device performance.')
    add_pic(doc,'validation_dashboard.png',width=6.75,alt='Dashboard reporting 65 tests, 19 perft checks, 2 schemas, 4 proof nodes, 2 exact tablebases and 1 built wheel.')
    caption(doc,'Release-gate summary generated from validation/summary.json.')

    rows=[
        ('Python compile','PASS','All source and tool modules compile.'),
        ('Automated tests','65/65 PASS',f"Captured suite completed in {validation['tests']['seconds']:.2f} s."),
        ('Perft','19/19 PASS',f"Largest exact leaf count {validation['perft']['largest_nodes']:,}."),
        ('Proof verification','PASS','Mate certificate schema valid; 4 nodes independently verified after 418-node proof search.'),
        ('Tablebases','PASS',f"Two SHA-checked tables, {validation['tablebases']['compressed_bytes']:,} compressed bytes total; maxima 20/32 plies."),
        ('JSON Schema','2/2 PASS','Project and proof examples validate under Draft 2020-12.'),
        ('Wheel build','PASS','ugts_kc_chess-1.0.0-py3-none-any.whl built without downloading dependencies.'),
        ('Reference benchmark','MEASURED','Mate +2; 1,195 main nodes + 796 quiescence nodes in one Python 3.13.5 run.'),
    ]
    add_table(doc,['Gate','Status','What is established'],rows,widths=[1.35,1.1,4.15],font_size=7.9,first_col_bold=True)

    add_callout(doc,'Measurement boundary','Run time and nodes per second are environment-specific. The exact claims are the rule outputs, proof verification, state-space counts and hashes - not a generalized speed advantage over mature chess engines.',fill='FFF9E8',accent=GOLD)
    doc.add_page_break()


def catalog_section(doc):
    add_section_title(doc,'12','Mechanism Catalog C001-C064','The namespaced catalog adds 64 chess-application mechanisms without renumbering the supplied UGTS source catalogs.')
    counts=Counter(m['domain'] for m in mechanisms)
    top=sorted(counts.items(),key=lambda kv:(-kv[1],kv[0]))
    rows=[]
    for domain,count in top:
        ids=[m['id'] for m in mechanisms if m['domain']==domain]
        mechanisms_names=[m['mechanism'] for m in mechanisms if m['domain']==domain]
        rows.append((
            domain,
            count,
            f"{ids[0]}-{ids[-1]}" if len(ids) > 1 else ids[0],
            '; '.join(mechanisms_names[:3]) + ('; ...' if len(mechanisms_names) > 3 else ''),
        ))
    table_caption(doc,'Catalog distribution by domain',5)
    add_table(doc,['Domain','Count','IDs','Representative mechanisms'],rows,widths=[1.1,0.55,0.8,4.15],font_size=7.4,first_col_bold=True)

    doc.add_heading('12.1 Representative operator records',level=2)
    selected=['C001','C009','C016','C025','C032','C038','C047','C055','C064']
    sel=[m for m in mechanisms if m['id'] in selected]
    rows=[(m['id'],m['domain'],m['mechanism'],m['definition'],m['validation']) for m in sel]
    add_table(doc,['ID','Domain','Mechanism','Normalized definition','Validation'],rows,widths=[0.42,0.82,1.2,3.65,0.65],font_size=6.8,first_col_bold=True)

    add_callout(doc,'Catalog meaning','Mechanism IDs are traceability entries for implementation and validation coverage. They are not, by themselves, claims of novelty, patentability, scientific priority, ownership or complete formal verification.',fill='FFF9E8',accent=GOLD)
    doc.add_page_break()


def boundaries_final(doc):
    add_section_title(doc,'13','Boundaries, Kill Criteria and Final Definition','The profile is promoted only where its exact contracts outperform or complement simpler conventional approaches at equal correctness.')
    doc.add_heading('13.1 Explicit non-claims',level=2)
    add_bullets(doc,[
        'No weak, strong or ultra-weak solution of the standard initial chess position is claimed.',
        'No playing-strength comparison with Stockfish, Leela Chess Zero or another mature engine is claimed.',
        'No universal cross-platform bit-identical floating-point evaluation is claimed; legality and serialized proof/hash records are the exact boundary.',
        'No complete 4- through 7-piece tablebase corpus is bundled; only complete KQK and KRK DTM tables are included.',
        'No exhaustive formal proof of the Python interpreter, operating system or hardware is claimed.',
        'No legal identity, authorship, patentability, licensing or ownership inference follows from the requester attribution.',
    ],compact=False)

    doc.add_heading('13.2 Kill criteria',level=2)
    add_bullets(doc,[
        'Any legal-move mismatch appears in perft, SAN round trips or special-rule tests.',
        'A proof verifier can accept a missing defender reply, illegal move, bad FEN/hash or non-mate leaf.',
        'A tablebase address collision occurs, counts fail to sum to 2^19, or sampled retrograde relations fail.',
        'Compact keys, gzip size or cache behavior are promoted as correctness without reconstruction and collision/error contracts.',
        'Repetition history, claim policy or halfmove thresholds are implicit in a result that depends on them.',
        'Distributed workers can mutate authoritative state or promote a claim without independent certificate verification.',
        'The UGTS layer becomes more complex, slower or less auditable than a conventional rules/search/tablebase implementation at equal error and evidence.',
    ],compact=False)

    doc.add_heading('13.3 Final formal definition',level=2)
    add_callout(doc,'Formal definition','UGTS-KC Chess 1.0 is a finite, content-addressed, deterministic application profile in which a typed chess position and history define move supports; compatibility and special-rule guards filter proposals; king-safety evaluation certifies legal events; atomic transitions patch board, rights, en-passant state and clocks; SHA-256 lineage supports replay; exact OR/AND certificates prove forced mate within a declared horizon; complete KQK/KRK retrograde tables answer bounded endgames; and heuristic alpha-beta search remains a downstream estimator.',fill='EAF3FA',accent=BLUE)
    p=doc.add_paragraph()
    p.add_run('Canonical shorthand: ').bold=True
    p.add_run('position + history -> move support -> compatibility -> special-rule and king-safety guards -> verified move event -> deterministic state patch -> hash lineage/replay -> optional search, proof, tablebase and presentation outputs.')
    doc.add_page_break()


def appendix_package(doc):
    add_section_title(doc,'Appendix A','Package Map and Reproduction','The ZIP contains the complete source, exact data, examples, report source and captured evidence needed to inspect or rerun the release.')
    rows=[
        ('src/ugts_chess/','Dependency-free rule kernel, events/replay, search, proofs, tablebase generator/prober and CLI.'),
        ('data/','KQK and KRK compressed tables plus metadata and SHA-256.'),
        ('spec/','Formal definition, 64-mechanism catalog, JSON schemas and source register.'),
        ('examples/','Mate proof/search/probe, replay, project and runnable demo.'),
        ('tests/','65 standard-library unittest cases.'),
        ('validation/','Compile, tests, perft, schemas, tablebase hashes, benchmark, wheel build and release summary.'),
        ('web/','Self-contained HTML proof viewer.'),
        ('report/','This PDF, editable DOCX source and generated figures.'),
        ('checksums/','Final package SHA-256 manifest.'),
    ]
    add_table(doc,['Path','Contents'],rows,widths=[1.5,5.1],font_size=8.2,first_col_bold=True)

    doc.add_heading('Clean reproduction sequence',level=2)
    add_code(doc,'cd UGTS_KC_CHESS_1_0\nPYTHONPATH=src python tools/generate_examples.py\nPYTHONPATH=src python tools/run_validation.py\npython tools/generate_report_assets.py\npython tools/build_report.py')
    p=doc.add_paragraph()
    p.add_run('Wheel installation. ').bold=True
    p.add_run('The built wheel is under validation/dist/. After installation, the console entry point is ugts-chess and the tablebase resources load from the installed package.')

    doc.add_heading('Release identifiers',level=2)
    rows=[
        ('Runtime version','1.0.0'),('Solver schema','ugts-kc-chess-solver-1.0'),('Proof schema','ugts-kc-chess-mate-proof-1.0'),
        ('Tablebase schema','ugts-kc-chess-kxk-tablebase-1.0'),('Catalog range','C001-C064'),('Automated tests','65'),('Exact tablebases','KQK and KRK'),
    ]
    add_table(doc,['Identifier','Value'],rows,widths=[2.0,4.6],font_size=8.4,first_col_bold=True)
    doc.add_page_break()


def appendix_sources(doc):
    add_section_title(doc,'Appendix B','Source Register and References','Supplied sources are referenced by exact SHA-256 and are not redistributed inside the accompanying ZIP.')
    rows=[]
    for s in source_reg['sources']:
        rows.append((s['title'],s['page_basis'],s['sha256'][:18]+'...',s['role']))
    add_table(doc,['Source','Page basis','SHA-256 prefix','Role'],rows,widths=[1.35,1.05,1.45,2.75],font_size=7.0,first_col_bold=True)

    doc.add_heading('External standards/context',level=2)
    p=doc.add_paragraph()
    p.add_run('FIDE Laws of Chess taking effect from 1 January 2023. ').bold=True
    p.add_run('Official handbook: https://handbook.fide.com/chapter/e012023. Used for current rule terminology and draw/checkmate semantics; the implementation boundary is described in Section 4.')
    p=doc.add_paragraph()
    p.add_run('Syzygy endgame tablebases. ').bold=True
    p.add_run('Public context: https://syzygy-tables.info/. Used only to state that public exact endgame coverage extends beyond the two bundled three-piece tables; no Syzygy files or code are redistributed.')

    doc.add_heading('Requester and legal boundary',level=2)
    p=doc.add_paragraph()
    p.add_run('Prepared for Tom Klootwijk. ').bold=True
    p.add_run('The requester attribution is recorded as supplied and has not been independently verified. This report and package are technical design artifacts. They are not legal proof of identity, authorship, ownership, patentability, priority, exclusive rights, licensing status or chain of title.')

    doc.add_heading('Closing statement',level=2)
    add_callout(doc,'Release interpretation','The package provides an auditable path from chess state to legal move, verified event, deterministic replay, bounded mate proof and exact finite endgame result. Its strongest claim is not that all chess has been solved, but that each promoted result states exactly what was solved, under which profile, with which certificate, hash, test and boundary.',fill='EAF7F3',accent=TEAL)


def main():
    REPORT.mkdir(parents=True,exist_ok=True)
    doc=setup_document()
    cover(doc)
    contents_exec(doc)
    source_section(doc)
    solve_meaning(doc)
    formal_state(doc)
    rule_kernel(doc)
    events_replay(doc)
    search_section(doc)
    proof_section(doc)
    worked_proof(doc)
    tablebase_section(doc)
    tablebase_metrics(doc)
    global_arch(doc)
    implementation(doc)
    cli_section(doc)
    validation_section(doc)
    validation_dashboard_section(doc)
    catalog_section(doc)
    boundaries_final(doc)
    appendix_package(doc)
    appendix_sources(doc)
    doc.save(OUT)
    print(OUT)

if __name__=='__main__':
    main()
