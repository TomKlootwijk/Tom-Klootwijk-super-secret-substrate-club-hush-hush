UGTOMS DOMAIN CARTRIDGES - BATCH 03
Release date: 30 August 2026

DELIVERY ORDER

07. UGTOMS CIVITAS 1.0
    Canonical identity: ugtoms.domain.civitas@1.0.0
    21 pages
    A living-city cartridge for streets, buildings, utilities, mobility,
    accessibility, permits, incidents, construction phases, service states,
    counterfactual city changes and replayable civic-world lineage.

08. UGTOMS ARCANA 1.0
    Canonical identity: ugtoms.domain.arcana@1.0.0
    22 pages
    An executable fictional-magic cartridge for rune OperatorCells, spell
    graphs, ritual phases, mana/resource accounting, spatial supports,
    compatibility, wards, counterspells, reversibility and deterministic
    magical-world commits. It defines fictional game and simulation rules;
    it makes no claim of real supernatural effects.

09. UGTOMS CHRONOFORGE 1.0
    Canonical identity: ugtoms.domain.chronoforge@1.0.0
    22 pages
    A branching-time cartridge for time-loop games, counterfactual worlds,
    forked timelines, dependency-aware descendant invalidation, rollback,
    compensation, paradox classification, branch merge, immutable parents
    and independently replayable histories.

BATCH DECISION
The previously proposed generic EVIDENCE and CAUSAL slots were replaced by
ARCANA and CHRONOFORGE to prioritize more distinctive, playable and visually
expressive applications while retaining typed state, explicit order, verified
commit, bounded uncertainty and lineage.

VALIDATION SUMMARY
- Searchable tagged A4 PDFs with embedded fonts.
- Visual page-by-page inspection completed for all 65 pages.
- PDF preflight: openable, unencrypted, non-scanned, no XFA.
- Renderer verification: 21 + 22 + 22 pages rendered successfully.
- Internal cartridge specification self-check: 32/32 PASS per cartridge.

EVIDENCE BOUNDARY
These reports are formal application and cartridge specifications. They do not
claim that production implementations, field deployments, safety certification,
legal authority, supernatural phenomena or physical time travel already exist.
External domain engines and real-world authorities remain versioned adapters
behind the UGTOMS proposal, verification, deterministic commit and lineage
boundary.
