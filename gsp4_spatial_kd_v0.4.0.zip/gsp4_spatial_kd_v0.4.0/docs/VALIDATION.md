# Validation report

## Validation completed in the preparation environment

Environment:

```text
Python 3.13.5
PyTorch 2.10.0+cpu
NumPy 2.3.5
CUDA unavailable
```

The following were executed successfully:

- source compilation with `python -m compileall`;
- 48 pytest cases and 34 unittest-discoverable cases;
- variable-length demo graph generation;
- `UGKG2` save/load and schema-hash verification;
- Morton cell encode/decode/neighborhood tests;
- GeoNames and OSM XML fixture ingestion;
- teacher embedding cache and bounded candidate generation;
- teacher-label and ULTRA score file adapters;
- compact HGT/TGN student training, save/load and inference;
- deterministic support/compatibility/guard query;
- `UGNL3` append, validation and tamper detection;
- G64/G32 buffer export and precision-margin assertion;
- `.ugdeploy` creation, duplicate-name regression test, payload SHA-256 checks,
  graph/model compatibility and novelty terminal-hash validation;
- CPU benchmark and environment report generation.

Test command:

```bash
python -m unittest discover -s tests -v
```

Result:

```text
Ran 34 tests
OK

pytest: 48 passed
```

## Included pilot artifacts

`data/flevoland_pilot.ugkg`:

```text
228 nodes
1,305 edges
97 observations over 8 irregular windows
9 to 15 observations per window
7 node types
16 relation types
64-dimensional deterministic smoke teacher
```

`data/flevoland_pilot.ugnl`:

```text
118 records
72 bytes per record
hash chain valid
```

`models/gsp4_flevoland_smoke.pt`:

```text
2 HGT-style layers
hidden dimension 64
4 heads
341,459 parameters
3 CPU smoke epochs
schema-bound to the included graph
```

The loss and test values in the included metrics are not model-quality claims.
Three epochs and hash-derived teacher vectors are intentionally insufficient for
production semantics.

## CPU benchmark boundary

The included CPU benchmark validates timing instrumentation and result shape.
It does not predict the laptop GPU rate. Logical throughput is not raw DRAM
bandwidth.

## Not validated here

- CUDA execution on the RTX 5070 Ti Laptop GPU;
- BF16 support and numerical agreement on that device;
- laptop power, thermal and TGP behavior;
- a full Qwen embedding run;
- relation labels from a real large teacher;
- ULTRA inference itself;
- model quality on a real, labeled geospatial task;
- H3 backend in this environment;
- large PBF ingestion using `pyosmium`;
- security against a malicious ZIP or untrusted model checkpoint.

PyTorch checkpoints should be treated as trusted artifacts. The package uses a
safe-loading helper when supported, but users should not load arbitrary model
files from unknown sources.

## Target acceptance sequence

1. Install the current NVIDIA driver and CUDA-capable PyTorch wheel.
2. Run `gsp4 doctor`; archive the JSON report.
3. Run the included model query on CUDA and compare event IDs with the CPU file.
4. Run the no-download training/demo path.
5. Validate the resulting graph, novelty log and deployment archive.
6. Export G64/G32 candidates and verify the packed precision result.
7. Benchmark p50/p95/p99, peak VRAM, candidate rejection and event yield.
8. Add a real embedding teacher.
9. Add real geographic data.
10. Apply the declared kill criteria before making a performance/compression
    claim.
