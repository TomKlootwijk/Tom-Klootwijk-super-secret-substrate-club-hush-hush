# RTX 5070 Ti Laptop GPU runbook

## Hardware target

The target is the NVIDIA GeForce RTX 5070 Ti Laptop GPU with 12 GB GDDR7. GSP4
uses ordinary PyTorch CUDA kernels; the lower-level substrate bridge can also be
consumed by CUDA or Vulkan/SPIR-V code.

## Prerequisites

- current NVIDIA Studio or Game Ready driver;
- Windows 11 or a supported Linux distribution;
- Python 3.11 or 3.12 x64;
- at least 12 GB free disk for a CUDA PyTorch environment and build caches;
- AC power and a performance power profile for meaningful benchmark runs.

The CUDA Toolkit is not required for the pure PyTorch GSP4 path because PyTorch
wheels include CUDA runtime libraries. It is required for compiling custom CUDA
extensions or the earlier native CUDA package. CUDA 12.8 is the minimum toolkit
release that added SM_120 compiler support.

## Installation

PowerShell:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\setup_windows.ps1
.\.venv\Scripts\Activate.ps1
gsp4 doctor --output results\rtx5070ti_doctor.json
```

The setup script defaults to the official CUDA 12.8 PyTorch wheel index. An
alternate official wheel suffix can be supplied:

```powershell
.\scripts\setup_windows.ps1 -TorchIndexUrl https://download.pytorch.org/whl/cu130
```

Do not proceed when the doctor report says `cuda_available=false`, the selected
device is not the intended GPU, or the FP16/indexed-reduction smoke test fails.

## First no-download run

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\run_demo_windows.ps1
```

The script writes all artifacts below `results\rtx5070ti_demo` and does not
contact a model server.

Expected functional checks:

```text
GPU doctor ready=true
training checkpoint graph schema hash matches graph
query returns deterministic source/target IDs
novelty chain valid=true
.ugdeploy valid=true and model_valid=true
benchmark runtime names the physical CUDA device
```

## Recommended first profile

```text
precision               bf16
hidden dimension        128
heads                    4
layers                   3
epochs                   20
maximum training edges  50,000
maximum encoder edges   250,000
```

The supplied graph is small, so it will not fill the GPU. It validates the
software path. For throughput work, ingest a larger graph and use sampled
subgraphs rather than building a fully connected neighborhood.

## Benchmark commands

```powershell
gsp4 benchmark data\flevoland_pilot.ugkg models\gsp4_flevoland_smoke.pt `
  --device cuda --precision bf16 --warmup 5 --repeats 30 `
  --source sensor:0:0:air --relation near --radius 10000 --epsilon 25 `
  --output results\included_model_gpu_benchmark.json
```

The included checkpoint was trained on CPU but is CUDA-loadable. The larger demo
trains a new checkpoint directly on the laptop.

Record alongside every result:

```text
GPU name and compute capability
NVIDIA driver
PyTorch and embedded CUDA versions
power mode/TGP if known
precision
model configuration and parameter count
graph schema hash and node/edge counts
candidate count and event yield
warmup/repeat count
peak CUDA memory
p50/p95/p99 latency
```

## VRAM controls

When memory is insufficient, change settings in this order:

1. reduce `--max-encoder-edges`;
2. reduce `--max-edges` and teacher edge batches;
3. reduce hidden dimension from 256 to 128;
4. reduce layers from 4 to 3;
5. keep teacher embeddings on disk and train only selected node types;
6. run the embedding/LLM teacher in a separate process or on CPU.

Do not solve variable-length input by padding every time window to its maximum
point count.

## Precision acceptance

Use BF16 for model operations where supported, but retain deterministic spatial
fields in float32 unless a measured packed export proves its error remains
inside the guard margin. `gsp4 export-ugts` reports the G32 conversion error and
a boolean precision verdict.

A run fails when:

- node/event IDs differ between repeated deterministic queries;
- graph/model schema hashes differ;
- the novelty chain is invalid;
- FP16/BF16 changes event ordering outside the application budget;
- candidate pruning is ineffective;
- compaction/atomic work dominates;
- a simpler sparse baseline is faster or more accurate at the same error.

## Thermal procedure

For comparable laptop measurements:

1. connect AC power;
2. select the same manufacturer performance profile;
3. close games, browsers and GPU-accelerated applications;
4. allow a short warmup;
5. record ambient/initial GPU temperature when available;
6. run at least 20 repeats;
7. report p50 and tail latency rather than only the best run.
