# Limitations and kill criteria

## Current implementation limits

- The included student is a compact dependency-light HGT/TGN-style implementation, not a reproduction of every published HGT or TGN feature.
- H3 is optional; the default Morton index is simpler and less geometrically uniform.
- OSM ingestion intentionally handles a bounded subset of tags and point/centroid features.
- The package does not merge arbitrary GeoNames and OSM graphs automatically; identity reconciliation is application-specific.
- Teacher quality depends on the selected model, prompt, ontology and review policy.
- ULTRA execution remains external; only interchange adapters are bundled.
- The included checkpoint is trained for a software smoke test and has no claim of real-world accuracy.
- CUDA timings must be generated on the target laptop.

## Kill criteria

Stop or redesign when:

- spatial/type pruning leaves nearly all candidate pairs;
- event or branch density approaches dense materialization cost;
- teacher labels are poorly calibrated or contradict deterministic facts;
- FP16/BF16/fixed-point error changes event ordering or exceeds epsilon;
- graph encoding or event compaction dominates the useful query;
- novelty density is high enough that a snapshot is smaller or simpler;
- identity split/merge cannot be reconciled explicitly;
- a simple rule, R-GCN or GraphSAGE baseline is cheaper and equally accurate;
- laptop thermal throttling makes the selected model impractical.

## Security and trust

Treat teacher output as untrusted structured input. GSP4 validates relation vocabulary and confidence range, but human review or application policy is required before high-impact ontology changes are promoted.
