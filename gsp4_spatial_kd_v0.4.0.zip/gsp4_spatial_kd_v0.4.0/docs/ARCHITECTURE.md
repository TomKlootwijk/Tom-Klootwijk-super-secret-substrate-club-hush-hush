# GSP4 architecture

## Purpose

GSP4 is the geospatial knowledge-transfer layer built on the supplied UGTS-GN
1.1 substrate. It is intended for variable-length point, sensor and event data
where persistent entities remain identifiable but the number of observations
changes from one time window to the next.

The package deliberately separates two concerns:

1. **Learned proposal:** a compact heterogeneous temporal graph model ranks
   semantic and structural relations.
2. **Deterministic authority:** spatial support, type/mode compatibility,
   distance/SDF guards, event commitment, route and lineage remain explicit
   substrate operations.

The GNN therefore replaces repeated edge-LLM calls, not the geometric guard.

## Source-derived core versus engineering extension

The following architectural commitments are retained from UGTS-GN 1.1:

- query-first state/event execution rather than a mandatory frame loop;
- local support before expensive relation work;
- explicit compatibility over typed state;
- a finite guard band around a relation surface;
- verified events as the only trigger for transition and lineage mutation;
- persistent identity from generative address/history rather than coordinates;
- seed/grammar reconstruction for closed dynamics and append-only storage for
  exogenous novelty;
- packed data only under an error margin contract;
- compact lineage hashes as checksums, not durable identity.

GSP4 adds the following engineering layer:

- `UGKG2`, a sparse heterogeneous graph container;
- `UGNL3`, a 72-byte hash-linked novelty/event record;
- a small 16-relation ontology ABI aligned with GeoSPARQL, SOSA/SSN, SKOS and
  PROV identifiers;
- Morton or optional H3 broad-phase spatial indexing;
- an HGT-style typed attention encoder implemented in dependency-light PyTorch;
- a TGN-style event-time memory update;
- offline embedding, chat-teacher and ULTRA score adapters;
- deterministic query execution and G64/G32 export to the lower-level UGTS
  buffer ABI;
- a hash-verified `.ugdeploy` deployment archive.

These additions are implementation choices. They are not represented as
source-established theorems or as measured RTX performance.

## State split

### Persistent graph state

Persistent entities remain present even when they emit no observation:

- spatial entities;
- sensors;
- spatial cells;
- concepts;
- lineage states.

Their runtime hot fields are:

```text
node_id:uint64
node_type:uint8
sheet:uint8
orientation:uint8
compatibility_mask:uint16
lineage_seed:uint32
latitude/longitude/elevation
node_time
cell_id:uint64
```

Text, external ontology terms, source provenance and larger teacher embeddings
remain cold graph data.

### Sparse transient state

Observations and verified events are represented as variable-length nodes and
append-only novelty records. No `[time, maximum_points, feature]` tensor is
constructed, and inactive sensors do not produce padded rows.

## Runtime path

```text
query entity / coordinate / time
              │
              ▼
Morton/H3 cell candidates + radius/cone support
              │
              ▼
type, sheet, orientation, relation-mask compatibility
              │
              ▼
exact local ENU distance or declared SDF guard
              │
              ▼
HGT/TGN student score for compatible survivors
              │
              ▼
confidence threshold + event limit
              │
              ▼
verified event record
              │
              ├── route/transition value
              ├── deterministic lineage checksum
              └── optional UGNL3 append
```

The current implementation scores after support and compatibility. This keeps
learned computation off candidates that deterministic predicates can reject.

## Graph model

### HGT-style typed attention

Each layer uses:

- node-type embeddings and type-conditioned projections;
- relation embeddings and relation-conditioned key/value transforms;
- temporal encodings from edge age;
- edge attributes `[distance_m, sin(bearing), cos(bearing), |delta_time|]`;
- segmented softmax over incoming destinations;
- residual update, layer normalization and feed-forward projection.

It is "HGT-style" rather than a claim of bit-for-bit equivalence to a named
third-party implementation. The code is in `src/ugts_spatial/model.py`.

### TGN-style temporal memory

Events and observations update a compact memory using source state, destination
state, relation and time features. The package trains an auxiliary temporal
prediction objective so the model learns ordering and event continuity without
requiring fixed graph snapshots.

### Student outputs

The student can produce:

- node embeddings;
- relation logits for candidate source/relation/target triples;
- node-type predictions;
- teacher-vector projections;
- temporal transition scores.

It cannot authoritatively declare exact containment or crossing. The query gate
still checks the declared geometry and guard.

## Knowledge-transfer roles

```text
text embedding teacher ───────► node-vector alignment
chat/hosted model ─────────────► bounded semantic relation labels
ULTRA or another KG model ─────► structural soft edge probabilities
existing graph ────────────────► supervised positive/negative links
UGTS event history ────────────► temporal and lineage supervision
```

All teacher outputs are versioned data artifacts. The production query path
requires only the distilled student and deterministic substrate.

## Spatial indexing

The default Morton cell implementation is dependency-free. H3 can be selected
when `h3` is installed. Either index is a broad phase only. Candidate distance,
bearing and local ENU coordinates are computed independently before a guarded
relation is committed.

## Seed-chain relation

GSP4 complements the earlier seed-chain codec rather than replacing it:

- seed-chain compression reconstructs stable/closed geometry and time state;
- `UGKG2` stores persistent ontological and graph context;
- `UGNL3` stores irreducible spatial/semantic events;
- a `.ugdeploy` archive binds graph, student, ontology, runtime contract and
  novelty terminal hash;
- G64/G32 export allows selected candidates to enter the lower-level substrate
  kernels.

The complete persistence identity is therefore:

```text
versioned base graph/seed
+ schema and ontology hash
+ deterministic productions/transitions
+ ordered novelty records
+ external source provenance
```

A current coordinate or a 32-bit lineage checksum is not sufficient identity.
