# GSP4 binary and exchange formats

All formats are little-endian where a byte order applies. SHA-256 values are
lowercase hexadecimal. Integer IDs are stable within the declared schema and
must not be silently reassigned.

## UGKG2 sparse graph (`.ugkg`)

`UGKG2` is a ZIP container with:

```text
metadata.json
arrays.npz
nodes.jsonl
```

`metadata.json` carries the format, schema hash, ontology version, node/relation
vocabulary, spatial index declaration, source/provenance notes and teacher
metadata. `arrays.npz` is stored without a second ZIP compression layer and
contains only non-object NumPy arrays. `nodes.jsonl` carries persistent keys and
human-readable text.

Core arrays:

| Array | Shape | Meaning |
|---|---:|---|
| `x` | `[N,input_dim]` | normalized engineered node features |
| `teacher_x` | `[N,teacher_dim]` | cached offline teacher vectors |
| `teacher_mask` | `[N]` | rows with authoritative teacher targets |
| `node_type` | `[N]` | compact node class 0..6 |
| `node_id` | `[N]` | stable unsigned 64-bit identity |
| `latitude`, `longitude`, `elevation` | `[N]` | WGS84/local spatial state |
| `node_time` | `[N]` | event/observation timestamp or zero |
| `cell_id` | `[N]` | Morton/H3 broad-phase key |
| `split` | `[N]` | train/validation/test spatial split |
| `sheet`, `orientation` | `[N]` | UGTS topological compatibility fields |
| `compatibility_mask` | `[N]` | 16-relation admissibility mask |
| `lineage_seed` | `[N]` | deterministic 32-bit checksum seed |
| `edge_index` | `[2,E]` | sparse source/destination node indices |
| `edge_type` | `[E]` | relation ID 0..15 |
| `edge_time` | `[E]` | relation/event time |
| `edge_weight` | `[E]` | observed or teacher confidence/weight |
| `edge_attr` | `[E,4]` | distance, sin bearing, cos bearing, abs dt |

The schema hash covers dimensionality, vocabularies, ontology version, edge
attribute contract and hot-state contract. Model loading fails when this hash
differs.

## UGNL3 novelty/event log (`.ugnl`)

Header: 64 bytes.

```text
magic[8]       = "UGNL3\0\0\0"
version:u32
record_bytes:u32 = 72
record_count:u64
seed:u64
terminal_hash:u64
reserved[24]
```

Record: 72 bytes.

```text
sequence:u64
timestamp:f64
op:u8
relation:u8
flags:u16
source_id:u64
target_id:u64
value:f32
confidence:f32
lineage_hash:u64
previous_hash:u64
self_hash:u64
reserved:u32
```

The `self_hash` is a keyed 64-bit BLAKE2 digest over the record with its hash
field zeroed. Each record stores the preceding hash, and the header stores the
terminal hash. This detects corruption and reordering; it is not a substitute
for a digital signature.

Operations include node/edge add/remove, state patch, observation, verified
event, identity split/merge and ontology reclassification.

## UGTE1 teacher edge set (`.ugte`)

ZIP container:

```text
metadata.json
arrays.npz
```

Arrays:

```text
source_id:uint64[E]
target_id:uint64[E]
relation:int64[E]
probability:float32[E]
weight:float32[E]
```

It is soft supervision and does not mutate the graph until explicitly merged or
passed to training.

## PyTorch student checkpoint (`.pt`)

Checkpoint format: `UGTS-SPATIAL-MODEL-1`.

Required payload:

```text
format
schema_hash
model_config
state_dict
```

Training also stores the loss/config metadata needed to reproduce the run.
Checkpoint loading validates the graph schema hash before constructing the
model.

## UGTS deployment archive (`.ugdeploy`)

ZIP container:

```text
graph.ugkg
student_model.pt          optional
novelty.ugnl              optional
ontology.json
runtime.json
attribution.json
manifest.json
<extra versioned files>   optional
```

`manifest.json` stores every payload size and SHA-256, graph schema hash,
novelty terminal hash, graph summary, portability contract and physical
performance boundary. Validation reopens the embedded graph, checkpoint and
novelty chain rather than checking ZIP CRC alone.

## Lower-level bridge

`gsp4 export-ugts` emits:

```text
PREFIX.g64.bin       64 bytes/candidate
PREFIX.g32.bin       32 bytes/candidate
PREFIX.exchange.json
PREFIX.manifest.json
```

The manifest records exact byte counts, hashes, G32 reconstruction error and
whether maximum position error remains within the declared guard epsilon.

G64 fields follow four 16-byte vectors:

```text
position_time
axis_radius
phase_guard
meta
```

G32 packs the twelve scalar fields as six IEEE binary16 pairs and topology into
two 32-bit words. G32 is accepted only when the measured conversion error is
within the event margin.

## ULTRA bridge

`gsp4 export-ultra` writes stable-ID triples to train/validation/test files and a
manifest. Imported score files use:

```text
source_id<TAB>relation_name_or_id<TAB>target_id<TAB>probability[<TAB>weight]
```

The import produces `UGTE1`; it does not give ULTRA authority over exact spatial
guards.
