# Manual data and model choices

The package works without downloading anything. All external assets below are
optional and are listed in `downloads.json` so they can be downloaded manually.
Sizes were observed on 16 August 2026 and may change.

## Smallest useful real-data pilot

### GeoNames Netherlands

```text
URL: https://download.geonames.org/export/dump/NL.zip
Observed compressed size: about 709 KiB
License: CC BY 4.0
```

Use:

```bash
gsp4 ingest-geonames NL.zip data/nl_geonames.ugkg \
  --country-code NL --limit 10000 --neighbors 3 --near-radius 8000
```

The converter records source filename/hash and parsing settings in graph
metadata. Preserve GeoNames attribution when redistributing derived data.

### OpenStreetMap Flevoland

```text
URL: https://download.geofabrik.de/europe/netherlands/flevoland-latest.osm.pbf
Observed compressed size: about 34.5 MiB
License: Open Database License; OpenStreetMap attribution required
```

Install the optional PBF parser:

```bash
pip install '.[osm]'
```

Then:

```bash
gsp4 ingest-osm flevoland-latest.osm.pbf data/flevoland_osm.ugkg \
  --limit 10000 --spatial-resolution 14 --neighbors 2
```

For a dependency-free converter test, use the included small `.osm` XML
fixture.

## Recommended embedding teacher

### Qwen3-Embedding-0.6B-GGUF

```text
Repository: Qwen/Qwen3-Embedding-0.6B-GGUF
Official quantizations: Q8_0 and F16
Q8_0 file size: about 639 MB
Parameters: 0.6B
Context: 32K
Native dimensions: up to 1024; Matryoshka prefixes 32..1024
License: Apache-2.0
```

On a 12 GB laptop, keep the embedding server context and batch modest. GSP4 asks
for 256 dimensions; if the server emits the native 1024, the adapter takes the
first 256 Matryoshka dimensions and renormalizes them.

Start a local OpenAI-compatible endpoint:

```bash
llama-server -hf Qwen/Qwen3-Embedding-0.6B-GGUF:Q8_0 \
  --embedding --pooling last --ctx-size 4096 --port 8080
```

Attach vectors:

```bash
gsp4 embed INPUT.ugkg OUTPUT.ugkg \
  --backend llama --base-url http://127.0.0.1:8080/v1 \
  --model Qwen3-Embedding-0.6B --dimensions 256 --batch-size 16
```

## Optional relation-label teacher

### Qwen3-4B-GGUF

```text
Repository: Qwen/Qwen3-4B-GGUF
Suggested variant: Q4_K_M
Observed file size: about 2.5 GB
License: Apache-2.0
```

Use it only for bounded candidate labels. Disable or minimize free-form
reasoning and require the strict JSON contract in `prompts/`.

```bash
llama-server -hf Qwen/Qwen3-4B-GGUF:Q4_K_M \
  --ctx-size 8192 --port 8081
```

A Qwen3-8B Q4_K_M file is about 5.03 GB and can be used as a stronger optional
teacher, but the 4B model is the more practical starting point for a 12 GB
laptop.

## Optional structural teacher

ULTRA is not bundled. Its official repository provides small pretrained
checkpoints and supports zero-shot or fine-tuned inference on custom knowledge
graphs. GSP4 avoids coupling to ULTRA's older Python/CUDA environment by using a
file bridge:

```bash
gsp4 export-ultra INPUT.ugkg external/ultra_input
# score externally
gsp4 import-scores INPUT.ugkg scores.tsv external/ultra_teacher.ugte
```

This lets ULTRA run in its own environment while the GSP4 student remains on a
current RTX-compatible PyTorch installation.

## Disk budgeting

A compact pilot can fit approximately within:

```text
GSP4 package and included artifacts        < 10 MB before ZIP overhead
Qwen3 embedding Q8_0                       ~639 MB
Qwen3 4B relation teacher Q4_K_M           ~2.5 GB optional
Flevoland OSM PBF                          ~35 MB
GeoNames NL                                < 1 MB
Python/PyTorch environment                 several GB
```

The Python CUDA environment is usually larger than the graph and student
weights. Keep model servers in separate environments when dependency versions
conflict.
