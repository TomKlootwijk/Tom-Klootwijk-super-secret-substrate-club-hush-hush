# Command reference

```text
gsp4 doctor              CUDA/PyTorch environment and smoke launch
gsp4 build-demo          create no-download UGKG2 and UGNL3 files
gsp4 demo                build, train, query, benchmark and bundle
gsp4 inspect-graph       validate and summarize a graph
gsp4 validate-novelty    verify the novelty hash chain
gsp4 embed               attach offline teacher vectors
gsp4 teacher-candidates  generate bounded/type-compatible candidates
gsp4 teacher-label       call an OpenAI-compatible semantic teacher
gsp4 labels-to-edges     compile teacher JSONL into UGTE1
gsp4 merge-labels        append accepted semantic training edges
gsp4 inspect-teacher     inspect UGTE1
gsp4 train               train HGT/TGN student
gsp4 query               execute the UGTS query chain
gsp4 package             create a hash-verified deployment
gsp4 validate-package    validate a deployment recursively
gsp4 ingest-geonames     import GeoNames ZIP/TXT and optional sensor CSV
gsp4 ingest-osm          import small OSM XML/PBF extracts
gsp4 check-gpu           alias-like explicit GPU primitive check
gsp4 export-ultra        export stable-ID KG triples
gsp4 import-scores       convert external scores to UGTE1
gsp4 export-ugts         emit G64/G32 substrate buffers
gsp4 benchmark           measure encoding, scoring and optional query
```

Run `gsp4 COMMAND --help` for all parameters.
