# GSP4 v0.4.0 deliverables

## Delivery objective

Implement a practical geospatial knowledge-transfer path for irregular point/event data without a fixed frame dimension and without placing an LLM in the online edge loop.

## Delivered components

| ID | Deliverable | Status | Primary files |
|---|---|---|---|
| GSP4-D01 | Sparse persistent graph with variable-length observations/events | Implemented | `graph.py`, `builder.py`, `builders.py`, `UGKG2` |
| GSP4-D02 | Compact seven-node-type, sixteen-relation ontology ABI | Implemented | `schema.py`, `ontology/` |
| GSP4-D03 | HGT-style heterogeneous spatial encoder | Implemented | `model.py` |
| GSP4-D04 | TGN-style time-ordered memory updates | Implemented | `model.py`, `training.py` |
| GSP4-D05 | Node embedding distillation | Implemented | `embeddings.py`, `distill.py`, `training.py` |
| GSP4-D06 | LLM relation-label distillation with strict abstention | Implemented | `teacher.py`, `prompts/`, `edge_teacher.py` |
| GSP4-D07 | ULTRA/external structural teacher bridge | Implemented | `edge_teacher.py`, `ultra.py` |
| GSP4-D08 | H3 or built-in Morton broad-phase indexing | Implemented | `geocell.py` |
| GSP4-D09 | Deterministic support/compatibility/guard query gate | Implemented | `query.py`, `spatial.py` |
| GSP4-D10 | Durable hash-linked novelty/event chain | Implemented | `novelty.py`, `UGNL3` |
| GSP4-D11 | GeoNames ingestion | Implemented | `ingest_geonames.py`, `builders.py` |
| GSP4-D12 | OpenStreetMap XML/PBF ingestion | Implemented | `ingest_osm.py` |
| GSP4-D13 | Direct G64/G32 substrate export | Implemented | `ugts_bridge.py` |
| GSP4-D14 | Hash-verified deployment bundle | Implemented | `deployment.py`, `.ugdeploy` |
| GSP4-D15 | RTX/PyTorch environment doctor | Implemented | `environment.py`, `gsp4 doctor` |
| GSP4-D16 | No-download graph, model, novelty and deployment | Included | `data/`, `models/`, `deploy/` |
| GSP4-D17 | CPU reference validation and release tests | Included | `tests/`, `results/` |
| GSP4-D18 | Windows/Linux runbooks and scripts | Included | `scripts/`, `docs/RTX5070TI_RUNBOOK.md` |

## Not claimed

- The smoke student is not a generally capable geospatial model.
- CPU measurements are not RTX 5070 Ti measurements.
- The package does not prove that all possible world state is compressible to novelty alone.
- A relation probability is not a geometric proof.
- H3 or Morton cell equality is not exact containment.
- The package does not replace the direct Vulkan/SPIR-V substrate; it feeds candidates and distilled knowledge into it.

## Release acceptance

A target-machine release is accepted only when:

1. `gsp4 doctor` passes on CUDA.
2. All unit tests pass.
3. Graph, novelty and deployment hashes validate.
4. The trained checkpoint schema hash matches the graph.
5. Deterministic query results are stable between CPU and GPU within the declared guard margin.
6. No event ordering or lineage differences occur.
7. Peak VRAM stays inside the target budget.
8. Sparse candidate rejection remains beneficial relative to a dense baseline.
