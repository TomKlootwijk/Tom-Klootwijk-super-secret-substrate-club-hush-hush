# Mapping to the supplied UGTS-GN substrate

## Source-derived contract retained

The upstream package defines the core as a directly queryable state-and-event substrate rather than a renderer. GSP4 retains this by treating maps, dashboards and visualizations as consumers of query/event output.

The source's canonical sequence is mapped as follows:

| UGTS-GN concept | GSP4 implementation |
|---|---|
| finite grammar / typed state | compact node and relation vocabulary plus schema hash |
| local radial-angular support | cell broad phase, local ENU, radius/cone tests |
| compatibility | relation type contract, 16-bit mask, sheet and orientation |
| relation guard / SDF | inside or shell guard with finite epsilon |
| verified event | confidence-qualified `QueryExecution` event |
| route / transition | deterministic route bits and typed event relation |
| lineage | persistent node ID, lineage seed/checksum and novelty history |
| irreducible novelty | append-only UGNL3 records |
| G64/E32 and G32/E16 | `export-ugts` binary bridge |
| precision rule | measured G32 error versus declared epsilon |

## Engineering-derived additions

The supplied source does not specify HGT/TGN distillation. GSP4 adds it as an engineering extension:

- sparse heterogeneous graph container;
- temporal memory student;
- offline embedding/LLM teacher adapters;
- ULTRA score adapter;
- GeoNames/OSM ingestion;
- deployment bundling.

These additions do not replace the deterministic event authority.

## Explicit boundaries

- A language model does not determine exact geometry.
- A cell index is not an exact spatial relation.
- A compact lineage hash is not durable identity.
- Binary16 packing is conditional on the event margin.
- CPU smoke-test results are not physical RTX throughput.
- Driver caches are not portable program objects.

The original schema, state layout and ABI header are under `substrate/upstream/` so the bridge can be audited directly.
