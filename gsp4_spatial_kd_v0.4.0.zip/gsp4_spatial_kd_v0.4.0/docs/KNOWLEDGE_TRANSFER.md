# Spatial and ontological knowledge transfer

## Objective

The deployment goal is to capture semantic knowledge from a model that may be
too large or too slow for the laptop's online path, then retain that knowledge
in compact graph artifacts and a student GNN.

The large model is used offline. Production queries do not call an LLM per
edge.

## Four teacher channels

### 1. Existing graph supervision

Observed, curated and ontology-derived relations provide positive edges.
Type-compatible corruptions provide negatives. Spatial holdouts are used so
nearby nodes do not leak trivially between training and test.

### 2. Embedding teacher

Node descriptions are embedded once. The vectors are stored in `teacher_x` and
become targets for the student's projection head.

Recommended compact local teacher:

```text
Qwen/Qwen3-Embedding-0.6B-GGUF
Q8_0, approximately 639 MB
256 output dimensions for the pilot
```

A deterministic hash embedder is included only to exercise the pipeline without
downloading weights. It is not semantic knowledge transfer.

### 3. Semantic relation teacher

GSP4 first creates candidates using only:

- source and target type compatibility;
- configured relation vocabulary;
- cell/radius broad phase;
- a maximum candidate budget.

The teacher receives a strict JSON object and may select only an allowed
relation or abstain. It is explicitly forbidden from claiming exact distance,
containment, intersection, crossing or sensor physics from text.

Outputs become `UGTE1` soft targets or may be merged above a declared
confidence threshold. Every accepted label records the teacher model name.

### 4. Structural KG teacher

The ULTRA bridge exports stable-ID triples and imports scored triples. This is
useful when the graph has sparse labels or new entity/relation vocabularies. The
scores are soft relation supervision and are combined with semantic embeddings
and observed graph edges.

## Student loss

The implemented training objective is a weighted sum of:

```text
link prediction loss
node teacher-vector alignment
edge teacher soft-label loss
node-type prediction loss
temporal event/transition loss
```

All weights are exposed in `gsp4 train`. The included smoke model is deliberately
small and undertrained; its purpose is format, execution and integration
validation, not a production quality claim.

## Recommended production curriculum

1. Ingest a bounded geographic region.
2. Freeze node/relation ontology version 1.
3. Attach 256-dimensional multilingual embeddings.
4. Generate type-compatible candidates within 2–10 km according to relation.
5. Label only ambiguous semantic candidates with a large teacher.
6. Score graph structure with ULTRA or a comparable KG model.
7. Train the HGT/TGN student.
8. Evaluate on held-out cells, later time ranges and held-out relation/entity
   classes.
9. Calibrate confidence against verified deterministic events.
10. Package graph, model, ontology and novelty chain together.

## Suggested RTX 5070 Ti profiles

### Pilot

```text
hidden_dim=128
heads=4
layers=3
teacher_dim=256
max_encoder_edges=250000
precision=bf16
```

### Medium graph

```text
hidden_dim=256
heads=8
layers=4
teacher_dim=256
neighbor/candidate sampling required
precision=bf16
```

Begin with the pilot. Increase graph size only after peak VRAM, candidate
rejection and event yield are measured.

## What is retained after teacher removal

- normalized ontology/type assignments;
- teacher embeddings or their student projection target;
- relation probability targets;
- trained student weights;
- uncertainty and abstention statistics;
- model/revision/instruction hashes;
- source and labeling provenance.

The original teacher weights may then remain on disk, be archived elsewhere or
be removed. Knowledge transfer is represented by these durable artifacts, not
by the mere presence of a model file.

## Authority and uncertainty

A high GNN score means a relation is semantically/structurally plausible. It
must not override:

- a failed type/mode compatibility mask;
- a failed exact distance/SDF guard;
- a guard-margin precision violation;
- a stale calibration or invalid source status;
- policy/provenance restrictions.

Low-evidence teacher cases should remain abstentions. Ontology changes should be
append-only `ONTOLOGY_RECLASSIFICATION` novelty events rather than destructive
history edits.
