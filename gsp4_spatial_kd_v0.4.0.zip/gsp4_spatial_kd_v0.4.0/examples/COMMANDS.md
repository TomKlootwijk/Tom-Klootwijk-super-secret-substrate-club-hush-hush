# Example commands

```bash
PYTHONPATH=src python -m ugts_spatial ingest-geonames \
  examples/data/minimal_geonames.txt results/example_geonames.ugkg \
  --observations examples/data/observations_variable.csv --limit 100

PYTHONPATH=src python -m ugts_spatial ingest-osm \
  examples/data/minimal.osm results/example_osm.ugkg --limit 100

PYTHONPATH=src python -m ugts_spatial teacher-candidates \
  data/flevoland_pilot.ugkg results/candidates.jsonl --max-candidates 500

PYTHONPATH=src python -m ugts_spatial export-ultra \
  data/flevoland_pilot.ugkg results/ultra
```
