# External assets

This directory is intentionally empty except for a machine-readable manifest. Put manually downloaded datasets under `external/data/` or `external_data/`, and teacher weights under `external/models/` or `external_data/models/`.

No external asset is required for the included synthetic deployment. See `models/MANUAL_DOWNLOADS.md` and `models/download_manifest.json`.
