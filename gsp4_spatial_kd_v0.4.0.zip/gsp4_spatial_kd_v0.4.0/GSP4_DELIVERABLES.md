# GSP4 v0.4.0 deliverables

## Delivery status

| ID | Deliverable | Status | Primary artifacts | Acceptance evidence |
|---|---|---|---|---|
| GSP4-1 | Sparse variable-length geospatial substrate | Delivered | `src/ugts_spatial/graph.py`, `novelty.py`, `schema.py`, `geocell.py`, `data/*.ugkg`, `data/*.ugnl` | graph round trip, irregular observation counts, spatial holdouts, novelty tamper detection |
| GSP4-2 | Offline ontological and spatial knowledge transfer | Delivered | `embeddings.py`, `teacher.py`, `distill.py`, `edge_teacher.py`, `ultra.py`, `prompts/` | bounded candidate, strict label, teacher-vector and ULTRA adapter tests |
| GSP4-3 | Compact heterogeneous temporal student | Delivered | `model.py`, `training.py`, bundled schema-bound checkpoint | CPU training/load/query tests, included metrics, CUDA/BF16 execution path |
| GSP4-4 | UGTS query and persistence deployment | Delivered | `query.py`, `deployment.py`, `ugts_bridge.py`, `deploy/*.ugdeploy` | deterministic gate, event commit, archive validation, G64/G32 error contract |
| GSP4-RTX | RTX 5070 Ti Laptop physical acceptance | Ready to execute | `environment.py`, `scripts/run_rtx5070ti_windows.ps1`, `docs/RTX5070TI_RUNBOOK.md` | not run in the preparation environment; machine-readable acceptance outputs defined |

## Ready artifacts

- `data/flevoland_pilot.ugkg`: 228 nodes, 1,305 edges, 97 irregular observations in eight windows.
- `data/flevoland_pilot.ugnl`: 118 valid hash-linked novelty/event records.
- `models/gsp4_flevoland_smoke.pt`: 341,459-parameter HGT/TGN smoke student bound to the graph schema.
- `deploy/gsp4_flevoland_smoke.ugdeploy`: graph, student, novelty, ontology, runtime and attribution in a self-verifying bundle.
- `results/bundled/`: query, committed novelty copy, CPU benchmark, deployment validation and G64/G32 bridge evidence.
- `dist/gsp4_spatial_kd-0.4.0-py3-none-any.whl`: installable Python wheel.

## GSP4-1 acceptance

- Persistent identity is independent of row position.
- Observations/events are sparse nodes and edges, not a fixed frame axis.
- Seven node types and sixteen relation IDs fit a compact compatibility vocabulary.
- WGS84 coordinates, local spatial edge features, time, sheet, orientation, compatibility mask and lineage seed are explicit.
- Morton indexing is built in; H3 is optional.
- GeoNames ZIP/TXT and OSM XML/PBF adapters are included.
- `UGNL3` detects record alteration, sequence errors and broken hash links.

## GSP4-2 acceptance

- Node knowledge may come from deterministic smoke embeddings, a local embedding endpoint or another OpenAI-compatible embedding service.
- Relation teachers see only type-compatible bounded candidates and may abstain.
- Geometry-dependent labels remain subject to exact support and guard evaluation.
- ULTRA/external structural scores are imported as soft relation supervision.
- Teacher weights are not required after distilled outputs and the student checkpoint are retained.

## GSP4-3 acceptance

- Type-specific projections, relation-specific multi-head attention, edge geometry, relative time and ordered-event memory are implemented.
- Training combines link prediction, node teacher alignment, optional edge teacher loss, node type and temporal objectives.
- Checkpoints refuse graphs with a different schema hash.
- The model ranks candidates; it does not bypass deterministic UGTS gates.

## GSP4-4 acceptance

- Query order is support → compatibility → guard → student score → verified event → route/lineage → optional novelty append.
- `.ugdeploy` validates every embedded payload hash and graph/model schema match.
- G64 exports 64 bytes/candidate; G32 exports 32 bytes/candidate.
- The packed bridge reports measured error and accepts G32 only below the selected event margin.

## Explicit non-claims

- The synthetic smoke model is not a generally capable geospatial model.
- CPU measurements are not RTX 5070 Ti measurements.
- A compact lineage hash is not full persistent identity.
- No universal compression or constant-time world claim is made.
- PyTorch/CUDA execution is low-level GPU deployment, not literal driverless hardware execution.
