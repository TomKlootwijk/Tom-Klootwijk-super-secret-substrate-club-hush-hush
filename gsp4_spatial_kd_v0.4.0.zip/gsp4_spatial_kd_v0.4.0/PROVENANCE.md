# GSP4 provenance

GSP4 is an engineering extension of the user-supplied **UGTS-GN 1.1** substrate.

The requester supplied the substrate attribution **Tom Klootwijk**, together with a private identifier and date used as a digital-log grounding point. The full supplied values are retained in `AUTHORS_AND_PROVENANCE.md` and deployment `attribution.json`. Treat those values as personal data and remove or redact them before public redistribution when they are unnecessary.

This package records the statement as user-supplied provenance. It does not independently determine identity, copyright, ownership, priority, patentability or inventorship.

The implementation preserves the substrate's technical boundary: the core is a queryable state-and-event system, and learned scores do not replace support, compatibility, guard, transition, lineage or novelty rules.
