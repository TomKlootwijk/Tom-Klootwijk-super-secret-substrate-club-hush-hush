from __future__ import annotations

import json
from pathlib import Path
import tempfile

import numpy as np
import torch

from ugts_spatial.builders import build_demo_graph
from ugts_spatial.deployment import build_deployment, validate_deployment
from ugts_spatial.distill import generate_relation_candidates
from ugts_spatial.edge_teacher import export_ultra_triples, import_scored_triples
from ugts_spatial.embeddings import HashEmbedder
from ugts_spatial.environment import gpu_environment_report
from ugts_spatial.geocell import decode_morton_cell, encode_morton_cell, haversine_m
from ugts_spatial.graph import GraphPackage
from ugts_spatial.ingest_osm import ingest_osm
from ugts_spatial.model import ModelConfig, UGTSSpatialModel
from ugts_spatial.novelty import NoveltyLog, NoveltyRecord
from ugts_spatial.query import QueryConfig, execute_query
from ugts_spatial.schema import NodeType, NoveltyOp, RelationType
from ugts_spatial.training import TrainConfig, load_model_for_graph, train_model
from ugts_spatial.ugts_bridge import UGTSState, export_ugts_candidates, pack_g32, pack_g64


def _sensor_index(graph: GraphPackage) -> int:
    return int(np.flatnonzero(graph.node_type == int(NodeType.SENSOR))[0])


def test_morton_cell_round_trip_is_local() -> None:
    latitude, longitude = 52.5185, 5.4714
    cell = encode_morton_cell(latitude, longitude, 14)
    decoded_lat, decoded_lon, resolution = decode_morton_cell(cell)
    assert resolution == 14
    assert haversine_m(latitude, longitude, decoded_lat, decoded_lon) < 2500.0


def test_demo_graph_is_sparse_and_variable_length() -> None:
    graph = build_demo_graph(seed=20260710, teacher_dimensions=32)
    assert graph.num_nodes > 250
    assert graph.num_edges < graph.num_nodes * graph.num_nodes // 10
    counts = graph.summary()["node_counts"]
    assert counts["observation"] > counts["sensor"]
    assert counts["event"] > 0
    assert graph.teacher_dim == 32


def test_graph_save_load_preserves_schema(tmp_path: Path) -> None:
    graph = build_demo_graph(seed=1, teacher_dimensions=16)
    path = tmp_path / "graph.ugkg"
    graph.save(path)
    loaded = GraphPackage.load(path)
    assert loaded.schema_hash == graph.schema_hash
    assert loaded.num_nodes == graph.num_nodes
    assert loaded.num_edges == graph.num_edges
    assert np.array_equal(loaded.node_id, graph.node_id)


def test_hash_embedder_is_deterministic_and_normalized() -> None:
    embedder = HashEmbedder(dimensions=32)
    first = embedder.encode(["sensor observes water level", "road in Flevoland"])
    second = embedder.encode(["sensor observes water level", "road in Flevoland"])
    assert np.array_equal(first, second)
    assert np.allclose(np.linalg.norm(first, axis=1), 1.0)


def test_novelty_chain_detects_order_and_hashes(tmp_path: Path) -> None:
    path = tmp_path / "events.ugnl"
    log = NoveltyLog(path, seed=123)
    log.create()
    first = log.append(
        NoveltyRecord(
            sequence=0,
            timestamp=1.0,
            op=int(NoveltyOp.OBSERVATION),
            relation=int(RelationType.OBSERVES),
            flags=0,
            source=10,
            target=20,
            value=0.5,
            confidence=0.9,
        )
    )
    second = log.append_verified(
        timestamp=2.0,
        relation=int(RelationType.CROSSED_GUARD),
        source_id=10,
        target_id=20,
        value=-0.1,
        confidence=0.95,
        lineage_hash=42,
    )
    summary = log.validate()
    assert summary["records"] == 2
    assert second.prev_hash == first.self_hash
    assert summary["terminal_hash"] == second.self_hash


def test_relation_candidates_are_bounded_and_typed() -> None:
    graph = build_demo_graph(seed=2, teacher_dimensions=16)
    candidates = generate_relation_candidates(
        graph,
        max_distance_m=5000.0,
        concepts_per_source=2,
        spatial_per_source=1,
        max_candidates=100,
    )
    assert 0 < len(candidates) <= 100
    for candidate in candidates:
        assert candidate.allowed_relations
        assert candidate.deterministic_fields["teacher_is_not_event_authority"] is True


def test_query_runs_deterministic_gates_without_model() -> None:
    graph = build_demo_graph(seed=3, teacher_dimensions=0)
    source = _sensor_index(graph)
    result = execute_query(
        graph,
        QueryConfig(
            source_node_id=int(graph.node_id[source]),
            relation=int(RelationType.NEAR),
            radius_m=10_000.0,
            epsilon_m=25.0,
            confidence_min=0.0,
            max_events=32,
        ),
        model=None,
        device="cpu",
    )
    assert result.summary["candidates"] >= result.summary["supported"]
    assert result.summary["supported"] >= result.summary["verified"]
    assert result.summary["verified"] == len(result.events)
    assert all(event["guard_m"] <= 0.0 for event in result.events)


def test_model_forward_shapes() -> None:
    graph = build_demo_graph(seed=4, teacher_dimensions=16)
    config = ModelConfig(
        input_dim=graph.input_dim,
        teacher_dim=graph.teacher_dim,
        edge_dim=graph.edge_dim,
        num_node_types=7,
        num_relations=16,
        hidden_dim=32,
        num_heads=4,
        num_layers=1,
        dropout=0.0,
    )
    model = UGTSSpatialModel(config)
    output = model(graph.to_torch("cpu"))
    assert output["node_state"].shape == (graph.num_nodes, 32)
    assert output["type_logits"].shape[0] == graph.num_nodes
    assert output["teacher_embedding"].shape == (graph.num_nodes, graph.teacher_dim)


def test_one_epoch_training_and_schema_bound_load(tmp_path: Path) -> None:
    graph = build_demo_graph(seed=5, teacher_dimensions=16)
    checkpoint = tmp_path / "student.pt"
    metrics = tmp_path / "metrics.json"
    result = train_model(
        graph,
        checkpoint,
        metrics_path=metrics,
        config=TrainConfig(
            hidden_dim=32,
            heads=4,
            layers=1,
            dropout=0.0,
            epochs=1,
            max_edges_per_epoch=2000,
            max_encoder_edges=4000,
            temporal_edges_per_epoch=256,
            early_stopping_patience=1,
            device="cpu",
            precision="float32",
        ),
    )
    assert checkpoint.exists() and metrics.exists()
    assert result.final_metrics["epochs_completed"] == 1.0
    model, device, payload = load_model_for_graph(graph, checkpoint, device="cpu")
    assert str(device) == "cpu"
    assert payload["schema_hash"] == graph.schema_hash
    assert isinstance(model, UGTSSpatialModel)


def test_deployment_archive_hashes_validate(tmp_path: Path) -> None:
    graph = build_demo_graph(seed=6, teacher_dimensions=0)
    graph_path = tmp_path / "graph.ugkg"
    novelty_path = tmp_path / "novelty.ugnl"
    bundle_path = tmp_path / "deployment.ugdeploy"
    graph.save(graph_path)
    novelty = NoveltyLog(novelty_path)
    novelty.create()
    build_deployment(bundle_path, graph_path, novelty_path=novelty_path)
    result = validate_deployment(bundle_path)
    assert result["valid"] is True
    assert result["graph_schema_hash"] == graph.schema_hash


def test_ugts_state_sizes_and_bridge_precision(tmp_path: Path) -> None:
    state = UGTSState(
        position=(1.0, 2.0, 3.0),
        time=4.0,
        axis=(0.0, 0.0, 1.0),
        radius=5000.0,
        cone_cos=-1.0,
        phase=0.1,
        guard_epsilon=25.0,
        confidence_floor=0.5,
        sheet=1,
        orientation=0,
        compatibility_mask=0xFFFF,
        lineage_seed=123,
    )
    assert len(pack_g64(state)) == 64
    assert len(pack_g32(state)) == 32

    graph = build_demo_graph(seed=7, teacher_dimensions=0)
    source = _sensor_index(graph)
    result = export_ugts_candidates(
        graph,
        tmp_path / "query",
        latitude=float(graph.latitude[source]),
        longitude=float(graph.longitude[source]),
        radius_m=10_000.0,
        guard_epsilon_m=100.0,
    )
    assert result["candidate_count"] > 0
    assert result["g64_bytes"] == result["candidate_count"] * 64
    assert result["g32_bytes"] == result["candidate_count"] * 32
    assert result["g32_precision_within_guard"] is True


def test_ultra_export_and_score_import(tmp_path: Path) -> None:
    graph = build_demo_graph(seed=8, teacher_dimensions=0)
    export_dir = tmp_path / "ultra"
    manifest = export_ultra_triples(graph, export_dir)
    assert manifest["triples"]["train"] > 0
    first = (export_dir / "train.txt").read_text(encoding="utf-8").splitlines()[0]
    source, relation, target = first.split("\t")
    score_path = tmp_path / "scores.tsv"
    score_path.write_text(f"{source}\t{relation}\t{target}\t0.8\t1.0\n", encoding="utf-8")
    edges = import_scored_triples(graph, score_path)
    edges.validate(graph)
    assert edges.size == 1
    assert float(edges.probability[0]) == np.float32(0.8)


def test_small_osm_xml_ingest(tmp_path: Path) -> None:
    osm = tmp_path / "tiny.osm"
    osm.write_text(
        """<?xml version='1.0' encoding='UTF-8'?>
<osm version='0.6'>
  <node id='1' lat='52.50' lon='5.45'><tag k='amenity' v='school'/><tag k='name' v='Pilot School'/></node>
  <node id='2' lat='52.51' lon='5.46'><tag k='highway' v='traffic_signals'/></node>
  <node id='3' lat='52.52' lon='5.47'/>
  <way id='10'><nd ref='1'/><nd ref='3'/><tag k='highway' v='residential'/><tag k='name' v='Pilot Road'/></way>
</osm>
""",
        encoding="utf-8",
    )
    graph = ingest_osm(osm, limit=100, morton_resolution=12, near_per_node=1)
    assert graph.num_nodes > 3
    assert graph.num_edges > 0
    assert graph.metadata["source_features"] >= 2


def test_environment_report_is_machine_readable() -> None:
    report = gpu_environment_report(run_smoke=False)
    assert report["format"] == "GSP4-GPU-ENVIRONMENT-1"
    assert isinstance(report["cuda_available"], bool)
    assert "ready" in report
