from __future__ import annotations

from pathlib import Path
import tempfile
import unittest

import numpy as np
import torch

from ugts_spatial.builders import build_demo_graph
from ugts_spatial.model import ModelConfig, UGTSSpatialModel, segment_softmax
from ugts_spatial.novelty import NoveltyLog
from ugts_spatial.query import QueryConfig, execute_query
from ugts_spatial.schema import NodeType, RelationType
from ugts_spatial.training import TrainConfig, load_model_for_graph, train_model
from ugts_spatial.ugts_bridge import UGTSState, pack_g32, pack_g64, unpack_g32_scalars


class ModelQueryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.graph = build_demo_graph(seed=2026, teacher_dimensions=8)

    def _model(self) -> UGTSSpatialModel:
        return UGTSSpatialModel(
            ModelConfig(
                input_dim=self.graph.input_dim,
                teacher_dim=self.graph.teacher_dim,
                edge_dim=self.graph.edge_dim,
                num_node_types=7,
                num_relations=16,
                hidden_dim=32,
                num_heads=4,
                num_layers=1,
                dropout=0.0,
            )
        )

    def test_segment_softmax_groups(self) -> None:
        scores = torch.tensor([[0.0, 1.0], [0.0, 1.0], [1.0, 0.0]])
        destinations = torch.tensor([0, 0, 1])
        alpha = segment_softmax(scores, destinations, 2)
        self.assertTrue(torch.allclose(alpha[:2].sum(dim=0), torch.ones(2), atol=1e-6))
        self.assertTrue(torch.allclose(alpha[2], torch.ones(2), atol=1e-6))

    def test_model_forward_shapes(self) -> None:
        model = self._model()
        tensors = self.graph.to_torch("cpu")
        output = model(tensors)
        self.assertEqual(tuple(output["node_state"].shape), (self.graph.num_nodes, 32))
        self.assertEqual(tuple(output["type_logits"].shape), (self.graph.num_nodes, 7))
        self.assertEqual(tuple(output["teacher_embedding"].shape), (self.graph.num_nodes, 8))

    def test_model_edge_scores(self) -> None:
        model = self._model()
        tensors = self.graph.to_torch("cpu")
        output = model(tensors)
        positions = torch.arange(min(16, self.graph.num_edges))
        scores = model.score_edges(
            output["node_state"],
            tensors["edge_index"][:, positions],
            tensors["edge_type"][positions],
            tensors["edge_attr"][positions],
        )
        self.assertEqual(scores.shape, (positions.numel(),))
        self.assertTrue(torch.isfinite(scores).all())

    def test_query_without_model(self) -> None:
        source_index = int(np.flatnonzero(self.graph.node_type == int(NodeType.SENSOR))[0])
        result = execute_query(
            self.graph,
            QueryConfig(
                source_node_id=int(self.graph.node_id[source_index]),
                relation=int(RelationType.NEAR),
                radius_m=10000,
                epsilon_m=25,
                confidence_min=0.0,
                max_events=16,
            ),
        )
        self.assertGreater(result.summary["candidates"], 0)
        self.assertLessEqual(result.summary["verified"], 16)
        for event in result.events:
            self.assertLessEqual(event["guard_m"], 0.0)

    def test_query_commit_to_novelty(self) -> None:
        source_index = int(np.flatnonzero(self.graph.node_type == int(NodeType.SENSOR))[0])
        with tempfile.TemporaryDirectory() as temp:
            log = NoveltyLog(Path(temp) / "query.ugnl")
            log.create()
            result = execute_query(
                self.graph,
                QueryConfig(
                    source_node_id=int(self.graph.node_id[source_index]),
                    relation=int(RelationType.NEAR),
                    radius_m=10000,
                    epsilon_m=25,
                    confidence_min=0.0,
                    max_events=8,
                    timestamp=123.0,
                ),
                novelty_log=log,
            )
            self.assertEqual(log.validate()["records"], len(result.events))

    def test_g64_g32_layout(self) -> None:
        state = UGTSState(
            position=(12.5, -2.0, 1.25),
            time=10.0,
            axis=(0.0, 0.0, 1.0),
            radius=500.0,
            cone_cos=0.5,
            phase=0.25,
            guard_epsilon=2.0,
            confidence_floor=0.7,
            sheet=1,
            orientation=0,
            compatibility_mask=0xFFFF,
            lineage_seed=123,
        )
        g64 = pack_g64(state)
        g32 = pack_g32(state)
        self.assertEqual(len(g64), 64)
        self.assertEqual(len(g32), 32)
        decoded = unpack_g32_scalars(g32)
        self.assertAlmostEqual(decoded[0], state.position[0], delta=0.02)
        self.assertAlmostEqual(decoded[7], state.radius, delta=0.5)

    def test_one_epoch_training_and_reload(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            checkpoint = Path(temp) / "student.pt"
            metrics = Path(temp) / "metrics.json"
            result = train_model(
                self.graph,
                checkpoint,
                metrics_path=metrics,
                config=TrainConfig(
                    hidden_dim=32,
                    heads=4,
                    layers=1,
                    dropout=0.0,
                    epochs=1,
                    max_edges_per_epoch=256,
                    max_encoder_edges=512,
                    temporal_edges_per_epoch=128,
                    early_stopping_patience=1,
                    device="cpu",
                ),
            )
            self.assertTrue(checkpoint.exists())
            self.assertTrue(metrics.exists())
            model, device, payload = load_model_for_graph(self.graph, checkpoint, device="cpu")
            self.assertEqual(str(device), "cpu")
            self.assertEqual(payload["schema_hash"], self.graph.schema_hash)
            self.assertIsInstance(model, UGTSSpatialModel)
            self.assertGreaterEqual(result.final_metrics["epochs_completed"], 1.0)


if __name__ == "__main__":
    unittest.main()
