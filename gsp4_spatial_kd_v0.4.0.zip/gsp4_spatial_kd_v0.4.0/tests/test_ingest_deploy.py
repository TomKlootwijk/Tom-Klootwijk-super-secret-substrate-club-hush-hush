from __future__ import annotations

from pathlib import Path
import tempfile
import unittest

import numpy as np

from ugts_spatial.builders import build_demo_graph, build_geonames_graph
from ugts_spatial.deployment import build_deployment, validate_deployment
from ugts_spatial.edge_teacher import export_ultra_triples, import_scored_triples
from ugts_spatial.environment import gpu_environment_report
from ugts_spatial.ingest_osm import ingest_osm
from ugts_spatial.novelty import NoveltyLog
from ugts_spatial.schema import NodeType, RelationType
from ugts_spatial.ugts_bridge import export_ugts_candidates


_GEONAMES = (
    "2751738\tLelystad\tLelystad\t\t52.50833\t5.475\tP\tPPLA\tNL\t\t16\t\t\t\t77893\t3\t3\tEurope/Amsterdam\t2026-01-01\n"
    "2759879\tAlmere Stad\tAlmere Stad\tAlmere\t52.37025\t5.21413\tP\tPPL\tNL\t\t16\t\t\t\t176432\t-3\t-3\tEurope/Amsterdam\t2026-01-01\n"
    "2756331\tDronten\tDronten\t\t52.525\t5.71806\tP\tPPL\tNL\t\t16\t\t\t\t28857\t-1\t-1\tEurope/Amsterdam\t2026-01-01\n"
)

_OSM = """<?xml version='1.0' encoding='UTF-8'?>
<osm version='0.6'>
 <node id='1' lat='52.5185' lon='5.4714'><tag k='amenity' v='school'/></node>
 <node id='2' lat='52.5190' lon='5.4720'><tag k='man_made' v='monitoring_station'/></node>
 <node id='3' lat='52.5200' lon='5.4730'/>
 <node id='4' lat='52.5210' lon='5.4740'/>
 <way id='10'><nd ref='3'/><nd ref='4'/><tag k='highway' v='residential'/></way>
</osm>
"""


class IngestDeploymentTests(unittest.TestCase):
    def test_geonames_with_variable_observations(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "NL.txt"
            source.write_text(_GEONAMES, encoding="utf-8")
            observations = root / "obs.csv"
            observations.write_text(
                "sensor_id,latitude,longitude,property,timestamp,value,uncertainty,unit\n"
                "s1,52.5083,5.4750,air quality,2026-01-01T00:00:01Z,10,0.1,ug/m3\n"
                "s1,52.5083,5.4750,air quality,2026-01-01T00:03:41Z,14,0.1,ug/m3\n"
                "s2,52.5250,5.7180,water level,2026-01-01T00:01:07Z,0.8,0.05,m\n",
                encoding="utf-8",
            )
            graph = build_geonames_graph(
                source,
                observations_csv=observations,
                max_rows=10,
                teacher_dimensions=0,
            )
            counts = graph.summary()["node_counts"]
            self.assertEqual(counts["spatial_entity"], 3)
            self.assertEqual(counts["sensor"], 2)
            self.assertEqual(counts["observation"], 3)

    def test_osm_xml_ingest(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            source = Path(temp) / "pilot.osm"
            source.write_text(_OSM, encoding="utf-8")
            graph = ingest_osm(source, limit=100, morton_resolution=12)
            self.assertGreaterEqual(graph.summary()["node_counts"]["spatial_entity"], 3)
            self.assertGreater(graph.num_edges, 0)

    def test_ultra_export_import(self) -> None:
        graph = build_demo_graph(seed=99, teacher_dimensions=0)
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            manifest = export_ultra_triples(graph, root / "ultra")
            self.assertGreater(manifest["triples"]["train"], 0)
            source = int(graph.node_id[int(graph.edge_index[0, 0])])
            target = int(graph.node_id[int(graph.edge_index[1, 0])])
            relation = int(graph.edge_type[0])
            relation_name = graph.metadata["relation_types"][str(relation)]
            scores = root / "scores.tsv"
            scores.write_text(f"{source}\t{relation_name}\t{target}\t0.91\n", encoding="utf-8")
            teacher = import_scored_triples(graph, scores)
            self.assertEqual(teacher.size, 1)
            self.assertAlmostEqual(float(teacher.probability[0]), 0.91, places=5)

    def test_ugts_export_precision_manifest(self) -> None:
        graph = build_demo_graph(seed=77, teacher_dimensions=0)
        sensor = int(np.flatnonzero(graph.node_type == int(NodeType.SENSOR))[0])
        with tempfile.TemporaryDirectory() as temp:
            result = export_ugts_candidates(
                graph,
                Path(temp) / "candidates",
                latitude=float(graph.latitude[sensor]),
                longitude=float(graph.longitude[sensor]),
                radius_m=10000,
                guard_epsilon_m=25,
                mode_bit=int(RelationType.NEAR),
            )
            self.assertEqual(result["g64_bytes"] % 64, 0)
            self.assertEqual(result["g32_bytes"] % 32, 0)
            self.assertTrue(result["g32_precision_within_guard"])

    def test_deployment_round_trip(self) -> None:
        graph = build_demo_graph(seed=66, teacher_dimensions=0)
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            graph_path = root / "graph.ugkg"
            graph.save(graph_path)
            novelty_path = root / "events.ugnl"
            NoveltyLog(novelty_path).create()
            bundle = root / "pilot.ugdeploy"
            summary = build_deployment(
                bundle,
                graph_path,
                novelty_path=novelty_path,
                runtime_config={"device": "cpu", "precision": "float32"},
            )
            validation = validate_deployment(bundle)
            self.assertTrue(validation["valid"])
            self.assertEqual(summary.graph_schema_hash, graph.schema_hash)

    def test_gpu_environment_report_is_machine_readable(self) -> None:
        report = gpu_environment_report(run_smoke=False)
        self.assertEqual(report["format"], "GSP4-GPU-ENVIRONMENT-1")
        self.assertIn("torch", report)
        self.assertIn("ready", report)


if __name__ == "__main__":
    unittest.main()
