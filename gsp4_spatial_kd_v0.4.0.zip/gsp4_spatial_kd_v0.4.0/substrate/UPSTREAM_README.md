# Selected UGTS-GN 1.1 substrate artifacts

This directory contains the specific portable artifacts used by GSP4 from the user-supplied UGTS GPU-native addendum package:

- schema and state-layout files;
- the G64/G32 ABI header;
- a dependency-free scalar reference;
- selected GLSL compute shaders;
- selected SPIR-V modules;
- a Markdown extraction of the UGTS-GN 1.1 report.

The original supplied ZIP is not duplicated in this smaller GSP4 release. Its SHA-256 is recorded in `UPSTREAM_PACKAGE.sha256` and `../SOURCE_BASIS.json`.

The portable contract is shader/SPIR-V source plus the declared ABI. Driver binaries and pipeline caches are implementation-specific. The GSP4 PyTorch path is an engineering extension that produces candidates, distilled scores and novelty records; `ugts_bridge.py` exports records for the direct substrate ABI.
