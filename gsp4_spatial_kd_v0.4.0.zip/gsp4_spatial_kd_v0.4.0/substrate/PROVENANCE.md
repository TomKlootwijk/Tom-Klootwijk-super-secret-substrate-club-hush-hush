# Substrate provenance boundary

This package is an engineering extension of the supplied UGTS-GN 1.1 material.
The requester supplied attribution to Tom Klootwijk together with an identifier
and date. Those values are recorded as user-supplied provenance and are not an
independent identity, copyright, priority or inventorship determination.

`SOURCE_BASIS.json` records SHA-256 values for the source documents available to
the implementation process. Selected upstream ABI, reference and shader files
are copied under `substrate/` to make the bridge reproducible. The GSP4 graph,
model, formats and adapters are engineering-derived deliverables.
