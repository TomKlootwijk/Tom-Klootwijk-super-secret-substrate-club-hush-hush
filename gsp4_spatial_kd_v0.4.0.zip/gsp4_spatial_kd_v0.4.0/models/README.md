# Models

The release includes one small schema-bound smoke student:

```text
gsp4_flevoland_smoke.pt
341,459 parameters
2 heterogeneous attention layers
64 hidden dimensions
4 heads
trained for 3 CPU smoke epochs on synthetic data
```

It exists to validate serialization, CUDA loading, relation scoring, deterministic gating and deployment. It is not a general geospatial model.

No third-party teacher weights are bundled. See `download_manifest.json` and `MANUAL_DOWNLOADS.md` for the optional Qwen and ULTRA paths.
