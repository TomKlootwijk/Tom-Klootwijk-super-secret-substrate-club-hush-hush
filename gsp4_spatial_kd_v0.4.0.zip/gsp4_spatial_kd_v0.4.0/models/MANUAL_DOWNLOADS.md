# Manual model and data downloads

Nothing in this file is required for the included graph/model test. Third-party weights and datasets are intentionally not redistributed.

## Recommended semantic embedding teacher

```text
Repository: Qwen/Qwen3-Embedding-0.6B-GGUF
Variant: Q8_0
Role: multilingual node/ontology embedding teacher
Target: external_data/models/Qwen3-Embedding-0.6B-Q8_0.gguf
```

A resumable explicit-file downloader is included:

```powershell
.\.venv\Scripts\python.exe scripts\download_hf_file.py `
  --repo Qwen/Qwen3-Embedding-0.6B-GGUF `
  --file Qwen3-Embedding-0.6B-Q8_0.gguf `
  --output external_data\models\Qwen3-Embedding-0.6B-Q8_0.gguf `
  --sha256 06507c7b42688469c4e7298b0a1e16deff06caf291cf0a5b278c308249c3e439
```

Alternatively, a current llama.cpp `llama-server` can fetch a Hugging Face selector directly:

```powershell
.\scripts\start_qwen_embedding_windows.ps1
```

Then run `scripts\embed_and_train_windows.ps1`.

## Optional relation-label teacher

```text
Repository: Qwen/Qwen3-4B-GGUF
Variant: Q4_K_M
Role: bounded semantic relation labels with strict JSON output
```

Start it with `scripts\start_relation_teacher_windows.ps1`, then run `scripts\distill_relations_windows.ps1`.

## Optional structural teacher

```text
Repository: DeepGraphLearning/ULTRA
Role: inductive relation/link structural scores
Bridge: gsp4 export-ultra / gsp4 import-scores
```

ULTRA can stay in a separate environment. Only its scored triples need to cross into GSP4 as a `.ugte` file.

## Small real Dutch data

```text
GeoNames Netherlands: https://download.geonames.org/export/dump/NL.zip
OpenStreetMap Flevoland: https://download.geofabrik.de/europe/netherlands/flevoland-latest.osm.pbf
```

Use `scripts\download_geonames_nl_windows.ps1` for the smallest pilot. OSM PBF ingestion requires the optional `osmium` dependency.

Exact repository names, filenames, known fixed hashes, roles and license notes are in `download_manifest.json`.
