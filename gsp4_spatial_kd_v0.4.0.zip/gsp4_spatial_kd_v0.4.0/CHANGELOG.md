# Changelog

## 0.4.0 — 2026-08-16

- delivered sparse variable-length geospatial graph format `UGKG2`;
- delivered hash-linked novelty/event format `UGNL3`;
- added HGT-style typed attention and TGN-style temporal memory student;
- added offline embedding and strict semantic relation-teacher adapters;
- added ULTRA triple/score bridge and `UGTE1` soft supervision;
- added deterministic UGTS support/compatibility/guard/event query path;
- added G64/G32 substrate bridge with packed precision verdict;
- added GeoNames and OSM ingestion plus irregular observation CSV;
- added hash-verified `.ugdeploy` archive and validation;
- added Windows/Linux RTX setup, demo and telemetry scripts;
- added included graph, novelty log, checkpoint, deployment and CPU results;
- added 48 collected pytest unit/integration cases;
- fixed duplicate `ontology.json` entries when packaging an explicit ontology.
