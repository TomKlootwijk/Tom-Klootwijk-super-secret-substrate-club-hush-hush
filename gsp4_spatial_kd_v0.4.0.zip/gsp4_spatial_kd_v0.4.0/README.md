# GSP4 — Sparse Geospatial Knowledge Transfer for UGTS-GN

GSP4 is a runnable geospatial knowledge-transfer and deployment package for irregular point and event streams. It deliberately avoids a padded `[frame, max_points, features]` tensor. Persistent places, assets, sensors, and ontology concepts retain stable identity; observations and verified events are sparse additions.

The production decision path is:

```text
spatial broad phase
  → exact support
  → typed compatibility
  → finite SDF/metric guard
  → compact HGT/TGN student score
  → verified event
  → route/transition
  → lineage + novelty append
```

Embedding and chat models are **offline teachers**. They create reusable node vectors, soft relation targets, and compact student weights. They are not called for every edge, and they cannot override failed geometry or compatibility checks.

## Delivered artifacts

| Deliverable | Included |
|---|---|
| GSP4-1 sparse substrate | `UGKG2` graph, `UGNL3` hash-linked novelty chain, persistent 64-bit IDs, variable-length observations, Morton/H3 broad phase, GeoNames and OSM adapters |
| GSP4-2 knowledge transfer | hash smoke teacher, OpenAI-compatible embedding/chat adapters, strict bounded relation candidates, `UGTE1` supervision, ULTRA export/import |
| GSP4-3 compact student | dependency-light HGT-style typed attention, relative-time features, TGN-style event memory, multi-objective distillation, CPU/CUDA execution |
| GSP4-4 deployment | deterministic UGTS query gate, verified-event commit, `UGDEPLOY` archive, G64/G32 substrate bridge, precision-margin report |

The ready-to-run package contains:

```text
data/flevoland_pilot.ugkg
[data/flevoland_pilot.ugnl]
models/gsp4_flevoland_smoke.pt
models/gsp4_flevoland_smoke.metrics.json
deploy/gsp4_flevoland_smoke.ugdeploy
results/bundled/
```

The pilot is synthetic and exists to validate software contracts, not geographic truth or model quality.

## Windows quick start on the RTX 5070 Ti Laptop GPU

Open PowerShell in the extracted directory:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\scripts\setup_windows.ps1
.\.venv\Scripts\Activate.ps1
gsp4 doctor
```

Run the included graph and trained smoke model without downloading a language model:

```powershell
.\scripts\run_included_model_windows.ps1
```

Run the fuller CUDA acceptance path, including new training and a fresh deployment bundle:

```powershell
.\scripts\run_rtx5070ti_windows.ps1
```

The first script is the fastest functional test. The second is the target-machine validation run.

## Linux or WSL

```bash
bash scripts/setup_linux.sh
bash scripts/run_included_model_linux.sh
```

For a CUDA training run:

```bash
bash scripts/run_rtx5070ti_linux.sh
```

## Included software validation

```bash
PYTHONPATH=src python -m unittest discover -s tests -v
PYTHONPATH=src python scripts/validate_release.py --output validation/release_validation.json
```

The package was prepared on a CPU-only environment. Included measurements are CPU software measurements, not RTX performance claims. See `docs/VALIDATION.md`.

## Query the included graph

```powershell
gsp4 query data\flevoland_pilot.ugkg `
  --model models\gsp4_flevoland_smoke.pt `
  --source sensor:0:0:air `
  --relation near `
  --radius 10000 `
  --epsilon 25 `
  --confidence-min 0.50 `
  --max-events 32 `
  --device cuda `
  --precision bf16 `
  --output results\my_query.json
```

The score is applied only after candidate support and type/topology compatibility. The final event record carries target identity, guard values, route, and lineage checksum.

## Export into the supplied UGTS GPU ABI

```powershell
gsp4 export-ugts data\flevoland_pilot.ugkg results\ugts\near_air `
  --source sensor:0:0:air `
  --relation near `
  --radius 10000 `
  --epsilon 25 `
  --confidence-min 0.50
```

Outputs:

```text
near_air.g64.bin        64-byte authoritative candidate records
near_air.g32.bin        32-byte packed candidate records
near_air.exchange.json  query and ABI contract
near_air.manifest.json  hashes and measured packed error
```

The bundled CPU export measured a maximum G32 position error of about 3.88 m against a 25 m guard epsilon and therefore passed this particular precision contract. This is workload-specific; it is not permission to use G32 for every guard.

## Optional real geospatial data

The smallest recommended real pilot is GeoNames Netherlands:

```powershell
.\scripts\download_geonames_nl_windows.ps1
gsp4 ingest-geonames external_data\NL.zip data\netherlands_geonames.ugkg `
  --country-code NL `
  --min-population 1000 `
  --limit 50000 `
  --near-radius 8000 `
  --neighbors 3
```

Tiny GeoNames, OSM XML, and irregular-observation fixtures are included under `examples/data/` and are covered by tests. OSM PBF ingestion is optional and requires `osmium`.

## Optional offline semantic teacher

The disk-conscious recommendation is Qwen3-Embedding-0.6B GGUF. It is not redistributed. Download details and fixed-file hashes are in `models/download_manifest.json` and `models/MANUAL_DOWNLOADS.md`.

Start a local llama.cpp embedding endpoint:

```powershell
.\scripts\start_qwen_embedding_windows.ps1
```

Then attach 256-dimensional teacher vectors and train a compact student:

```powershell
.\scripts\embed_and_train_windows.ps1
```

Once the student is trained and the teacher outputs are retained with provenance, the embedding server can be stopped and the GGUF file can be archived or removed.

## Optional semantic relation teacher

A local or hosted OpenAI-compatible chat endpoint can label only a bounded, type-compatible candidate set:

```powershell
.\scripts\distill_relations_windows.ps1
```

The teacher may select one allowed relation or abstain. Exact distance, containment, cone membership, physical compatibility, and guard crossing remain deterministic.

## Structural teacher

Use:

```powershell
gsp4 export-ultra data\flevoland_pilot.ugkg results\ultra_export
gsp4 import-scores data\flevoland_pilot.ugkg scores.tsv results\ultra_teacher.ugte
```

ULTRA is optional and external. GSP4 stores imported structural scores as soft supervision rather than keeping ULTRA in the online path.

## Formats

| Extension | Contract |
|---|---|
| `.ugkg` | sparse heterogeneous graph package (`UGKG2`) |
| `.ugnl` | append-only hash-linked novelty/event log (`UGNL3`) |
| `.ugte` | soft relation-teacher set (`UGTE1`) |
| `.pt` | schema-bound compact student checkpoint |
| `.ugdeploy` | hash-verified graph/model/novelty/ontology deployment ZIP |

See `docs/FORMATS.md`.

## Important boundaries

GSP4 should not be promoted for a workload when pruning is weak, event or branch density defeats avoided materialization, quantization changes event ordering, atomic/compaction pressure dominates, or a conventional sparse baseline is better at equal error. A model probability is not a geometric proof; a lineage checksum is not complete durable identity; H3/Morton equality is not exact containment.

## Documentation map

- `GSP4_DELIVERABLES.md` — concrete delivery and acceptance status.
- `docs/ARCHITECTURE.md` — sparse graph, student, gate, novelty, and deployment layout.
- `docs/KNOWLEDGE_TRANSFER.md` — teacher products and distillation flow.
- `docs/FORMATS.md` — binary/exchange formats.
- `docs/RTX5070TI_RUNBOOK.md` — target setup and measurement procedure.
- `docs/DATA_AND_MODELS.md` — manual download choices and storage budget.
- `docs/SOURCE_MAPPING.md` — source-derived substrate versus engineering additions.
- `docs/VALIDATION.md` — completed checks and remaining physical-GPU acceptance.
- `docs/LIMITATIONS.md` — explicit failure and kill criteria.
