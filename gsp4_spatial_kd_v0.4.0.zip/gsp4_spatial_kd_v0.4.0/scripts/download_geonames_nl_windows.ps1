param([string]$Output = "external_data\NL.zip")
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root
New-Item -ItemType Directory -Force (Split-Path -Parent $Output) | Out-Null
if (-not (Test-Path $Output)) {
    curl.exe -L --fail --retry 3 -C - -o $Output "https://download.geonames.org/export/dump/NL.zip"
}
Get-Item $Output | Format-List FullName,Length,LastWriteTime
