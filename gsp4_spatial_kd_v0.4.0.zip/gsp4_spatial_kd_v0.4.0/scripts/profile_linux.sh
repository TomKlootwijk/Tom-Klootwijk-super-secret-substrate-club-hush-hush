#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
PY="$ROOT/.venv/bin/python"
[[ -x "$PY" ]] || { echo "Run scripts/setup_linux.sh first." >&2; exit 2; }
mkdir -p results
"$PY" -m ugts_spatial doctor --output results/profile_environment.json
command -v nvidia-smi >/dev/null && nvidia-smi \
  --query-gpu=name,driver_version,memory.total,power.limit,temperature.gpu \
  --format=csv,noheader > results/profile_nvidia_smi.txt || true
"$PY" -m ugts_spatial benchmark \
  "${GSP4_GRAPH:-data/flevoland_pilot.ugkg}" \
  "${GSP4_MODEL:-models/gsp4_flevoland_smoke.pt}" \
  --device cuda --precision "${GSP4_PRECISION:-bf16}" --warmup 10 --repeats 50 \
  --output "${GSP4_PROFILE_OUTPUT:-results/profile_rtx5070ti.json}"
