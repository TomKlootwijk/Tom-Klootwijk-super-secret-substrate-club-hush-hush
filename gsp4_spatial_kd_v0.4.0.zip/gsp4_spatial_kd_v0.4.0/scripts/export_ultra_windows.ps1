param([string]$Graph = "results\distill\embedded.ugkg")
$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)
$Py = Join-Path $PWD ".venv\Scripts\python.exe"
& $Py -m ugts_spatial export-ultra $Graph results\ultra_export
Write-Host "Run ULTRA externally, write scored triples, then import with:"
Write-Host "$Py -m ugts_spatial import-scores $Graph scores.tsv results\ultra_teacher.ugte"
