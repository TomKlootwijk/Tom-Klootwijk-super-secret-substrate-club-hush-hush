[CmdletBinding()]
param(
    [string]$Model = 'Qwen/Qwen3-Embedding-0.6B-GGUF:Q8_0',
    [int]$Port = 8080,
    [int]$Context = 4096,
    [int]$GpuLayers = 99
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$Command = Get-Command llama-server.exe -ErrorAction SilentlyContinue
if (-not $Command) { $Command = Get-Command llama-server -ErrorAction SilentlyContinue }
if (-not $Command) {
    throw 'llama-server was not found on PATH. Install a current llama.cpp release first.'
}
& $Command.Source -hf $Model --embedding --pooling last --ctx-size $Context --port $Port -ngl $GpuLayers
