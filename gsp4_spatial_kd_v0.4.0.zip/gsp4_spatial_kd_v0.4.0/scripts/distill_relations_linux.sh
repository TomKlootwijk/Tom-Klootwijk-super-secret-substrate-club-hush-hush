#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
PY="$ROOT/.venv/bin/python"
[[ -x "$PY" ]] || { echo "Run scripts/setup_linux.sh first." >&2; exit 2; }
INPUT="${1:-data/flevoland_pilot.ugkg}"
OUT="${2:-results/relation_distill}"
LIMIT="${GSP4_TEACHER_LIMIT:-2000}"
mkdir -p "$OUT"
"$PY" -m ugts_spatial embed "$INPUT" "$OUT/embedded.ugkg" \
  --backend openai-compatible --base-url "${GSP4_EMBED_URL:-http://127.0.0.1:8080/v1}" \
  --model "${GSP4_EMBED_MODEL:-Qwen3-Embedding-0.6B-GGUF}" --dimensions 256 --batch-size 32
"$PY" -m ugts_spatial teacher-candidates "$OUT/embedded.ugkg" "$OUT/candidates.jsonl" \
  --max-candidates "$LIMIT"
"$PY" -m ugts_spatial teacher-label "$OUT/candidates.jsonl" "$OUT/labels.jsonl" \
  --base-url "${GSP4_RELATION_URL:-http://127.0.0.1:8081/v1}" \
  --model "${GSP4_RELATION_MODEL:-Qwen3-4B-GGUF}" --limit "$LIMIT" --progress
"$PY" -m ugts_spatial labels-to-edges "$OUT/embedded.ugkg" "$OUT/labels.jsonl" \
  "$OUT/teacher.ugte" --teacher-name "${GSP4_RELATION_MODEL:-Qwen3-4B-GGUF}"
"$PY" -m ugts_spatial train "$OUT/embedded.ugkg" "$OUT/student.pt" \
  --teacher-edges "$OUT/teacher.ugte" --metrics "$OUT/student.metrics.json" \
  --device "${GSP4_DEVICE:-cuda}" --precision "${GSP4_PRECISION:-bf16}" \
  --hidden-dim 128 --heads 4 --layers 3 --epochs "${GSP4_EPOCHS:-20}"
