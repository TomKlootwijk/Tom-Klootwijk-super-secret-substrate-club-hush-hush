#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
PY="$ROOT/.venv/bin/python"
[[ -x "$PY" ]] || { echo "Run scripts/setup_linux.sh first." >&2; exit 2; }
INPUT="${1:-data/flevoland_pilot.ugkg}"
OUT="${2:-results/embedding_distill}"
mkdir -p "$OUT"
"$PY" -m ugts_spatial embed "$INPUT" "$OUT/embedded.ugkg" \
  --backend openai-compatible --base-url "${GSP4_EMBED_URL:-http://127.0.0.1:8080/v1}" \
  --model "${GSP4_EMBED_MODEL:-Qwen3-Embedding-0.6B-GGUF}" \
  --dimensions "${GSP4_EMBED_DIM:-256}" --batch-size 32
"$PY" -m ugts_spatial train "$OUT/embedded.ugkg" "$OUT/student.pt" \
  --metrics "$OUT/student.metrics.json" --device "${GSP4_DEVICE:-cuda}" \
  --precision "${GSP4_PRECISION:-bf16}" --hidden-dim 128 --heads 4 --layers 3 \
  --epochs "${GSP4_EPOCHS:-30}"
