#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
PYTHON_BIN="${PYTHON_BIN:-python3}"
TORCH_INDEX_URL="${TORCH_INDEX_URL:-https://download.pytorch.org/whl/cu128}"
if [[ ! -d .venv ]]; then
  "$PYTHON_BIN" -m venv .venv
fi
. .venv/bin/activate
python -m pip install --upgrade pip setuptools wheel
python -m pip install 'numpy>=1.26'
if [[ "${GSP4_CPU_ONLY:-0}" == "1" ]]; then
  python -m pip install 'torch>=2.7'
else
  python -m pip install 'torch>=2.7' --index-url "$TORCH_INDEX_URL"
fi
python -m pip install -e . --no-build-isolation
python -m ugts_spatial --version
printf '\nEnvironment ready. Next: .venv/bin/python -m ugts_spatial doctor\n'
