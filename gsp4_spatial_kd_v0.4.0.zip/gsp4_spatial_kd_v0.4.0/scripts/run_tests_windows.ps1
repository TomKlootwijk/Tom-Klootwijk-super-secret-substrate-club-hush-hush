[CmdletBinding()]
param([string]$Venv = '.venv')
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root
$Python = Join-Path $Venv 'Scripts\python.exe'
if (-not (Test-Path $Python)) { throw 'Run setup_windows.ps1 first.' }
& $Python -m compileall -q src tests
& $Python -m unittest discover -s tests -v
& $Python -m ugts_spatial validate-package deploy\gsp4_flevoland_smoke.ugdeploy
