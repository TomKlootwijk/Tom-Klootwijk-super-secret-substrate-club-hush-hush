#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
mkdir -p external_data
curl -L --fail --retry 3 -C - -o external_data/NL.zip \
  https://download.geonames.org/export/dump/NL.zip
sha256sum external_data/NL.zip
