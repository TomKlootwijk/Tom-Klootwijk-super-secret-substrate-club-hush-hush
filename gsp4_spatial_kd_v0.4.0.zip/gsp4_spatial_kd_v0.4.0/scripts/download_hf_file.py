#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
from pathlib import Path
import sys
from urllib import error, request

CHUNK = 8 * 1024 * 1024


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(CHUNK), b''):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description='Download one explicit Hugging Face file with optional resume and SHA-256 verification')
    parser.add_argument('--repo', required=True)
    parser.add_argument('--file', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--revision', default='main')
    parser.add_argument('--sha256')
    args = parser.parse_args()

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    url = f'https://huggingface.co/{args.repo}/resolve/{args.revision}/{args.file}?download=true'
    existing = output.stat().st_size if output.exists() else 0
    headers = {'User-Agent': 'GSP4/0.4.0'}
    if existing:
        headers['Range'] = f'bytes={existing}-'

    try:
        response = request.urlopen(request.Request(url, headers=headers), timeout=120)
    except error.HTTPError as exc:
        if exc.code == 416 and output.exists():
            response = None
        else:
            raise

    if response is not None:
        content_range = response.headers.get('Content-Range', '')
        resumed = existing > 0 and response.status == 206 and content_range.startswith(f'bytes {existing}-')
        mode = 'ab' if resumed else 'wb'
        downloaded = existing if resumed else 0
        if existing and not resumed:
            print('Server did not honor Range; restarting download.', file=sys.stderr)
        with response, output.open(mode) as handle:
            while True:
                chunk = response.read(CHUNK)
                if not chunk:
                    break
                handle.write(chunk)
                downloaded += len(chunk)
                print(f'\r{downloaded:,} bytes', end='', file=sys.stderr, flush=True)
        print(file=sys.stderr)

    digest = sha256_file(output)
    print(f'sha256  {digest}  {output}')
    if args.sha256 and digest.casefold() != args.sha256.casefold():
        raise SystemExit('SHA-256 mismatch')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
