#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
PY="$ROOT/.venv/bin/python"
[[ -x "$PY" ]] || { echo "Run scripts/setup_linux.sh first." >&2; exit 2; }
OUTPUT="${1:-results/rtx5070ti}"
EPOCHS="${EPOCHS:-30}"
mkdir -p "$OUTPUT"
"$PY" -m ugts_spatial doctor --output "$OUTPUT/environment.json"
"$PY" -m ugts_spatial demo "$OUTPUT" \
  --device cuda --precision bf16 --epochs "$EPOCHS" \
  --hidden-dim 192 --heads 6 --layers 3 --dropout 0.10 \
  --max-edges 50000 --max-encoder-edges 250000 \
  --max-teacher-edges 20000 --temporal-edges 4096 \
  --early-stopping 10 --warmup 5 --repeats 20
"$PY" -m ugts_spatial validate-package "$OUTPUT/flevoland_demo.ugdeploy"
"$PY" scripts/validate_release.py --runtime-only --result-dir "$OUTPUT"
