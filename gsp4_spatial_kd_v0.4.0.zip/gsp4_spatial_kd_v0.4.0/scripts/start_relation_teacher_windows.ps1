[CmdletBinding()]
param(
    [string]$Model = 'Qwen/Qwen3-4B-GGUF:Q4_K_M',
    [int]$Port = 8081,
    [int]$Context = 8192,
    [int]$GpuLayers = 99
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$Command = Get-Command llama-server.exe -ErrorAction SilentlyContinue
if (-not $Command) { $Command = Get-Command llama-server -ErrorAction SilentlyContinue }
if (-not $Command) { throw 'llama-server was not found on PATH.' }
& $Command.Source -hf $Model --host 127.0.0.1 --port $Port `
  --ctx-size $Context -ngl $GpuLayers --jinja
