[CmdletBinding()]
param(
    [string]$Graph = 'data\flevoland_pilot.ugkg',
    [string]$Output = 'results\relation_distill',
    [string]$BaseUrl = 'http://127.0.0.1:8081/v1',
    [string]$TeacherModel = 'Qwen3-4B-GGUF',
    [int]$Limit = 2000,
    [int]$Epochs = 20,
    [ValidateSet('auto','cpu','cuda')]
    [string]$Device = 'cuda',
    [ValidateSet('float32','float16','bf16')]
    [string]$Precision = 'bf16'
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root
$Py = Join-Path $Root '.venv\Scripts\python.exe'
if (-not (Test-Path $Py)) { throw 'Run scripts\setup_windows.ps1 first.' }
New-Item -ItemType Directory -Force -Path $Output | Out-Null
$Candidates = Join-Path $Output 'candidates.jsonl'
$Labels = Join-Path $Output 'labels.jsonl'
$Edges = Join-Path $Output 'teacher.ugte'
$Student = Join-Path $Output 'student.pt'

& $Py -m ugts_spatial teacher-candidates $Graph $Candidates `
  --max-distance 5000 --concepts-per-source 8 --spatial-per-source 4 --max-candidates $Limit
& $Py -m ugts_spatial teacher-label $Candidates $Labels `
  --base-url $BaseUrl --model $TeacherModel --limit $Limit --progress
& $Py -m ugts_spatial labels-to-edges $Graph $Labels $Edges --teacher-name $TeacherModel
& $Py -m ugts_spatial train $Graph $Student --teacher-edges $Edges `
  --metrics ($Student + '.metrics.json') --device $Device --precision $Precision `
  --hidden-dim 128 --heads 4 --layers 3 --epochs $Epochs `
  --max-edges 100000 --max-encoder-edges 250000 --temporal-edges 8192
