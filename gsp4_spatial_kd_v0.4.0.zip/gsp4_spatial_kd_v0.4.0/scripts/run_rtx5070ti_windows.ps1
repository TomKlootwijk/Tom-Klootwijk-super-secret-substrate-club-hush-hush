param(
    [string]$Output = "results\rtx5070ti",
    [int]$Epochs = 30
)
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root
$Python = Join-Path $Root ".venv\Scripts\python.exe"
if (-not (Test-Path $Python)) { throw "Run scripts\setup_windows.ps1 first." }
New-Item -ItemType Directory -Force -Path $Output | Out-Null

& $Python -m ugts_spatial doctor --output (Join-Path $Output "environment.json")
if ($LASTEXITCODE -ne 0) { throw "CUDA GPU smoke test failed. See environment.json." }

& $Python -m ugts_spatial demo $Output `
    --device cuda --precision bf16 --epochs $Epochs `
    --hidden-dim 192 --heads 6 --layers 3 --dropout 0.10 `
    --max-edges 50000 --max-encoder-edges 250000 `
    --max-teacher-edges 20000 --temporal-edges 4096 `
    --early-stopping 10 --warmup 5 --repeats 20

& $Python -m ugts_spatial validate-package (Join-Path $Output "flevoland_demo.ugdeploy")
& $Python scripts\validate_release.py --runtime-only --result-dir $Output
