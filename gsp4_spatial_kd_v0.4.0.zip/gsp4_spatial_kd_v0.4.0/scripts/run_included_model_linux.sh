#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
PY="${VENV:-.venv}/bin/python"
[[ -x "$PY" ]] || { echo "Run scripts/setup_linux.sh first." >&2; exit 2; }
OUT="${1:-results/included_model_gpu}"
PRECISION="${GSP4_PRECISION:-bf16}"
mkdir -p "$OUT/ugts_bridge"
"$PY" -m ugts_spatial doctor --output "$OUT/environment.json"
"$PY" -m ugts_spatial query data/flevoland_pilot.ugkg \
  --model models/gsp4_flevoland_smoke.pt \
  --source sensor:0:0:air --relation near --radius 10000 --epsilon 25 \
  --confidence-min 0.50 --max-events 32 --device cuda --precision "$PRECISION" \
  --output "$OUT/query.json" | tee "$OUT/query_console.json"
"$PY" -m ugts_spatial benchmark data/flevoland_pilot.ugkg models/gsp4_flevoland_smoke.pt \
  --source sensor:0:0:air --relation near --radius 10000 --epsilon 25 \
  --confidence-min 0.50 --max-events 32 --device cuda --precision "$PRECISION" \
  --warmup 5 --repeats 30 --output "$OUT/benchmark.json" | tee "$OUT/benchmark_console.json"
"$PY" -m ugts_spatial export-ugts data/flevoland_pilot.ugkg "$OUT/ugts_bridge/near_air" \
  --source sensor:0:0:air --relation near --radius 10000 --epsilon 25 --confidence-min 0.50 \
  | tee "$OUT/ugts_bridge/export_console.json"
"$PY" -m ugts_spatial validate-package deploy/gsp4_flevoland_smoke.ugdeploy \
  | tee "$OUT/deployment_validation.json"
