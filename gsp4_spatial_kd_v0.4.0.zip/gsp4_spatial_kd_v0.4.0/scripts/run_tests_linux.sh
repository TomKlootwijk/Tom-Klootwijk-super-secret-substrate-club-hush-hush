#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
PY="${VENV:-.venv}/bin/python"
"$PY" -m compileall -q src tests
"$PY" -m unittest discover -s tests -v
"$PY" -m ugts_spatial validate-package deploy/gsp4_flevoland_smoke.ugdeploy
