#!/usr/bin/env bash
set -euo pipefail
MODEL="${MODEL:-Qwen/Qwen3-Embedding-0.6B-GGUF:Q8_0}"
PORT="${PORT:-8080}"
CTX="${CTX:-4096}"
GPU_LAYERS="${GPU_LAYERS:-99}"
exec llama-server -hf "$MODEL" --embedding --pooling last --ctx-size "$CTX" --port "$PORT" -ngl "$GPU_LAYERS"
