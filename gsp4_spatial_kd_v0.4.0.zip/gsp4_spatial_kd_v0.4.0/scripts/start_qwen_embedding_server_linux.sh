#!/usr/bin/env bash
set -euo pipefail
[[ $# -ge 1 ]] || { echo "usage: $0 MODEL.gguf [LLAMA_SERVER]" >&2; exit 2; }
MODEL="$1"
SERVER="${2:-llama-server}"
exec "$SERVER" -m "$MODEL" --embedding --pooling last --host 127.0.0.1 \
  --port "${GSP4_EMBED_PORT:-8080}" --ctx-size "${GSP4_EMBED_CONTEXT:-4096}" \
  --n-gpu-layers "${GSP4_GPU_LAYERS:-99}"
