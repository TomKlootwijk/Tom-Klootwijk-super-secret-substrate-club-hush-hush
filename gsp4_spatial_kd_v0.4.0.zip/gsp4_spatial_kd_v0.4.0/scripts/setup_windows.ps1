[CmdletBinding()]
param(
    [string]$PythonVersion = '3.12',
    [string]$Venv = '.venv',
    [string]$TorchIndexUrl = 'https://download.pytorch.org/whl/cu128',
    [switch]$CpuOnly
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root

if (-not (Get-Command py -ErrorAction SilentlyContinue)) {
    throw 'The Python launcher `py` was not found. Install 64-bit Python 3.11 or 3.12.'
}
if (-not (Test-Path $Venv)) {
    & py "-$PythonVersion" -m venv $Venv
    if ($LASTEXITCODE -ne 0) { throw 'Virtual environment creation failed.' }
}
$Py = Join-Path $Root "$Venv\Scripts\python.exe"
if (-not (Test-Path $Py)) { throw "Virtual environment Python not found: $Py" }

& $Py -m pip install --upgrade pip setuptools wheel
if ($CpuOnly) {
    & $Py -m pip install --upgrade torch --index-url https://download.pytorch.org/whl/cpu
} else {
    Write-Host "Installing CUDA PyTorch from $TorchIndexUrl"
    & $Py -m pip install --upgrade torch --index-url $TorchIndexUrl
}
& $Py -m pip install 'numpy>=1.26'
& $Py -m pip install -e . --no-deps --no-build-isolation
& $Py -m ugts_spatial --version

Write-Host "Environment ready: $Py"
Write-Host "Next command: $Py -m ugts_spatial doctor"
