#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
mkdir -p external_data
curl -L --fail --retry 3 -C - -o external_data/NL.zip \
  https://download.geonames.org/export/dump/NL.zip
if [[ "${INCLUDE_OSM:-0}" == "1" ]]; then
  curl -L --fail --retry 3 -C - -o external_data/flevoland-latest.osm.pbf \
    https://download.geofabrik.de/europe/netherlands/flevoland-latest.osm.pbf
fi
ls -lh external_data
