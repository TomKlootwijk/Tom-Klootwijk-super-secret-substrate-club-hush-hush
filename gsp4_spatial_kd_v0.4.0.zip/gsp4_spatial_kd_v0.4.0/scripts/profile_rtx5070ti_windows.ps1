[CmdletBinding()]
param(
    [string]$Venv = '.venv',
    [string]$Output = 'results\rtx5070ti_profile'
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root
$Python = Join-Path $Venv 'Scripts\python.exe'
if (-not (Test-Path $Python)) { throw 'Run setup_windows.ps1 first.' }
if (-not (Get-Command nvidia-smi -ErrorAction SilentlyContinue)) {
    throw 'nvidia-smi was not found.'
}
New-Item -ItemType Directory -Force -Path $Output | Out-Null
$Telemetry = Join-Path $Output 'nvidia_smi.csv'
$Args = '--query-gpu=timestamp,name,temperature.gpu,power.draw,memory.used,utilization.gpu,clocks.sm --format=csv -l 1'
$Monitor = Start-Process nvidia-smi -ArgumentList $Args -NoNewWindow -PassThru -RedirectStandardOutput $Telemetry
try {
    & $Python -m ugts_spatial benchmark data\flevoland_pilot.ugkg models\gsp4_flevoland_smoke.pt `
      --source sensor:0:0:air --relation near --radius 10000 --epsilon 25 `
      --max-events 32 --device cuda --precision bf16 --warmup 10 --repeats 100 `
      --output (Join-Path $Output 'benchmark.json') |
      Tee-Object -FilePath (Join-Path $Output 'benchmark_console.json')
} finally {
    if (-not $Monitor.HasExited) { Stop-Process -Id $Monitor.Id -Force }
}
Write-Host "Benchmark and telemetry written to $Output"
