#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ugts_spatial.deployment import validate_deployment  # noqa: E402
from ugts_spatial.graph import GraphPackage  # noqa: E402
from ugts_spatial.novelty import NoveltyLog  # noqa: E402
from ugts_spatial.training import load_model_for_graph  # noqa: E402
from ugts_spatial.utils import safe_torch_load, sha256_file  # noqa: E402


def _check_hash(path: Path, expected: str) -> None:
    actual = sha256_file(path)
    if actual != expected:
        raise ValueError(f"SHA-256 mismatch for {path}: {actual} != {expected}")


def _validate_result_dir(path: Path) -> dict[str, Any]:
    graph_path = path / "flevoland_demo.ugkg"
    model_path = path / "flevoland_student.pt"
    novelty_path = path / "flevoland_demo.ugnl"
    deployment_path = path / "flevoland_demo.ugdeploy"
    missing = [str(p) for p in (graph_path, model_path, novelty_path, deployment_path) if not p.exists()]
    if missing:
        raise FileNotFoundError("missing runtime artifacts: " + ", ".join(missing))
    graph = GraphPackage.load(graph_path)
    novelty = NoveltyLog(novelty_path).validate()
    checkpoint = safe_torch_load(model_path, map_location="cpu")
    if checkpoint.get("schema_hash") != graph.schema_hash:
        raise ValueError("student checkpoint schema hash does not match graph")
    model, device, _ = load_model_for_graph(graph, model_path, device="cpu")
    del model
    deployment = validate_deployment(deployment_path)
    if deployment.get("graph_schema_hash") != graph.schema_hash:
        raise ValueError("deployment schema hash does not match graph")
    bridge_manifest_path = path / "ugts_bridge" / "query.manifest.json"
    bridge: dict[str, Any] | None = None
    if bridge_manifest_path.exists():
        bridge = json.loads(bridge_manifest_path.read_text(encoding="utf-8"))
        base = bridge_manifest_path.parent
        _check_hash(base / "query.g64.bin", bridge["g64_sha256"])
        _check_hash(base / "query.g32.bin", bridge["g32_sha256"])
        _check_hash(base / "query.exchange.json", bridge["exchange_sha256"])
        if not bridge.get("g32_precision_within_guard"):
            raise ValueError("G32 packing error exceeds the declared guard")
    return {
        "graph": graph.summary(),
        "model_bytes": model_path.stat().st_size,
        "model_device_validation": str(device),
        "novelty": novelty,
        "deployment": deployment,
        "bridge": bridge,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--runtime-only", action="store_true")
    parser.add_argument("--result-dir", type=Path, default=ROOT / "results" / "cpu_demo")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    result: dict[str, Any] = {
        "format": "GSP4-RELEASE-VALIDATION-1",
        "root": str(root),
        "runtime": _validate_result_dir(args.result_dir.resolve()),
    }
    if not args.runtime_only:
        graph = GraphPackage.load(root / "data" / "flevoland_pilot.ugkg")
        novelty = NoveltyLog(root / "data" / "flevoland_pilot.ugnl").validate()
        result["included_pilot"] = {
            "graph": graph.summary(),
            "novelty": novelty,
            "graph_sha256": sha256_file(root / "data" / "flevoland_pilot.ugkg"),
            "novelty_sha256": sha256_file(root / "data" / "flevoland_pilot.ugnl"),
        }
        source_manifest = root / "substrate" / "source_hashes.json"
        if source_manifest.exists():
            values = json.loads(source_manifest.read_text(encoding="utf-8"))
            verified: list[dict[str, Any]] = []
            for row in values.get("sources", []):
                source = Path(row["path"])
                item = {"path": str(source), "expected_sha256": row["sha256"], "available": source.exists()}
                if source.exists():
                    item["actual_sha256"] = sha256_file(source)
                    item["valid"] = item["actual_sha256"] == row["sha256"]
                    if not item["valid"]:
                        raise ValueError(f"source hash mismatch: {source}")
                verified.append(item)
            result["source_hashes"] = verified
    result["valid"] = True
    text = json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text, encoding="utf-8")
    print(text, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
