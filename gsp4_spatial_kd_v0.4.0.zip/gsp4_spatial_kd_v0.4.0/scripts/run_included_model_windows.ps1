[CmdletBinding()]
param(
    [string]$Venv = '.venv',
    [string]$Output = 'results\included_model_gpu',
    [ValidateSet('float32','float16','bf16')]
    [string]$Precision = 'bf16'
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root
$Py = Join-Path $Root "$Venv\Scripts\python.exe"
if (-not (Test-Path $Py)) { throw 'Run scripts\setup_windows.ps1 first.' }
New-Item -ItemType Directory -Force -Path $Output | Out-Null

& $Py -m ugts_spatial doctor --output (Join-Path $Output 'environment.json')
if ($LASTEXITCODE -ne 0) { throw 'CUDA readiness test failed. Inspect environment.json.' }

& $Py -m ugts_spatial query data\flevoland_pilot.ugkg `
  --model models\gsp4_flevoland_smoke.pt `
  --source sensor:0:0:air --relation near --radius 10000 --epsilon 25 `
  --confidence-min 0.50 --max-events 32 --device cuda --precision $Precision `
  --output (Join-Path $Output 'query.json') |
  Tee-Object -FilePath (Join-Path $Output 'query_console.json')

& $Py -m ugts_spatial benchmark data\flevoland_pilot.ugkg models\gsp4_flevoland_smoke.pt `
  --source sensor:0:0:air --relation near --radius 10000 --epsilon 25 `
  --confidence-min 0.50 --max-events 32 --device cuda --precision $Precision `
  --warmup 5 --repeats 30 --output (Join-Path $Output 'benchmark.json') |
  Tee-Object -FilePath (Join-Path $Output 'benchmark_console.json')

New-Item -ItemType Directory -Force -Path (Join-Path $Output 'ugts_bridge') | Out-Null
& $Py -m ugts_spatial export-ugts data\flevoland_pilot.ugkg (Join-Path $Output 'ugts_bridge\near_air') `
  --source sensor:0:0:air --relation near --radius 10000 --epsilon 25 --confidence-min 0.50 |
  Tee-Object -FilePath (Join-Path $Output 'ugts_bridge\export_console.json')

& $Py -m ugts_spatial validate-package deploy\gsp4_flevoland_smoke.ugdeploy |
  Tee-Object -FilePath (Join-Path $Output 'deployment_validation.json')
Write-Host "Included-model CUDA test completed: $Output"
