param(
    [string]$Graph = "data\flevoland_pilot.ugkg",
    [string]$EmbeddedGraph = "results\distill\flevoland_embedded.ugkg",
    [string]$OutputModel = "results\distill\flevoland_student.pt",
    [string]$BaseUrl = "http://127.0.0.1:8080/v1",
    [string]$EmbeddingModel = "Qwen3-Embedding-0.6B-GGUF",
    [int]$Dimensions = 256,
    [int]$Epochs = 20,
    [ValidateSet("auto", "cpu", "cuda")][string]$Device = "cuda",
    [ValidateSet("float32", "float16", "bf16")][string]$Precision = "bf16"
)
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root
$Py = Join-Path $Root ".venv\Scripts\python.exe"
if (-not (Test-Path $Py)) { throw "Run scripts\setup_windows.ps1 first." }
New-Item -ItemType Directory -Force (Split-Path -Parent $EmbeddedGraph) | Out-Null
& $Py -m ugts_spatial embed $Graph $EmbeddedGraph `
    --backend openai-compatible --base-url $BaseUrl --model $EmbeddingModel `
    --dimensions $Dimensions --batch-size 32
& $Py -m ugts_spatial train $EmbeddedGraph $OutputModel `
    --metrics ($OutputModel + ".metrics.json") `
    --device $Device --precision $Precision `
    --hidden-dim 128 --heads 4 --layers 3 --epochs $Epochs `
    --max-edges 100000 --max-encoder-edges 250000 --temporal-edges 8192
