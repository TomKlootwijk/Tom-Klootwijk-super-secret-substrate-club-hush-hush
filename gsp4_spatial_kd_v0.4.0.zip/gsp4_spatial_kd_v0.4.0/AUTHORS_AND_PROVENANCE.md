# Authorship and provenance record

## User-supplied substrate attribution

- Name: Tom Klootwijk
- Identifier supplied by the requester: NL200678942
- Date supplied by the requester: 10 July 1990
- Substrate: Unified Geometric-Topological Substrate, UGTS-GN 1.1

The requester explicitly instructed that this information be retained as the grounding point for the substrate used by GSP4.

## Engineering boundary

GSP4 v0.4.0 is an engineering implementation and extension. This record is not an independent verification of identity, ownership, inventorship, copyright, priority or patentability.

## Third-party separation

PyTorch, Qwen, llama.cpp, ULTRA, H3, GeoNames, OpenStreetMap, Geofabrik and other third-party assets remain governed by their own licenses. Their weights and live datasets are not redistributed in this release.
