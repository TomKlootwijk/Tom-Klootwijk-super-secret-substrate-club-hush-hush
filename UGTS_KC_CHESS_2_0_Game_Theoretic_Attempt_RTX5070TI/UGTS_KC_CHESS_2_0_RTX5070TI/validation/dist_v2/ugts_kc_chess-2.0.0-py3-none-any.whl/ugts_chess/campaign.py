"""SQLite-backed, hash-chained proof campaign ledger.

The campaign database coordinates work; it is not itself the mathematical
proof.  Workers may lease an obligation and attach a candidate certificate,
but only an independently recorded checker result changes the obligation to
``verified``.  Unverified values aggregate as UNKNOWN.
"""
from __future__ import annotations

import hashlib
import json
import sqlite3
from contextlib import closing
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from .game_state import HistoryContext, game_state_sha256
from .game_theory import WDL, aggregate_root_wdl, root_obligations
from .hashing import canonical_json_bytes, state_sha256
from .position import Position, START_FEN

SCHEMA = "ugts-chess-campaign-2.0"
GENESIS_HASH = hashlib.sha256(b"UGTS-CHESS2-CAMPAIGN-GENESIS").hexdigest()


def _utc_now() -> str:
    return datetime.now(UTC).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _path_for_storage(db_path: str | Path, path: str | Path) -> str:
    """Store package-local paths relative to the campaign database.

    Absolute paths make a campaign checkpoint impossible to move to another
    workstation.  Paths outside the database directory remain absolute because
    there is no safe portable relative reference for them.
    """

    base = Path(db_path).resolve().parent
    resolved = Path(path).resolve()
    try:
        return resolved.relative_to(base).as_posix()
    except ValueError:
        return str(resolved)


def _path_from_storage(db_path: str | Path, stored: str | Path) -> Path:
    path = Path(stored)
    if path.is_absolute():
        return path
    return Path(db_path).resolve().parent / path


def _connect(path: str | Path) -> sqlite3.Connection:
    conn = sqlite3.connect(str(path))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=FULL")
    return conn


def _append_event(conn: sqlite3.Connection, action: str, payload: dict[str, Any], job_id: str | None = None) -> str:
    row = conn.execute("SELECT event_hash FROM events ORDER BY sequence DESC LIMIT 1").fetchone()
    prev_hash = row["event_hash"] if row else GENESIS_HASH
    timestamp = _utc_now()
    record = {
        "action": action,
        "job_id": job_id,
        "payload": payload,
        "prev_hash": prev_hash,
        "timestamp": timestamp,
    }
    event_hash = hashlib.sha256(canonical_json_bytes(record)).hexdigest()
    conn.execute(
        "INSERT INTO events(timestamp,job_id,action,payload_json,prev_hash,event_hash) VALUES(?,?,?,?,?,?)",
        (timestamp, job_id, action, json.dumps(payload, sort_keys=True, separators=(",", ":")), prev_hash, event_hash),
    )
    return event_hash


def init_campaign(
    db_path: str | Path,
    shard_dir: str | Path,
    *,
    root_fen: str = START_FEN,
    force: bool = False,
) -> dict[str, Any]:
    db_path = Path(db_path)
    shard_dir = Path(shard_dir)
    if db_path.exists() and not force:
        raise FileExistsError(f"campaign database already exists: {db_path}")
    if db_path.exists():
        db_path.unlink()
    for suffix in ("-wal", "-shm"):
        sidecar = Path(str(db_path) + suffix)
        if sidecar.exists():
            sidecar.unlink()
    db_path.parent.mkdir(parents=True, exist_ok=True)
    shard_dir.mkdir(parents=True, exist_ok=True)
    for old in shard_dir.glob("root-*.json"):
        old.unlink()

    root = Position.from_fen(root_fen)
    root_history = HistoryContext.initial(root)
    obligations = root_obligations(root, root_history)
    created_at = _utc_now()
    metadata = {
        "schema": SCHEMA,
        "created_at": created_at,
        "canonical_component": "ugts.application.chess.game-theoretic-solver@2.0.0",
        "root_fen": root.to_fen(),
        "root_position_sha256": state_sha256(root),
        "root_game_state_sha256": game_state_sha256(root, root_history),
        "root_history_counts": root_history.record(),
        "rules_profile": "fide-classical-2023-claims-as-actions-v2",
        "root_wdl": "unknown",
        "claim_boundary": "Only independently verified certificate records may set a child WDL.",
    }

    with closing(_connect(db_path)) as conn:
        conn.executescript(
            """
            CREATE TABLE meta(key TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE TABLE jobs(
                obligation_id TEXT PRIMARY KEY,
                parent_game_state_sha256 TEXT NOT NULL,
                move_uci TEXT NOT NULL,
                move_san TEXT NOT NULL,
                child_fen TEXT NOT NULL,
                child_position_sha256 TEXT NOT NULL,
                child_game_state_sha256 TEXT NOT NULL,
                child_history_json TEXT NOT NULL,
                child_side_to_move TEXT NOT NULL,
                wdl TEXT NOT NULL DEFAULT 'unknown' CHECK(wdl IN ('win','draw','loss','unknown')),
                status TEXT NOT NULL DEFAULT 'unresolved' CHECK(status IN ('unresolved','leased','candidate','verified','rejected')),
                verification TEXT NOT NULL DEFAULT 'unverified',
                priority INTEGER NOT NULL DEFAULT 0,
                attempts INTEGER NOT NULL DEFAULT 0,
                lease_owner TEXT,
                lease_expires TEXT,
                certificate_path TEXT,
                certificate_sha256 TEXT,
                checker_path TEXT,
                checker_sha256 TEXT,
                shard_path TEXT NOT NULL,
                shard_sha256 TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            CREATE TABLE events(
                sequence INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                job_id TEXT,
                action TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                prev_hash TEXT NOT NULL,
                event_hash TEXT NOT NULL UNIQUE
            );
            """
        )
        conn.executemany("INSERT INTO meta(key,value) VALUES(?,?)", [(key, json.dumps(value)) for key, value in metadata.items()])
        for obligation in obligations:
            record = obligation.to_dict()
            shard_path = shard_dir / f"{obligation.obligation_id}.json"
            shard_path.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n", encoding="utf-8")
            shard_hash = _file_sha256(shard_path)
            conn.execute(
                """INSERT INTO jobs(
                    obligation_id,parent_game_state_sha256,move_uci,move_san,child_fen,
                    child_position_sha256,child_game_state_sha256,child_history_json,
                    child_side_to_move,shard_path,shard_sha256,updated_at
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    obligation.obligation_id,
                    obligation.parent_game_state_sha256,
                    obligation.move_uci,
                    obligation.move_san,
                    obligation.child_fen,
                    obligation.child_position_sha256,
                    obligation.child_game_state_sha256,
                    json.dumps([[key, count] for key, count in obligation.child_history_counts], separators=(",", ":")),
                    obligation.child_side_to_move,
                    _path_for_storage(db_path, shard_path),
                    shard_hash,
                    created_at,
                ),
            )
        _append_event(
            conn,
            "campaign_initialized",
            {
                "root_game_state_sha256": metadata["root_game_state_sha256"],
                "obligations": len(obligations),
                "root_wdl": "unknown",
            },
        )
        conn.commit()
        conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    return {
        **metadata,
        "database": str(db_path),
        "shard_dir": str(shard_dir),
        "obligation_count": len(obligations),
    }


def lease_next(db_path: str | Path, worker: str, *, seconds: int = 900) -> dict[str, Any] | None:
    if not worker.strip():
        raise ValueError("worker name must be non-empty")
    now = datetime.now(UTC)
    expiry = (now + timedelta(seconds=max(1, seconds))).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    now_text = now.replace(microsecond=0).isoformat().replace("+00:00", "Z")
    with closing(_connect(db_path)) as conn:
        conn.execute("BEGIN IMMEDIATE")
        row = conn.execute(
            """SELECT * FROM jobs
               WHERE status='unresolved' OR (status='leased' AND lease_expires < ?)
               ORDER BY priority DESC, attempts ASC, obligation_id ASC LIMIT 1""",
            (now_text,),
        ).fetchone()
        if row is None:
            conn.rollback()
            return None
        conn.execute(
            """UPDATE jobs SET status='leased',lease_owner=?,lease_expires=?,
               attempts=attempts+1,updated_at=? WHERE obligation_id=?""",
            (worker, expiry, now_text, row["obligation_id"]),
        )
        _append_event(conn, "job_leased", {"worker": worker, "lease_expires": expiry}, row["obligation_id"])
        conn.commit()
        return dict(conn.execute("SELECT * FROM jobs WHERE obligation_id=?", (row["obligation_id"],)).fetchone())


def record_candidate(
    db_path: str | Path,
    obligation_id: str,
    wdl: WDL | str,
    certificate_path: str | Path,
    *,
    worker: str,
) -> dict[str, Any]:
    value = wdl if isinstance(wdl, WDL) else WDL(wdl)
    if value == WDL.UNKNOWN:
        raise ValueError("candidate WDL must be win, draw, or loss")
    certificate_path = Path(certificate_path).resolve()
    if not certificate_path.is_file():
        raise FileNotFoundError(certificate_path)
    certificate_hash = _file_sha256(certificate_path)
    now = _utc_now()
    with closing(_connect(db_path)) as conn:
        conn.execute("BEGIN IMMEDIATE")
        row = conn.execute("SELECT * FROM jobs WHERE obligation_id=?", (obligation_id,)).fetchone()
        if row is None:
            raise KeyError(obligation_id)
        if row["status"] == "verified":
            raise ValueError("verified job cannot be overwritten")
        if row["lease_owner"] not in (None, worker):
            raise PermissionError("job is leased to a different worker")
        conn.execute(
            """UPDATE jobs SET status='candidate',wdl=?,verification='pending-independent-check',
               certificate_path=?,certificate_sha256=?,checker_path=NULL,checker_sha256=NULL,
               lease_owner=NULL,lease_expires=NULL,updated_at=? WHERE obligation_id=?""",
            (value.value, _path_for_storage(db_path, certificate_path), certificate_hash, now, obligation_id),
        )
        _append_event(
            conn,
            "candidate_recorded",
            {"worker": worker, "wdl": value.value, "certificate_sha256": certificate_hash},
            obligation_id,
        )
        conn.commit()
        return dict(conn.execute("SELECT * FROM jobs WHERE obligation_id=?", (obligation_id,)).fetchone())


def mark_verified(
    db_path: str | Path,
    obligation_id: str,
    *,
    verifier: str,
    checker_record: str | Path,
) -> dict[str, Any]:
    if not verifier.strip():
        raise ValueError("verifier name must be non-empty")
    checker_record = Path(checker_record).resolve()
    if not checker_record.is_file():
        raise FileNotFoundError(checker_record)
    checker_hash = _file_sha256(checker_record)
    try:
        checker_payload = json.loads(checker_record.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"checker record is not valid JSON: {exc}") from exc
    now = _utc_now()
    with closing(_connect(db_path)) as conn:
        conn.execute("BEGIN IMMEDIATE")
        row = conn.execute("SELECT * FROM jobs WHERE obligation_id=?", (obligation_id,)).fetchone()
        if row is None:
            raise KeyError(obligation_id)
        if row["status"] != "candidate" or not row["certificate_sha256"]:
            raise ValueError("only a complete candidate can be marked verified")
        required_checker = {
            "schema": "ugts-chess-independent-check-2.0",
            "valid": True,
            "obligation_id": obligation_id,
            "wdl": row["wdl"],
            "certificate_sha256": row["certificate_sha256"],
            "child_game_state_sha256": row["child_game_state_sha256"],
        }
        for key, expected in required_checker.items():
            if checker_payload.get(key) != expected:
                raise ValueError(f"checker record field {key!r} does not match the candidate")
        conn.execute(
            """UPDATE jobs SET status='verified',verification=?,checker_path=?,checker_sha256=?,
               updated_at=? WHERE obligation_id=?""",
            (f"independent-check:{verifier}", _path_for_storage(db_path, checker_record), checker_hash, now, obligation_id),
        )
        _append_event(
            conn,
            "candidate_verified",
            {"verifier": verifier, "checker_sha256": checker_hash, "wdl": row["wdl"]},
            obligation_id,
        )
        conn.commit()
        return dict(conn.execute("SELECT * FROM jobs WHERE obligation_id=?", (obligation_id,)).fetchone())


def reject_candidate(db_path: str | Path, obligation_id: str, *, verifier: str, reason: str) -> dict[str, Any]:
    now = _utc_now()
    with closing(_connect(db_path)) as conn:
        conn.execute("BEGIN IMMEDIATE")
        row = conn.execute("SELECT * FROM jobs WHERE obligation_id=?", (obligation_id,)).fetchone()
        if row is None:
            raise KeyError(obligation_id)
        if row["status"] not in ("candidate", "leased"):
            raise ValueError("only a candidate or leased job can be rejected")
        conn.execute(
            """UPDATE jobs SET status='rejected',verification=?,lease_owner=NULL,lease_expires=NULL,
               updated_at=? WHERE obligation_id=?""",
            (f"rejected:{verifier}:{reason}", now, obligation_id),
        )
        _append_event(conn, "candidate_rejected", {"verifier": verifier, "reason": reason}, obligation_id)
        conn.commit()
        return dict(conn.execute("SELECT * FROM jobs WHERE obligation_id=?", (obligation_id,)).fetchone())


def campaign_status(db_path: str | Path) -> dict[str, Any]:
    with closing(_connect(db_path)) as conn:
        meta = {row["key"]: json.loads(row["value"]) for row in conn.execute("SELECT key,value FROM meta")}
        rows = list(conn.execute("SELECT obligation_id,status,wdl FROM jobs ORDER BY obligation_id"))
        counts: dict[str, int] = {}
        values: list[WDL] = []
        for row in rows:
            counts[row["status"]] = counts.get(row["status"], 0) + 1
            values.append(WDL(row["wdl"]) if row["status"] == "verified" else WDL.UNKNOWN)
        root_value = aggregate_root_wdl(values)
        last = conn.execute("SELECT sequence,event_hash FROM events ORDER BY sequence DESC LIMIT 1").fetchone()
        return {
            "schema": SCHEMA,
            "root_fen": meta["root_fen"],
            "root_game_state_sha256": meta["root_game_state_sha256"],
            "root_wdl": root_value.value,
            "game_solved": root_value != WDL.UNKNOWN,
            "obligations": len(rows),
            "status_counts": counts,
            "verified_children": sum(1 for row in rows if row["status"] == "verified"),
            "last_event_sequence": 0 if last is None else last["sequence"],
            "last_event_hash": None if last is None else last["event_hash"],
            "evidence_boundary": "UNKNOWN remains UNKNOWN until proof certificates are independently verified.",
        }


def campaign_snapshot(db_path: str | Path) -> dict[str, Any]:
    status = campaign_status(db_path)
    with closing(_connect(db_path)) as conn:
        jobs = []
        for row in conn.execute("SELECT * FROM jobs ORDER BY obligation_id"):
            item = dict(row)
            item["child_history_counts"] = json.loads(item.pop("child_history_json"))
            jobs.append(item)
        events = []
        for row in conn.execute("SELECT * FROM events ORDER BY sequence"):
            item = dict(row)
            item["payload"] = json.loads(item.pop("payload_json"))
            events.append(item)
    return {"schema": SCHEMA, "status": status, "jobs": jobs, "events": events}


def export_campaign(db_path: str | Path, output: str | Path) -> dict[str, Any]:
    output = Path(output)
    payload = campaign_snapshot(db_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return {"path": str(output), "sha256": _file_sha256(output), "jobs": len(payload["jobs"]), "events": len(payload["events"])}


def verify_campaign(db_path: str | Path) -> dict[str, Any]:
    errors: list[str] = []
    db_path = Path(db_path)
    if not db_path.is_file():
        raise FileNotFoundError(db_path)
    expected_root = Position.from_fen(START_FEN)
    expected_history = HistoryContext.initial(expected_root)
    expected_obligations = {item.obligation_id: item for item in root_obligations(expected_root, expected_history)}

    with closing(_connect(db_path)) as conn:
        meta = {row["key"]: json.loads(row["value"]) for row in conn.execute("SELECT key,value FROM meta")}
        if meta.get("schema") != SCHEMA:
            errors.append("meta schema mismatch")
        try:
            root = Position.from_fen(str(meta["root_fen"]))
            root_history = HistoryContext(tuple((str(k), int(v)) for k, v in meta["root_history_counts"]))
            if state_sha256(root) != meta.get("root_position_sha256"):
                errors.append("root position hash mismatch")
            if game_state_sha256(root, root_history) != meta.get("root_game_state_sha256"):
                errors.append("root game-state hash mismatch")
        except Exception as exc:
            errors.append(f"invalid root metadata: {exc}")

        prev_hash = GENESIS_HASH
        event_count = 0
        for row in conn.execute("SELECT * FROM events ORDER BY sequence"):
            event_count += 1
            payload = json.loads(row["payload_json"])
            record = {
                "action": row["action"],
                "job_id": row["job_id"],
                "payload": payload,
                "prev_hash": prev_hash,
                "timestamp": row["timestamp"],
            }
            expected = hashlib.sha256(canonical_json_bytes(record)).hexdigest()
            if row["prev_hash"] != prev_hash:
                errors.append(f"event {row['sequence']} prev_hash mismatch")
            if row["event_hash"] != expected:
                errors.append(f"event {row['sequence']} event_hash mismatch")
            prev_hash = row["event_hash"]

        seen_jobs: set[str] = set()
        job_count = 0
        for row in conn.execute("SELECT * FROM jobs ORDER BY obligation_id"):
            job_count += 1
            obligation_id = row["obligation_id"]
            seen_jobs.add(obligation_id)
            expected = expected_obligations.get(obligation_id)
            if expected is None:
                errors.append(f"unexpected obligation {obligation_id}")
                continue
            checks = {
                "parent_game_state_sha256": expected.parent_game_state_sha256,
                "move_uci": expected.move_uci,
                "move_san": expected.move_san,
                "child_fen": expected.child_fen,
                "child_position_sha256": expected.child_position_sha256,
                "child_game_state_sha256": expected.child_game_state_sha256,
                "child_side_to_move": expected.child_side_to_move,
            }
            for field, wanted in checks.items():
                if row[field] != wanted:
                    errors.append(f"{obligation_id}: {field} mismatch")
            if json.loads(row["child_history_json"]) != [[k, c] for k, c in expected.child_history_counts]:
                errors.append(f"{obligation_id}: child history mismatch")
            shard_path = _path_from_storage(db_path, row["shard_path"])
            if not shard_path.is_file():
                errors.append(f"{obligation_id}: shard file missing")
            elif _file_sha256(shard_path) != row["shard_sha256"]:
                errors.append(f"{obligation_id}: shard hash mismatch")
            if row["certificate_path"]:
                certificate = _path_from_storage(db_path, row["certificate_path"])
                if not certificate.is_file():
                    errors.append(f"{obligation_id}: certificate file missing")
                elif _file_sha256(certificate) != row["certificate_sha256"]:
                    errors.append(f"{obligation_id}: certificate hash mismatch")
            if row["status"] == "verified":
                if not row["checker_path"] or not row["checker_sha256"]:
                    errors.append(f"{obligation_id}: verified job lacks checker record")
                else:
                    checker = _path_from_storage(db_path, row["checker_path"])
                    if not checker.is_file() or _file_sha256(checker) != row["checker_sha256"]:
                        errors.append(f"{obligation_id}: checker record mismatch")
        missing = sorted(set(expected_obligations) - seen_jobs)
        if missing:
            errors.append(f"missing obligations: {missing}")

    status = campaign_status(db_path)
    return {
        "schema": SCHEMA,
        "valid": not errors,
        "job_count": job_count,
        "expected_job_count": len(expected_obligations),
        "event_count": event_count,
        "errors": errors,
        "final_event_hash": prev_hash,
        "root_wdl": status["root_wdl"],
        "game_solved": status["game_solved"],
    }
