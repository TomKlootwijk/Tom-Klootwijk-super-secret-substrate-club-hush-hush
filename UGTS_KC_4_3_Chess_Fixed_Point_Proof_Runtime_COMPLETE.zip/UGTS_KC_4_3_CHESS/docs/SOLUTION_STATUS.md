# Solution status

## Exact

- Legal-move kernel for orthodox chess, including castling, en passant and promotion.
- Published perft reference counts included in the test suite.
- Finite-graph WDL fixed-point solver.
- Three-piece no-castling, zero-clock tablebase for KQK, KRK, KBK, KNK and KPK.
- Deterministic proposal/commit/replay and state hashes.

## Bounded

- Mate/draw proof search is sound inside its depth horizon.
- The common dead-material predicate certifies selected exact cases only.
- FIDE claimable draws are represented in the rule profile and status layer; the generic full game graph must add them as explicit actions.

## Unresolved

- The game-theoretic value of the orthodox initial position.
- A complete all-material strategy certificate.
- Full dead-position decision for arbitrary material.
- Native generation of eight-piece or larger tablebases.

`unknown` and `unresolved` are intentional machine-readable outcomes. They are never rewritten as draw, equality or likely result.
