# Reproduction

```bash
cd UGTS_KC_4_3_CHESS
PYTHONPATH=src python -m unittest discover -s tests -v
PYTHONPATH=src python examples/demo.py
PYTHONPATH=src python -m ugts_chess43 build-tb3 \
  data/tb3_orthodox_zero_clock.bin \
  --summary data/tb3_summary.json
python tools/generate_spec.py
python tools/validate_release.py
```

Tablebase generation is deterministic under the same Python semantics and writes sorted canonical keys. Verify the package SHA-256 manifest after extraction.
