# Architecture

The reference runtime is split into small standard-library modules:

- `position.py`: immutable position and move records, FEN/UCI.
- `rules.py`: attacks, pseudo moves, legal moves, transitions and terminal status.
- `canonical.py`: canonical JSON, state hashes and repetition keys.
- `ugts.py`: proposal verification, atomic commit, lineage and replay.
- `search.py`: bounded proof search and explicit finite-graph fixed point.
- `retrograde3.py`: symmetry-reduced three-piece generation, binary format and probe API.
- `cli.py`: reproducible command-line entry point.

The board display, FEN, UCI and reports are projections. The authoritative object is the typed state plus its verified event/proof lineage.
