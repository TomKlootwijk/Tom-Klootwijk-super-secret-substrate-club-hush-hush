# Scaling toward a full strong solution

1. Freeze the complete rule profile, including claim actions and terminal precedence.
2. Import verified WDL/DTZ endgame oracles through a hash-checked adapter.
3. Partition states by material, pawn structure, castling rights, en-passant state and symmetry orbit.
4. Generate exact predecessor/successor coverage and reject incomplete partitions.
5. Apply retrograde fixed points where the domain is closed.
6. Use forward proof-number or minimax frontier work for open higher-material regions.
7. Merge results as a content-addressed proof DAG with deterministic conflict checks.
8. Promote the initial position only after every quantified move obligation is discharged.

Heuristic engine evaluations may order work but cannot be proof authority.
