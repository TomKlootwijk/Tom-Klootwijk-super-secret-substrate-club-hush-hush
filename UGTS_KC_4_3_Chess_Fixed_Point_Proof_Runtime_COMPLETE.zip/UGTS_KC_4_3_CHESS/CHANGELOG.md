# Changelog

## 4.3.0 - 2026-08-29

- Added orthodox chess state, move, attack and transition operators.
- Added deterministic UGTS proposal, commit, hash and replay records.
- Added sound bounded proof search and generic finite-graph retrograde solver.
- Added exact KQK/KRK/KBK/KNK/KPK tablebase with 367,868 canonical states.
- Added mechanism catalog M886-M949, schemas, rule profiles and validation evidence.
- Preserved the standard initial position as explicitly unresolved under full strong-solution scope.
