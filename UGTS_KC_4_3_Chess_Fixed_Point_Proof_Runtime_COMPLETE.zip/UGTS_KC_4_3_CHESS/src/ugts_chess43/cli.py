"""Command-line interface for the UGTS chess kernel."""
from __future__ import annotations

import argparse
from dataclasses import asdict
import json
from pathlib import Path
from typing import Sequence

from . import __version__
from .position import Position, START_FEN
from .retrograde3 import ThreePieceTablebase, generate_tablebase
from .rules import apply_uci, legal_moves, perft, terminal_status
from .search import BoundedMateSolver
from .ugts import ChessRuntime


def _position(text: str | None) -> Position:
    return Position.from_fen(text or START_FEN)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="ugts-chess", description="UGTS-KC 4.3 chess proof runtime")
    parser.add_argument("--version", action="version", version=__version__)
    sub = parser.add_subparsers(dest="command", required=True)

    moves = sub.add_parser("moves", help="list legal UCI moves")
    moves.add_argument("--fen")

    pft = sub.add_parser("perft", help="run exact legal move-path count")
    pft.add_argument("depth", type=int)
    pft.add_argument("--fen")

    play = sub.add_parser("play", help="commit a UCI move sequence through UGTS events")
    play.add_argument("moves", nargs="+")
    play.add_argument("--fen")

    solve = sub.add_parser("solve", help="bounded sound mate/draw proof search")
    solve.add_argument("--fen")
    solve.add_argument("--depth", type=int, default=6)

    build = sub.add_parser("build-tb3", help="generate exact three-piece tablebase")
    build.add_argument("output")
    build.add_argument("--summary")

    probe = sub.add_parser("probe-tb3", help="probe exact three-piece tablebase")
    probe.add_argument("tablebase")
    probe.add_argument("--fen", required=True)

    status = sub.add_parser("status", help="show terminal/draw status")
    status.add_argument("--fen")
    status.add_argument("--repetitions", type=int, default=1)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "moves":
        print(json.dumps([m.uci() for m in legal_moves(_position(args.fen))], indent=2))
    elif args.command == "perft":
        position = _position(args.fen)
        print(json.dumps({"fen": position.to_fen(), "depth": args.depth, "nodes": perft(position, args.depth)}, indent=2))
    elif args.command == "play":
        runtime = ChessRuntime(_position(args.fen))
        for uci in args.moves:
            runtime.play(uci)
        print(json.dumps(runtime.snapshot(), indent=2, sort_keys=True))
    elif args.command == "solve":
        result = BoundedMateSolver(args.depth).solve(_position(args.fen))
        print(json.dumps(asdict(result), indent=2, sort_keys=True))
    elif args.command == "build-tb3":
        result = generate_tablebase(args.output, args.summary)
        print(json.dumps(result.summary, indent=2, sort_keys=True))
    elif args.command == "probe-tb3":
        tablebase = ThreePieceTablebase(args.tablebase)
        position = _position(args.fen)
        result = tablebase.probe(position)
        payload = asdict(result)
        payload["best_moves"] = tablebase.best_moves(position)
        print(json.dumps(payload, indent=2, sort_keys=True))
    elif args.command == "status":
        print(json.dumps(asdict(terminal_status(_position(args.fen), repetition_count=args.repetitions)), indent=2))
    else:  # pragma: no cover
        raise AssertionError(args.command)
    return 0
