"""UGTS-KC 4.3 Chess Fixed-Point and Proof Runtime."""

from .position import BLACK, WHITE, Move, Position, START_FEN
from .rules import apply_move, apply_uci, in_check, legal_moves, perft, terminal_status
from .search import BoundedMateSolver, DRAW, LOSS, UNKNOWN, WIN
from .ugts import ChessRuntime, MoveProposal, RuntimeEvent

__all__ = [
    "BLACK",
    "WHITE",
    "Move",
    "Position",
    "START_FEN",
    "apply_move",
    "apply_uci",
    "in_check",
    "legal_moves",
    "perft",
    "terminal_status",
    "BoundedMateSolver",
    "WIN",
    "LOSS",
    "DRAW",
    "UNKNOWN",
    "ChessRuntime",
    "MoveProposal",
    "RuntimeEvent",
]

__version__ = "4.3.0"
