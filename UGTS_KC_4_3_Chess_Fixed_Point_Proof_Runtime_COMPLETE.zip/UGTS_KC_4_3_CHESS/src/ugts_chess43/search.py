"""Exact bounded proof search and finite-graph fixed-point solving."""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import Any, Callable, Hashable, Iterable, Mapping, Sequence

from .canonical import position_hash, repetition_key, sha256_digest
from .position import Position
from .rules import apply_move, in_check, legal_moves, terminal_status

WIN = "win"
LOSS = "loss"
DRAW = "draw"
UNKNOWN = "unknown"


@dataclass(frozen=True, slots=True)
class ProofResult:
    outcome: str
    distance_plies: int | None
    best_moves: tuple[str, ...]
    nodes: int
    depth_limit: int
    root_hash: str
    certificate_hash: str
    reason: str


class BoundedMateSolver:
    """Sound mate/draw proof search with an explicit depth budget.

    ``unknown`` is a first-class result: a horizon miss is never relabeled as a
    draw or a heuristic evaluation.
    """

    def __init__(self, depth_limit: int = 6) -> None:
        if depth_limit < 0:
            raise ValueError("depth_limit must be non-negative")
        self.depth_limit = depth_limit
        self._memo: dict[tuple[Position, int], tuple[str, int | None, tuple[str, ...]]] = {}
        self.nodes = 0

    def solve(self, position: Position) -> ProofResult:
        self._memo.clear()
        self.nodes = 0
        outcome, distance, moves = self._solve(position, self.depth_limit)
        record = {
            "schema": "ugts-kc-chess-bounded-proof-4.3",
            "root_fen": position.to_fen(),
            "root_hash": position_hash(position),
            "depth_limit": self.depth_limit,
            "outcome": outcome,
            "distance_plies": distance,
            "best_moves": list(moves),
            "nodes": self.nodes,
            "semantics": "exact within horizon; unknown is not draw",
        }
        return ProofResult(
            outcome,
            distance,
            moves,
            self.nodes,
            self.depth_limit,
            record["root_hash"],
            sha256_digest(record),
            "terminal/fixed-horizon minimax",
        )

    def _solve(self, position: Position, depth: int) -> tuple[str, int | None, tuple[str, ...]]:
        self.nodes += 1
        key = (position, depth)
        if key in self._memo:
            return self._memo[key]
        status = terminal_status(position)
        if status.terminal:
            if status.kind == "checkmate":
                result = (LOSS, 0, ())
            else:
                result = (DRAW, 0, ())
            self._memo[key] = result
            return result
        if depth == 0:
            result = (UNKNOWN, None, ())
            self._memo[key] = result
            return result

        children: list[tuple[str, int | None, str]] = []
        for move in legal_moves(position):
            child_outcome, child_distance, _ = self._solve(apply_move(position, move), depth - 1)
            children.append((child_outcome, child_distance, move.uci()))

        losing_children = [(d, uci) for outcome, d, uci in children if outcome == LOSS]
        if losing_children:
            best_distance = min((d or 0) + 1 for d, _ in losing_children)
            best = tuple(sorted(uci for d, uci in losing_children if (d or 0) + 1 == best_distance))
            result = (WIN, best_distance, best)
        elif children and all(outcome == WIN for outcome, _, _ in children):
            distance = max((d or 0) + 1 for _, d, _ in children)
            best = tuple(sorted(uci for _, d, uci in children if (d or 0) + 1 == distance))
            result = (LOSS, distance, best)
        elif children and all(outcome in (WIN, DRAW) for outcome, _, _ in children) and any(
            outcome == DRAW for outcome, _, _ in children
        ):
            best = tuple(sorted(uci for outcome, _, uci in children if outcome == DRAW))
            result = (DRAW, None, best)
        else:
            result = (UNKNOWN, None, ())
        self._memo[key] = result
        return result


@dataclass(frozen=True, slots=True)
class FixedPointResult:
    values: tuple[str, ...]
    distances: tuple[int, ...]
    wins: int
    losses: int
    draws: int
    certificate_hash: str


def solve_finite_graph(
    successors: Sequence[Sequence[int | None]],
    *,
    terminal_losses: Iterable[int] = (),
    terminal_draws: Iterable[int] = (),
) -> FixedPointResult:
    """Solve a finite alternating game graph by retrograde fixed point.

    Values are relative to the player to move at each node. ``None`` successors
    are explicit draw sinks. All unclassified nodes after the least fixed point
    are draws.
    """
    n = len(successors)
    values = [UNKNOWN] * n
    distances = [0] * n
    remaining = [len(s) for s in successors]
    max_win_child = [0] * n
    predecessors: list[list[int]] = [[] for _ in range(n)]
    for source, targets in enumerate(successors):
        for target in targets:
            if target is not None:
                if not 0 <= target < n:
                    raise ValueError("successor index out of range")
                predecessors[target].append(source)
    queue: deque[int] = deque()
    for node in terminal_draws:
        values[node] = DRAW
    for node in terminal_losses:
        values[node] = LOSS
        queue.append(node)
    while queue:
        node = queue.popleft()
        for pred in predecessors[node]:
            if values[pred] != UNKNOWN:
                continue
            if values[node] == LOSS:
                values[pred] = WIN
                distances[pred] = distances[node] + 1
                queue.append(pred)
            elif values[node] == WIN:
                remaining[pred] -= 1
                max_win_child[pred] = max(max_win_child[pred], distances[node])
                if remaining[pred] == 0:
                    values[pred] = LOSS
                    distances[pred] = max_win_child[pred] + 1
                    queue.append(pred)
    for i, value in enumerate(values):
        if value == UNKNOWN:
            values[i] = DRAW
    record = {
        "node_count": n,
        "edge_count": sum(len(s) for s in successors),
        "wins": values.count(WIN),
        "losses": values.count(LOSS),
        "draws": values.count(DRAW),
        "algorithm": "least fixed point W/L; complement draw",
    }
    return FixedPointResult(
        tuple(values),
        tuple(distances),
        record["wins"],
        record["losses"],
        record["draws"],
        sha256_digest(record),
    )
