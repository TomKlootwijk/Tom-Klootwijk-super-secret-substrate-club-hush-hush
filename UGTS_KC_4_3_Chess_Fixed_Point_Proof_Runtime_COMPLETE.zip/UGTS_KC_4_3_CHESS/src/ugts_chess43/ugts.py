"""UGTS proposal, verification, commit, replay and lineage records for chess."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable

from .canonical import move_record, position_hash, repetition_key, sha256_digest
from .position import Move, Position
from .rules import apply_move, legal_move_map, terminal_status


@dataclass(frozen=True, slots=True)
class MoveProposal:
    proposal_id: str
    ply: int
    uci: str
    source: str
    priority: int
    pre_hash: str
    support_ok: bool
    compatibility_ok: bool
    guard_status: str
    numeric_error: int = 0
    event_margin: int = 0
    confidence: int = 1
    confidence_floor: int = 1
    reason_codes: tuple[str, ...] = ()

    @property
    def verified(self) -> bool:
        return (
            self.support_ok
            and self.compatibility_ok
            and self.guard_status == "legal"
            and self.confidence >= self.confidence_floor
            and self.numeric_error <= self.event_margin
        )


@dataclass(frozen=True, slots=True)
class RuntimeEvent:
    sequence: int
    proposal_id: str
    uci: str
    source: str
    pre_hash: str
    post_hash: str
    repetition_key: str
    halfmove_clock: int
    fullmove_number: int
    terminal_kind: str
    winner: str | None
    event_hash: str


@dataclass(slots=True)
class ChessRuntime:
    position: Position
    events: list[RuntimeEvent] = field(default_factory=list)
    repetition: dict[str, int] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.repetition:
            key = repetition_key(self.position)
            self.repetition[key] = 1

    @property
    def sequence(self) -> int:
        return len(self.events)

    def propose(self, uci: str, *, source: str = "cli", priority: int = 0) -> MoveProposal:
        legal = legal_move_map(self.position)
        requested = uci.lower()
        move = legal.get(requested)
        reason_codes: list[str] = []
        if move is None:
            reason_codes.append("not_in_legal_move_set")
        proposal_id = sha256_digest(
            {
                "sequence": self.sequence,
                "pre_hash": position_hash(self.position),
                "uci": requested,
                "source": source,
                "priority": priority,
            }
        )
        return MoveProposal(
            proposal_id=proposal_id,
            ply=self.sequence,
            uci=requested,
            source=source,
            priority=priority,
            pre_hash=position_hash(self.position),
            support_ok=move is not None,
            compatibility_ok=move is not None,
            guard_status="legal" if move is not None else "rejected",
            reason_codes=tuple(reason_codes),
        )

    def commit(self, proposal: MoveProposal) -> RuntimeEvent:
        current_hash = position_hash(self.position)
        if proposal.pre_hash != current_hash:
            raise ValueError("proposal pre-hash does not match authoritative state")
        if not proposal.verified:
            raise ValueError(f"proposal is not verified: {proposal.reason_codes}")
        move = legal_move_map(self.position).get(proposal.uci)
        if move is None:
            raise ValueError("move became illegal before commit")
        new_position = apply_move(self.position, move)
        key = repetition_key(new_position)
        repetition_count = self.repetition.get(key, 0) + 1
        status = terminal_status(new_position, repetition_count=repetition_count)
        post_hash = position_hash(new_position)
        payload = {
            "sequence": self.sequence + 1,
            "proposal_id": proposal.proposal_id,
            "move": move_record(move),
            "pre_hash": current_hash,
            "post_hash": post_hash,
            "repetition_key": key,
            "terminal_kind": status.kind,
            "winner": status.winner,
        }
        event = RuntimeEvent(
            sequence=self.sequence + 1,
            proposal_id=proposal.proposal_id,
            uci=move.uci(),
            source=proposal.source,
            pre_hash=current_hash,
            post_hash=post_hash,
            repetition_key=key,
            halfmove_clock=new_position.halfmove_clock,
            fullmove_number=new_position.fullmove_number,
            terminal_kind=status.kind,
            winner=status.winner,
            event_hash=sha256_digest(payload),
        )
        self.position = new_position
        self.repetition[key] = repetition_count
        self.events.append(event)
        return event

    def play(self, uci: str, *, source: str = "cli") -> RuntimeEvent:
        return self.commit(self.propose(uci, source=source))

    def snapshot(self) -> dict[str, Any]:
        return {
            "schema": "ugts-kc-chess-runtime-4.3",
            "fen": self.position.to_fen(),
            "state_hash": position_hash(self.position),
            "sequence": self.sequence,
            "repetition": dict(sorted(self.repetition.items())),
            "events": [event.__dict__ if hasattr(event, "__dict__") else {
                name: getattr(event, name) for name in event.__dataclass_fields__
            } for event in self.events],
        }

    @classmethod
    def replay(cls, initial: Position, events: Iterable[RuntimeEvent]) -> "ChessRuntime":
        runtime = cls(initial)
        for expected in events:
            if position_hash(runtime.position) != expected.pre_hash:
                raise ValueError(f"replay divergence before event {expected.sequence}")
            actual = runtime.play(expected.uci, source=expected.source)
            if actual.post_hash != expected.post_hash or actual.event_hash != expected.event_hash:
                raise ValueError(f"replay divergence at event {expected.sequence}")
        return runtime
