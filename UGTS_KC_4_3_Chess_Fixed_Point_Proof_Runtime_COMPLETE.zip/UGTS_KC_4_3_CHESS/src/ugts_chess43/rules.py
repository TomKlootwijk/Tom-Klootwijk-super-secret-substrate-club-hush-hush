"""Orthodox legal-move, attack, transition and terminal operators."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Iterator, Mapping, Sequence

from .position import (
    BLACK,
    EMPTY,
    WHITE,
    Move,
    Position,
    color_of,
    opposite,
    parse_square,
)

KNIGHT_DELTAS = ((1, 2), (2, 1), (2, -1), (1, -2), (-1, -2), (-2, -1), (-2, 1), (-1, 2))
KING_DELTAS = tuple((df, dr) for df in (-1, 0, 1) for dr in (-1, 0, 1) if df or dr)
BISHOP_DIRS = ((1, 1), (1, -1), (-1, 1), (-1, -1))
ROOK_DIRS = ((1, 0), (-1, 0), (0, 1), (0, -1))
QUEEN_DIRS = BISHOP_DIRS + ROOK_DIRS


@dataclass(frozen=True, slots=True)
class TerminalStatus:
    terminal: bool
    kind: str
    winner: str | None
    claimable: tuple[str, ...] = ()
    automatic: tuple[str, ...] = ()


def _inside(file_: int, rank: int) -> bool:
    return 0 <= file_ < 8 and 0 <= rank < 8


def attacked(position: Position, square: int, by_color: str) -> bool:
    """Return whether ``square`` is attacked by ``by_color``.

    This is the attack relation, not legal-move generation: pinned pieces still
    attack squares for king-move and castling purposes.
    """
    board = position.board
    file_ = square & 7
    rank = square >> 3

    # Pawns: reverse from the target to possible attacker origins.
    pawn = "P" if by_color == WHITE else "p"
    origin_rank = rank - 1 if by_color == WHITE else rank + 1
    if 0 <= origin_rank < 8:
        for origin_file in (file_ - 1, file_ + 1):
            if 0 <= origin_file < 8 and board[origin_rank * 8 + origin_file] == pawn:
                return True

    knight = "N" if by_color == WHITE else "n"
    for df, dr in KNIGHT_DELTAS:
        of, orank = file_ - df, rank - dr
        if _inside(of, orank) and board[orank * 8 + of] == knight:
            return True

    king = "K" if by_color == WHITE else "k"
    for df, dr in KING_DELTAS:
        of, orank = file_ + df, rank + dr
        if _inside(of, orank) and board[orank * 8 + of] == king:
            return True

    bishop = "B" if by_color == WHITE else "b"
    rook = "R" if by_color == WHITE else "r"
    queen = "Q" if by_color == WHITE else "q"
    for df, dr in BISHOP_DIRS:
        f, r = file_ + df, rank + dr
        while _inside(f, r):
            piece = board[r * 8 + f]
            if piece != EMPTY:
                if piece in (bishop, queen):
                    return True
                break
            f += df
            r += dr
    for df, dr in ROOK_DIRS:
        f, r = file_ + df, rank + dr
        while _inside(f, r):
            piece = board[r * 8 + f]
            if piece != EMPTY:
                if piece in (rook, queen):
                    return True
                break
            f += df
            r += dr
    return False


def in_check(position: Position, color: str | None = None) -> bool:
    color = position.turn if color is None else color
    return attacked(position, position.king_square(color), opposite(color))


def _pawn_moves(position: Position, square: int, piece: str) -> Iterator[Move]:
    board = position.board
    color = color_of(piece)
    assert color is not None
    direction = 8 if color == WHITE else -8
    start_rank = 1 if color == WHITE else 6
    promotion_rank = 7 if color == WHITE else 0
    rank = square >> 3
    file_ = square & 7

    one = square + direction
    if 0 <= one < 64 and board[one] == EMPTY:
        if (one >> 3) == promotion_rank:
            for promotion in "qrbn":
                yield Move(square, one, promotion)
        else:
            yield Move(square, one)
            two = square + 2 * direction
            if rank == start_rank and board[two] == EMPTY:
                yield Move(square, two)

    capture_offsets = (7, 9) if color == WHITE else (-9, -7)
    for offset in capture_offsets:
        target = square + offset
        if not 0 <= target < 64 or abs((target & 7) - file_) != 1:
            continue
        target_piece = board[target]
        if target_piece != EMPTY and color_of(target_piece) == opposite(color) and target_piece.lower() != "k":
            if (target >> 3) == promotion_rank:
                for promotion in "qrbn":
                    yield Move(square, target, promotion)
            else:
                yield Move(square, target)
        elif position.ep_square == target:
            captured_square = target - direction
            expected = "p" if color == WHITE else "P"
            if board[captured_square] == expected:
                yield Move(square, target, en_passant=True)


def _jump_moves(position: Position, square: int, piece: str, deltas: Sequence[tuple[int, int]]) -> Iterator[Move]:
    file_ = square & 7
    rank = square >> 3
    color = color_of(piece)
    for df, dr in deltas:
        f, r = file_ + df, rank + dr
        if not _inside(f, r):
            continue
        target = r * 8 + f
        occupant = position.board[target]
        if occupant == EMPTY or (color_of(occupant) != color and occupant.lower() != "k"):
            yield Move(square, target)


def _slider_moves(position: Position, square: int, piece: str, directions: Sequence[tuple[int, int]]) -> Iterator[Move]:
    file_ = square & 7
    rank = square >> 3
    color = color_of(piece)
    for df, dr in directions:
        f, r = file_ + df, rank + dr
        while _inside(f, r):
            target = r * 8 + f
            occupant = position.board[target]
            if occupant == EMPTY:
                yield Move(square, target)
            else:
                if color_of(occupant) != color and occupant.lower() != "k":
                    yield Move(square, target)
                break
            f += df
            r += dr


def _castling_moves(position: Position, square: int, piece: str) -> Iterator[Move]:
    color = color_of(piece)
    assert color is not None
    enemy = opposite(color)
    board = position.board
    if color == WHITE:
        if square != parse_square("e1") or piece != "K":
            return
        if "K" in position.castling:
            if board[parse_square("h1")] == "R" and all(board[parse_square(s)] == EMPTY for s in ("f1", "g1")):
                if not any(attacked(position, parse_square(s), enemy) for s in ("e1", "f1", "g1")):
                    yield Move(square, parse_square("g1"), castling=True)
        if "Q" in position.castling:
            if board[parse_square("a1")] == "R" and all(board[parse_square(s)] == EMPTY for s in ("b1", "c1", "d1")):
                if not any(attacked(position, parse_square(s), enemy) for s in ("e1", "d1", "c1")):
                    yield Move(square, parse_square("c1"), castling=True)
    else:
        if square != parse_square("e8") or piece != "k":
            return
        if "k" in position.castling:
            if board[parse_square("h8")] == "r" and all(board[parse_square(s)] == EMPTY for s in ("f8", "g8")):
                if not any(attacked(position, parse_square(s), enemy) for s in ("e8", "f8", "g8")):
                    yield Move(square, parse_square("g8"), castling=True)
        if "q" in position.castling:
            if board[parse_square("a8")] == "r" and all(board[parse_square(s)] == EMPTY for s in ("b8", "c8", "d8")):
                if not any(attacked(position, parse_square(s), enemy) for s in ("e8", "d8", "c8")):
                    yield Move(square, parse_square("c8"), castling=True)


def pseudo_legal_moves(position: Position) -> Iterator[Move]:
    """Generate geometry/occupancy-valid moves before the king-safety guard."""
    for square, piece in position.pieces(position.turn):
        kind = piece.lower()
        if kind == "p":
            yield from _pawn_moves(position, square, piece)
        elif kind == "n":
            yield from _jump_moves(position, square, piece, KNIGHT_DELTAS)
        elif kind == "b":
            yield from _slider_moves(position, square, piece, BISHOP_DIRS)
        elif kind == "r":
            yield from _slider_moves(position, square, piece, ROOK_DIRS)
        elif kind == "q":
            yield from _slider_moves(position, square, piece, QUEEN_DIRS)
        elif kind == "k":
            yield from _jump_moves(position, square, piece, KING_DELTAS)
            yield from _castling_moves(position, square, piece)
        else:  # pragma: no cover - Position validation prevents this.
            raise ValueError(f"unsupported piece: {piece}")


def _remove_castling(rights: str, *letters: str) -> str:
    remove = set(letters)
    return "".join(c for c in "KQkq" if c in rights and c not in remove)


def apply_move(position: Position, move: Move, *, validate_origin: bool = True) -> Position:
    """Apply a pseudo-legal move as an immutable candidate state transition."""
    board = list(position.board)
    piece = board[move.from_sq]
    if validate_origin:
        if piece == EMPTY or color_of(piece) != position.turn:
            raise ValueError("move origin does not contain a side-to-move piece")
    target_piece = board[move.to_sq]
    color = color_of(piece)
    if color is None:
        raise ValueError("empty origin")

    is_pawn = piece.lower() == "p"
    is_capture = target_piece != EMPTY
    direction = 8 if color == WHITE else -8

    board[move.from_sq] = EMPTY
    if move.en_passant:
        if not is_pawn or position.ep_square != move.to_sq or target_piece != EMPTY:
            raise ValueError("invalid en-passant flag")
        captured_square = move.to_sq - direction
        expected = "p" if color == WHITE else "P"
        if board[captured_square] != expected:
            raise ValueError("missing en-passant pawn")
        board[captured_square] = EMPTY
        is_capture = True

    placed_piece = piece
    target_rank = move.to_sq >> 3
    if is_pawn and target_rank in (0, 7):
        if move.promotion is None:
            raise ValueError("promotion piece required")
        placed_piece = move.promotion.upper() if color == WHITE else move.promotion.lower()
    elif move.promotion is not None:
        raise ValueError("promotion only allowed on last rank")
    board[move.to_sq] = placed_piece

    # Castling rook movement is determined from king displacement; flag must agree if set.
    actual_castling = piece.lower() == "k" and abs(move.to_sq - move.from_sq) == 2
    if move.castling and not actual_castling:
        raise ValueError("invalid castling flag")
    if actual_castling:
        if move.to_sq > move.from_sq:
            rook_from, rook_to = move.from_sq + 3, move.from_sq + 1
        else:
            rook_from, rook_to = move.from_sq - 4, move.from_sq - 1
        expected_rook = "R" if color == WHITE else "r"
        if board[rook_from] != expected_rook:
            raise ValueError("castling rook missing")
        board[rook_from] = EMPTY
        board[rook_to] = expected_rook

    rights = position.castling
    if piece == "K":
        rights = _remove_castling(rights, "K", "Q")
    elif piece == "k":
        rights = _remove_castling(rights, "k", "q")
    elif move.from_sq == parse_square("h1") and piece == "R":
        rights = _remove_castling(rights, "K")
    elif move.from_sq == parse_square("a1") and piece == "R":
        rights = _remove_castling(rights, "Q")
    elif move.from_sq == parse_square("h8") and piece == "r":
        rights = _remove_castling(rights, "k")
    elif move.from_sq == parse_square("a8") and piece == "r":
        rights = _remove_castling(rights, "q")

    # Capturing a rook on its original square revokes that side's right.
    if target_piece == "R" and move.to_sq == parse_square("h1"):
        rights = _remove_castling(rights, "K")
    elif target_piece == "R" and move.to_sq == parse_square("a1"):
        rights = _remove_castling(rights, "Q")
    elif target_piece == "r" and move.to_sq == parse_square("h8"):
        rights = _remove_castling(rights, "k")
    elif target_piece == "r" and move.to_sq == parse_square("a8"):
        rights = _remove_castling(rights, "q")

    ep_square: int | None = None
    if is_pawn and abs(move.to_sq - move.from_sq) == 16:
        ep_square = move.from_sq + direction

    halfmove = 0 if is_pawn or is_capture else position.halfmove_clock + 1
    fullmove = position.fullmove_number + (1 if position.turn == BLACK else 0)
    return Position(tuple(board), opposite(position.turn), rights, ep_square, halfmove, fullmove)


def legal_moves(position: Position) -> Iterator[Move]:
    mover = position.turn
    for move in pseudo_legal_moves(position):
        try:
            candidate = apply_move(position, move)
        except ValueError:
            continue
        if not in_check(candidate, mover):
            yield move


def legal_move_map(position: Position) -> dict[str, Move]:
    return {move.uci(): move for move in legal_moves(position)}


def apply_uci(position: Position, uci: str) -> Position:
    try:
        move = legal_move_map(position)[uci.lower()]
    except KeyError as exc:
        raise ValueError(f"illegal move {uci!r} in {position.to_fen()}") from exc
    return apply_move(position, move)


def perft(position: Position, depth: int) -> int:
    if depth < 0:
        raise ValueError("depth must be non-negative")
    if depth == 0:
        return 1
    if depth == 1:
        return sum(1 for _ in legal_moves(position))
    return sum(perft(apply_move(position, move), depth - 1) for move in legal_moves(position))


def perft_divide(position: Position, depth: int) -> dict[str, int]:
    if depth < 1:
        raise ValueError("divide depth must be at least one")
    return {move.uci(): perft(apply_move(position, move), depth - 1) for move in legal_moves(position)}


def common_dead_material(position: Position) -> bool:
    """Exact common dead-material cases, intentionally not a universal detector.

    The result is exact when True. False means "not established by this fast
    predicate", not necessarily that checkmate is possible.
    """
    non_kings = [(sq, p) for sq, p in position.pieces() if p.lower() != "k"]
    if not non_kings:
        return True
    if len(non_kings) == 1 and non_kings[0][1].lower() in ("b", "n"):
        return True
    if all(p.lower() == "b" for _, p in non_kings):
        colors = {(((sq & 7) + (sq >> 3)) & 1) for sq, _ in non_kings}
        # All bishops on one square color: no mating material for either side.
        if len(colors) == 1:
            return True
    return False


def terminal_status(
    position: Position,
    *,
    repetition_count: int = 1,
    include_common_dead_material: bool = True,
) -> TerminalStatus:
    moves = list(legal_moves(position))
    if not moves:
        if in_check(position):
            return TerminalStatus(True, "checkmate", opposite(position.turn))
        return TerminalStatus(True, "stalemate", None)

    # Checkmate takes precedence over automatic 75-move/fivefold conditions,
    # handled above by testing legal moves first.
    automatic: list[str] = []
    claimable: list[str] = []
    if include_common_dead_material and common_dead_material(position):
        automatic.append("dead_position_common_exact")
    if repetition_count >= 5:
        automatic.append("fivefold_repetition")
    elif repetition_count >= 3:
        claimable.append("threefold_repetition")
    if position.halfmove_clock >= 150:
        automatic.append("seventy_five_move")
    elif position.halfmove_clock >= 100:
        claimable.append("fifty_move")
    if automatic:
        return TerminalStatus(True, automatic[0], None, tuple(claimable), tuple(automatic))
    return TerminalStatus(False, "ongoing", None, tuple(claimable), ())
