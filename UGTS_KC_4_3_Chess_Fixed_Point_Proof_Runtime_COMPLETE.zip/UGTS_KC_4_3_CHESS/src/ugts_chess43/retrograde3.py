"""Exact no-castling three-piece retrograde solver and compact tablebase.

The solved profile contains KQK, KRK, KBK, KNK and KPK, with the extra
piece normalized to White. Color-swapped positions are isomorphic. The
halfmove clock is assumed zero and castling rights absent, matching the
usual material-tablebase boundary. All forced wins in this domain are far
inside the 50-move horizon from a zeroed clock.
"""
from __future__ import annotations

from array import array
from dataclasses import dataclass
import bisect
import heapq
import json
from pathlib import Path
import struct
import sys
import time
from typing import Any, Iterator, Mapping, Sequence

from .canonical import sha256_digest
from .position import BLACK, EMPTY, WHITE, Position, color_of, opposite, square_name
from .rules import apply_move, legal_moves

TYPES = "QRBNP"
UNKNOWN = 0
WIN = 1
LOSS = 2
DRAW = 3
MAGIC = b"UGTSTB3\0"
FORMAT_VERSION = 1

# Board transforms. Non-pawns use D4; white pawns only use file reflection.
_D4 = [[0] * 64 for _ in range(8)]
for square in range(64):
    file_, rank = square & 7, square >> 3
    coords = (
        (file_, rank),
        (7 - rank, file_),
        (7 - file_, 7 - rank),
        (rank, 7 - file_),
        (7 - file_, rank),
        (file_, 7 - rank),
        (rank, file_),
        (7 - rank, 7 - file_),
    )
    for i, (f, r) in enumerate(coords):
        _D4[i][square] = r * 8 + f
_MIRROR_FILE = [(s >> 3) * 8 + 7 - (s & 7) for s in range(64)]

_KING_MOVES: list[tuple[int, ...]] = []
_KNIGHT_MOVES: list[tuple[int, ...]] = []
for square in range(64):
    file_, rank = square & 7, square >> 3
    kings: list[int] = []
    knights: list[int] = []
    for df in (-1, 0, 1):
        for dr in (-1, 0, 1):
            if not (df or dr):
                continue
            f, r = file_ + df, rank + dr
            if 0 <= f < 8 and 0 <= r < 8:
                kings.append(r * 8 + f)
    for df, dr in ((1, 2), (2, 1), (2, -1), (1, -2), (-1, -2), (-2, -1), (-2, 1), (-1, 2)):
        f, r = file_ + df, rank + dr
        if 0 <= f < 8 and 0 <= r < 8:
            knights.append(r * 8 + f)
    _KING_MOVES.append(tuple(kings))
    _KNIGHT_MOVES.append(tuple(knights))

_DIRS: dict[str, tuple[tuple[int, int], ...]] = {
    "B": ((1, 1), (1, -1), (-1, 1), (-1, -1)),
    "R": ((1, 0), (-1, 0), (0, 1), (0, -1)),
    "Q": ((1, 1), (1, -1), (-1, 1), (-1, -1), (1, 0), (-1, 0), (0, 1), (0, -1)),
}

State3 = tuple[int, int, int, int]  # white king, black king, extra piece, turn(0=w,1=b)


def _king_adjacent(a: int, b: int) -> bool:
    return b in _KING_MOVES[a]


def canonical_state(state: State3, piece_type: str) -> State3:
    wk, bk, extra, turn = state
    if piece_type == "P":
        return min(state, (_MIRROR_FILE[wk], _MIRROR_FILE[bk], _MIRROR_FILE[extra], turn))
    return min((_D4[i][wk], _D4[i][bk], _D4[i][extra], turn) for i in range(8))


def pack_state(state: State3) -> int:
    wk, bk, extra, turn = state
    return wk | (bk << 6) | (extra << 12) | (turn << 18)


def unpack_state(word: int) -> State3:
    return word & 63, (word >> 6) & 63, (word >> 12) & 63, (word >> 18) & 1


def _piece_attacks(piece_type: str, extra: int, target: int, wk: int, bk: int) -> bool:
    ef, er = extra & 7, extra >> 3
    tf, tr = target & 7, target >> 3
    dx, dy = tf - ef, tr - er
    if piece_type == "N":
        return target in _KNIGHT_MOVES[extra]
    if piece_type == "P":
        return dy == 1 and abs(dx) == 1
    for sx, sy in _DIRS.get(piece_type, ()):
        if sx == 0:
            if dx != 0 or dy * sy <= 0:
                continue
            length = abs(dy)
        elif sy == 0:
            if dy != 0 or dx * sx <= 0:
                continue
            length = abs(dx)
        else:
            if abs(dx) != abs(dy) or dx * sx <= 0 or dy * sy <= 0:
                continue
            length = abs(dx)
        for step in range(1, length):
            square = (er + sy * step) * 8 + ef + sx * step
            if square in (wk, bk):
                break
        else:
            return True
    return False


def legal_state(state: State3, piece_type: str) -> bool:
    wk, bk, extra, turn = state
    if len({wk, bk, extra}) < 3 or _king_adjacent(wk, bk):
        return False
    if piece_type == "P" and extra >> 3 in (0, 7):
        return False
    # At White's turn Black just moved; Black may not already be in check.
    if turn == 0 and _piece_attacks(piece_type, extra, bk, wk, bk):
        return False
    return True


def in_check_state(state: State3, piece_type: str) -> bool:
    wk, bk, extra, turn = state
    if turn == 1:
        return _piece_attacks(piece_type, extra, bk, wk, bk)
    return False


def successors_state(
    state: State3,
    piece_type: str,
    *,
    labels: bool = False,
) -> list[tuple[str, str | None, State3 | None]] | list[tuple[str | None, State3 | None]]:
    wk, bk, extra, turn = state
    result: list[Any] = []

    def add(label: str, target_type: str, target: State3) -> None:
        canonical = canonical_state(target, target_type)
        if labels:
            result.append((label, target_type, canonical))
        else:
            result.append((target_type, canonical))

    if turn == 0:
        for destination in _KING_MOVES[wk]:
            if destination in (bk, extra) or _king_adjacent(destination, bk):
                continue
            add(f"K{square_name(wk)}{square_name(destination)}", piece_type, (destination, bk, extra, 1))
        if piece_type == "N":
            for destination in _KNIGHT_MOVES[extra]:
                if destination in (wk, bk):
                    continue
                add(f"N{square_name(extra)}{square_name(destination)}", piece_type, (wk, bk, destination, 1))
        elif piece_type in _DIRS:
            ef, er = extra & 7, extra >> 3
            for df, dr in _DIRS[piece_type]:
                f, r = ef + df, er + dr
                while 0 <= f < 8 and 0 <= r < 8:
                    destination = r * 8 + f
                    if destination in (wk, bk):
                        break
                    add(
                        f"{piece_type}{square_name(extra)}{square_name(destination)}",
                        piece_type,
                        (wk, bk, destination, 1),
                    )
                    f += df
                    r += dr
        elif piece_type == "P":
            rank = extra >> 3
            one = extra + 8
            if one not in (wk, bk):
                if rank == 6:
                    for promoted in "QRBN":
                        add(f"P{square_name(extra)}{square_name(one)}={promoted}", promoted, (wk, bk, one, 1))
                else:
                    add(f"P{square_name(extra)}{square_name(one)}", "P", (wk, bk, one, 1))
                    if rank == 1:
                        two = extra + 16
                        if two not in (wk, bk):
                            add(f"P{square_name(extra)}{square_name(two)}", "P", (wk, bk, two, 1))
    else:
        for destination in _KING_MOVES[bk]:
            if destination == wk or _king_adjacent(wk, destination):
                continue
            if destination == extra:
                if labels:
                    result.append((f"K{square_name(bk)}x{square_name(destination)}", None, None))
                else:
                    result.append((None, None))
            elif not _piece_attacks(piece_type, extra, destination, wk, destination):
                add(f"K{square_name(bk)}{square_name(destination)}", piece_type, (wk, destination, extra, 0))
    return result


def enumerate_states(piece_type: str) -> list[State3]:
    states: set[State3] = set()
    extra_squares = range(8, 56) if piece_type == "P" else range(64)
    for wk in range(64):
        for bk in range(64):
            if wk == bk or _king_adjacent(wk, bk):
                continue
            for extra in extra_squares:
                if extra in (wk, bk):
                    continue
                for turn in (0, 1):
                    state = wk, bk, extra, turn
                    if legal_state(state, piece_type):
                        states.add(canonical_state(state, piece_type))
    return sorted(states)


@dataclass(frozen=True, slots=True)
class TablebaseBuild:
    summary: dict[str, Any]
    output_path: str


def generate_tablebase(output_path: str | Path, summary_path: str | Path | None = None) -> TablebaseBuild:
    start = time.perf_counter()
    states = {piece_type: enumerate_states(piece_type) for piece_type in TYPES}
    offsets: dict[str, int] = {}
    total = 0
    for piece_type in TYPES:
        offsets[piece_type] = total
        total += len(states[piece_type])
    indexes = {
        piece_type: {state: offsets[piece_type] + i for i, state in enumerate(states[piece_type])}
        for piece_type in TYPES
    }
    types = [""] * total
    local_states: list[State3 | None] = [None] * total
    for piece_type in TYPES:
        for i, state in enumerate(states[piece_type]):
            gid = offsets[piece_type] + i
            types[gid] = piece_type
            local_states[gid] = state

    outdegree = array("I", [0]) * total
    indegree = array("I", [0]) * total
    terminal_loss = bytearray(total)
    edge_count = 0
    for gid in range(total):
        piece_type = types[gid]
        state = local_states[gid]
        assert state is not None
        successors = successors_state(state, piece_type)
        outdegree[gid] = len(successors)
        if not successors and in_check_state(state, piece_type):
            terminal_loss[gid] = 1
        for target_type, target_state in successors:  # type: ignore[misc]
            if target_type is None:
                continue
            target = indexes[target_type][target_state]
            indegree[target] += 1
            edge_count += 1

    predecessor_offsets = array("Q", [0]) * (total + 1)
    for i in range(total):
        predecessor_offsets[i + 1] = predecessor_offsets[i] + indegree[i]
    predecessors = array("I", [0]) * edge_count
    cursor = array("Q", predecessor_offsets[:-1])
    for gid in range(total):
        piece_type = types[gid]
        state = local_states[gid]
        assert state is not None
        for target_type, target_state in successors_state(state, piece_type):  # type: ignore[misc]
            if target_type is None:
                continue
            target = indexes[target_type][target_state]
            slot = cursor[target]
            predecessors[slot] = gid
            cursor[target] = slot + 1

    status = bytearray(total)
    distance = array("H", [0]) * total
    remaining = array("I", outdegree)
    max_win_child = array("H", [0]) * total
    heap: list[tuple[int, int]] = []
    for gid, is_loss in enumerate(terminal_loss):
        if is_loss:
            status[gid] = LOSS
            heapq.heappush(heap, (0, gid))
    while heap:
        child_distance, child = heapq.heappop(heap)
        if status[child] == UNKNOWN or distance[child] != child_distance:
            continue
        for slot in range(predecessor_offsets[child], predecessor_offsets[child + 1]):
            predecessor = predecessors[slot]
            if status[predecessor] != UNKNOWN:
                continue
            if status[child] == LOSS:
                status[predecessor] = WIN
                distance[predecessor] = child_distance + 1
                heapq.heappush(heap, (distance[predecessor], predecessor))
            else:
                if child_distance > max_win_child[predecessor]:
                    max_win_child[predecessor] = child_distance
                remaining[predecessor] -= 1
                if remaining[predecessor] == 0:
                    status[predecessor] = LOSS
                    distance[predecessor] = max_win_child[predecessor] + 1
                    heapq.heappush(heap, (distance[predecessor], predecessor))
    for gid in range(total):
        if status[gid] == UNKNOWN:
            status[gid] = DRAW

    sections: dict[str, dict[str, Any]] = {}
    max_examples: dict[str, list[dict[str, Any]]] = {}
    for piece_type in TYPES:
        first = offsets[piece_type]
        last = first + len(states[piece_type])
        counts = {"win_to_move": 0, "loss_to_move": 0, "draw": 0, "strong_side_win": 0}
        max_dtm = 0
        examples: list[dict[str, Any]] = []
        for local_index, state in enumerate(states[piece_type]):
            gid = first + local_index
            value = status[gid]
            if value == WIN:
                counts["win_to_move"] += 1
            elif value == LOSS:
                counts["loss_to_move"] += 1
            else:
                counts["draw"] += 1
            if (state[3] == 0 and value == WIN) or (state[3] == 1 and value == LOSS):
                counts["strong_side_win"] += 1
            if distance[gid] > max_dtm:
                max_dtm = distance[gid]
                examples = []
            if distance[gid] == max_dtm and value != DRAW and len(examples) < 8:
                examples.append(
                    {
                        "state": state_to_fen(state, piece_type),
                        "side_to_move_value": status_name(value),
                        "dtm_plies": int(distance[gid]),
                        "packed_key": pack_state(state),
                    }
                )
        sections[piece_type] = {
            "canonical_states": len(states[piece_type]),
            **counts,
            "max_dtm_plies": max_dtm,
            "max_dtm_full_moves": max_dtm / 2,
        }
        max_examples[piece_type] = examples

    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("wb") as handle:
        handle.write(MAGIC)
        handle.write(struct.pack("<II", FORMAT_VERSION, len(TYPES)))
        for piece_type in TYPES:
            handle.write(struct.pack("<c3xI", piece_type.encode("ascii"), len(states[piece_type])))
            first = offsets[piece_type]
            records = []
            for local_index, state in enumerate(states[piece_type]):
                gid = first + local_index
                encoded = (int(distance[gid]) << 2) | int(status[gid])
                records.append((pack_state(state), encoded))
            records.sort(key=lambda item: item[0])
            for key, encoded in records:
                handle.write(struct.pack("<IH", key, encoded))

    summary: dict[str, Any] = {
        "schema": "ugts-kc-chess-tb3-summary-4.3",
        "profile": "orthodox-three-piece-zero-clock-no-castling-v1",
        "piece_classes": list(TYPES),
        "color_normalization": "extra piece belongs to White; color-swapped positions are isomorphic",
        "canonical_state_count": total,
        "directed_internal_edges": edge_count,
        "terminal_checkmates": int(sum(terminal_loss)),
        "sections": sections,
        "max_dtm_examples": max_examples,
        "binary_bytes": output.stat().st_size,
        "build_seconds": round(time.perf_counter() - start, 6),
        "algorithm": "D4/file-reflection canonicalization + exact retrograde least fixed point",
        "status_semantics": "win/loss relative to side to move; unclassified complement is draw",
        "boundary": "castling rights absent; halfmove clock starts at zero; no claim that this solves the 32-piece initial position",
    }
    summary["content_hash"] = sha256_digest(summary)
    if summary_path is not None:
        summary_file = Path(summary_path)
        summary_file.parent.mkdir(parents=True, exist_ok=True)
        summary_file.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return TablebaseBuild(summary, str(output))


def status_name(value: int) -> str:
    return {WIN: "win", LOSS: "loss", DRAW: "draw"}.get(value, "unknown")


def state_to_fen(state: State3, piece_type: str) -> str:
    wk, bk, extra, turn = state
    board = [EMPTY] * 64
    board[wk] = "K"
    board[bk] = "k"
    board[extra] = piece_type
    return Position(tuple(board), WHITE if turn == 0 else BLACK, "", None, 0, 1).to_fen()


def position_to_state(position: Position) -> tuple[str, State3, bool]:
    if position.castling:
        raise ValueError("three-piece tablebase profile excludes castling rights")
    pieces = [(square, piece) for square, piece in position.pieces()]
    if len(pieces) != 3:
        raise ValueError("position must contain exactly three pieces")
    wk = position.king_square(WHITE)
    bk = position.king_square(BLACK)
    extras = [(square, piece) for square, piece in pieces if piece.lower() != "k"]
    if len(extras) != 1:
        raise ValueError("position must contain exactly one non-king piece")
    extra_square, piece = extras[0]
    piece_type = piece.upper()
    if piece_type not in TYPES:
        raise ValueError("unsupported three-piece class")
    color_swapped = color_of(piece) == BLACK
    if color_swapped:
        # Rotate 180 degrees and swap colors so the extra piece becomes White.
        state = (63 - bk, 63 - wk, 63 - extra_square, 0 if position.turn == BLACK else 1)
    else:
        state = (wk, bk, extra_square, 0 if position.turn == WHITE else 1)
    if not legal_state(state, piece_type):
        raise ValueError("position is outside the legal tablebase state set")
    return piece_type, canonical_state(state, piece_type), color_swapped


@dataclass(frozen=True, slots=True)
class ProbeResult:
    piece_class: str
    side_to_move_value: str
    strong_side_value: str
    original_white_value: str
    dtm_plies: int
    canonical_key: int
    color_swapped: bool


class ThreePieceTablebase:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.keys: dict[str, array] = {}
        self.values: dict[str, array] = {}
        with self.path.open("rb") as handle:
            if handle.read(8) != MAGIC:
                raise ValueError("not a UGTS three-piece tablebase")
            version, sections = struct.unpack("<II", handle.read(8))
            if version != FORMAT_VERSION or sections != len(TYPES):
                raise ValueError("unsupported tablebase format")
            for _ in range(sections):
                piece_raw, count = struct.unpack("<c3xI", handle.read(8))
                piece_type = piece_raw.decode("ascii")
                raw = handle.read(count * 6)
                if len(raw) != count * 6:
                    raise ValueError("truncated tablebase")
                keys = array("I")
                vals = array("H")
                for key, value in struct.iter_unpack("<IH", raw):
                    keys.append(key)
                    vals.append(value)
                self.keys[piece_type] = keys
                self.values[piece_type] = vals

    def probe(self, position: Position) -> ProbeResult:
        piece_type, state, color_swapped = position_to_state(position)
        key = pack_state(state)
        keys = self.keys[piece_type]
        index = bisect.bisect_left(keys, key)
        if index >= len(keys) or keys[index] != key:
            raise KeyError("canonical state not found")
        encoded = self.values[piece_type][index]
        value = encoded & 3
        dtm = encoded >> 2
        side_value = status_name(value)
        turn_is_strong = state[3] == 0
        strong_value = (
            "win"
            if (turn_is_strong and value == WIN) or ((not turn_is_strong) and value == LOSS)
            else "draw"
        )
        # Convert strong-side result to original White perspective.
        strong_is_original_white = not color_swapped
        original_white_value = strong_value if strong_is_original_white else ("loss" if strong_value == "win" else "draw")
        return ProbeResult(piece_type, side_value, strong_value, original_white_value, dtm, key, color_swapped)

    def best_moves(self, position: Position) -> tuple[str, ...]:
        root = self.probe(position)
        candidates: list[tuple[str, str, int]] = []
        for move in legal_moves(position):
            child = apply_move(position, move)
            if child.piece_count() == 2:
                child_value, child_dtm = "draw", 0
            elif child.piece_count() == 3:
                probed = self.probe(child)
                child_value, child_dtm = probed.side_to_move_value, probed.dtm_plies
            else:
                continue
            candidates.append((move.uci(), child_value, child_dtm))
        if root.side_to_move_value == "win":
            losses = [(uci, dtm) for uci, value, dtm in candidates if value == "loss"]
            if not losses:
                return ()
            best = min(dtm for _, dtm in losses)
            return tuple(sorted(uci for uci, dtm in losses if dtm == best))
        if root.side_to_move_value == "loss":
            wins = [(uci, dtm) for uci, value, dtm in candidates if value == "win"]
            if not wins:
                return ()
            best = max(dtm for _, dtm in wins)
            return tuple(sorted(uci for uci, dtm in wins if dtm == best))
        draws = [uci for uci, value, _ in candidates if value == "draw"]
        return tuple(sorted(draws))
