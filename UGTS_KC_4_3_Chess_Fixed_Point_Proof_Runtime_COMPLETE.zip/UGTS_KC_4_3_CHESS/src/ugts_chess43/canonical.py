"""Canonical chess and UGTS record identities."""
from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, is_dataclass
from typing import Any, Iterable

from .position import EMPTY, Move, Position, square_name
from .rules import legal_moves


def _normalize(value: Any) -> Any:
    if is_dataclass(value):
        value = asdict(value)
    if isinstance(value, dict):
        return {str(k): _normalize(value[k]) for k in sorted(value, key=str)}
    if isinstance(value, (list, tuple)):
        return [_normalize(v) for v in value]
    if isinstance(value, set):
        return sorted((_normalize(v) for v in value), key=lambda x: json.dumps(x, sort_keys=True))
    if isinstance(value, float):
        if not (float("-inf") < value < float("inf")):
            raise ValueError("non-finite float in canonical record")
        if value.is_integer():
            return int(value)
    return value


def canonical_json(value: Any) -> str:
    return json.dumps(_normalize(value), sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha256_digest(value: Any) -> str:
    return "sha256:" + hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def board_placement(position: Position) -> str:
    return position.to_fen().split()[0]


def ep_is_repetition_relevant(position: Position) -> bool:
    """Whether the FEN ep square changes the legal move set.

    Repetition identity depends on the legal possibilities, not merely a stale
    target marker. We therefore retain the ep square only when a legal
    en-passant capture exists.
    """
    if position.ep_square is None:
        return False
    return any(move.en_passant for move in legal_moves(position))


def repetition_key(position: Position) -> str:
    ep = square_name(position.ep_square) if position.ep_square is not None and ep_is_repetition_relevant(position) else "-"
    return " ".join((board_placement(position), position.turn, position.castling or "-", ep))


def position_record(position: Position, *, include_clocks: bool = True) -> dict[str, Any]:
    record: dict[str, Any] = {
        "placement": board_placement(position),
        "turn": position.turn,
        "castling": position.castling or "-",
        "ep": "-" if position.ep_square is None else square_name(position.ep_square),
    }
    if include_clocks:
        record["halfmove_clock"] = position.halfmove_clock
        record["fullmove_number"] = position.fullmove_number
    return record


def position_hash(position: Position, *, include_clocks: bool = True) -> str:
    return sha256_digest(position_record(position, include_clocks=include_clocks))


def move_record(move: Move) -> dict[str, Any]:
    return {
        "uci": move.uci(),
        "from": square_name(move.from_sq),
        "to": square_name(move.to_sq),
        "promotion": move.promotion,
        "en_passant": move.en_passant,
        "castling": move.castling,
    }
