"""Orthodox chess state, move and FEN records.

The module deliberately keeps board state immutable. State mutation is represented
as a candidate transition and committed by :mod:`ugts_chess43.ugts`.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Iterator

FILES = "abcdefgh"
RANKS = "12345678"
EMPTY = "."
WHITE = "w"
BLACK = "b"
START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
VALID_PIECES = frozenset("PNBRQKpnbrqk")


def square_name(square: int) -> str:
    if not 0 <= square < 64:
        raise ValueError(f"square out of range: {square}")
    return FILES[square & 7] + RANKS[square >> 3]


def parse_square(name: str) -> int:
    if len(name) != 2 or name[0] not in FILES or name[1] not in RANKS:
        raise ValueError(f"invalid square: {name!r}")
    return FILES.index(name[0]) + 8 * RANKS.index(name[1])


def color_of(piece: str) -> str | None:
    if piece == EMPTY:
        return None
    return WHITE if piece.isupper() else BLACK


def opposite(color: str) -> str:
    if color == WHITE:
        return BLACK
    if color == BLACK:
        return WHITE
    raise ValueError(f"invalid color: {color!r}")


@dataclass(frozen=True, slots=True, order=True)
class Move:
    """A fully explicit move record.

    Promotion is one of ``q``, ``r``, ``b`` or ``n`` in UCI spelling.
    The flags are derived/verified by move generation; callers should normally
    identify moves by UCI and retrieve the generated record.
    """

    from_sq: int
    to_sq: int
    promotion: str | None = None
    en_passant: bool = False
    castling: bool = False

    def __post_init__(self) -> None:
        if not 0 <= self.from_sq < 64 or not 0 <= self.to_sq < 64:
            raise ValueError("move squares must be in [0, 63]")
        if self.from_sq == self.to_sq:
            raise ValueError("origin and destination must differ")
        if self.promotion is not None and self.promotion not in "qrbn":
            raise ValueError("promotion must be one of q, r, b, n")

    def uci(self) -> str:
        return square_name(self.from_sq) + square_name(self.to_sq) + (self.promotion or "")

    @classmethod
    def from_uci(cls, text: str) -> "Move":
        text = text.strip().lower()
        if len(text) not in (4, 5):
            raise ValueError(f"invalid UCI move: {text!r}")
        return cls(parse_square(text[:2]), parse_square(text[2:4]), text[4] if len(text) == 5 else None)


@dataclass(frozen=True, slots=True)
class Position:
    """A FEN-complete orthodox chess position.

    ``board`` uses a1=0, h8=63 and contains 64 single-character cells.
    Castling is normalized to the order ``KQkq`` or ``-`` when serialized.
    """

    board: tuple[str, ...]
    turn: str = WHITE
    castling: str = "KQkq"
    ep_square: int | None = None
    halfmove_clock: int = 0
    fullmove_number: int = 1

    def __post_init__(self) -> None:
        if len(self.board) != 64:
            raise ValueError("board must contain exactly 64 cells")
        bad = [p for p in self.board if p != EMPTY and p not in VALID_PIECES]
        if bad:
            raise ValueError(f"invalid board pieces: {bad[:4]}")
        if self.turn not in (WHITE, BLACK):
            raise ValueError("turn must be 'w' or 'b'")
        if any(c not in "KQkq" for c in self.castling) or len(set(self.castling)) != len(self.castling):
            raise ValueError("invalid castling rights")
        if self.ep_square is not None and not 0 <= self.ep_square < 64:
            raise ValueError("invalid en-passant square")
        if self.halfmove_clock < 0:
            raise ValueError("halfmove clock must be non-negative")
        if self.fullmove_number < 1:
            raise ValueError("fullmove number must be positive")

    @classmethod
    def empty(cls, turn: str = WHITE) -> "Position":
        return cls((EMPTY,) * 64, turn, "", None, 0, 1)

    @classmethod
    def start(cls) -> "Position":
        return cls.from_fen(START_FEN)

    @classmethod
    def from_fen(cls, fen: str, *, validate_kings: bool = True) -> "Position":
        parts = fen.strip().split()
        if len(parts) != 6:
            raise ValueError("FEN must have six fields")
        placement, turn, castling, ep, halfmove, fullmove = parts
        ranks = placement.split("/")
        if len(ranks) != 8:
            raise ValueError("FEN placement must have eight ranks")
        board = [EMPTY] * 64
        for fen_rank, token in enumerate(ranks):
            rank = 7 - fen_rank
            file_ = 0
            for ch in token:
                if ch.isdigit():
                    n = int(ch)
                    if not 1 <= n <= 8:
                        raise ValueError("FEN empty-run digit must be 1..8")
                    file_ += n
                elif ch in VALID_PIECES:
                    if file_ >= 8:
                        raise ValueError("too many files in FEN rank")
                    board[rank * 8 + file_] = ch
                    file_ += 1
                else:
                    raise ValueError(f"invalid FEN placement character: {ch!r}")
            if file_ != 8:
                raise ValueError("each FEN rank must describe eight files")
        normalized_castling = "" if castling == "-" else "".join(c for c in "KQkq" if c in castling)
        ep_square = None if ep == "-" else parse_square(ep)
        pos = cls(tuple(board), turn, normalized_castling, ep_square, int(halfmove), int(fullmove))
        if validate_kings:
            if pos.board.count("K") != 1 or pos.board.count("k") != 1:
                raise ValueError("orthodox position must contain exactly one king per side")
        return pos

    def to_fen(self) -> str:
        rows: list[str] = []
        for rank in range(7, -1, -1):
            run = 0
            row: list[str] = []
            for file_ in range(8):
                piece = self.board[rank * 8 + file_]
                if piece == EMPTY:
                    run += 1
                else:
                    if run:
                        row.append(str(run))
                        run = 0
                    row.append(piece)
            if run:
                row.append(str(run))
            rows.append("".join(row))
        return " ".join(
            (
                "/".join(rows),
                self.turn,
                self.castling or "-",
                "-" if self.ep_square is None else square_name(self.ep_square),
                str(self.halfmove_clock),
                str(self.fullmove_number),
            )
        )

    def king_square(self, color: str) -> int:
        king = "K" if color == WHITE else "k"
        try:
            return self.board.index(king)
        except ValueError as exc:
            raise ValueError(f"missing {color} king") from exc

    def pieces(self, color: str | None = None) -> Iterator[tuple[int, str]]:
        for square, piece in enumerate(self.board):
            if piece != EMPTY and (color is None or color_of(piece) == color):
                yield square, piece

    def piece_count(self) -> int:
        return sum(piece != EMPTY for piece in self.board)

    def replace(
        self,
        *,
        board: Iterable[str] | None = None,
        turn: str | None = None,
        castling: str | None = None,
        ep_square: int | None | object = ...,
        halfmove_clock: int | None = None,
        fullmove_number: int | None = None,
    ) -> "Position":
        return Position(
            tuple(self.board if board is None else board),
            self.turn if turn is None else turn,
            self.castling if castling is None else castling,
            self.ep_square if ep_square is ... else ep_square,  # type: ignore[arg-type]
            self.halfmove_clock if halfmove_clock is None else halfmove_clock,
            self.fullmove_number if fullmove_number is None else fullmove_number,
        )

    def ascii(self) -> str:
        lines: list[str] = []
        for rank in range(7, -1, -1):
            lines.append(f"{rank + 1}  " + " ".join(self.board[rank * 8 : rank * 8 + 8]))
        lines.append("   " + " ".join(FILES))
        return "\n".join(lines)
