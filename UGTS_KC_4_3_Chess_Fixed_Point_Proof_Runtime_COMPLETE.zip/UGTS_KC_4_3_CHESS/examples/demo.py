from __future__ import annotations

from dataclasses import asdict
import json
from pathlib import Path

from ugts_chess43.position import Position
from ugts_chess43.retrograde3 import ThreePieceTablebase
from ugts_chess43.rules import perft
from ugts_chess43.search import BoundedMateSolver
from ugts_chess43.ugts import ChessRuntime

ROOT = Path(__file__).resolve().parents[1]

initial = Position.start()
initial_proof = BoundedMateSolver(3).solve(initial)

runtime = ChessRuntime(initial)
for uci in ("e2e4", "e7e5", "g1f3", "b8c6", "f1b5"):
    runtime.play(uci, source="demo")

mate = Position.from_fen("7k/8/6K1/8/8/8/5Q2/8 w - - 0 1")
mate_proof = BoundedMateSolver(1).solve(mate)

tb = ThreePieceTablebase(ROOT / "data" / "tb3_orthodox_zero_clock.bin")
endgame = Position.from_fen("8/8/8/8/4k3/8/1Q6/K7 b - - 0 1")
endgame_probe = asdict(tb.probe(endgame))
endgame_probe["best_moves"] = list(tb.best_moves(endgame))

payload = {
    "schema": "ugts-kc-chess-demo-4.3",
    "initial_position": {
        "fen": initial.to_fen(),
        "perft_depth_4": perft(initial, 4),
        "bounded_proof": asdict(initial_proof),
        "interpretation": "unknown at depth 3; no full-game result is inferred",
    },
    "event_runtime": runtime.snapshot(),
    "mate_in_one": asdict(mate_proof),
    "three_piece_probe": endgame_probe,
}
print(json.dumps(payload, indent=2, sort_keys=True))
