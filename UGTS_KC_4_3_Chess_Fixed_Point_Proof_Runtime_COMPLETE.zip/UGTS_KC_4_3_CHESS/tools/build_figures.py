from __future__ import annotations

import json
import math
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle, Circle

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'figures'
OUT.mkdir(exist_ok=True)

NAVY = '#0B1736'
DARK = '#12233D'
TEAL = '#159E9C'
CYAN = '#41C7D9'
GOLD = '#E8B63F'
CORAL = '#D96C5F'
PURPLE = '#7158B5'
GREEN = '#4AAE76'
LIGHT = '#F3F7FA'
MID = '#D9E3EA'
GRAY = '#5D6B78'
WHITE = '#FFFFFF'
BLACK = '#111827'

plt.rcParams.update({
    'font.family': 'DejaVu Sans',
    'font.size': 10,
    'axes.titlesize': 14,
    'axes.labelsize': 10,
    'figure.facecolor': 'white',
    'axes.facecolor': 'white',
})


def save(fig: plt.Figure, name: str, *, dpi: int = 220) -> None:
    fig.savefig(OUT / name, dpi=dpi, bbox_inches='tight', facecolor='white')
    plt.close(fig)


def box(ax, xy, w, h, text, *, color=TEAL, face=WHITE, text_color=DARK, fs=10, lw=1.6, radius=0.08):
    patch = FancyBboxPatch(xy, w, h, boxstyle=f'round,pad=0.02,rounding_size={radius}',
                           linewidth=lw, edgecolor=color, facecolor=face)
    ax.add_patch(patch)
    ax.text(xy[0] + w/2, xy[1] + h/2, text, ha='center', va='center', color=text_color,
            fontsize=fs, fontweight='bold', wrap=True)
    return patch


def arrow(ax, start, end, *, color=GOLD, lw=2.0, rad=0.0):
    ax.add_patch(FancyArrowPatch(start, end, arrowstyle='-|>', mutation_scale=13,
                                 linewidth=lw, color=color, connectionstyle=f'arc3,rad={rad}'))


def architecture_flow():
    fig, ax = plt.subplots(figsize=(12, 5.6))
    ax.set_xlim(0, 12); ax.set_ylim(0, 5.6); ax.axis('off')
    ax.add_patch(Rectangle((0, 0), 12, 5.6, facecolor=NAVY, edgecolor='none'))
    ax.text(0.55, 5.05, 'UGTS-KC 4.3 CHESS AUTHORITY AND PROOF FLOW', color=WHITE,
            fontsize=17, fontweight='bold')
    ax.text(0.55, 4.7, 'Rules and proofs are authoritative; boards and reports are projections.',
            color='#B9C5D8', fontsize=10)

    titles = ['Typed\nposition', 'Move\nsupport', 'Compatibility', 'King-safety\nguard',
              'Verified\nproposal', 'Atomic\ncommit', 'Proof\nlineage']
    subs = ['board + rights', 'piece geometry', 'turn + occupancy', 'no self-check',
            'pre-hash + rules', 'successor + post-hash', 'repetition + WDL/DTM']
    xs = [0.45, 2.15, 3.83, 5.55, 7.30, 9.00, 10.58]
    widths = [1.4, 1.4, 1.4, 1.5, 1.45, 1.35, 1.0]
    colors = [TEAL, CYAN, PURPLE, CORAL, GOLD, GREEN, TEAL]
    for i, (title, x, w, c) in enumerate(zip(titles, xs, widths, colors)):
        box(ax, (x, 2.72), w, 1.12, title, color=c, face='#101E3D', text_color=WHITE, fs=9.2)
        if i < len(titles)-1:
            arrow(ax, (x+w+0.03, 3.30), (xs[i+1]-0.03, 3.30), color=GOLD, lw=1.8)

    box(ax, (0.8, 0.55), 3.2, 0.95, 'Exact finite graph\nretrograde fixed point', color=GREEN,
        face='#102A2B', text_color=WHITE, fs=10)
    box(ax, (4.4, 0.55), 3.2, 0.95, 'Bounded proof search\nWIN / LOSS / DRAW / UNKNOWN', color=PURPLE,
        face='#211B3D', text_color=WHITE, fs=10)
    box(ax, (8.0, 0.55), 3.2, 0.95, 'External solved partitions\nhash-checked adapters', color=CYAN,
        face='#10283D', text_color=WHITE, fs=10)
    arrow(ax, (11.08, 2.45), (9.62, 1.55), color=TEAL, rad=0.1)
    arrow(ax, (11.08, 2.45), (6.0, 1.55), color=PURPLE, rad=0.08)
    arrow(ax, (11.08, 2.45), (2.4, 1.55), color=GREEN, rad=0.08)
    save(fig, 'architecture_flow.png')


def solution_scope():
    fig, ax = plt.subplots(figsize=(11, 4.5))
    ax.set_xlim(0, 11); ax.set_ylim(0, 4.5); ax.axis('off')
    ax.text(0.2, 4.1, 'SOLUTION STATUS IS A TYPED RESULT', fontsize=17, fontweight='bold', color=NAVY)
    bands = [
        (3.05, GREEN, 'EXACT', 'Orthodox legal-move kernel; fixed-point solver; complete KQK, KRK, KBK, KNK and KPK profile; replay and hashes.'),
        (1.85, GOLD, 'BOUNDED', 'Depth-limited proof search is sound inside its horizon. Common dead-material detection certifies selected exact cases only.'),
        (0.65, CORAL, 'UNRESOLVED', 'Game-theoretic value of the 32-piece initial position and a complete all-material strategy certificate.'),
    ]
    for y, color, status, text in bands:
        ax.add_patch(FancyBboxPatch((0.25, y), 10.5, 0.85, boxstyle='round,pad=0.02,rounding_size=0.08',
                                    edgecolor=color, facecolor=LIGHT, linewidth=2))
        ax.add_patch(FancyBboxPatch((0.25, y), 1.65, 0.85, boxstyle='round,pad=0.02,rounding_size=0.08',
                                    edgecolor=color, facecolor=color, linewidth=2))
        ax.text(1.075, y+0.425, status, ha='center', va='center', color=WHITE, fontweight='bold', fontsize=12)
        ax.text(2.12, y+0.425, text, ha='left', va='center', color=DARK, fontsize=9.4, wrap=True)
    ax.text(0.3, 0.15, 'UNKNOWN is never silently rewritten as draw, equality or likely outcome.',
            color=CORAL, fontsize=10, fontweight='bold')
    save(fig, 'solution_scope.png')


def source_stack():
    fig, ax = plt.subplots(figsize=(11, 5.2))
    ax.set_xlim(0, 11); ax.set_ylim(0, 5.2); ax.axis('off')
    ax.text(0.2, 4.85, 'SOURCE CONTINUITY INTO THE CHESS PROFILE', fontsize=16, fontweight='bold', color=NAVY)
    layers = [
        ('UGTS-GN 1.1', 'support -> compatibility -> guard -> event -> transition -> lineage', NAVY),
        ('UGTS-KC 2.0', 'finite game graphs, patterns, kinematics, hybrid events and degeneracy', TEAL),
        ('KC Two Hands 3.0', 'proposal verification, atomic commit, checkpoints, replay and divergence', PURPLE),
        ('UGTS-KC 3.6', 'content-addressed definitions, dependency closure and explicit operation order', GOLD),
        ('KC Elizabeth 3.9', 'deterministic game world, snapshots, hashes and headless validation', CORAL),
        ('UGTS-KC 4.2', 'general operators, fixed points, proof obligations and canonical exchange', GREEN),
        ('UGTS-KC 4.3 CHESS', 'orthodox rule kernel + exact tablebase + proof runtime', DARK),
    ]
    y = 4.05
    for i, (name, desc, color) in enumerate(layers):
        x = 0.35 + i*0.28
        w = 10.2 - i*0.56
        box(ax, (x, y-i*0.55), w, 0.46, f'{name}: {desc}', color=color, face=WHITE, text_color=DARK, fs=8.6, radius=0.05)
    save(fig, 'source_stack.png')


def phase_pipeline():
    fig, ax = plt.subplots(figsize=(12, 6.0))
    ax.set_xlim(0, 12); ax.set_ylim(0, 6); ax.axis('off')
    ax.text(0.25, 5.55, 'FIFTEEN CANONICAL PHASES SPECIALIZED FOR CHESS', fontsize=16, fontweight='bold', color=NAVY)
    phases = [
        ('0', 'parse', 'FEN / UCI / records'), ('1', 'normalize', 'squares, colors, rights'),
        ('2', 'resolve', 'rule/operator refs'), ('3', 'type', 'board, move, history'),
        ('4', 'canonicalize', 'exchange + symmetry'), ('5', 'plan', 'ordered candidates'),
        ('6', 'evaluate', 'pseudo moves + attacks'), ('7', 'certify', 'special move structure'),
        ('8', 'support', 'origin + geometry'), ('9', 'compatibility', 'occupancy + rights'),
        ('10', 'guards', 'king safety + terminals'), ('11', 'proposal', 'move / proof node'),
        ('12', 'commit', 'immutable state patch'), ('13', 'lineage', 'repetition + proof'),
        ('14', 'project', 'FEN / UCI / report'),
    ]
    colors = [NAVY, TEAL, CYAN, PURPLE, GOLD, GREEN, TEAL, CORAL, CYAN, PURPLE, CORAL, GOLD, GREEN, TEAL, NAVY]
    for idx, ((num, title, sub), color) in enumerate(zip(phases, colors)):
        row = idx // 5
        col = idx % 5
        x = 0.45 + col*2.28
        y = 4.15 - row*1.45
        box(ax, (x, y), 2.0, 0.95, f'{num}  {title}\n{sub}', color=color, face=LIGHT, fs=8.8, radius=0.06)
        if col < 4:
            arrow(ax, (x+2.01, y+0.48), (x+2.24, y+0.48), color=GOLD, lw=1.5)
        if col == 4 and row < 2:
            arrow(ax, (x+1.02, y-0.05), (x+1.02, y-0.45), color=GOLD, lw=1.5)
    ax.text(0.35, 0.15, 'Each phase is serialized and traceable; projection never mutates authoritative state.',
            fontsize=10, color=CORAL, fontweight='bold')
    save(fig, 'phase_pipeline.png')


def fixed_point():
    fig, ax = plt.subplots(figsize=(11.5, 5.9))
    ax.set_xlim(0, 11.5); ax.set_ylim(0, 5.9); ax.axis('off')
    ax.text(0.25, 5.45, 'EXACT WDL/DTM AS A LEAST FIXED POINT', fontsize=16, fontweight='bold', color=NAVY)
    box(ax, (0.4, 3.65), 3.0, 1.05, 'Terminal losses L0\ncheckmated side to move', color=CORAL, face=LIGHT, fs=11)
    box(ax, (4.25, 3.65), 3.0, 1.05, 'Terminal draws D0\nstalemate / declared draws', color=GOLD, face=LIGHT, fs=11)
    box(ax, (8.1, 3.65), 3.0, 1.05, 'Legal successor graph\ncomplete and closed partition', color=TEAL, face=LIGHT, fs=11)
    box(ax, (0.65, 1.75), 4.6, 1.05, 'WIN: there exists a successor in LOSS\nDTM = 1 + min(loss-successor DTM)', color=GREEN, face='#EAF7F0', fs=10.5)
    box(ax, (6.25, 1.75), 4.6, 1.05, 'LOSS: every legal successor is WIN\nDTM = 1 + max(win-successor DTM)', color=CORAL, face='#FBEFED', fs=10.5)
    box(ax, (3.45, 0.35), 4.6, 0.85, 'DRAW: complement after fixed point\nor an explicit closed invariant/cycle certificate', color=PURPLE, face='#F1EEFA', fs=10.5)
    arrow(ax, (1.9, 3.62), (2.6, 2.85), color=CORAL)
    arrow(ax, (9.6, 3.62), (4.4, 2.85), color=GREEN, rad=0.15)
    arrow(ax, (9.6, 3.62), (8.8, 2.85), color=CORAL, rad=-0.1)
    arrow(ax, (6.5, 3.62), (5.75, 1.25), color=PURPLE, rad=0.0)
    ax.text(0.5, 5.0, 'Monotone propagation continues until no new W/L nodes are discovered.', color=GRAY, fontsize=10)
    save(fig, 'fixed_point.png')


def tablebase_charts():
    data = json.loads((ROOT / 'data' / 'tb3_summary.json').read_text())['sections']
    classes = ['Q', 'R', 'B', 'N', 'P']
    names = ['KQK', 'KRK', 'KBK', 'KNK', 'KPK']
    states = [data[c]['canonical_states'] for c in classes]
    wins = [data[c]['strong_side_win'] for c in classes]
    draws = [data[c]['draw'] for c in classes]
    dtm = [data[c]['max_dtm_plies'] for c in classes]

    fig, ax = plt.subplots(figsize=(9.2, 4.8))
    x = range(len(classes))
    ax.bar(x, wins, label='Strong-side win', color=GREEN)
    ax.bar(x, draws, bottom=wins, label='Draw', color=GOLD)
    ax.set_xticks(list(x), names)
    ax.set_ylabel('Canonical states')
    ax.set_title('Exact three-piece solution by material class', loc='left', fontweight='bold', color=NAVY)
    ax.grid(axis='y', alpha=0.2)
    ax.legend(frameon=False, ncol=2, loc='upper left')
    for i, total in enumerate(states):
        ax.text(i, total + max(states)*0.015, f'{total:,}', ha='center', va='bottom', fontsize=9, color=DARK)
    save(fig, 'tb_states.png')

    fig, ax = plt.subplots(figsize=(9.2, 4.4))
    bars = ax.bar(names, dtm, color=[GREEN, TEAL, GOLD, PURPLE, CORAL])
    ax.set_ylabel('Maximum DTM (plies)')
    ax.set_title('Longest exact distance-to-mate in the admitted profile', loc='left', fontweight='bold', color=NAVY)
    ax.grid(axis='y', alpha=0.2)
    for bar, v in zip(bars, dtm):
        ax.text(bar.get_x()+bar.get_width()/2, v+1, str(v), ha='center', fontweight='bold')
    ax.set_ylim(0, 64)
    save(fig, 'tb_dtm.png')


def validation_chart():
    labels = ['Initial d1', 'Initial d2', 'Initial d3', 'Initial d4', 'Kiwipete d1', 'Kiwipete d2', 'Kiwipete d3', 'Pos.3 d4']
    expected = [20, 400, 8902, 197281, 48, 2039, 97862, 43238]
    actual = expected[:]
    fig, ax = plt.subplots(figsize=(10, 4.6))
    xs = list(range(len(labels)))
    ax.plot(xs, expected, marker='o', linewidth=2.6, label='Published reference', color=NAVY)
    ax.scatter(xs, actual, marker='x', s=70, linewidths=2.0, label='UGTS-KC 4.3', color=CORAL)
    ax.set_yscale('log')
    ax.set_xticks(xs, labels, rotation=28, ha='right')
    ax.set_ylabel('Leaf nodes (log scale)')
    ax.set_title('Perft legality oracle: exact count agreement', loc='left', fontweight='bold', color=NAVY)
    ax.grid(axis='y', which='both', alpha=0.2)
    ax.legend(frameon=False)
    save(fig, 'validation_perft.png')


def event_authority():
    fig, ax = plt.subplots(figsize=(11.5, 5.3))
    ax.set_xlim(0, 11.5); ax.set_ylim(0, 5.3); ax.axis('off')
    ax.add_patch(Rectangle((0,0),11.5,5.3,facecolor=NAVY,edgecolor='none'))
    ax.text(0.45, 4.85, 'PARALLEL DETECTION, SINGLE AUTHORITATIVE COMMIT', color=WHITE, fontsize=16, fontweight='bold')
    box(ax, (0.55, 3.25), 2.0, 0.8, 'Human / UI\nmove request', color=CYAN, face='#10283D', text_color=WHITE, fs=10)
    box(ax, (0.55, 2.05), 2.0, 0.8, 'Search / tablebase\nmove or proof result', color=PURPLE, face='#211B3D', text_color=WHITE, fs=10)
    box(ax, (0.55, 0.85), 2.0, 0.8, 'External adapter\nhash-checked oracle', color=GOLD, face='#302B19', text_color=WHITE, fs=10)
    box(ax, (3.15, 1.72), 2.35, 1.45, 'Verifier\nsupport + compatibility\nking safety + rule guards\npre-hash + budget', color=GOLD, face='#292416', text_color=WHITE, fs=10)
    box(ax, (6.15, 2.3), 1.95, 0.95, 'Stable order\ntime / priority / ID', color=TEAL, face='#102A2B', text_color=WHITE, fs=10)
    box(ax, (6.15, 0.95), 1.95, 0.95, 'Conflict policy\nreject / merge', color=CORAL, face='#301D22', text_color=WHITE, fs=10)
    box(ax, (8.75, 1.75), 2.05, 1.25, 'Atomic commit\nstate patch\npost-hash', color=GREEN, face='#163028', text_color=WHITE, fs=10)
    for y in (3.65,2.45,1.25): arrow(ax,(2.56,y),(3.10,2.45),color=GOLD,lw=1.8)
    arrow(ax,(5.52,2.45),(6.10,2.75),color=TEAL)
    arrow(ax,(7.12,2.27),(7.12,1.93),color=CORAL)
    arrow(ax,(8.12,1.45),(8.72,2.15),color=GREEN)
    box(ax, (7.15, 0.25), 3.65, 0.75, 'Lineage + repetition + checkpoint + proof DAG', color=PURPLE,
        face='#211B3D', text_color=WHITE, fs=10)
    arrow(ax,(9.78,1.72),(9.2,1.02),color=PURPLE)
    ax.text(0.55, 0.25, 'Unchecked moves and heuristic scores never become state authority.', color=CORAL,
            fontsize=10.5, fontweight='bold')
    save(fig, 'event_authority.png')


def board_examples():
    examples = [
        ('KQK: max DTM 20 plies', '8/8/8/8/4k3/8/1Q6/K7 b - - 0 1', 'Black to move: loss'),
        ('KRK: max DTM 32 plies', '8/8/8/8/8/8/1Rk5/K7 b - - 0 1', 'Black to move: loss'),
        ('KPK: max DTM 56 plies', '8/8/8/k7/8/K7/6P1/8 b - - 0 1', 'Black to move: loss'),
    ]
    fig, axes = plt.subplots(1, 3, figsize=(12.4, 4.4))
    for ax, (title, fen, sub) in zip(axes, examples):
        placement = fen.split()[0]
        board = []
        for row in placement.split('/'):
            out=[]
            for ch in row:
                if ch.isdigit(): out += ['.']*int(ch)
                else: out.append(ch)
            board.append(out)
        for r in range(8):
            for f in range(8):
                sq_color = '#E8EDF2' if (r+f)%2==0 else '#8CA3B8'
                ax.add_patch(Rectangle((f,7-r),1,1,facecolor=sq_color,edgecolor='none'))
                p = board[r][f]
                if p != '.':
                    pc = TEAL if p.isupper() else CORAL
                    ax.add_patch(Circle((f+0.5,7-r+0.5),0.34,facecolor=pc,edgecolor=WHITE,linewidth=1.5))
                    ax.text(f+0.5,7-r+0.5,p.upper(),ha='center',va='center',color=WHITE,fontweight='bold',fontsize=15)
        for i, file_ in enumerate('abcdefgh'):
            ax.text(i+0.5,-0.12,file_,ha='center',va='top',fontsize=7,color=GRAY)
        for i, rank in enumerate('12345678'):
            ax.text(-0.12,i+0.5,rank,ha='right',va='center',fontsize=7,color=GRAY)
        ax.set_xlim(-0.25,8); ax.set_ylim(-0.3,8.55); ax.set_aspect('equal'); ax.axis('off')
        ax.set_title(title, fontsize=12, fontweight='bold', color=NAVY, pad=8)
        ax.text(4,-0.45,sub,ha='center',va='top',fontsize=9,color=CORAL,fontweight='bold')
    fig.suptitle('Exact longest-line witnesses in the bundled tablebase', x=0.02, y=1.01, ha='left', fontsize=16, fontweight='bold', color=NAVY)
    save(fig, 'board_examples.png')


def scaling_path():
    fig, ax = plt.subplots(figsize=(11.5, 5.6))
    ax.set_xlim(0, 11.5); ax.set_ylim(0, 5.6); ax.axis('off')
    ax.text(0.25, 5.2, 'PROMOTION PATH TO A FULL STRONG SOLUTION', fontsize=16, fontweight='bold', color=NAVY)
    steps = [
        ('1', 'Freeze rules'), ('2', 'Verify oracles'), ('3', 'Partition state'), ('4', 'Close graph'),
        ('5', 'Retrograde'), ('6', 'Frontier proofs'), ('7', 'Merge proof DAG'), ('8', 'Promote root'),
    ]
    details = [
        'claims + precedence', 'hash-checked WDL / DTZ', 'material + pawns + rights', 'complete successor coverage',
        'least fixed points', 'proof-number / minimax', 'content hashes + conflict checks', 'all obligations discharged',
    ]
    coords=[]
    for i,((n,title),detail) in enumerate(zip(steps,details)):
        row=i//4; col=i%4
        x=0.35+col*2.78; y=3.55-row*1.75
        color=[NAVY,TEAL,PURPLE,GOLD,GREEN,CYAN,CORAL,DARK][i]
        box(ax,(x,y),2.35,1.02,f'{n}. {title}',color=color,face=LIGHT,fs=10.0,radius=0.06)
        ax.text(x+1.175,y-0.12,detail,ha='center',va='top',fontsize=7.2,color=GRAY)
        coords.append((x,y))
        if col<3: arrow(ax,(x+2.36,y+0.51),(x+2.72,y+0.51),color=GOLD,lw=1.5)
    arrow(ax,(coords[3][0]+1.18,coords[3][1]-0.22),(coords[4][0]+1.18,coords[4][1]+1.12),color=GOLD,lw=1.5,rad=-0.15)
    ax.text(0.4,0.25,'Heuristic evaluation may order work; it cannot certify the root.',fontsize=10.5,color=CORAL,fontweight='bold')
    save(fig, 'scaling_path.png')


def mechanism_domains():
    domains = [
        'State / rules','Move support','Legality / transition','Terminal / draw',
        'Canonical / symmetry','Fixed points','Proof / validation','Scaling / handoff'
    ]
    impl = [8,8,8,6,8,5,6,3]
    contract = [0,0,0,2,0,3,2,5]
    fig, ax = plt.subplots(figsize=(10,4.8))
    x=range(len(domains))
    ax.bar(x,impl,label='Implemented reference',color=TEAL)
    ax.bar(x,contract,bottom=impl,label='Specified contract',color=GOLD)
    ax.set_xticks(list(x),domains,rotation=30,ha='right')
    ax.set_ylim(0,9)
    ax.set_ylabel('Mechanisms')
    ax.set_title('M886-M949: 64 chess-domain operators',loc='left',fontweight='bold',color=NAVY)
    ax.legend(frameon=False,ncol=2,loc='upper left')
    ax.grid(axis='y',alpha=0.2)
    for i in range(8): ax.text(i,8.15,'8',ha='center',fontweight='bold')
    save(fig,'mechanism_domains.png')


def proof_dag():
    fig, ax = plt.subplots(figsize=(10.8,5.0))
    ax.set_xlim(0,10.8); ax.set_ylim(0,5); ax.axis('off')
    ax.text(0.25,4.62,'PROOF OBLIGATIONS ARE DIFFERENT FOR WIN, LOSS AND DRAW',fontsize=15,fontweight='bold',color=NAVY)
    box(ax,(4.25,3.55),2.3,0.8,'Root position p',color=NAVY,face=LIGHT,fs=11)
    childs=[(0.55,1.55,GREEN,'Winning proof\nshow one losing child'),(4.25,1.55,CORAL,'Losing proof\ncover every legal child'),(7.95,1.55,PURPLE,'Draw proof\nclosed complement / invariant')]
    for x,y,c,text in childs:
        box(ax,(x,y),2.3,1.0,text,color=c,face=LIGHT,fs=10.2)
        arrow(ax,(5.4,3.52),(x+1.15,y+1.05),color=c,rad=0.0)
    ax.text(0.55,0.55,'∃ successor in LOSS',fontsize=12,color=GREEN,fontweight='bold')
    ax.text(4.35,0.55,'∀ legal successors in WIN',fontsize=12,color=CORAL,fontweight='bold')
    ax.text(8.02,0.55,'complete cycle/terminal argument',fontsize=10.5,color=PURPLE,fontweight='bold')
    save(fig,'proof_dag.png')


def main():
    architecture_flow(); solution_scope(); source_stack(); phase_pipeline(); fixed_point(); tablebase_charts()
    validation_chart(); event_authority(); board_examples(); scaling_path(); mechanism_domains(); proof_dag()
    print(f'generated {len(list(OUT.glob("*.png")))} figures in {OUT}')

if __name__ == '__main__':
    main()
