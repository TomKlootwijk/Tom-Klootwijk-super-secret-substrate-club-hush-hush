from __future__ import annotations

import compileall
import csv
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def run() -> dict:
    started = time.time()
    result: dict = {"schema": "ugts-kc-chess-validation-4.3", "checks": {}}
    checks = result["checks"]

    checks["compileall"] = {"pass": compileall.compile_dir(str(SRC), quiet=1)}

    env = dict(os.environ)
    env["PYTHONPATH"] = str(SRC)
    proc = subprocess.run(
        [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"],
        cwd=ROOT,
        env=env,
        capture_output=True,
        text=True,
    )
    checks["unittest"] = {
        "pass": proc.returncode == 0,
        "returncode": proc.returncode,
        "summary_tail": (proc.stdout + proc.stderr).splitlines()[-6:],
    }

    catalog_path = ROOT / "spec" / "chess_operator_catalog_M886_M949.csv"
    rows = list(csv.DictReader(catalog_path.open(encoding="utf-8")))
    ids = [int(row["mechanism_id"][1:]) for row in rows]
    checks["catalog"] = {
        "pass": len(rows) == 64 and ids == list(range(886, 950)) and len({r["operator_id"] for r in rows}) == 64,
        "count": len(rows),
        "range": [min(ids), max(ids)],
        "unique_hashes": len({r["content_hash"] for r in rows}),
    }

    summary = json.loads((ROOT / "data" / "tb3_summary.json").read_text())
    tb_path = ROOT / "data" / "tb3_orthodox_zero_clock.bin"
    checks["tablebase"] = {
        "pass": summary["canonical_state_count"] == 367868
        and summary["directed_internal_edges"] == 3217270
        and summary["sections"]["Q"]["max_dtm_plies"] == 20
        and summary["sections"]["R"]["max_dtm_plies"] == 32
        and summary["sections"]["P"]["max_dtm_plies"] == 56
        and tb_path.stat().st_size == summary["binary_bytes"],
        "bytes": tb_path.stat().st_size,
        "sha256": sha256(tb_path),
        "summary_hash": summary["content_hash"],
    }

    required_json = list((ROOT / "spec").glob("*.json")) + list((ROOT / "examples").glob("*.json")) + [
        ROOT / "data" / "tb3_summary.json"
    ]
    json_errors = []
    for path in required_json:
        try:
            json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            json_errors.append({"file": str(path.relative_to(ROOT)), "error": str(exc)})
    checks["json_parse"] = {"pass": not json_errors, "files": len(required_json), "errors": json_errors}

    from ugts_chess43.position import Position
    from ugts_chess43.rules import perft

    perft_cases = [
        (Position.start(), 4, 197281),
        (
            Position.from_fen("r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1"),
            3,
            97862,
        ),
        (Position.from_fen("8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1"), 4, 43238),
    ]
    perft_results = []
    for position, depth, expected in perft_cases:
        actual = perft(position, depth)
        perft_results.append({"fen": position.to_fen(), "depth": depth, "expected": expected, "actual": actual})
    checks["perft"] = {"pass": all(x["actual"] == x["expected"] for x in perft_results), "cases": perft_results}

    result["pass"] = all(check["pass"] for check in checks.values())
    result["duration_seconds"] = round(time.time() - started, 6)
    return result


if __name__ == "__main__":
    payload = run()
    text = json.dumps(payload, indent=2, sort_keys=True) + "\n"
    (ROOT / "validation" / "validation_summary.json").write_text(text, encoding="utf-8")
    print(text, end="")
    raise SystemExit(0 if payload["pass"] else 1)
