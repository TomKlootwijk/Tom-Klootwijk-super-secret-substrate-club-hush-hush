from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Iterable, Sequence

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_ALIGN_VERTICAL, WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Inches, Pt, RGBColor

ROOT = Path(__file__).resolve().parents[1]
FIG = ROOT / 'figures'
REPORT = ROOT / 'report'
REPORT.mkdir(exist_ok=True)
OUT = REPORT / 'UGTS_KC_4_3_Chess_Fixed_Point_Proof_Runtime.docx'

NAVY = '0B1736'
DARK = '12233D'
TEAL = '159E9C'
CYAN = '41C7D9'
GOLD = 'E8B63F'
CORAL = 'D96C5F'
PURPLE = '7158B5'
GREEN = '4AAE76'
LIGHT = 'F3F7FA'
MID = 'D9E3EA'
GRAY = '5D6B78'
WHITE = 'FFFFFF'
BLACK = '111827'

BODY_FONT = 'Inter'
HEAD_FONT = 'Inter Display'
MONO_FONT = 'DejaVu Sans Mono'


def set_font(run, name: str, size: float | None = None, bold: bool | None = None, color: str | None = None, italic: bool | None = None):
    run.font.name = name
    run._element.get_or_add_rPr().rFonts.set(qn('w:ascii'), name)
    run._element.get_or_add_rPr().rFonts.set(qn('w:hAnsi'), name)
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if italic is not None:
        run.italic = italic
    if color:
        run.font.color.rgb = RGBColor.from_string(color)
    return run


def shade_cell(cell, fill: str):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = tcPr.find(qn('w:shd'))
    if shd is None:
        shd = OxmlElement('w:shd')
        tcPr.append(shd)
    shd.set(qn('w:fill'), fill)


def set_cell_border(cell, **kwargs):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcBorders = tcPr.first_child_found_in('w:tcBorders')
    if tcBorders is None:
        tcBorders = OxmlElement('w:tcBorders')
        tcPr.append(tcBorders)
    for edge in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        if edge in kwargs:
            tag = 'w:' + edge
            element = tcBorders.find(qn(tag))
            if element is None:
                element = OxmlElement(tag)
                tcBorders.append(element)
            for key in ('val', 'sz', 'space', 'color'):
                if key in kwargs[edge]:
                    element.set(qn('w:' + key), str(kwargs[edge][key]))


def set_cell_margins(cell, top=80, start=100, bottom=80, end=100):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcMar = tcPr.first_child_found_in('w:tcMar')
    if tcMar is None:
        tcMar = OxmlElement('w:tcMar')
        tcPr.append(tcMar)
    for m, v in [('top', top), ('start', start), ('bottom', bottom), ('end', end)]:
        node = tcMar.find(qn(f'w:{m}'))
        if node is None:
            node = OxmlElement(f'w:{m}')
            tcMar.append(node)
        node.set(qn('w:w'), str(v))
        node.set(qn('w:type'), 'dxa')


def set_repeat_table_header(row):
    trPr = row._tr.get_or_add_trPr()
    tblHeader = OxmlElement('w:tblHeader')
    tblHeader.set(qn('w:val'), 'true')
    trPr.append(tblHeader)


def set_table_width(table, widths: Sequence[float]):
    table.autofit = False
    for row in table.rows:
        for idx, width in enumerate(widths):
            row.cells[idx].width = Inches(width)
            tcPr = row.cells[idx]._tc.get_or_add_tcPr()
            tcW = tcPr.find(qn('w:tcW'))
            if tcW is None:
                tcW = OxmlElement('w:tcW')
                tcPr.append(tcW)
            tcW.set(qn('w:w'), str(int(width * 1440)))
            tcW.set(qn('w:type'), 'dxa')


def add_page_number(paragraph):
    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = paragraph.add_run('Page ')
    set_font(run, BODY_FONT, 8.5, color=GRAY)
    fldChar1 = OxmlElement('w:fldChar')
    fldChar1.set(qn('w:fldCharType'), 'begin')
    instrText = OxmlElement('w:instrText')
    instrText.set(qn('xml:space'), 'preserve')
    instrText.text = 'PAGE'
    fldChar2 = OxmlElement('w:fldChar')
    fldChar2.set(qn('w:fldCharType'), 'end')
    run2 = paragraph.add_run()
    run2._r.append(fldChar1)
    run2._r.append(instrText)
    run2._r.append(fldChar2)
    set_font(run2, BODY_FONT, 8.5, color=GRAY)


def set_alt_text(inline_shape, title: str, descr: str):
    try:
        docPr = inline_shape._inline.docPr
        docPr.set('title', title)
        docPr.set('descr', descr)
    except Exception:
        pass


def paragraph_bg(paragraph, fill: str):
    pPr = paragraph._p.get_or_add_pPr()
    shd = pPr.find(qn('w:shd'))
    if shd is None:
        shd = OxmlElement('w:shd')
        pPr.append(shd)
    shd.set(qn('w:fill'), fill)


def add_rule(paragraph, color=TEAL, size=12):
    pPr = paragraph._p.get_or_add_pPr()
    pBdr = pPr.find(qn('w:pBdr'))
    if pBdr is None:
        pBdr = OxmlElement('w:pBdr')
        pPr.append(pBdr)
    bottom = OxmlElement('w:bottom')
    bottom.set(qn('w:val'), 'single')
    bottom.set(qn('w:sz'), str(size))
    bottom.set(qn('w:space'), '1')
    bottom.set(qn('w:color'), color)
    pBdr.append(bottom)


def set_paragraph_spacing(p, before=0, after=5, line=1.05):
    fmt = p.paragraph_format
    fmt.space_before = Pt(before)
    fmt.space_after = Pt(after)
    fmt.line_spacing = line


def add_title(doc: Document, text: str, subtitle: str | None = None):
    p = doc.add_paragraph()
    p.style = doc.styles['Heading 1']
    p.paragraph_format.keep_with_next = True
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(4)
    r = p.add_run(text)
    set_font(r, HEAD_FONT, 22, bold=True, color=NAVY)
    add_rule(p, TEAL, 12)
    if subtitle:
        q = doc.add_paragraph()
        set_paragraph_spacing(q, after=7)
        set_font(q.add_run(subtitle), BODY_FONT, 9.5, italic=True, color=GRAY)
    return p


def add_h2(doc: Document, text: str):
    p = doc.add_paragraph()
    p.style = doc.styles['Heading 2']
    p.paragraph_format.keep_with_next = True
    p.paragraph_format.space_before = Pt(5)
    p.paragraph_format.space_after = Pt(3)
    set_font(p.add_run(text), HEAD_FONT, 13.5, bold=True, color=TEAL)
    return p


def add_body(doc: Document, text: str, *, bold_prefix: str | None = None, italic=False, color=DARK, size=9.25, after=4.0):
    p = doc.add_paragraph()
    set_paragraph_spacing(p, after=after, line=1.05)
    if bold_prefix and text.startswith(bold_prefix):
        set_font(p.add_run(bold_prefix), BODY_FONT, size, bold=True, color=color)
        set_font(p.add_run(text[len(bold_prefix):]), BODY_FONT, size, italic=italic, color=color)
    else:
        set_font(p.add_run(text), BODY_FONT, size, italic=italic, color=color)
    return p


def add_bullets(doc: Document, items: Iterable[str], *, level=0, size=8.9, after=2.0):
    for item in items:
        p = doc.add_paragraph(style='List Bullet' if level == 0 else 'List Bullet 2')
        set_paragraph_spacing(p, after=after, line=1.0)
        p.paragraph_format.left_indent = Inches(0.22 + level*0.18)
        p.paragraph_format.first_line_indent = Inches(-0.13)
        set_font(p.add_run(item), BODY_FONT, size, color=DARK)


def add_numbered(doc: Document, items: Iterable[str], *, size=8.8, after=1.8):
    for item in items:
        p = doc.add_paragraph(style='List Number')
        set_paragraph_spacing(p, after=after, line=1.0)
        p.paragraph_format.left_indent = Inches(0.24)
        p.paragraph_format.first_line_indent = Inches(-0.15)
        set_font(p.add_run(item), BODY_FONT, size, color=DARK)


def add_code(doc: Document, text: str, *, size=8.0, fill=NAVY, color=WHITE, after=5):
    t = doc.add_table(rows=1, cols=1)
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.autofit = False
    t.columns[0].width = Inches(6.85)
    c = t.cell(0,0)
    shade_cell(c, fill)
    set_cell_margins(c, top=110, bottom=110, start=140, end=140)
    set_cell_border(c, top={'val':'single','sz':'8','color':fill}, bottom={'val':'single','sz':'8','color':fill}, left={'val':'single','sz':'8','color':fill}, right={'val':'single','sz':'8','color':fill})
    p = c.paragraphs[0]
    p.paragraph_format.space_after = Pt(0)
    p.paragraph_format.line_spacing = 1.0
    for idx, line in enumerate(text.splitlines()):
        if idx:
            p.add_run().add_break()
        set_font(p.add_run(line), MONO_FONT, size, color=color)
    p_after = doc.add_paragraph()
    p_after.paragraph_format.space_after = Pt(after)
    return t


def add_callout(doc: Document, heading: str, text: str, *, color=TEAL, fill=LIGHT, size=9.0):
    t = doc.add_table(rows=2, cols=1)
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.autofit = False
    t.columns[0].width = Inches(6.85)
    h = t.cell(0,0); b = t.cell(1,0)
    shade_cell(h, color); shade_cell(b, fill)
    set_cell_margins(h, top=75, bottom=65, start=120, end=120)
    set_cell_margins(b, top=90, bottom=90, start=120, end=120)
    set_font(h.paragraphs[0].add_run(heading.upper()), HEAD_FONT, 9.1, bold=True, color=WHITE)
    set_font(b.paragraphs[0].add_run(text), BODY_FONT, size, color=DARK)
    for c in (h,b):
        set_cell_border(c, top={'val':'single','sz':'8','color':color}, bottom={'val':'single','sz':'8','color':color}, left={'val':'single','sz':'8','color':color}, right={'val':'single','sz':'8','color':color})
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
    return t


def add_table(doc: Document, headers: Sequence[str], rows: Sequence[Sequence[str]], widths: Sequence[float], *, font_size=7.8, header_color=NAVY, stripe=True, alignments: Sequence[str] | None = None):
    t = doc.add_table(rows=1, cols=len(headers))
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.autofit = False
    hdr = t.rows[0]
    set_repeat_table_header(hdr)
    for i,h in enumerate(headers):
        c=hdr.cells[i]
        shade_cell(c, header_color)
        set_cell_margins(c, top=70,bottom=70,start=80,end=80)
        set_font(c.paragraphs[0].add_run(str(h)), BODY_FONT, font_size, bold=True, color=WHITE)
        c.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
        set_cell_border(c, bottom={'val':'single','sz':'8','color':WHITE}, top={'val':'single','sz':'8','color':header_color}, left={'val':'single','sz':'5','color':header_color}, right={'val':'single','sz':'5','color':header_color})
    for r_idx,row in enumerate(rows):
        cells=t.add_row().cells
        if stripe and r_idx % 2 == 0:
            for c in cells: shade_cell(c, LIGHT)
        for i,value in enumerate(row):
            c=cells[i]
            set_cell_margins(c, top=60,bottom=60,start=75,end=75)
            p=c.paragraphs[0]
            if alignments:
                p.alignment = {'left':WD_ALIGN_PARAGRAPH.LEFT,'center':WD_ALIGN_PARAGRAPH.CENTER,'right':WD_ALIGN_PARAGRAPH.RIGHT}[alignments[i]]
            set_font(p.add_run(str(value)), BODY_FONT, font_size, color=DARK)
            c.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            set_cell_border(c, bottom={'val':'single','sz':'4','color':MID}, top={'val':'single','sz':'4','color':MID}, left={'val':'single','sz':'4','color':MID}, right={'val':'single','sz':'4','color':MID})
    set_table_width(t,widths)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
    return t


def add_figure(doc: Document, filename: str, width: float, caption: str, *, alt: str | None = None, cap_size=7.9):
    p=doc.add_paragraph()
    p.alignment=WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before=Pt(1)
    p.paragraph_format.space_after=Pt(2)
    shape=p.add_run().add_picture(str(FIG/filename), width=Inches(width))
    set_alt_text(shape, filename, alt or caption)
    c=doc.add_paragraph()
    c.alignment=WD_ALIGN_PARAGRAPH.CENTER
    set_paragraph_spacing(c,after=4,line=1.0)
    set_font(c.add_run(caption), BODY_FONT, cap_size, italic=True, color=GRAY)
    return shape


def page_break(doc: Document):
    p=doc.add_paragraph()
    p.add_run().add_break(WD_BREAK.PAGE)


def cover(doc: Document):
    t=doc.add_table(rows=1,cols=1)
    t.alignment=WD_TABLE_ALIGNMENT.CENTER
    c=t.cell(0,0)
    shade_cell(c,NAVY)
    set_cell_margins(c,top=300,bottom=260,start=260,end=260)
    p=c.paragraphs[0]
    set_font(p.add_run('UGTS-KC 4.3'),HEAD_FONT,29,bold=True,color=WHITE)
    p.add_run().add_break()
    set_font(p.add_run('CHESS FIXED-POINT AND PROOF RUNTIME'),HEAD_FONT,18,bold=True,color=CYAN)
    p.add_run().add_break()
    set_font(p.add_run('Orthodox rule kernel, exact three-piece solution and full-solution proof architecture'),BODY_FONT,11,color=WHITE)
    set_cell_border(c, top={'val':'single','sz':'16','color':NAVY}, bottom={'val':'single','sz':'16','color':NAVY}, left={'val':'single','sz':'16','color':NAVY}, right={'val':'single','sz':'16','color':NAVY})
    doc.add_paragraph().paragraph_format.space_after=Pt(2)
    add_figure(doc,'architecture_flow.png',6.9,'Figure 1. Chess is specialized into the canonical UGTS authority and proof flow.',alt='Diagram of typed chess position flowing through move support, compatibility, king-safety guard, verified proposal, atomic commit and proof lineage.')
    add_callout(doc,'Release result','The complete declared KQK, KRK, KBK, KNK and KPK three-piece profile is solved exactly. The orthodox 32-piece initial position is represented, tested and explicitly recorded as UNRESOLVED rather than assigned an unsupported result.',color=GOLD,fill='FFF8E6',size=9.4)
    t2=doc.add_table(rows=4,cols=2)
    t2.alignment=WD_TABLE_ALIGNMENT.CENTER
    rows=[('Prepared for','Tom Klootwijk'),('Version','4.3.0'),('Generated','29 August 2026'),('Release schema','ugts-kc-chess-4.3')]
    for i,(a,b) in enumerate(rows):
        c1,c2=t2.rows[i].cells
        shade_cell(c1,LIGHT)
        set_font(c1.paragraphs[0].add_run(a),BODY_FONT,8.4,bold=True,color=NAVY)
        set_font(c2.paragraphs[0].add_run(b),BODY_FONT,8.4,color=DARK)
        for cc in (c1,c2):
            set_cell_margins(cc,top=55,bottom=55,start=70,end=70)
            set_cell_border(cc,bottom={'val':'single','sz':'3','color':MID},top={'val':'single','sz':'3','color':MID},left={'val':'single','sz':'3','color':MID},right={'val':'single','sz':'3','color':MID})
    set_table_width(t2,[1.8,5.05])


def configure(doc: Document):
    sec=doc.sections[0]
    sec.page_width=Cm(21.0); sec.page_height=Cm(29.7)
    sec.top_margin=Inches(0.55); sec.bottom_margin=Inches(0.52); sec.left_margin=Inches(0.67); sec.right_margin=Inches(0.67)
    sec.header_distance=Inches(0.22); sec.footer_distance=Inches(0.22)
    sec.different_first_page_header_footer=True
    normal=doc.styles['Normal']
    normal.font.name=BODY_FONT; normal.font.size=Pt(9.25)
    normal._element.rPr.rFonts.set(qn('w:ascii'),BODY_FONT); normal._element.rPr.rFonts.set(qn('w:hAnsi'),BODY_FONT)
    for style_name in ('Title','Heading 1','Heading 2','Heading 3'):
        s=doc.styles[style_name]
        s.font.name=HEAD_FONT
        s._element.rPr.rFonts.set(qn('w:ascii'),HEAD_FONT); s._element.rPr.rFonts.set(qn('w:hAnsi'),HEAD_FONT)
    header=sec.header
    hp=header.paragraphs[0]
    hp.alignment=WD_ALIGN_PARAGRAPH.LEFT
    set_font(hp.add_run('UGTS-KC 4.3 | Chess Fixed-Point and Proof Runtime'),BODY_FONT,8.3,bold=True,color=TEAL)
    add_rule(hp,TEAL,6)
    fp=sec.footer.paragraphs[0]
    t=sec.footer.add_table(rows=1,cols=3,width=Inches(7.0))
    t.alignment=WD_TABLE_ALIGNMENT.CENTER
    set_table_width(t,[2.4,2.2,2.4])
    set_font(t.cell(0,0).paragraphs[0].add_run('Tom Klootwijk - requester-supplied attribution'),BODY_FONT,7.5,color=GRAY)
    t.cell(0,1).paragraphs[0].alignment=WD_ALIGN_PARAGRAPH.CENTER
    set_font(t.cell(0,1).paragraphs[0].add_run('Version 4.3.0'),BODY_FONT,7.5,color=GRAY)
    add_page_number(t.cell(0,2).paragraphs[0])
    sec.first_page_footer.paragraphs[0].text=''
    # Metadata
    doc.core_properties.title='UGTS-KC 4.3 - Chess Fixed-Point and Proof Runtime'
    doc.core_properties.subject='Orthodox chess rule kernel, exact three-piece tablebase and proof architecture'
    doc.core_properties.author='OpenAI, prepared for Tom Klootwijk'
    doc.core_properties.keywords='UGTS, chess, fixed point, tablebase, proof, retrograde, deterministic replay'


def build():
    doc=Document()
    configure(doc)
    cover(doc)
    page_break(doc)

    # Page 2
    add_title(doc,'1. Executive Decision and Solution Boundary','The word solve is treated as a proof obligation, not as a heuristic engine score.')
    add_callout(doc,'Decision - GO','Represent orthodox chess as a finite typed state-transition graph. Admit exact WDL/DTM labels only when all legal successor obligations are closed under a declared rule profile. Retain UNKNOWN/UNRESOLVED as first-class results when proof coverage is incomplete.',color=GREEN,fill='EAF7F0',size=9.4)
    add_figure(doc,'solution_scope.png',6.75,'Figure 2. Exact, bounded and unresolved results are separated in the release schema.',alt='Three status bands: exact, bounded and unresolved, with initial chess position unresolved.')
    add_h2(doc,'Measured release result')
    add_table(doc,['Item','Result','Meaning'],[
        ('Chess mechanisms','64 (M886-M949)','Eight typed domains; 52 executable reference records and 12 advanced contracts.'),
        ('Exact tablebase','367,868 canonical states','Complete admitted KQK, KRK, KBK, KNK and KPK profile.'),
        ('Graph coverage','3,217,270 directed edges','Every internal legal successor in the closed three-piece graph.'),
        ('Binary payload','2,207,264 bytes','Compact exact WDL/DTM table plus section metadata.'),
        ('Automated verification','31/31 tests PASS','Rule, perft, replay, fixed-point, tablebase, catalog and CLI checks.'),
        ('Initial position','UNRESOLVED','Depth-three bounded proof visits 9,323 nodes and returns unknown.'),
    ],[1.45,1.55,3.85],font_size=7.65)
    add_body(doc,'A complete solution of the full initial position is not claimed. The release instead supplies a correct proof machine, an exact solved domain and a machine-readable route for extending proof coverage without silently promoting guesses.')
    page_break(doc)

    # Page 3
    add_title(doc,'2. Contents and Source Continuity','The chess profile is additive: it specializes retained definitions, order, event authority and replay.')
    add_table(doc,['Section','Purpose'],[
        ('1-3','Decision, scope, source basis and chess state identity.'),('4-7','Move authority, orthodox rules and legal-move validation.'),
        ('8-12','Fixed-point proof calculus, tablebase construction and exact probes.'),('13-16','Replay, bounded proof search, operator catalog and scaling plan.'),
        ('17-20','Kill criteria, reproduction, sources and final definition.'),
    ],[1.0,5.85],font_size=8.1)
    add_figure(doc,'source_stack.png',6.8,'Figure 3. UGTS-KC 4.3 specializes the retained authority chain rather than replacing it.',alt='Layered source stack from UGTS-GN 1.1 through UGTS-KC 4.2 and the new chess profile.')
    add_h2(doc,'Source-derived commitments')
    add_bullets(doc,[
        'UGTS-KC 4.2 supplies typed operators, fixed points, proof obligations, canonical exchange and deterministic state authority [S1].',
        'KC Elizabeth 3.9 supplies deterministic game state, fixed-step discipline, canonical snapshots, hashes and replay [S2].',
        'KC Two Hands 3.0 supplies verified proposals, atomic commit, checkpoints and divergence detection [S3].',
        'UGTS-KC 3.6 supplies content-addressed definitions, dependency closure and explicit operation order [S4].',
        'FIDE Laws, published perft counts and Syzygy are external rules/validation/adapter sources [S5-S7].',
    ],size=8.6)
    add_callout(doc,'Evidence boundary','Source continuity justifies the architecture. It does not by itself solve a chess state. Every game-theoretic label must still be discharged by legal graph coverage or a complete proof certificate.',color=CORAL,fill='FBEFED',size=8.8)
    page_break(doc)

    # Page 4
    add_title(doc,'3. Formal Chess State and Identity','A board diagram is a projection. Complete state includes rights, clocks and lineage.')
    add_code(doc,'q = (B, s, C, e, h, m, R, P, L)\n\nB : 64-square occupancy map          s : side to move\nC : castling rights                  e : en-passant relation\nh : halfmove clock                   m : fullmove number\nR : repetition lineage               P : rule / solver profile\nL : event and proof lineage',size=8.35)
    add_table(doc,['Field','Typed meaning','Why it matters'],[
        ('B','Piece code or empty on each square','Defines geometry and occupancy but not the complete legal state.'),
        ('s','White or Black','Changes which moves and attacks are authoritative.'),
        ('C','Subset of KQkq','Two identical placements can differ in castling legality.'),
        ('e','Square or none','Retained only when created by a double pawn move; repetition key keeps it only when a legal capture exists.'),
        ('h / m','Non-negative clocks','Drive claimable/automatic draw status and exchange semantics.'),
        ('R','Canonical repetition multiset/order','Coordinates alone cannot certify repeated-position conditions.'),
        ('P / L','Versioned rule profile and lineage','Freeze semantics, proof scope, transitions and audit history.'),
    ],[0.8,2.05,4.0],font_size=7.55)
    add_h2(doc,'Canonical exchange')
    add_code(doc,'Initial FEN:\nrnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1\n\nMove exchange: e2e4  |  promotion: a7a8q',size=8.0,fill=DARK)
    add_callout(doc,'Identity invariant','The same board placement with a different side, castling right, legal en-passant capture, halfmove clock or repetition history may have a different successor relation or game-theoretic value.',color=GOLD,fill='FFF8E6',size=8.8)
    page_break(doc)

    # Page 5
    add_title(doc,'4. Canonical Move Authority and Operation Order','The 4.2 phase schedule is specialized rather than hidden inside a move generator.')
    add_figure(doc,'phase_pipeline.png',6.9,'Figure 4. Fifteen explicit phases separate parsing, construction, guards, commit, lineage and projection.',alt='Fifteen chess evaluation phases from parse to projection.')
    add_h2(doc,'Authoritative move predicate')
    add_code(doc,'verified_move = origin_support_ok\n             and piece_geometry_ok\n             and occupancy_compatibility_ok\n             and special_rights_ok\n             and king_safety_guard_ok\n             and pre_hash_matches_authority\n             and numeric_error <= event_margin',size=8.35)
    add_body(doc,'Candidate generation may be parallel or heuristic. State mutation is not. A move becomes authoritative only after deterministic verification against the current immutable position and rule profile.')
    add_callout(doc,'Non-commutative order','Applying a move before the king-safety guard, changing castling rights after repetition hashing, or normalizing en-passant state without checking legal capture availability changes semantics. Order is part of the proof.',color=CORAL,fill='FBEFED',size=8.8)
    page_break(doc)

    # Page 6
    add_title(doc,'5. Orthodox Rule Kernel and Draw Semantics','The dependency-free kernel handles ordinary moves and the stateful exceptions that often break solvers.')
    add_table(doc,['Rule family','Implemented relation / guard','Boundary'],[
        ('Pawn','Single/double push, diagonal capture, en passant, four promotions','En-passant discovered-check is rejected by post-move king safety.'),
        ('Knight','Eight bounded jumps','Destination must be empty or hold an opponent non-king piece.'),
        ('Bishop/Rook/Queen','Ordered rays with first blocker','No move may jump through an occupied square.'),
        ('King','Eight neighbors plus castling','Destination and castling transit squares must not be attacked.'),
        ('Check/mate','Opponent attack on king + legal successor set','Checkmate is no legal move while in check; stalemate is no legal move while not in check.'),
        ('Repetition','Canonical placement, side, castling, legal ep possibility','Threefold is claimable; fivefold is automatic under the selected FIDE profile.'),
        ('Move clock','Pawn/capture resets, otherwise increment','Fifty moves is claimable; seventy-five moves is automatic; checkmate takes precedence.'),
        ('Dead position','Selected exact material certificates','True is exact; false is not a proof that mate is possible.'),
    ],[0.9,3.0,2.95],font_size=7.35)
    add_h2(doc,'Terminal precedence')
    add_code(doc,'1. Generate all legal moves.\n2. If none: checkmate if in check, otherwise stalemate.\n3. Evaluate exact dead-position certificates.\n4. Evaluate fivefold / seventy-five-move automatic draws.\n5. Expose threefold / fifty-move claim actions as claimable status.',size=8.1)
    add_callout(doc,'Rule profile boundary','The generic full game graph must model claimable draws as explicit player actions. The exact bundled three-piece tablebase uses a zero-clock, no-castling profile so its graph remains finite and closed under the declared semantics.',color=GOLD,fill='FFF8E6',size=8.8)
    page_break(doc)

    # Page 7
    add_title(doc,'6. Exact Legal-Move Validation','Perft counts validate the successor relation without relying on an evaluation function.')
    add_figure(doc,'validation_perft.png',6.75,'Figure 5. UGTS-KC 4.3 matches published leaf-node counts on the tested depths.',alt='Log-scale line chart showing exact agreement between published and computed perft counts.')
    add_table(doc,['Position','Depths checked','Expected / actual highest depth','Coverage stress'],[
        ('Initial','1-4','197,281 / 197,281','Ordinary development, checks and early captures.'),
        ('Kiwipete','1-3','97,862 / 97,862','Castling, pins, checks and dense tactical branches.'),
        ('Position 3','1-4','43,238 / 43,238','En passant, checks, rook/pawn geometry and unusual king exposure.'),
        ('Position 4','1-3','9,467 / 9,467','Castling rights, promotions and tactical legality.'),
    ],[1.0,1.0,1.8,3.05],font_size=7.75)
    add_h2(doc,'Validation interpretation')
    add_body(doc,'Perft agreement is a strong legality regression test: it checks the exact number of legal move paths. It does not prove strategic correctness by itself, but a fixed-point proof built on an incorrect successor relation would be invalid, so this gate is mandatory.')
    add_callout(doc,'Current captured result','31 unit tests pass. Compile checks, JSON parsing, catalog continuity, tablebase hashes and three independent perft cases also pass in the release validator.',color=GREEN,fill='EAF7F0',size=8.8)
    page_break(doc)

    # Page 8
    add_title(doc,'7. Exact Fixed-Point Solution Calculus','Chess becomes solvable on any finite, complete and closed state graph.')
    add_figure(doc,'fixed_point.png',6.75,'Figure 6. The least fixed point propagates win and loss from terminal losses; the remaining complement is draw.',alt='Diagram of terminal losses, draws and legal successor graph propagating win, loss and draw fixed points.')
    add_code(doc,'W_(n+1) = W_n union { p | exists q in Succ(p): q in L_n }\nL_(n+1) = L_n union { p | Succ(p) nonempty and every q in Succ(p) lies in W_(n+1) }\n\nDTM(win p)  = 1 + min DTM(loss successor)\nDTM(loss p) = 1 + max DTM(win successor)',size=8.0,fill=DARK)
    add_body(doc,'Values are always relative to the player to move. A strong-side win is derived afterward from side-to-move value, color normalization and material ownership. This avoids silently confusing a losing side-to-move node with a losing material class.')
    add_callout(doc,'Closure requirement','The draw complement is exact only when the partition is complete and closed, all terminal rules are explicit, and every legal successor has been represented. Otherwise the correct result is UNKNOWN.',color=CORAL,fill='FBEFED',size=8.8)
    page_break(doc)

    # Page 9
    add_title(doc,'8. Proof Obligations and Certificate Semantics','A proof is not a principal variation alone; obligations differ by value.')
    add_figure(doc,'proof_dag.png',6.65,'Figure 7. Winning, losing and drawn nodes require different quantified evidence.',alt='Proof obligation diagram: winning proof needs one losing successor, losing proof needs every successor winning, draw needs a closed argument.')
    add_table(doc,['Claim','Required certificate','Invalid shortcut'],[
        ('WIN','At least one verified legal move to a LOSS node, recursively certified.','A positive heuristic score or one attractive line.'),
        ('LOSS','Every verified legal move leads to a WIN node, with complete successor coverage.','Showing only the opponent best reply.'),
        ('DRAW','Solved complement, closed invariant, or complete cycle/terminal argument under the rule profile.','No mate found at a finite search horizon.'),
        ('UNKNOWN','Proof budget or graph coverage ended before an obligation closed.','Silently coercing the result to draw.'),
    ],[0.8,3.45,2.7],font_size=7.75)
    add_h2(doc,'Certificate identity')
    add_code(doc,'certificate_hash = SHA256(canonical JSON of\n  root hash + rule profile + solver profile + obligations + child hashes + status)\n\nA hash detects change/divergence; full proof content remains authoritative.',size=8.0)
    add_callout(doc,'Replay and proof DAG sharing','Transpositions share canonical nodes. Event replay checks pre/post hashes; proof replay checks child obligations and content hashes. Neither digest replaces the underlying state, legal-move set or lineage.',color=PURPLE,fill='F1EEFA',size=8.8)
    page_break(doc)

    # Page 10
    add_title(doc,'9. Exact Three-Piece Tablebase Construction','The release solves a complete symmetry-reduced graph, not a sampled set of positions.')
    add_numbered(doc,[
        'Enumerate legal KQK, KRK, KBK, KNK and KPK states with the extra piece normalized to White.',
        'Reject adjacent kings, missing kings, impossible occupancy and illegal predecessor/check states.',
        'Normalize non-pawn positions under the eight D4 board symmetries; normalize pawn positions by file reflection only.',
        'Generate every legal successor, including pawn promotion into queen, rook, bishop or knight sections.',
        'Build exact predecessor lists and terminal checkmate seeds.',
        'Run the monotone W/L fixed point; classify the unmarked closed complement as draw.',
        'Propagate DTM with min on wins and max on losses.',
        'Write sorted canonical keys and compact values; probe through the same canonicalization contract.',
    ],size=8.45,after=1.6)
    add_table(doc,['Profile field','Value'],[
        ('Profile ID','orthodox-three-piece-zero-clock-no-castling-v1'),
        ('Material classes','KQK, KRK, KBK, KNK, KPK with all promotions'),
        ('Color normalization','Extra piece belongs to White; color-swapped positions are isomorphic'),
        ('Symmetry','D4 for Q/R/B/N; file reflection for P'),
        ('Canonical states','367,868'),('Internal directed edges','3,217,270'),('Terminal checkmates','73'),
        ('Build evidence','16.766 s in the captured run; deterministic sorted output'),
    ],[2.05,4.8],font_size=7.7)
    add_callout(doc,'Scope boundary','Castling rights are absent, the halfmove clock begins at zero, and the table is not promoted as a solution of the 32-piece initial position. The profile is explicit in every probe result.',color=GOLD,fill='FFF8E6',size=8.8)
    page_break(doc)

    # Page 11
    add_title(doc,'10. Exact Three-Piece Results','Every value below is generated from the closed graph and stored in the bundled binary tablebase.')
    add_figure(doc,'tb_states.png',6.6,'Figure 8. Exact strong-side wins and draws by material class.',alt='Stacked bar chart of canonical states split into strong-side win and draw for KQK, KRK, KBK, KNK and KPK.')
    add_figure(doc,'tb_dtm.png',6.2,'Figure 9. Maximum exact distance to mate in plies.',alt='Bar chart showing maximum DTM 20 for KQK, 32 for KRK, 0 for KBK, 0 for KNK and 56 for KPK.')
    data=json.loads((ROOT/'data'/'tb3_summary.json').read_text())['sections']
    rows=[]
    for c,name in [('Q','KQK'),('R','KRK'),('B','KBK'),('N','KNK'),('P','KPK')]:
        d=data[c]
        rows.append((name,f"{d['canonical_states']:,}",f"{d['strong_side_win']:,}",f"{d['draw']:,}",str(d['max_dtm_plies'])))
    add_table(doc,['Class','States','Strong-side win','Draw','Max DTM'],rows,[0.75,1.2,1.55,1.2,1.0],font_size=7.6,alignments=['left','right','right','right','right'])

    # Page 12
    add_title(doc,'11. Worked Exact Probes','These positions are witnesses for the longest DTM values in the shipped profile.')
    add_figure(doc,'board_examples.png',6.85,'Figure 10. Exact KQK, KRK and KPK longest-line examples after canonicalization.',alt='Three chessboards showing longest DTM examples for queen, rook and pawn endgames.')
    add_table(doc,['FEN','Side-to-move value','Strong-side value','DTM / best move'],[
        ('8/8/8/8/4k3/8/1Q6/K7 b - - 0 1','LOSS','White WIN','20 plies; e4f5 delays mate'),
        ('8/8/8/8/8/8/1Rk5/K7 b - - 0 1','LOSS','White WIN','32 plies; exact longest KRK class'),
        ('8/8/8/k7/8/K7/6P1/8 b - - 0 1','LOSS','White WIN','56 plies; exact longest KPK class'),
    ],[3.1,1.2,1.15,1.4],font_size=7.35)
    add_h2(doc,'Probe semantics')
    add_bullets(doc,[
        'side_to_move_value is the local minimax value at the queried node.',
        'strong_side_value translates the local result back to the side owning the extra piece.',
        'dtm_plies is exact under the table profile; best moves maximize survival in LOSS and minimize mate length in WIN.',
        'A successful probe returns the canonical key, material section, color-swap flag and profile boundary.',
    ],size=8.5)
    add_callout(doc,'Drawn material classes','Every admitted legal KBK and KNK state is drawn. KQK and KRK still contain drawn states where the extra piece is capturable, lost, or the position terminates without mate.',color=TEAL,fill='EAF7F7',size=8.8)
    page_break(doc)

    # Page 13
    add_title(doc,'12. Move Proposals, Atomic Commit and Replay','Search, tablebases and humans may propose; one deterministic boundary changes state.')
    add_figure(doc,'event_authority.png',6.85,'Figure 11. Parallel detection feeds a single verified, ordered and hash-checked commit path.',alt='Diagram of human, search and external adapter proposals flowing through verifier, stable order, conflict policy, atomic commit and lineage.')
    add_h2(doc,'Runtime event record')
    add_code(doc,'RuntimeEvent = {\n  sequence, proposal_id, uci, source,\n  pre_hash, post_hash, repetition_key,\n  halfmove_clock, fullmove_number,\n  terminal_kind, winner, event_hash\n}',size=7.9)
    add_body(doc,'The demonstration commits e2e4, e7e5, g1f3, b8c6 and f1b5. Replay starts from the initial position, recomputes every legal move and halts at the first pre-hash, post-hash or event-hash mismatch.')
    add_callout(doc,'Authority invariant','Unchecked GPU writes, stale tablebase probes, UI animations and heuristic lines never mutate the chess state. A proposal whose pre-hash does not match the current authority is rejected.',color=CORAL,fill='FBEFED',size=8.8)
    page_break(doc)

    # Page 14
    add_title(doc,'13. Bounded Proof Search and Initial-Position Status','Finite-horizon search remains useful when its epistemic boundary is machine-readable.')
    add_table(doc,['Example','Depth','Nodes','Result','Certificate'],[
        ('Mate in one: 7k/8/6K1/8/8/8/5Q2/8 w - - 0 1','1','30','WIN in 1 ply','Best move f2f8; terminal proof closed.'),
        ('Orthodox initial position','3','9,323','UNKNOWN','No full-game value inferred.'),
    ],[2.8,0.55,0.75,0.9,1.85],font_size=7.5)
    add_code(doc,'if terminal: return exact terminal value\nif depth == 0: return UNKNOWN\nif any child is LOSS: return WIN\nif all children are WIN: return LOSS\nif all children are WIN or DRAW and at least one DRAW: return DRAW\notherwise: return UNKNOWN',size=7.95)
    add_callout(doc,'Initial-position release status','UNRESOLVED under full strong-solution scope. The position is fully represented, legal moves are validated, and a bounded proof certificate is emitted. This is an explicit result, not a refusal or a hidden heuristic.',color=CORAL,fill='FBEFED',size=9.1)
    add_h2(doc,'Why depth-limited no-mate is not draw')
    add_body(doc,'A draw claim quantifies over all possible future play or establishes a closed repetition/terminal invariant. Reaching a search horizon only proves that the selected proof budget ended. The runtime therefore keeps UNKNOWN separate from DRAW in APIs, JSON and tests.')
    page_break(doc)

    # Page 15
    add_title(doc,'14. Operator Catalog M886-M949','Chess receives a contiguous 64-mechanism namespace without renumbering the retained 4.2 catalog.')
    add_figure(doc,'mechanism_domains.png',6.55,'Figure 12. Eight domains contain eight mechanisms each; implemented and contract-only status stays visible.',alt='Stacked bars showing eight chess operator domains with implemented and specified-contract mechanisms.')
    add_table(doc,['Range','Domain','Representative mechanisms'],[
        ('M886-M893','Chess state and rule schema','Rule profile, squares, pieces, occupancy, side, castling, ep, clocks and repetition.'),
        ('M894-M901','Move geometry and support','Pawn, knight, sliders, king, castling path, attacks and first blocker.'),
        ('M902-M909','Legality and transitions','Pseudo moves, support, compatibility, king safety, proposals and atomic transition.'),
        ('M910-M917','Terminal and draw calculus','Check, mate, stalemate, dead-position contract, clocks, repetition and precedence.'),
        ('M918-M925','Canonicalization and symmetry','FEN/UCI, repetition keys, hashes, D4, color swap and transposition DAG.'),
        ('M926-M933','Game solving and fixed points','Finite graph, minimax, retrograde, WDL, DTM, bounded proof and frontier schedule.'),
        ('M934-M941','Proof, validation and status','Proof nodes, strategy certificates, perft, conformance, replay and unresolved status.'),
        ('M942-M949','Scaling and UGTS handoff','Packed profiles, partitioning, joins, compression, Syzygy/GPU contracts and kill criteria.'),
    ],[1.0,1.75,4.1],font_size=7.15)
    add_body(doc,'Catalog meaning: Mechanism IDs provide traceability, typed contracts and validation status. They are not by themselves claims of novelty, patentability or a solved initial chess position.',bold_prefix='Catalog meaning:',size=8.0,after=0)
    page_break(doc)

    # Page 16
    add_title(doc,'15. Scaling Toward a Full Strong Solution','The exact three-piece release is a base partition in a larger proof DAG.')
    add_figure(doc,'scaling_path.png',6.85,'Figure 13. Promotion of the initial position occurs only after all quantified move obligations are discharged.',alt='Eight-step path from freezing rules and verifying tablebases to merging proof DAGs and promoting the initial position.')
    add_h2(doc,'External tablebase adapter')
    add_body(doc,'The M946 contract accepts external Syzygy WDL/DTZ partitions only after profile, material, file checksum, probe result and 50-move semantics are verified. The public Syzygy generator supports endgame tablebases through seven pieces, but those datasets are not redistributed in this compact release [S7].')
    add_h2(doc,'Full-solution work partition')
    add_bullets(doc,[
        'Partition by material, pawn structure, castling rights, en-passant state and symmetry orbit.',
        'Reject any slice with incomplete predecessor or successor coverage.',
        'Use exact retrograde on closed slices and proof-number/minimax frontier work on open higher-material regions.',
        'Share transpositions through canonical content hashes and merge only under deterministic conflict policy.',
        'Use heuristic engines solely to order work; never as proof authority.',
    ],size=8.55)
    add_callout(doc,'Promotion gate','The initial position receives WIN, LOSS or DRAW only when its root obligation and every required descendant obligation reference complete verified certificates under the frozen rule profile.',color=GREEN,fill='EAF7F0',size=8.8)
    page_break(doc)

    # Page 17
    add_title(doc,'16. Storage, Error Contracts and Kill Criteria','Compression is admitted only when semantics, decode cost and proof reconstructibility remain explicit.')
    add_table(doc,['Record','Current release','Boundary'],[
        ('Three-piece table','2,207,264-byte binary; SHA-256 checked','Exact only for the declared zero-clock/no-castling profile.'),
        ('Position hash','Canonical JSON SHA-256','Divergence/integrity signal, not a substitute for full state or legal proof.'),
        ('Repetition key','Placement + side + rights + legally relevant ep','Clocks excluded by repetition law; lineage counts remain external.'),
        ('Symmetry key','D4 or file reflection canonical representative','Only transformations preserving piece movement and profile semantics are admitted.'),
        ('Proof DAG','Content-addressed obligations and child hashes','A compressed certificate must still reconstruct every quantified obligation.'),
        ('External oracle','Profile + checksum + probe result','Rejected when rule semantics, files or successor consistency do not match.'),
    ],[1.35,2.55,2.95],font_size=7.45)
    add_h2(doc,'Solver kill criteria')
    add_bullets(doc,[
        'A legal move, predecessor or terminal action is missing from a claimed closed partition.',
        'Castling, en-passant, repetition or draw semantics are implicit or disagree across joined partitions.',
        'Canonicalization merges non-isomorphic states or a content hash fails verification.',
        'Compression or packed precision changes move legality, event order, WDL or DTM.',
        'A heuristic score, principal variation or finite search horizon is promoted as a strong proof.',
        'Graph/frontier density, merge conflicts or proof storage exceed the declared budget without an explicit UNKNOWN result.',
        'A conventional verified solver is simpler, faster or more auditable at equal proof coverage.',
    ],size=8.45)
    add_callout(doc,'Evidence rule','Failure of a promotion gate does not prove draw or impossibility. It returns a reason-coded incomplete/unknown status and preserves the last verified boundary.',color=CORAL,fill='FBEFED',size=8.8)
    page_break(doc)

    # Page 18
    add_title(doc,'17. Package Layout, Reproduction and Validation','The source, table, examples, tests and evidence are shipped together.')
    add_table(doc,['Path','Contents'],[
        ('src/ugts_chess43/','Immutable position/move records, rules, canonical identities, proposal/commit/replay, search and three-piece tablebase.'),
        ('data/','Exact binary tablebase and machine-readable build summary.'),
        ('spec/','Formal definition, M886-M949 CSV/JSON catalog, rule profiles, schema and source register.'),
        ('examples/','Initial UNKNOWN certificate, mate-in-one proof, event replay and exact tablebase probe.'),
        ('tests/','31 tests spanning move rules, perft, special moves, terminal states, replay, fixed points, tablebase, catalog and CLI.'),
        ('validation/','Captured test output, perft checks, compile/JSON gates and hashes.'),
        ('report/','This editable DOCX and derived PDF.'),
        ('checksums/','SHA-256 manifest and release summary.'),
    ],[1.45,5.4],font_size=7.55)
    add_h2(doc,'Reproduction commands')
    add_code(doc,'cd UGTS_KC_4_3_CHESS\nPYTHONPATH=src python -m unittest discover -s tests -v\nPYTHONPATH=src python examples/demo.py\nPYTHONPATH=src python -m ugts_chess43 build-tb3 data/tb3_orthodox_zero_clock.bin --summary data/tb3_summary.json\npython tools/generate_spec.py\npython tools/validate_release.py',size=7.55)
    add_table(doc,['Gate','Captured result'],[
        ('Python compile','PASS'),('Automated tests','31/31 PASS'),('Perft reference checks','PASS'),('Catalog continuity','M886-M949, 64 unique hashes'),
        ('Tablebase integrity','2,207,264 bytes; SHA-256 16a9c6f7...c035'),('JSON/schema records','Parse and validation gates PASS'),
    ],[2.25,4.6],font_size=7.8)
    add_body(doc,'Reproducibility boundary: Regeneration is deterministic under the same specified Python semantics and sorted canonical key order. Cross-implementation identity still requires the same rule profile, canonicalization and binary format.',bold_prefix='Reproducibility boundary:',size=7.9,after=0)
    page_break(doc)

    # Page 19
    add_title(doc,'18. Source Register and Normative References','External standards are cited for rule semantics and validation; UGTS documents supply the architectural basis.')
    add_table(doc,['ID','Source','Release use'],[
        ('S1','UGTS-KC 4.2 General Operator and Order Addendum','Typed operators, fixed points, proof obligations, deterministic order and canonical exchange.'),
        ('S2','UGTS-KC 3.9 KC Elizabeth Vector Game Runtime','Deterministic game state, snapshots, hashes, replay and headless validation.'),
        ('S3','UGTS-KC Two Hands 3.0','Proposal verification, atomic commit, checkpoints and divergence detection.'),
        ('S4','UGTS-KC 3.6 Literal Referential Substrate','Content-addressed definitions, dependencies and explicit operation order.'),
        ('S5','FIDE Laws of Chess effective 1 January 2023','Orthodox move, terminal, repetition and move-count rule profile.'),
        ('S6','Chess Programming Wiki - Perft Results','Published legal move-path reference counts used in regression tests.'),
        ('S7','syzygy1/tb - Chess endgame tablebase generator','External WDL/DTZ adapter target and seven-piece boundary.'),
    ],[0.45,2.65,3.75],font_size=7.45)
    add_h2(doc,'Reference locations')
    refs=[
        '[S5] https://handbook.fide.com/chapter/e012023',
        '[S6] https://www.chessprogramming.org/Perft_Results',
        '[S7] https://github.com/syzygy1/tb',
    ]
    for ref in refs:
        add_body(doc,ref,size=8.15,after=2.2,color=GRAY)
    add_h2(doc,'Attribution and evidence notice')
    add_body(doc,'Prepared for Tom Klootwijk as UGTS-KC 4.3. The requester-supplied name and project attribution are recorded for continuity and are not independently verified. This technical package is not legal proof of identity, authorship, ownership, patentability, priority, standard conformance or chain of title.')
    add_body(doc,'External URLs and public chess reference data are not silently relicensed by this package. The included implementation and generated table are original engineering artifacts built for this release; see NOTICE.md for the package boundary.')
    add_callout(doc,'Scientific boundary','The release demonstrates executable internal consistency, exact results inside a declared finite profile and a falsifiable path toward larger proofs. It does not establish the game-theoretic value of the initial position.',color=GOLD,fill='FFF8E6',size=8.8)
    page_break(doc)

    # Page 20
    add_title(doc,'19. Final Formal Definition and Release Decision','The solved object is a typed proof state, not a rendered board or an engine evaluation.')
    add_callout(doc,'Formal definition','UGTS-KC 4.3 is a content-addressed orthodox-chess profile in which a complete position state defines a deterministic legal successor relation; every move passes through support, compatibility and king-safety guards; verified proposals commit immutable state patches with repetition and replay lineage; finite closed partitions are solved by a least W/L fixed point with exact DTM; bounded searches return UNKNOWN when obligations remain open; and only complete hash-checked proof certificates may promote a root to WIN, LOSS or DRAW.',color=TEAL,fill='EAF7F7',size=9.15)
    add_code(doc,'UGTS-CHESS = (Q, M, A, G, T, R, V, C, L)\n\nQ : typed position states\nM : deterministic legal move relation\nA : attack and king-safety relations\nG : terminal and draw guards\nT : atomic transitions\nR : repetition and rule-profile state\nV : WDL / DTM fixed-point values\nC : proof certificates and validation evidence\nL : event, replay and proof lineage',size=8.05)
    add_h2(doc,'Release decision')
    add_bullets(doc,[
        'GO: the orthodox rule kernel, event authority and fixed-point proof runtime are coherent and executable.',
        'SOLVED: the complete declared KQK, KRK, KBK, KNK and KPK three-piece domain.',
        'BOUNDED: finite-horizon proof search and selected dead-material certificates.',
        'UNRESOLVED: the game-theoretic value of the orthodox 32-piece initial position.',
        'NEXT PROMOTION GATE: verified external endgame partitions and a content-addressed all-material proof DAG.',
    ],size=9.0,after=2.8)
    add_callout(doc,'Final statement','Chess has been converted into an explicit UGTS proof problem and solved exactly where this release closes the full legal graph. No unsupported whole-game result is substituted for the remaining proof work.',color=GREEN,fill='EAF7F0',size=9.5)

    doc.save(OUT)
    print(OUT)

if __name__=='__main__':
    build()
