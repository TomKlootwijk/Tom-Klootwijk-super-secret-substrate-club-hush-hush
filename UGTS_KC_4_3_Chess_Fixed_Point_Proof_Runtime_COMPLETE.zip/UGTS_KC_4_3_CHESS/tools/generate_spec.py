from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

DOMAINS = [
    ("Chess state and rule schema", [
        ("profile.orthodox-chess-v1", "Orthodox chess rule profile", "{} -> rule profile", "Binds board geometry, piece types, move rights, draw actions, terminal precedence and certificate semantics to a versioned profile."),
        ("state.square-v1", "Square coordinate", "file x rank -> square", "Represents one of 64 board squares with a1=0 and explicit file/rank conversion."),
        ("state.piece-v1", "Typed chess piece", "color x kind -> piece", "Defines king, queen, rook, bishop, knight and pawn as color-qualified piece sorts."),
        ("state.board-v1", "Board occupancy record", "Square -> Piece or Empty", "Stores exactly one occupancy value per square and rejects duplicate placement."),
        ("state.turn-v1", "Side-to-move state", "position -> color", "Makes alternation and move authority explicit rather than inferred from move count."),
        ("state.castling-rights-v1", "Castling-rights state", "position -> subset[KQkq]", "Stores revocable rights separately from current king and rook coordinates."),
        ("state.en-passant-v1", "En-passant relation state", "position -> square or none", "Stores the one-ply target relation and validates the capturable pawn before admission."),
        ("state.clock-and-history-v1", "Clock and repetition lineage", "position x history -> counters", "Stores halfmove/fullmove clocks and repetition lineage needed to make draw rules Markovian."),
    ]),
    ("Move geometry and support", [
        ("move.pawn-push-v1", "Pawn push support", "pawn state -> candidate squares", "Generates single and initial double advances only through empty support squares."),
        ("move.pawn-capture-promotion-v1", "Pawn capture and promotion", "pawn x target -> move family", "Generates diagonal captures, en passant and four explicit promotion branches."),
        ("move.knight-v1", "Knight jump relation", "square -> up to 8 squares", "Applies the fixed (1,2) displacement family with board-bound guards."),
        ("move.slider-v1", "Bishop, rook and queen ray relation", "square x directions x occupancy -> moves", "Traverses ordered rays until the first blocker and never treats the enemy king as capturable."),
        ("move.king-v1", "King neighborhood relation", "square -> neighboring squares", "Generates adjacent-square candidates before attack and adjacency guards."),
        ("move.castling-path-v1", "Castling path support", "rights x occupancy x attack relation -> candidate", "Requires the original king/rook, clear path and unattacked origin, transit and destination squares."),
        ("relation.attack-v1", "Attack relation", "position x color x square -> truth", "Computes pseudo-attack coverage, including pinned attackers, for king safety and castling."),
        ("relation.ray-blocker-v1", "First-blocker operator", "ray x occupancy -> prefix/blocker", "Returns the unobstructed ray prefix and typed blocker status deterministically."),
    ]),
    ("Legality, proposals and transitions", [
        ("legality.pseudo-move-v1", "Pseudo-legal move constructor", "position -> move proposals", "Combines piece geometry and occupancy before global king-safety verification."),
        ("legality.origin-support-v1", "Origin support predicate", "position x move -> truth", "Requires a side-to-move piece at the declared origin."),
        ("legality.occupancy-compatibility-v1", "Destination compatibility", "position x move -> truth/status", "Rejects own-piece destinations, king capture and malformed special-move targets."),
        ("legality.king-safety-guard-v1", "Post-move king-safety guard", "candidate state x mover -> truth", "Rejects every candidate that leaves or places the mover's king in check."),
        ("legality.pin-and-discovery-v1", "Pin and discovered-line consequence", "candidate transition -> status", "Derives pins and discovered checks from the post-move attack relation rather than heuristic labels."),
        ("legality.en-passant-discovery-v1", "En-passant discovered-check guard", "ep candidate -> truth", "Removes both pawns before testing whether the move exposes the king along a rank or diagonal."),
        ("event.move-proposal-v1", "Chess move proposal record", "detector/input -> proposal", "Records UCI move, pre-hash, source, priority, gates, reason codes and confidence."),
        ("transition.atomic-move-v1", "Atomic chess transition", "position x verified move -> position", "Applies captures, promotion, castling rook motion, rights, ep target and clocks in one immutable patch."),
    ]),
    ("Terminal and draw calculus", [
        ("terminal.check-v1", "Check predicate", "position x color -> truth", "Classifies whether the selected king is attacked in the current state."),
        ("terminal.checkmate-v1", "Checkmate terminal", "position -> terminal result", "Check plus an empty legal-move set yields a loss for the side to move."),
        ("terminal.stalemate-v1", "Stalemate terminal", "position -> terminal draw", "No legal moves without check yields a draw."),
        ("terminal.dead-position-v1", "Dead-position proof obligation", "position -> draw/certificate/unknown", "Fast exact material cases may certify draw; otherwise a complete no-mating-sequence proof remains separately typed."),
        ("draw.halfmove-clock-v1", "Fifty/seventy-five move clock", "transition history -> halfmove count", "Resets on pawn moves and captures and distinguishes claimable 100-ply from automatic 150-ply conditions."),
        ("draw.repetition-identity-v1", "Repetition identity", "position -> repetition key", "Uses placement, turn, castling and legally relevant en-passant possibilities, not the full FEN clocks."),
        ("draw.claim-action-v1", "Claimable draw action", "position x lineage -> legal action/status", "Models threefold and fifty-move claims as optional strategic actions in a complete game graph."),
        ("draw.automatic-precedence-v1", "Automatic draw and checkmate precedence", "position x lineage -> terminal", "Applies fivefold and seventy-five-move draws while preserving checkmate precedence on the last move."),
    ]),
    ("Canonicalization and symmetry", [
        ("exchange.fen-v1", "FEN position exchange", "text <-> position", "Parses and serializes six-field orthodox FEN with explicit validation."),
        ("exchange.uci-move-v1", "UCI move exchange", "text <-> move", "Uses explicit origin, destination and optional promotion without notation ambiguity."),
        ("canonical.repetition-key-v1", "Canonical repetition key", "position -> key", "Normalizes stale en-passant fields that do not change the legal move set."),
        ("canonical.position-hash-v1", "Canonical position content hash", "position record -> SHA-256", "Hashes sorted canonical state records for cache, replay and divergence checks."),
        ("symmetry.board-d4-v1", "D4 board symmetry", "state -> orbit representative", "Uses rotations/reflections only for material classes whose movement laws are preserved."),
        ("symmetry.color-swap-v1", "Color-swap isomorphism", "position -> normalized position", "Rotates 180 degrees and swaps colors so a lone extra piece can be normalized to White."),
        ("symmetry.material-class-v1", "Material-class canonicalizer", "position -> class/key", "Separates Q, R, B, N and P classes and retains pawn-direction restrictions."),
        ("canonical.transposition-dag-v1", "Transposition DAG sharing", "game tree -> shared DAG", "Stores identical canonical positions once while preserving distinct move and lineage edges."),
    ]),
    ("Game solving and fixed points", [
        ("solve.game-graph-v1", "Finite chess game graph", "rule profile -> directed state graph", "Nodes are complete rule states and edges are verified moves or claim actions."),
        ("solve.minimax-v1", "Alternating minimax value", "game graph x root -> value/strategy", "Defines win, draw and loss relative to the player to move with deterministic tie policy."),
        ("solve.retrograde-fixed-point-v1", "Retrograde least fixed point", "finite graph -> WDL partition", "Seeds terminal losses, propagates predecessor wins/losses and classifies the complement as draw."),
        ("solve.wdl-v1", "Win/draw/loss table", "position -> WDL", "Returns an exact value only inside a closed, validated solved domain."),
        ("solve.dtm-v1", "Distance to mate", "solved W/L state -> plies", "Winner minimizes and loser maximizes the number of plies to checkmate."),
        ("solve.dtz-v1", "Distance to zeroing contract", "position -> plies/status", "Tracks distance to pawn move/capture for fifty-move-aware tablebase integration; adapter contract in this release."),
        ("solve.bounded-proof-v1", "Bounded sound proof search", "position x depth -> win/loss/draw/unknown", "Proves terminal values inside a finite horizon and never relabels a horizon miss as draw."),
        ("solve.partition-schedule-v1", "Proof-number and partition schedule", "frontier x budgets -> work units", "Specifies deterministic frontier splitting, priorities and rejoin certificates for distributed solving."),
    ]),
    ("Proof, validation and status", [
        ("proof.node-v1", "Proof node record", "position x value x children -> proof node", "Stores canonical state, quantified move obligation, child certificates and local hash."),
        ("proof.strategy-certificate-v1", "Strategy certificate", "solved root -> certificate DAG", "For wins supplies at least one losing successor; for losses covers every legal successor; draws require a closed invariant or solved complement."),
        ("validation.perft-v1", "Perft legality oracle", "position x depth -> path count", "Counts all legal move paths and compares against published reference counts without evaluation heuristics."),
        ("validation.rule-conformance-v1", "Rule conformance suite", "engine -> validation report", "Exercises castling, en passant, promotion, checks, pins, repetition keys and terminal precedence."),
        ("validation.tablebase-roundtrip-v1", "Tablebase encode/decode round trip", "records -> binary -> records", "Preserves sorted canonical keys, WDL and DTM under a versioned compact format."),
        ("validation.replay-divergence-v1", "Replay divergence detector", "initial x events -> state/status", "Stops at the first pre/post hash or event-hash mismatch."),
        ("status.solution-scope-v1", "Solution scope record", "result -> exact domain statement", "Names board variant, rules, counters, castling policy, material closure and certificate coverage."),
        ("status.unresolved-v1", "Unresolved result", "budget exhaustion -> explicit unknown", "Keeps the orthodox initial position unresolved until a complete certificate exists."),
    ]),
    ("Scaling, storage and UGTS handoff", [
        ("storage.packed-position-v1", "Packed position profile", "position -> compact code + metadata", "Allows bitboards or indexed records only when rights, clocks, uncertainty and lineage semantics are retained."),
        ("distributed.material-partition-v1", "Material and pawn-slice partition", "state space -> disjoint work units", "Partitions by material, pawn structure, side, rights and canonical orbit with exact coverage accounting."),
        ("distributed.deterministic-join-v1", "Deterministic frontier join", "work results -> merged proof DAG", "Uses stable keys, conflict detection and content hashes when merging parallel results."),
        ("storage.frontier-compression-v1", "Frontier and proof compression", "proof DAG -> shared/encoded DAG", "Combines structural sharing, sorted key deltas and value runs without discarding obligations."),
        ("adapter.syzygy-v1", "Syzygy WDL/DTZ adapter contract", "position x tables -> probe/status", "Imports externally generated up-to-seven-piece values only after file/hash/rule-profile validation."),
        ("adapter.gpu-proposal-v1", "GPU move/proof proposal contract", "position batch -> proposals", "Parallel kernels may generate candidates or predecessor records; authoritative verification and joins remain deterministic."),
        ("governance.kill-criteria-v1", "Chess solver kill criteria", "run/profile -> continue/delegate/reject", "Stops on rule ambiguity, incomplete successor coverage, hash divergence, memory blow-up or unverified pruning."),
        ("handoff.ugts-chess-v1", "Canonical UGTS chess handoff", "move/result -> support/compatibility/guard/event/transition/lineage", "Returns every authoritative chess change and proof claim to the retained UGTS order."),
    ]),
]


def canonical_hash(record: dict) -> str:
    payload = json.dumps(record, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
    return "sha256:" + hashlib.sha256(payload).hexdigest()


rows = []
mid = 886
for domain, entries in DOMAINS:
    for operator_suffix, name, signature, definition in entries:
        record = {
            "mechanism_id": f"M{mid}",
            "operator_id": f"ugts43.chess.{operator_suffix}",
            "domain": domain,
            "name": name,
            "signature": signature,
            "exactness": "exact_discrete_or_explicit_status",
            "status": "implemented_reference" if mid not in {913, 916, 931, 933, 934, 935, 942, 943, 944, 945, 946, 947} else "specified_contract",
            "definition": definition,
            "ugts_integration": "parse/normalize/resolve/type/plan/evaluate/certify/support/compatibility/guard/proposal/commit/lineage/projection as applicable",
            "validation": "tests_and_artifacts" if mid not in {913, 916, 931, 933, 934, 935, 942, 943, 944, 945, 946, 947} else "contract_only",
            "source_basis": "UGTS-KC 4.2 operator/order layer; UGTS-KC 3.9 deterministic game runtime; FIDE orthodox rule profile",
        }
        record["content_hash"] = canonical_hash(record)
        rows.append(record)
        mid += 1
assert mid == 950 and len(rows) == 64

spec = ROOT / "spec"
spec.mkdir(exist_ok=True)
with (spec / "chess_operator_catalog_M886_M949.csv").open("w", newline="", encoding="utf-8") as handle:
    writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
    writer.writeheader()
    writer.writerows(rows)
(spec / "chess_operator_catalog_M886_M949.json").write_text(json.dumps(rows, indent=2, sort_keys=True) + "\n", encoding="utf-8")

profiles = {
    "schema": "ugts-kc-chess-rule-profiles-4.3",
    "profiles": [
        {
            "id": "fide-2023-orthodox-v1",
            "board": "8x8 orthodox",
            "claim_actions": ["threefold_repetition", "fifty_move"],
            "automatic_draws": ["stalemate", "dead_position", "fivefold_repetition", "seventy_five_move"],
            "checkmate_precedence": True,
            "state_requirements": ["placement", "turn", "castling", "ep", "halfmove", "repetition_lineage"],
            "status": "rule-kernel implemented; complete dead-position proof and global solve remain obligations",
        },
        {
            "id": "orthodox-three-piece-zero-clock-no-castling-v1",
            "material": ["KQK", "KRK", "KBK", "KNK", "KPK"],
            "castling": "absent",
            "halfmove_clock": 0,
            "symmetry": "D4 for non-pawns; file reflection for pawn; color swap",
            "status": "fully solved and bundled",
        },
        {
            "id": "perft-legality-v1",
            "terminal_evaluation": False,
            "result": "number of legal move paths at exact depth",
            "status": "implemented",
        },
        {
            "id": "bounded-proof-v1",
            "outcomes": ["win", "loss", "draw", "unknown"],
            "unknown_policy": "never coerce to draw",
            "status": "implemented",
        },
    ],
}
(spec / "rule_profiles.json").write_text(json.dumps(profiles, indent=2, sort_keys=True) + "\n", encoding="utf-8")

source_register = {
    "schema": "ugts-kc-chess-source-register-4.3",
    "sources": [
        {"id": "S1", "title": "UGTS-KC 4.2 General Operator and Order Addendum", "use": "typed operators, fixed points, proof obligations, deterministic order"},
        {"id": "S2", "title": "UGTS-KC 3.9 KC Elizabeth Vector Game Runtime", "use": "deterministic game state, snapshots, hashes, replay"},
        {"id": "S3", "title": "UGTS-KC Two Hands 3.0", "use": "proposal verification, atomic commit, replay and divergence"},
        {"id": "S4", "title": "UGTS-KC 3.6 Literal Referential Substrate", "use": "content-addressed definitions and explicit operation order"},
        {"id": "S5", "title": "FIDE Laws of Chess effective 1 January 2023", "url": "https://handbook.fide.com/chapter/e012023", "use": "orthodox move and draw profile"},
        {"id": "S6", "title": "Chess Programming Wiki Perft Results", "url": "https://chessprogramming.org/Perft_Results", "use": "move-generation reference counts"},
        {"id": "S7", "title": "Syzygy tablebase generator", "url": "https://github.com/syzygy1/tb", "use": "external seven-piece tablebase boundary and adapter target"},
    ],
}
(spec / "source_register.json").write_text(json.dumps(source_register, indent=2, sort_keys=True) + "\n", encoding="utf-8")

schema = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "$id": "ugts-kc-chess-4.3.schema.json",
    "title": "UGTS-KC 4.3 Chess project/certificate",
    "type": "object",
    "required": ["schema", "rule_profile", "status"],
    "properties": {
        "schema": {"const": "ugts-kc-chess-project-4.3"},
        "rule_profile": {"type": "string"},
        "status": {"enum": ["solved", "bounded", "unresolved", "invalid"]},
        "root_fen": {"type": "string"},
        "root_hash": {"type": "string", "pattern": "^sha256:[0-9a-f]{64}$"},
        "outcome": {"enum": ["win", "loss", "draw", "unknown"]},
        "distance_plies": {"type": ["integer", "null"], "minimum": 0},
        "best_moves": {"type": "array", "items": {"type": "string"}, "uniqueItems": True},
        "certificate_hash": {"type": "string", "pattern": "^sha256:[0-9a-f]{64}$"},
        "scope": {"type": "object"},
        "metrics": {"type": "object"},
    },
    "additionalProperties": True,
}
(spec / "ugts_kc_chess_4_3.schema.json").write_text(json.dumps(schema, indent=2, sort_keys=True) + "\n", encoding="utf-8")

summary = {
    "mechanism_range": "M886-M949",
    "count": 64,
    "domains": {domain: len(entries) for domain, entries in DOMAINS},
    "implemented_reference": sum(r["status"] == "implemented_reference" for r in rows),
    "specified_contract": sum(r["status"] == "specified_contract" for r in rows),
}
summary["content_hash"] = canonical_hash(summary)
(spec / "catalog_summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(json.dumps(summary, indent=2))
