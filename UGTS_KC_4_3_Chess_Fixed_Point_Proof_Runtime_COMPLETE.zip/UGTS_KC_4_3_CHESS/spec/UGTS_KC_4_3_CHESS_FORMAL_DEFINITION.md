# UGTS-KC 4.3 Chess Fixed-Point and Proof Runtime

## 1. Release object

UGTS-KC 4.3 is an additive chess-domain profile over the retained UGTS-KC 4.2 operator and order substrate.

Let a complete chess rule state be

`q = (B, s, C, e, h, m, R, P, L)`

where `B` is the 64-square occupancy map; `s` is side to move; `C` is castling-right state; `e` is the en-passant relation; `h` is the halfmove clock; `m` is fullmove number; `R` is repetition lineage; `P` is the selected rule/solver profile; and `L` is event/proof lineage.

Coordinates alone are not a complete chess state. The same board placement with a different side, castling right, en-passant possibility, halfmove clock or repetition history can have a different legal move set or game-theoretic value.

## 2. Canonical move authority

A move request passes through the UGTS sequence:

`piece/local support -> occupancy/rule compatibility -> king-safety guard -> verified move proposal -> atomic transition -> repetition/proof lineage`.

The 15 phases inherited from 4.2 are specialized as follows:

0. parse FEN/UCI or literal records;
1. normalize square, color, castling and en-passant spellings;
2. resolve the rule profile and operator definitions;
3. type board, piece, move and history fields;
4. canonicalize exchange and symmetry records;
5. plan ordered candidate generation;
6. evaluate pseudo-legal moves and attacks;
7. certify special-move structure;
8. test origin and geometric support;
9. test occupancy, turn, rights and promotion compatibility;
10. apply king-safety and draw/terminal guards;
11. emit a move or proof proposal;
12. commit the immutable state patch;
13. append repetition, event and proof lineage;
14. project to FEN, UCI, board display, tablebase or report output.

## 3. Legal successor relation

For a position `p`, let `M(p)` be the deterministically ordered set of verified legal moves and let `T(p,m)` be the atomic successor state. The successor relation is

`Succ(p) = { T(p,m) | m in M(p) }`.

A complete FIDE game graph also includes claim actions for threefold repetition and the fifty-move rule. Fivefold repetition and the seventy-five-move rule are automatic terminals. Checkmate on the final move takes precedence over the automatic seventy-five-move result.

## 4. Fixed-point solution

Values are relative to the player to move. Let `L0` be checkmated positions and `D0` be terminal draws. Define iteratively

`W_(n+1) = W_n union { p | exists q in Succ(p): q in L_n }`

`L_(n+1) = L_n union { p | Succ(p) is nonempty and every q in Succ(p) lies in W_(n+1) }`.

For a finite closed graph, the monotone process reaches a fixed point. Positions outside `W union L` are draws. Distance to mate is

`DTM(win p) = 1 + min DTM(loss successor)`

`DTM(loss p) = 1 + max DTM(win successor)`.

A winning proof node must exhibit at least one losing successor. A losing proof node must cover every legal successor. A draw certificate requires either a solved complement, a closed invariant, or a complete cycle/terminal argument under the selected rule profile.

## 5. Exact solved domain in this release

The bundled tablebase exactly solves the no-castling, zero-halfmove-clock three-piece material classes:

- KQK;
- KRK;
- KBK;
- KNK;
- KPK, including all four promotions and transitions into the other classes.

The extra piece is normalized to White; color-swapped positions are isomorphic. Non-pawn classes use the dihedral group D4 for board-symmetry reduction. Pawn states use file reflection only because pawn direction is not preserved by arbitrary rotations.

The binary table contains 367,868 canonical states and 3,217,270 internal directed edges. The maximum DTM is 20 plies for KQK, 32 plies for KRK and 56 plies for KPK. KBK and KNK are draws throughout the admitted legal state set.

## 6. General orthodox rule kernel

The standard-library reference implementation supports:

- six-field FEN parse/serialization;
- UCI moves;
- legal pawn, knight, bishop, rook, queen and king moves;
- promotion, castling and en passant;
- attack, check, checkmate and stalemate;
- common exact dead-material certificates;
- halfmove and repetition status;
- canonical position and repetition keys;
- deterministic proposal, commit, state hash and replay;
- published perft reference positions;
- sound bounded mate/draw proof search with explicit `unknown`.

The common dead-material predicate is one-way: `true` is a certificate, while `false` is not a proof that mate is possible. A complete dead-position decision remains a separate proof obligation.

## 7. Initial-position status

The orthodox 32-piece initial position is represented and validated, but this release does not attach an unsupported win/draw/loss label. Its status is:

`UNRESOLVED under full strong-solution scope`.

This is an explicit substrate result, not a hidden heuristic. A bounded depth-three proof search visits 9,323 nodes and returns `unknown`. Published perft counts are matched through depth four for the initial position and through depth three or four for multiple castling, en-passant and promotion stress positions.

## 8. Scaling path

A full strong solution requires:

1. freeze one complete rule profile, including claim actions and automatic draw precedence;
2. prove complete legal successor coverage;
3. import or regenerate exact endgame values under compatible semantics;
4. partition higher-material state space by material, pawn structure, rights and canonical symmetry;
5. solve retrograde regions and forward proof frontiers;
6. merge work through content-addressed proof DAGs;
7. validate every W/L quantifier obligation and every draw closure;
8. issue a root strategy certificate whose transitive dependencies are complete.

Parallel CPU/GPU work may generate candidate moves, predecessors or proof proposals. Unchecked parallel output never becomes authoritative state or proof.

## 9. Completeness and evidence boundary

This package establishes an exact rule kernel, a general finite-graph solver, a complete admitted three-piece solution, deterministic replay, published move-generation conformance and a machine-readable route toward larger proofs. It does not claim that the standard initial position has been strongly solved, that a heuristic engine score is a proof, or that storage compression removes the combinatorial cost.

## 10. Final definition

**UGTS-KC 4.3 represents chess as a finite typed state-and-relation system whose legal moves are verified events and whose game-theoretic value is a fixed point over the complete successor graph. State, rule rights, draw lineage, operator order, proof obligations and unresolved status are explicit data. The release fully solves its declared three-piece domain and preserves the orthodox initial position as unresolved until a complete strategy certificate exists.**
