# Notice and evidence boundary

UGTS-KC 4.3 is a technical reference package prepared in the UGTS project context. It is not a claim of legal ownership, patentability, independent scientific validation or endorsement by FIDE, Syzygy contributors, chess-engine developers or any standards body.

The implementation and tests establish internal consistency and the explicitly reported exact three-piece result. They do not establish a strong solution of the orthodox initial position.

External names, rule texts, perft values and tablebase formats remain the work of their respective authors and communities. The package contains no copied third-party engine or tablebase source code and ships no Syzygy data files.
