# UGTS-KC 4.3 - Chess Fixed-Point and Proof Runtime

This package turns orthodox chess into a typed UGTS state, move, event and proof problem.

## What is genuinely solved

The bundled exact retrograde tablebase solves the complete admitted three-piece domain KQK, KRK, KBK, KNK and KPK, including promotion transitions, after color and legal board-symmetry normalization. Its profile excludes castling rights and starts the halfmove clock at zero.

The standard 32-piece initial position is **not falsely labeled**. It is recorded as `unresolved` under the full strong-solution target.

## Included

- dependency-free orthodox legal move generator;
- FEN and UCI exchange;
- castling, en passant and promotion;
- check, checkmate, stalemate and draw-status operators;
- canonical hashes, repetition keys, proposal/commit and replay;
- exact finite-graph fixed-point solver;
- bounded sound mate proof search with explicit `unknown`;
- 2.2 MiB exact three-piece tablebase;
- 64 chess-domain UGTS mechanisms, M886-M949;
- tests against published perft counts;
- PDF/DOCX technical report and machine-readable validation evidence.

## Quick start

```bash
PYTHONPATH=src python -m ugts_chess43 moves
PYTHONPATH=src python -m ugts_chess43 perft 4
PYTHONPATH=src python -m ugts_chess43 probe-tb3 \
  data/tb3_orthodox_zero_clock.bin \
  --fen "8/8/8/8/4k3/8/1Q6/K7 b - - 0 1"
PYTHONPATH=src python examples/demo.py
PYTHONPATH=src python -m unittest discover -s tests -v
```

## Canonical chess authority path

`piece support -> rule compatibility -> king-safety guard -> verified move proposal -> atomic commit -> repetition/proof lineage`

See `spec/UGTS_KC_4_3_CHESS_FORMAL_DEFINITION.md` for the normative definition and `docs/SOLUTION_STATUS.md` for the exact evidence boundary.
