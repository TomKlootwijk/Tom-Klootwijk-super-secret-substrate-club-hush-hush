from __future__ import annotations

import json
from pathlib import Path
import unittest

from ugts_chess43.position import Position
from ugts_chess43.retrograde3 import ThreePieceTablebase

ROOT = Path(__file__).resolve().parents[1]


class ThreePieceTablebaseTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.tb = ThreePieceTablebase(ROOT / "data" / "tb3_orthodox_zero_clock.bin")
        cls.summary = json.loads((ROOT / "data" / "tb3_summary.json").read_text())

    def test_exact_state_count(self) -> None:
        self.assertEqual(self.summary["canonical_state_count"], 367868)
        self.assertEqual(self.summary["directed_internal_edges"], 3217270)

    def test_max_dtm_metrics(self) -> None:
        self.assertEqual(self.summary["sections"]["Q"]["max_dtm_plies"], 20)
        self.assertEqual(self.summary["sections"]["R"]["max_dtm_plies"], 32)
        self.assertEqual(self.summary["sections"]["P"]["max_dtm_plies"], 56)

    def test_bishop_and_knight_are_drawn(self) -> None:
        bishop = Position.from_fen("8/8/8/8/8/8/2K5/kB6 w - - 0 1")
        knight = Position.from_fen("8/8/8/8/8/8/2K5/kN6 w - - 0 1")
        self.assertEqual(self.tb.probe(bishop).strong_side_value, "draw")
        self.assertEqual(self.tb.probe(knight).strong_side_value, "draw")

    def test_max_queen_example(self) -> None:
        position = Position.from_fen("8/8/8/8/4k3/8/1Q6/K7 b - - 0 1")
        result = self.tb.probe(position)
        self.assertEqual(result.side_to_move_value, "loss")
        self.assertEqual(result.dtm_plies, 20)
        self.assertEqual(self.tb.best_moves(position), ("e4f5",))

    def test_color_swapped_equivalence(self) -> None:
        white_rook = Position.from_fen("8/8/8/8/8/8/1Rk5/K7 b - - 0 1")
        black_rook = Position.from_fen("7k/5Kr1/8/8/8/8/8/8 w - - 0 1")
        a = self.tb.probe(white_rook)
        b = self.tb.probe(black_rook)
        self.assertEqual(a.dtm_plies, b.dtm_plies)
        self.assertEqual(a.strong_side_value, b.strong_side_value)
        self.assertTrue(b.color_swapped)

    def test_castling_rights_rejected_by_profile(self) -> None:
        position = Position.from_fen("4k3/8/8/8/8/8/8/4K2R w K - 0 1")
        with self.assertRaises(ValueError):
            self.tb.probe(position)


if __name__ == "__main__":
    unittest.main()
