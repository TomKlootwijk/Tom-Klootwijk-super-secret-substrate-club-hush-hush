from __future__ import annotations

import unittest

from ugts_chess43.position import Position
from ugts_chess43.search import BoundedMateSolver, DRAW, LOSS, UNKNOWN, WIN, solve_finite_graph
from ugts_chess43.ugts import ChessRuntime


class RuntimeTests(unittest.TestCase):
    def test_proposal_commit_and_replay(self) -> None:
        runtime = ChessRuntime(Position.start())
        event1 = runtime.play("e2e4")
        event2 = runtime.play("e7e5")
        replayed = ChessRuntime.replay(Position.start(), [event1, event2])
        self.assertEqual(replayed.position.to_fen(), runtime.position.to_fen())
        self.assertEqual(replayed.events[-1].post_hash, runtime.events[-1].post_hash)

    def test_rejected_proposal(self) -> None:
        runtime = ChessRuntime(Position.start())
        proposal = runtime.propose("e2e5")
        self.assertFalse(proposal.verified)
        with self.assertRaises(ValueError):
            runtime.commit(proposal)


class SearchTests(unittest.TestCase):
    def test_mate_in_one(self) -> None:
        position = Position.from_fen("7k/8/6K1/8/8/8/5Q2/8 w - - 0 1")
        result = BoundedMateSolver(1).solve(position)
        self.assertEqual(result.outcome, WIN)
        self.assertEqual(result.distance_plies, 1)
        self.assertTrue(result.best_moves)

    def test_initial_position_remains_unknown_at_small_horizon(self) -> None:
        result = BoundedMateSolver(2).solve(Position.start())
        self.assertEqual(result.outcome, UNKNOWN)

    def test_explicit_fixed_point(self) -> None:
        # node 0 -> terminal loss node 1, so 0 is win. node 2 -> draw sink.
        result = solve_finite_graph(((1,), (), (None,)), terminal_losses=(1,))
        self.assertEqual(result.values, (WIN, LOSS, DRAW))


if __name__ == "__main__":
    unittest.main()
