from __future__ import annotations

import unittest

from ugts_chess43.canonical import ep_is_repetition_relevant, position_hash, repetition_key
from ugts_chess43.position import Move, Position, START_FEN, parse_square, square_name
from ugts_chess43.rules import (
    apply_move,
    apply_uci,
    in_check,
    legal_move_map,
    legal_moves,
    perft,
    terminal_status,
)


class PositionTests(unittest.TestCase):
    def test_start_fen_round_trip(self) -> None:
        self.assertEqual(Position.start().to_fen(), START_FEN)

    def test_square_round_trip(self) -> None:
        for name in ("a1", "e4", "h8"):
            self.assertEqual(square_name(parse_square(name)), name)

    def test_move_uci_round_trip(self) -> None:
        self.assertEqual(Move.from_uci("e7e8q").uci(), "e7e8q")

    def test_position_hash_is_stable(self) -> None:
        self.assertEqual(position_hash(Position.start()), position_hash(Position.from_fen(START_FEN)))


class PerftTests(unittest.TestCase):
    def test_initial_position(self) -> None:
        position = Position.start()
        expected = {1: 20, 2: 400, 3: 8902, 4: 197281}
        for depth, nodes in expected.items():
            with self.subTest(depth=depth):
                self.assertEqual(perft(position, depth), nodes)

    def test_kiwipete(self) -> None:
        position = Position.from_fen(
            "r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1"
        )
        self.assertEqual([perft(position, d) for d in (1, 2, 3)], [48, 2039, 97862])

    def test_en_passant_position(self) -> None:
        position = Position.from_fen("8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1")
        self.assertEqual([perft(position, d) for d in (1, 2, 3, 4)], [14, 191, 2812, 43238])

    def test_promotion_and_castling_position(self) -> None:
        position = Position.from_fen("r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1")
        self.assertEqual([perft(position, d) for d in (1, 2, 3)], [6, 264, 9467])


class SpecialMoveTests(unittest.TestCase):
    def test_castling_commit(self) -> None:
        position = Position.from_fen("r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1")
        move = legal_move_map(position)["e1g1"]
        result = apply_move(position, move)
        self.assertEqual(result.board[parse_square("g1")], "K")
        self.assertEqual(result.board[parse_square("f1")], "R")
        self.assertNotIn("K", result.castling)
        self.assertNotIn("Q", result.castling)

    def test_en_passant_commit(self) -> None:
        position = Position.from_fen("4k3/8/8/3pP3/8/8/8/4K3 w - d6 0 2")
        move = legal_move_map(position)["e5d6"]
        self.assertTrue(move.en_passant)
        result = apply_move(position, move)
        self.assertEqual(result.board[parse_square("d6")], "P")
        self.assertEqual(result.board[parse_square("d5")], ".")

    def test_promotion_commit(self) -> None:
        position = Position.from_fen("7k/P7/8/8/8/8/8/7K w - - 0 1")
        result = apply_uci(position, "a7a8n")
        self.assertEqual(result.board[parse_square("a8")], "N")

    def test_illegal_self_check_removed(self) -> None:
        position = Position.from_fen("4r1k1/8/8/8/8/8/4R3/4K3 w - - 0 1")
        self.assertNotIn("e2f2", legal_move_map(position))

    def test_ep_repetition_normalization(self) -> None:
        stale = Position.from_fen("4k3/8/8/8/4P3/8/8/4K3 b - e3 0 1")
        self.assertFalse(ep_is_repetition_relevant(stale))
        self.assertTrue(repetition_key(stale).endswith(" -"))
        live = Position.from_fen("4k3/8/8/8/3pP3/8/8/4K3 b - e3 0 1")
        self.assertTrue(ep_is_repetition_relevant(live))


class TerminalTests(unittest.TestCase):
    def test_checkmate(self) -> None:
        position = Position.from_fen("7k/6Q1/6K1/8/8/8/8/8 b - - 0 1")
        status = terminal_status(position)
        self.assertTrue(status.terminal)
        self.assertEqual(status.kind, "checkmate")
        self.assertEqual(status.winner, "w")

    def test_stalemate(self) -> None:
        position = Position.from_fen("7k/5Q2/6K1/8/8/8/8/8 b - - 0 1")
        status = terminal_status(position)
        self.assertTrue(status.terminal)
        self.assertEqual(status.kind, "stalemate")

    def test_automatic_draw_rules(self) -> None:
        position = Position.from_fen("7k/8/8/8/8/8/6R1/6K1 w - - 150 76")
        status = terminal_status(position, repetition_count=5)
        self.assertTrue(status.terminal)
        self.assertIn("fivefold_repetition", status.automatic)
        self.assertIn("seventy_five_move", status.automatic)


if __name__ == "__main__":
    unittest.main()
