from __future__ import annotations

import csv
import json
from pathlib import Path
import subprocess
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]


class SpecTests(unittest.TestCase):
    def test_catalog_contiguous(self) -> None:
        with (ROOT / "spec" / "chess_operator_catalog_M886_M949.csv").open(newline="", encoding="utf-8") as fh:
            rows = list(csv.DictReader(fh))
        self.assertEqual(len(rows), 64)
        self.assertEqual([int(r["mechanism_id"][1:]) for r in rows], list(range(886, 950)))
        self.assertEqual(len({r["operator_id"] for r in rows}), 64)
        self.assertEqual(len({r["content_hash"] for r in rows}), 64)

    def test_rule_profiles(self) -> None:
        data = json.loads((ROOT / "spec" / "rule_profiles.json").read_text())
        ids = {p["id"] for p in data["profiles"]}
        self.assertIn("fide-2023-orthodox-v1", ids)
        self.assertIn("orthodox-three-piece-zero-clock-no-castling-v1", ids)

    def test_cli_moves(self) -> None:
        env = {**__import__("os").environ, "PYTHONPATH": str(ROOT / "src")}
        proc = subprocess.run(
            [sys.executable, "-m", "ugts_chess43", "moves"],
            cwd=ROOT,
            env=env,
            capture_output=True,
            text=True,
            check=True,
        )
        self.assertEqual(len(json.loads(proc.stdout)), 20)

    def test_cli_probe(self) -> None:
        env = {**__import__("os").environ, "PYTHONPATH": str(ROOT / "src")}
        proc = subprocess.run(
            [
                sys.executable,
                "-m",
                "ugts_chess43",
                "probe-tb3",
                "data/tb3_orthodox_zero_clock.bin",
                "--fen",
                "8/8/8/8/4k3/8/1Q6/K7 b - - 0 1",
            ],
            cwd=ROOT,
            env=env,
            capture_output=True,
            text=True,
            check=True,
        )
        payload = json.loads(proc.stdout)
        self.assertEqual(payload["side_to_move_value"], "loss")
        self.assertEqual(payload["dtm_plies"], 20)


if __name__ == "__main__":
    unittest.main()
