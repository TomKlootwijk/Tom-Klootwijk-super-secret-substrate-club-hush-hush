#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/.host-test-build"
rm -rf "$BUILD" && mkdir -p "$BUILD"
find "$ROOT/core/src/main/java" -name '*.java' -print0 | xargs -0 javac -encoding UTF-8 -source 17 -target 17 -d "$BUILD"
javac -encoding UTF-8 -source 17 -target 17 -cp "$BUILD" -d "$BUILD" "$ROOT/tools/host_tests/CoreSelfTest.java"
java -ea -cp "$BUILD" CoreSelfTest
rm -rf "$BUILD"
