#!/usr/bin/env python3
"""Verify, inspect, and convert UGTS Atlas 3.9.4 .ugtsscan files."""
from __future__ import annotations
import argparse, csv, hashlib, json, math, struct, sys, zipfile, zlib
from pathlib import Path

def read_varint(data: bytes, pos: int):
    v=0;shift=0
    while shift<64:
        if pos>=len(data): raise ValueError("truncated varint")
        b=data[pos];pos+=1;v|=(b&0x7f)<<shift
        if not b&0x80:return v,pos
        shift+=7
    raise ValueError("varint overflow")
def unzigzag(v): return (v>>1)^-(v&1)
def decode_map(blob: bytes):
    if blob[:4]!=b'UG3D' or blob[4]!=1:raise ValueError("unsupported map")
    voxel=struct.unpack('>d',blob[5:13])[0];raw=zlib.decompress(blob[13:]);count,pos=read_varint(raw,0);x=y=z=0;records=[]
    if count>10_000_000:raise ValueError("unreasonable point count")
    for _ in range(count):
        dx,pos=read_varint(raw,pos);dy,pos=read_varint(raw,pos);dz,pos=read_varint(raw,pos);x+=unzigzag(dx);y+=unzigzag(dy);z+=unzigzag(dz)
        intensity,confidence=raw[pos],raw[pos+1];pos+=2;obs,pos=read_varint(raw,pos);records.append((x*voxel,y*voxel,z*voxel,intensity,confidence/255,obs))
    return voxel,records
def load(path: Path):
    with zipfile.ZipFile(path) as z:
        names=set(z.namelist());manifest=json.loads(z.read('manifest.json'));errors=[]
        for name,meta in manifest.get('entries',{}).items():
            if name not in names:errors.append(f"missing {name}");continue
            got=hashlib.sha256(z.read(name)).hexdigest()
            if got!=meta.get('sha256'):errors.append(f"hash mismatch {name}")
        voxel,records=decode_map(z.read('map.ugtsbin'))
    return manifest,voxel,records,errors
def main():
    p=argparse.ArgumentParser();p.add_argument('scan',type=Path);p.add_argument('--to-ply',type=Path);a=p.parse_args();m,v,r,e=load(a.scan)
    print(json.dumps({'manifest':m,'decoded_voxels':len(r),'voxel_size':v,'verification_errors':e},indent=2))
    if a.to_ply:
        with a.to_ply.open('w',encoding='ascii',newline='\n') as f:
            f.write('ply\nformat ascii 1.0\n');f.write(f'element vertex {len(r)}\n');f.write('property float x\nproperty float y\nproperty float z\nproperty uchar red\nproperty uchar green\nproperty uchar blue\nproperty float confidence\nend_header\n')
            for x,y,z,i,c,o in r:f.write(f'{x:.7g} {y:.7g} {z:.7g} {i} {i} {i} {c:.5g}\n')
    return 1 if e else 0
if __name__=='__main__':raise SystemExit(main())
