#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
./tools/run_host_tests.sh
./gradlew --no-daemon --stacktrace :app:assembleDebug :app:assembleRelease
mkdir -p dist
find app/build/outputs/apk -type f -name '*.apk' -exec cp -f {} dist/ \;
(cd dist && sha256sum *.apk > APK_SHA256SUMS.txt)
