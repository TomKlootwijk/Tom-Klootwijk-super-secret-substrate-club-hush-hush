#!/usr/bin/env python3
"""Create a deterministic source release after local validation."""
from pathlib import Path
import hashlib, json, os, zipfile
root=Path(__file__).resolve().parents[1]
out=root.parent/(root.name+'_SOURCE.zip')
excluded={'.gradle','.idea','.git','build','.host-test-build'}
files=[p for p in root.rglob('*') if p.is_file() and not any(x in excluded for x in p.relative_to(root).parts)]
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(files):
        info=zipfile.ZipInfo(str(p.relative_to(root)).replace(os.sep,'/'),(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=(0o755 if os.access(p,os.X_OK) else 0o644)<<16;z.writestr(info,p.read_bytes())
print(out,hashlib.sha256(out.read_bytes()).hexdigest())
