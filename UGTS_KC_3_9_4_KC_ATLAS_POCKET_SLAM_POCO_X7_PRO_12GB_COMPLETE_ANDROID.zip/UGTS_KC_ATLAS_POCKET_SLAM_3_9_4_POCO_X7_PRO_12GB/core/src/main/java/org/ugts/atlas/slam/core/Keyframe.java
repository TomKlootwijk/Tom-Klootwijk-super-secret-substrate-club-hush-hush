package org.ugts.atlas.slam.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class Keyframe {
    public final long id,timestampNs;
    public Pose pose;
    public final CameraModel camera;
    public final GrayFrame frame;
    public final List<Feature> features;
    public final long signature;
    public Keyframe(long id,long timestampNs,Pose pose,CameraModel camera,GrayFrame frame,List<Feature> features){this.id=id;this.timestampNs=timestampNs;this.pose=pose;this.camera=camera;this.frame=frame.copy();this.features=Collections.unmodifiableList(new ArrayList<>(features));this.signature=signature(features);}
    private static long signature(List<Feature> fs){int[] votes=new int[64];for(Feature f:fs){long v=f.d0^Long.rotateLeft(f.d1,11)^Long.rotateLeft(f.d2,29)^Long.rotateLeft(f.d3,47);for(int i=0;i<64;i++)votes[i]+=((v>>>i)&1L)==1?1:-1;}long s=0;for(int i=0;i<64;i++)if(votes[i]>=0)s|=1L<<i;return s;}
}
