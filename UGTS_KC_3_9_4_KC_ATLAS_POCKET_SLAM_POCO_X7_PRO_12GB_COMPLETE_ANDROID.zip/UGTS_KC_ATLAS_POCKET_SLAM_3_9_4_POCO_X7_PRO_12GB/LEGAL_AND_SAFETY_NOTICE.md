# Legal and safety notice

Copyright and authorship attribution supplied by the project: Tom Klootwijk.
This package does not create an additional licence grant for upstream UGTS or
Grove materials. Third-party AndroidX/CameraX dependencies remain under their
respective licences and are resolved by Gradle rather than redistributed as
source here.

The scanner is not certified for structural assessment, emergency egress,
clinical measurement, autonomous navigation, or evidentiary chain of custody.
Its map is an observation-derived estimate. Users must preserve uncertainty,
verify scale, and obtain qualified review for consequential decisions.
