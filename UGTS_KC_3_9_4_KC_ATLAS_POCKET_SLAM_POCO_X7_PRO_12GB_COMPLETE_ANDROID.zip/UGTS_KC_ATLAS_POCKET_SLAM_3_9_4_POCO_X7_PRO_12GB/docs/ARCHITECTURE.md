# Architecture

```text
CameraX Y plane ──► rotate/downsample ──► FAST/BRIEF ──► LSH matching
      │                                            │
      └─ timestamp ─► IMU ring buffer ─► rotation ─┤
                                                   ▼
                              epipolar proposal + uncertainty
                                                   ▼
               support → compatibility → guard → commit → lineage
                                                   ▼
                      keyframes + sparse triangulation
                                                   ▼
                     keyframe-only plane sweep
                                                   ▼
              confidence voxel fusion (bounded active map)
                                                   ▼
        UG3D quantization/delta/varint/DEFLATE + ledger + hashes
```

The vision frontend proposes motion and geometry; it does not mutate the map
directly. A point is fused only after positive depth, minimum parallax,
bounded ray gap, descriptor consistency, and reprojection-error guards. This
implements the Atlas proposal/commit separation in the mobile capture layer.

`core/` is pure Java 17 and host-testable. `app/` owns Android camera, sensor,
lifecycle, thermal, UI, and file-sharing concerns. No cloud service or remote
model is required.
