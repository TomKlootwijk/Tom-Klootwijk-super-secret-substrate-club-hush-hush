# Accuracy policy and known limits

## Accuracy protections

- Camera intrinsics are read from Camera2 physical-size/focal metadata when
  available; a fallback is labelled uncalibrated.
- Camera and IMU observations use monotonic nanosecond timestamps.
- IMU orientation removes rotational optical flow before translation solving.
- Motion requires a minimum inlier count and bounded epipolar residual.
- Triangulated points require positive depth, minimum parallax, bounded ray
  gap, and bounded reprojection error.
- Semi-dense points require texture, a unique photometric minimum, and a
  reverse-neighbourhood consistency guard.
- Metric units remain disabled until a known-distance scale anchor is
  committed to the ledger.
- Unknown or unobserved space is never declared traversable free space.

## Limits

A single camera cannot recover absolute metric scale without an external
constraint. Low texture, repetitive patterns, glass, specular surfaces,
moving objects, motion blur, rolling shutter, and weak translation can cause
drift or false geometry. The current 3.9.4 implementation records loop
closure candidates but deliberately defers geometric bundle adjustment; it
does not pretend that a visual-signature match is sufficient to rewrite the
map. It also does not perform semantic object recognition or dense learned
depth.

Device-specific numerical accuracy is not asserted by source inspection or
emulator tests. Benchmark on the physical POCO X7 Pro against calibrated
lengths, trajectories, and reference scans before operational use.
