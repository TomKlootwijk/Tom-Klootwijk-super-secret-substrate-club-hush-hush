# Compression and storage design

The authoritative map is a bounded set of confidence-weighted voxels, not an
unbounded frame archive. Each exported voxel is represented by signed integer
coordinates at the session voxel size, an 8-bit intensity, an 8-bit
confidence, and a varint observation count.

Coordinates are sorted lexicographically and stored as delta-coded signed
integers using zigzag varints. The resulting stream is compressed using
DEFLATE level 3 inside `map.ugtsbin`; the outer `.ugtsscan` ZIP also uses level
3 to keep export latency bounded. Keyframe pixels are retained only in memory
for adjacent multi-view reconstruction and are omitted from compact exports by
default. This is the largest storage saving and also reduces privacy exposure.

The desktop decoder can reconstruct a PLY interchange file. PLY is derived
output and is intentionally not stored by default because ASCII coordinates
are substantially larger than the UG3D representation.

App size is controlled by avoiding packaged neural weights and OpenCV, using
framework UI, restricting dependencies to CameraX, and enabling R8 plus
resource shrinking in release builds.
