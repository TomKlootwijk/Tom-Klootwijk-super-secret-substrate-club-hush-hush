# POCO X7 Pro 12 GB profile

The profile spends memory on a bounded active voxel map and recent keyframes,
while keeping the shipped application and saved sessions small. Default frame
analysis is 640 pixels on the long edge. Camera preview remains full-screen;
only the analysis stream is reduced. A single analyzer thread and CameraX
`KEEP_ONLY_LATEST` strategy prevent latency accumulation.

Normal operation targets a 66 ms minimum analysis interval. Android thermal
status automatically increases this to 100 ms at moderate thermal pressure
and 166 ms at severe pressure. The algorithm runs without a packaged model,
so there is no model-loading spike and no dependency on a particular NPU
delegate.

The 260,000-voxel cap, 480-keyframe cap, and adjacent-keyframe pixel buffers
are conservative ceilings rather than an instruction to occupy all available
12 GB. Android may reclaim the process; exports should be made at logical
scan boundaries.
