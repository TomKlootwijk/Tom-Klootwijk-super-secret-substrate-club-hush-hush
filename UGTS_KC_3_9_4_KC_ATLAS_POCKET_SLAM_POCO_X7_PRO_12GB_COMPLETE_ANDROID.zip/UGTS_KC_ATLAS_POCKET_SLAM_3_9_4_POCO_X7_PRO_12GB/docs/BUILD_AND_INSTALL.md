# Build and install

Requirements: JDK 17, an Android SDK matching the generated `compileSdk`, and
the Gradle wrapper included in this package. The wrapper and compatible plugin
settings are reused/detected from the supplied Grove baseline when available.

```bash
./tools/build_android.sh
adb install -r dist/app-debug.apk
```

The release APK produced by `assembleRelease` is unsigned unless a signing
configuration is supplied locally. Do not put private signing keys in this
repository or release ZIP.

On first launch grant camera access. No location, microphone, network, or
broad storage permission is requested. Exports are written under the app's
external Documents directory and shared through a scoped `FileProvider` URI.
