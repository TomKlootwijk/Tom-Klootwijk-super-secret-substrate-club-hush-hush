# Physical-device benchmark protocol

Use a rigid, dimensioned scene with matte high-texture surfaces and at least
ten independently measured control distances. Record app version, device
build, lighting, camera mode, session duration, thermal status, battery drop,
scan size, voxel count, and scale-anchor method.

Evaluate:

1. Absolute trajectory error against a reference trajectory.
2. Relative pose error over 1 m, 5 m, and loop-return segments.
3. Point-to-plane error against a calibrated reference mesh.
4. Control-length median, 95th percentile, and worst error.
5. Repeatability across at least ten independent scans.
6. Tracking-loss rate and recovery behaviour.
7. Export bytes per accepted voxel and per minute.
8. Sustained frame analysis rate, thermal state, memory peak, and battery use.

Do not publish an accuracy number without the raw sessions, reference method,
calibration trace, and statistical aggregation.
