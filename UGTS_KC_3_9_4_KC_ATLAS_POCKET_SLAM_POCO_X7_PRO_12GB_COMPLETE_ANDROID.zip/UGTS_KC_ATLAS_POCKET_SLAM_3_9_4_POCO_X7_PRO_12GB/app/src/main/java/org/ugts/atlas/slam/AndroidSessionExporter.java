package org.ugts.atlas.slam;

import android.content.Context;
import android.os.Environment;
import org.ugts.atlas.slam.core.JsonUtil;
import org.ugts.atlas.slam.core.Keyframe;
import org.ugts.atlas.slam.core.LedgerEvent;
import org.ugts.atlas.slam.core.SessionData;
import org.ugts.atlas.slam.core.UgtsScanCodec;
import org.ugts.atlas.slam.core.Vec3;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

final class AndroidSessionExporter {
    private AndroidSessionExporter(){}
    static File exportCompact(Context context,SessionData data)throws Exception{
        File base=new File(context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),"UGTS");if(!base.exists()&&!base.mkdirs())throw new IOException("cannot create export directory");File out=new File(base,safe(data.sessionId)+".ugtsscan");
        LinkedHashMap<String,byte[]> entries=new LinkedHashMap<>();entries.put("map.ugtsbin",UgtsScanCodec.encode(data.cells,data.voxelSize));entries.put("trajectory.csv",trajectory(data).getBytes(StandardCharsets.UTF_8));entries.put("ledger.ndjson",ledger(data).getBytes(StandardCharsets.UTF_8));entries.put("capture_policy.json",policy(data).getBytes(StandardCharsets.UTF_8));entries.put("README.txt",readme(data).getBytes(StandardCharsets.UTF_8));
        LinkedHashMap<String,String> digests=new LinkedHashMap<>();for(Map.Entry<String,byte[]>e:entries.entrySet())digests.put(e.getKey(),hex(MessageDigest.getInstance("SHA-256").digest(e.getValue())));entries.put("manifest.json",manifest(data,digests).getBytes(StandardCharsets.UTF_8));
        try(ZipOutputStream z=new ZipOutputStream(new FileOutputStream(out))){z.setLevel(3);for(Map.Entry<String,byte[]>e:entries.entrySet()){ZipEntry ze=new ZipEntry(e.getKey());ze.setTime(0L);z.putNextEntry(ze);z.write(e.getValue());z.closeEntry();}}return out;
    }
    private static String trajectory(SessionData d){StringBuilder s=new StringBuilder("keyframe,timestamp_ns,x,y,z,qw,qx,qy,qz\n");for(Keyframe k:d.keyframes){s.append(k.id).append(',').append(k.timestampNs).append(',').append(f(k.pose.position.x)).append(',').append(f(k.pose.position.y)).append(',').append(f(k.pose.position.z)).append(',').append(f(k.pose.orientation.w)).append(',').append(f(k.pose.orientation.x)).append(',').append(f(k.pose.orientation.y)).append(',').append(f(k.pose.orientation.z)).append('\n');}return s.toString();}
    private static String ledger(SessionData d){StringBuilder s=new StringBuilder();for(LedgerEvent e:d.events)s.append(e.toJson()).append('\n');return s.toString();}
    private static String policy(SessionData d){return "{\n  \"schema\": \"ugts.capture-policy/3.9.4\",\n  \"device_profile\": \"poco-x7-pro-12gb-atlas-394\",\n  \"offline\": true,\n  \"metric_scale\": \""+JsonUtil.escape(d.scaleState)+"\",\n  \"camera_intrinsics_source\": \""+JsonUtil.escape(d.cameraSource)+"\",\n  \"camera_intrinsics_calibrated\": "+d.cameraCalibrated+",\n  \"keyframe_images_persisted\": false,\n  \"unknown_is_free_space\": false\n}\n";}
    private static String readme(SessionData d){return "UGTS-KC Atlas Pocket SLAM 3.9.4 compact scan\n\nmap.ugtsbin: quantized, delta/zigzag-varint and DEFLATE-compressed voxel centres.\ntrajectory.csv: accepted keyframe camera poses.\nledger.ndjson: ordered capture and verification events.\ncapture_policy.json: accuracy and privacy state.\nmanifest.json: SHA-256 hashes for all preceding entries.\n\nScale state: "+d.scaleState+". Relative-unit scans must not be interpreted as metres.\n";}
    private static String manifest(SessionData d,LinkedHashMap<String,String> hashes){StringBuilder s=new StringBuilder("{\n  \"schema\": \"ugts.scan-manifest/3.9.4\",\n  \"session_id\": \"").append(JsonUtil.escape(d.sessionId)).append("\",\n  \"frames\": ").append(d.frames).append(",\n  \"keyframes\": ").append(d.keyframes.size()).append(",\n  \"voxels\": ").append(d.cells.size()).append(",\n  \"voxel_size\": ").append(f(d.voxelSize)).append(",\n  \"scale_state\": \"").append(JsonUtil.escape(d.scaleState)).append("\",\n  \"entries\": {\n");int i=0;for(Map.Entry<String,String>e:hashes.entrySet()){s.append("    \"").append(JsonUtil.escape(e.getKey())).append("\": {\"sha256\": \"").append(e.getValue()).append("\"}");if(++i<hashes.size())s.append(',');s.append('\n');}return s.append("  }\n}\n").toString();}
    private static String safe(String s){return s.replaceAll("[^A-Za-z0-9._-]","_");}
    private static String f(double v){return String.format(Locale.ROOT,"%.9g",v);}
    private static String hex(byte[] b){StringBuilder s=new StringBuilder(b.length*2);for(byte x:b)s.append(String.format(Locale.ROOT,"%02x",x&255));return s.toString();}
}
