package org.ugts.atlas.slam;
public final class UgtsFileProvider extends androidx.core.content.FileProvider { public UgtsFileProvider(){super();} }
