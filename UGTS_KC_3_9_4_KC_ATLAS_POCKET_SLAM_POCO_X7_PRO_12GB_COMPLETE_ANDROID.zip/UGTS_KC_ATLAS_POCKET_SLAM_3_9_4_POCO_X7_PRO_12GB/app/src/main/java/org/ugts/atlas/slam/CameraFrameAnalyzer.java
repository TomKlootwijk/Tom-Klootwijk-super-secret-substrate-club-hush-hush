package org.ugts.atlas.slam;

import android.content.Context;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import org.ugts.atlas.slam.core.CameraModel;
import org.ugts.atlas.slam.core.GrayFrame;
import org.ugts.atlas.slam.core.Quat;
import org.ugts.atlas.slam.core.SlamEngine;
import org.ugts.atlas.slam.core.SlamSnapshot;
import org.ugts.atlas.slam.core.Vec3;

final class CameraFrameAnalyzer implements ImageAnalysis.Analyzer {
    interface Listener {void onSnapshot(SlamSnapshot snapshot,String thermal);void onError(Throwable error);}
    private final Context context;private final SlamEngine engine;private final SensorFusion sensors;private final ThermalGovernor thermal;private final Listener listener;private long lastAcceptedNs,lastUiNs;private CameraModel camera;
    CameraFrameAnalyzer(Context context,SlamEngine engine,SensorFusion sensors,ThermalGovernor thermal,Listener listener){this.context=context.getApplicationContext();this.engine=engine;this.sensors=sensors;this.thermal=thermal;this.listener=listener;}
    @Override public void analyze(ImageProxy image){try{long ts=image.getImageInfo().getTimestamp();if(ts-lastAcceptedNs<thermal.minimumFrameIntervalNs())return;lastAcceptedNs=ts;GrayFrame gray=LumaResampler.convert(image,640);if(camera==null||camera.width!=gray.width||camera.height!=gray.height)camera=CameraCalibration.queryBackCamera(context,gray.width,gray.height);Quat q=sensors.orientationAt(ts);Vec3 d=sensors.displacementHint(lastUiNs==0?ts:lastUiNs,ts);SlamSnapshot s=engine.process(gray,camera,q,d);if(s!=null&&ts-lastUiNs>120_000_000L){lastUiNs=ts;listener.onSnapshot(s,thermal.label());}}catch(Throwable t){listener.onError(t);}finally{image.close();}}
}
