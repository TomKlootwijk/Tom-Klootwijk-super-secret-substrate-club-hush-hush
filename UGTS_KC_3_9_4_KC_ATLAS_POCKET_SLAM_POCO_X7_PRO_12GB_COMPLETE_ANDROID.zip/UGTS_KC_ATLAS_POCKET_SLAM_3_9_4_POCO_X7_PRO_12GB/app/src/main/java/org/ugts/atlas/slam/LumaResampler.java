package org.ugts.atlas.slam;

import androidx.camera.core.ImageProxy;
import org.ugts.atlas.slam.core.GrayFrame;
import java.nio.ByteBuffer;

final class LumaResampler {
    private LumaResampler(){}
    static GrayFrame convert(ImageProxy image,int maxLongEdge){
        int sw=image.getWidth(),sh=image.getHeight(),rot=((image.getImageInfo().getRotationDegrees()%360)+360)%360;
        int rw=(rot==90||rot==270)?sh:sw,rh=(rot==90||rot==270)?sw:sh;
        double scale=Math.min(1.0,(double)maxLongEdge/Math.max(rw,rh));int ow=Math.max(64,((int)Math.round(rw*scale))&~1),oh=Math.max(64,((int)Math.round(rh*scale))&~1);
        byte[] out=new byte[ow*oh];ImageProxy.PlaneProxy p=image.getPlanes()[0];ByteBuffer buf=p.getBuffer().duplicate();int rowStride=p.getRowStride(),pixelStride=p.getPixelStride(),base=buf.position();
        for(int y=0;y<oh;y++)for(int x=0;x<ow;x++){
            double ux=(x+0.5)/ow*rw-0.5,uy=(y+0.5)/oh*rh-0.5;double sx,sy;
            if(rot==90){sx=uy;sy=sh-1-ux;}else if(rot==180){sx=sw-1-ux;sy=sh-1-uy;}else if(rot==270){sx=sw-1-uy;sy=ux;}else{sx=ux;sy=uy;}
            int ix=Math.max(0,Math.min(sw-1,(int)Math.round(sx))),iy=Math.max(0,Math.min(sh-1,(int)Math.round(sy)));int idx=base+iy*rowStride+ix*pixelStride;out[y*ow+x]=buf.get(idx);
        }
        return new GrayFrame(ow,oh,image.getImageInfo().getTimestamp(),out);
    }
}
