package org.ugts.atlas.slam;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.HandlerThread;
import org.ugts.atlas.slam.core.Quat;
import org.ugts.atlas.slam.core.Vec3;

final class SensorFusion implements SensorEventListener {
    private static final int CAP=512;
    private final SensorManager manager;private final Sensor rotation,linearAcceleration;private final HandlerThread thread;private final Handler handler;
    private final long[] qt=new long[CAP];private final Quat[] qv=new Quat[CAP];private int qHead,qSize;
    private final long[] at=new long[CAP];private final Vec3[] av=new Vec3[CAP];private int aHead,aSize;
    SensorFusion(Context context){manager=(SensorManager)context.getSystemService(Context.SENSOR_SERVICE);Sensor r=manager.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR);if(r==null)r=manager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);rotation=r;Sensor la=manager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);linearAcceleration=la;thread=new HandlerThread("ugts-imu");thread.start();handler=new Handler(thread.getLooper());}
    void start(){if(rotation!=null)manager.registerListener(this,rotation,SensorManager.SENSOR_DELAY_GAME,handler);if(linearAcceleration!=null)manager.registerListener(this,linearAcceleration,SensorManager.SENSOR_DELAY_GAME,handler);}
    void stop(){manager.unregisterListener(this);}
    void close(){stop();thread.quitSafely();}
    @Override public synchronized void onSensorChanged(SensorEvent e){
        if(e.sensor.getType()==Sensor.TYPE_GAME_ROTATION_VECTOR||e.sensor.getType()==Sensor.TYPE_ROTATION_VECTOR){float[] q=new float[4];SensorManager.getQuaternionFromVector(q,e.values);qt[qHead]=e.timestamp;qv[qHead]=new Quat(q[0],q[1],q[2],q[3]);qHead=(qHead+1)%CAP;qSize=Math.min(CAP,qSize+1);}
        else if(e.sensor.getType()==Sensor.TYPE_LINEAR_ACCELERATION){at[aHead]=e.timestamp;av[aHead]=new Vec3(e.values[0],e.values[1],e.values[2]);aHead=(aHead+1)%CAP;aSize=Math.min(CAP,aSize+1);}
    }
    @Override public void onAccuracyChanged(Sensor sensor,int accuracy){}
    synchronized Quat orientationAt(long ts){if(qSize==0)return Quat.IDENTITY;int newest=(qHead-1+CAP)%CAP,older=newest;for(int i=0;i<qSize;i++){int idx=(qHead-1-i+CAP)%CAP;if(qt[idx]<=ts){older=idx;break;}}int newer=(older+1)%CAP;if(qv[older]==null)return qv[newest]==null?Quat.IDENTITY:qv[newest];if(qv[newer]==null||qt[newer]<=qt[older]||ts<=qt[older])return qv[older];double u=Math.max(0,Math.min(1,(double)(ts-qt[older])/(qt[newer]-qt[older])));return Quat.slerp(qv[older],qv[newer],u);}
    synchronized Vec3 displacementHint(long fromNs,long toNs){if(aSize<2||toNs<=fromNs)return Vec3.ZERO;Vec3 v=Vec3.ZERO,p=Vec3.ZERO;long last=fromNs;for(int i=aSize-1;i>=0;i--){int idx=(aHead-aSize+i+CAP)%CAP;long t=at[idx];if(t<fromNs||t>toNs||av[idx]==null)continue;double dt=Math.min(0.03,Math.max(0,(t-last)*1e-9));v=v.add(av[idx].scale(dt));p=p.add(v.scale(dt));last=t;}double dt=Math.min(0.03,Math.max(0,(toNs-last)*1e-9));return p.add(v.scale(dt));}
    boolean hasRotation(){return rotation!=null;}
}
