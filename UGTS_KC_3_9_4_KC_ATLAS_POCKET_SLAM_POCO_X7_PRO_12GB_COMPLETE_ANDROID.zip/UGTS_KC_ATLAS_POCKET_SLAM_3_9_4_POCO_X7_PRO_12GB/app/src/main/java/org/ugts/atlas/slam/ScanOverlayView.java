package org.ugts.atlas.slam;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;
import org.ugts.atlas.slam.core.MapPoint;
import org.ugts.atlas.slam.core.SlamSnapshot;
import org.ugts.atlas.slam.core.Vec3;
import java.util.List;

final class ScanOverlayView extends View {
    private final Paint feature=new Paint(Paint.ANTI_ALIAS_FLAG),mapPaint=new Paint(Paint.ANTI_ALIAS_FLAG),pathPaint=new Paint(Paint.ANTI_ALIAS_FLAG),panel=new Paint(Paint.ANTI_ALIAS_FLAG),text=new Paint(Paint.ANTI_ALIAS_FLAG);
    private volatile SlamSnapshot snapshot;
    ScanOverlayView(Context c){super(c);setWillNotDraw(false);feature.setColor(Color.argb(180,40,240,205));feature.setStyle(Paint.Style.STROKE);feature.setStrokeWidth(1.5f);mapPaint.setColor(Color.argb(210,255,210,80));mapPaint.setStrokeWidth(2);pathPaint.setColor(Color.argb(230,40,210,255));pathPaint.setStrokeWidth(2.5f);pathPaint.setStyle(Paint.Style.STROKE);panel.setColor(Color.argb(150,8,15,22));text.setColor(Color.WHITE);text.setTextSize(28);}
    void setSnapshot(SlamSnapshot s){snapshot=s;postInvalidateOnAnimation();}
    @Override protected void onDraw(Canvas c){super.onDraw(c);SlamSnapshot s=snapshot;if(s==null)return;float sx=(float)getWidth()/Math.max(1,s.imageWidth),sy=(float)getHeight()/Math.max(1,s.imageHeight);float[] xy=s.featureXY;for(int i=0;i+1<xy.length;i+=2)c.drawCircle(xy[i]*sx,xy[i+1]*sy,3.2f,feature);
        float box=Math.min(getWidth(),getHeight())*0.34f,left=getWidth()-box-18,top=18;c.drawRoundRect(new RectF(left,top,left+box,top+box),12,12,panel);drawMap(c,s.mapSample,s.trajectory,left,top,box);String units="metric_anchor".equals(s.scaleState)?"m":"relative";c.drawText(s.mapPointCount+" voxels · "+s.inlierCount+" inliers · "+units,18,getHeight()-160,text);
    }
    private void drawMap(Canvas c,List<MapPoint> pts,List<Vec3> path,float left,float top,float box){if(pts.isEmpty()&&path.isEmpty())return;double minx=Double.POSITIVE_INFINITY,minz=minx,maxx=-minx,maxz=-minx;for(MapPoint p:pts){minx=Math.min(minx,p.position.x);maxx=Math.max(maxx,p.position.x);minz=Math.min(minz,p.position.z);maxz=Math.max(maxz,p.position.z);}for(Vec3 p:path){minx=Math.min(minx,p.x);maxx=Math.max(maxx,p.x);minz=Math.min(minz,p.z);maxz=Math.max(maxz,p.z);}double span=Math.max(1e-3,Math.max(maxx-minx,maxz-minz));float scale=(float)(box*0.86/span),ox=left+box*0.07f,oy=top+box*0.93f;for(MapPoint p:pts)c.drawPoint(ox+(float)((p.position.x-minx)*scale),oy-(float)((p.position.z-minz)*scale),mapPaint);for(int i=1;i<path.size();i++){Vec3 a=path.get(i-1),b=path.get(i);c.drawLine(ox+(float)((a.x-minx)*scale),oy-(float)((a.z-minz)*scale),ox+(float)((b.x-minx)*scale),oy-(float)((b.z-minz)*scale),pathPaint);}}
}
