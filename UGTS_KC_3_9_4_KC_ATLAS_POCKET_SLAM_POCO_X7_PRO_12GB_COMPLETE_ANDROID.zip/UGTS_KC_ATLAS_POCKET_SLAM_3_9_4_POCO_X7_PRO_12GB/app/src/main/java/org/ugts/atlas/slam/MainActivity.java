package org.ugts.atlas.slam;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LifecycleRegistry;
import com.google.common.util.concurrent.ListenableFuture;
import org.ugts.atlas.slam.core.SessionData;
import org.ugts.atlas.slam.core.SlamConfig;
import org.ugts.atlas.slam.core.SlamEngine;
import org.ugts.atlas.slam.core.SlamSnapshot;
import org.ugts.atlas.slam.core.Vec3;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity implements LifecycleOwner,CameraFrameAnalyzer.Listener {
    private static final int CAMERA_REQUEST=394;
    private final LifecycleRegistry lifecycle=new LifecycleRegistry(this);
    private final ExecutorService analysisExecutor=Executors.newSingleThreadExecutor(r->new Thread(r,"ugts-vision"));
    private final ExecutorService ioExecutor=Executors.newSingleThreadExecutor(r->new Thread(r,"ugts-export"));
    private PreviewView previewView;private ScanOverlayView overlay;private TextView status,banner;private Button start,pause,finish,scale,export;
    private ProcessCameraProvider cameraProvider;private SensorFusion sensors;private ThermalGovernor thermal;private SlamEngine engine;private CameraFrameAnalyzer analyzer;private Vec3 scaleStart;
    @Override public Lifecycle getLifecycle(){return lifecycle;}
    @Override protected void onCreate(Bundle b){super.onCreate(b);lifecycle.handleLifecycleEvent(Lifecycle.Event.ON_CREATE);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);engine=new SlamEngine(SlamConfig.pocoX7Pro12Gb());sensors=new SensorFusion(this);thermal=new ThermalGovernor(this,getMainExecutor());buildUi();if(checkSelfPermission(Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)startCamera();else requestPermissions(new String[]{Manifest.permission.CAMERA},CAMERA_REQUEST);}
    private void buildUi(){FrameLayout root=new FrameLayout(this);previewView=new PreviewView(this);previewView.setImplementationMode(PreviewView.ImplementationMode.PERFORMANCE);previewView.setScaleType(PreviewView.ScaleType.FILL_CENTER);root.addView(previewView,new FrameLayout.LayoutParams(-1,-1));overlay=new ScanOverlayView(this);root.addView(overlay,new FrameLayout.LayoutParams(-1,-1));
        banner=new TextView(this);banner.setText("MONOCULAR · RELATIVE SCALE UNTIL ANCHORED");banner.setTextColor(Color.WHITE);banner.setBackgroundColor(Color.argb(190,110,42,22));banner.setGravity(Gravity.CENTER);banner.setTextSize(13);FrameLayout.LayoutParams bp=new FrameLayout.LayoutParams(-1,48);bp.gravity=Gravity.TOP;root.addView(banner,bp);
        status=new TextView(this);status.setTextColor(Color.WHITE);status.setTextSize(14);status.setPadding(18,10,18,10);status.setBackgroundColor(Color.argb(170,7,15,22));status.setText("Ready · offline · no network permission");FrameLayout.LayoutParams sp=new FrameLayout.LayoutParams(-1,-2);sp.gravity=Gravity.TOP;sp.topMargin=48;root.addView(status,sp);
        LinearLayout controls=new LinearLayout(this);controls.setOrientation(LinearLayout.VERTICAL);controls.setPadding(10,8,10,14);controls.setBackgroundColor(Color.argb(210,10,18,25));LinearLayout row1=new LinearLayout(this),row2=new LinearLayout(this);row1.setGravity(Gravity.CENTER);row2.setGravity(Gravity.CENTER);start=button("Start");pause=button("Pause");finish=button("Finish");scale=button("Scale anchor");export=button("Export compact");add(row1,start);add(row1,pause);add(row1,finish);add(row2,scale);add(row2,export);controls.addView(row1);controls.addView(row2);FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(-1,-2);cp.gravity=Gravity.BOTTOM;root.addView(controls,cp);setContentView(root);
        start.setOnClickListener(v->beginOrResume());pause.setOnClickListener(v->{engine.pause(SystemClock.elapsedRealtimeNanos());status.setText("Paused; camera preview remains local");});finish.setOnClickListener(v->{engine.finish(SystemClock.elapsedRealtimeNanos());status.setText("Finished · ready to export");});scale.setOnClickListener(v->scaleAction());export.setOnClickListener(v->exportAction());}
    private Button button(String text){Button b=new Button(this);b.setText(text);b.setAllCaps(false);b.setTextSize(13);return b;}
    private void add(LinearLayout row,View v){row.addView(v,new LinearLayout.LayoutParams(0,-2,1));}
    private void beginOrResume(){long now=SystemClock.elapsedRealtimeNanos();if(engine.state()==SlamEngine.State.IDLE||engine.state()==SlamEngine.State.FINISHED){String id="atlas394_"+new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.ROOT).format(new Date());engine.start(id,now);scaleStart=null;banner.setText("RELATIVE SCALE · TAP SCALE ANCHOR AFTER A KNOWN MOVE");}else engine.resume(now);status.setText("Scanning · move slowly with translation and texture");}
    private void startCamera(){sensors.start();ListenableFuture<ProcessCameraProvider> future=ProcessCameraProvider.getInstance(this);future.addListener(()->{try{cameraProvider=future.get();Preview preview=new Preview.Builder().build();preview.setSurfaceProvider(previewView.getSurfaceProvider());ImageAnalysis analysis=new ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888).build();analyzer=new CameraFrameAnalyzer(this,engine,sensors,thermal,this);analysis.setAnalyzer(analysisExecutor,analyzer);cameraProvider.unbindAll();cameraProvider.bindToLifecycle(this,CameraSelector.DEFAULT_BACK_CAMERA,preview,analysis);status.setText("Camera ready · press Start");}catch(Exception e){onError(e);}},getMainExecutor());}
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results){super.onRequestPermissionsResult(request,permissions,results);if(request==CAMERA_REQUEST&&results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)startCamera();else status.setText("Camera permission is required for scanning");}
    @Override public void onSnapshot(SlamSnapshot s,String thermalLabel){runOnUiThread(()->{overlay.setSnapshot(s);String scaleLabel="metric_anchor".equals(s.scaleState)?String.format(Locale.ROOT,"metric × %.4g",s.metricScale):"relative/unanchored";status.setText(String.format(Locale.ROOT,"%s · frame %d · KF %d · %d voxels · Q %.2f · %s",thermalLabel,s.frameId,s.keyframeCount,s.mapPointCount,s.trackingQuality,scaleLabel));if("metric_anchor".equals(s.scaleState)){banner.setText("METRIC ANCHOR ACTIVE · VERIFY AGAINST A SECOND CONTROL LENGTH");banner.setBackgroundColor(Color.argb(190,14,92,74));}});}
    @Override public void onError(Throwable error){runOnUiThread(()->status.setText("Capture error: "+error.getClass().getSimpleName()+" · "+String.valueOf(error.getMessage())));}
    private void scaleAction(){if(engine.state()!=SlamEngine.State.SCANNING&&engine.state()!=SlamEngine.State.PAUSED){Toast.makeText(this,"Start a scan first",Toast.LENGTH_SHORT).show();return;}if(scaleStart==null){scaleStart=engine.currentPosition();scale.setText("Finish anchor");Toast.makeText(this,"Move the camera a known straight-line distance, then tap Finish anchor",Toast.LENGTH_LONG).show();return;}Vec3 end=engine.currentPosition();EditText input=new EditText(this);input.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);input.setHint("Known distance in metres");new AlertDialog.Builder(this).setTitle("Metric scale anchor").setMessage("Enter the measured straight-line camera displacement. This does not remove monocular drift; verify with a second control length.").setView(input).setNegativeButton("Cancel",null).setPositiveButton("Apply",(d,w)->{try{double metres=Double.parseDouble(input.getText().toString());boolean ok=engine.applyKnownDistanceAnchor(scaleStart,end,metres,SystemClock.elapsedRealtimeNanos());Toast.makeText(this,ok?"Metric anchor applied":"Anchor rejected",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"Invalid distance",Toast.LENGTH_SHORT).show();}finally{scaleStart=null;scale.setText("Scale anchor");}}).show();}
    private void exportAction(){engine.finish(SystemClock.elapsedRealtimeNanos());SessionData data=engine.sessionData();export.setEnabled(false);status.setText("Encoding compact scan…");ioExecutor.execute(()->{try{File file=AndroidSessionExporter.exportCompact(this,data);runOnUiThread(()->{export.setEnabled(true);status.setText("Exported "+file.getName()+" · "+human(file.length()));share(file);});}catch(Exception e){runOnUiThread(()->{export.setEnabled(true);onError(e);});}});}
    private void share(File file){try{Uri uri=androidx.core.content.FileProvider.getUriForFile(this,getPackageName()+".files",file);Intent i=new Intent(Intent.ACTION_SEND);i.setType("application/zip");i.putExtra(Intent.EXTRA_STREAM,uri);i.setClipData(ClipData.newRawUri(file.getName(),uri));i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"Share UGTS compact scan"));}catch(Exception e){onError(e);}}
    private static String human(long b){if(b<1024)return b+" B";if(b<1024*1024)return String.format(Locale.ROOT,"%.1f KiB",b/1024.0);return String.format(Locale.ROOT,"%.1f MiB",b/1048576.0);}
    @Override protected void onStart(){super.onStart();lifecycle.handleLifecycleEvent(Lifecycle.Event.ON_START);}
    @Override protected void onResume(){super.onResume();lifecycle.handleLifecycleEvent(Lifecycle.Event.ON_RESUME);}
    @Override protected void onPause(){lifecycle.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE);super.onPause();}
    @Override protected void onStop(){lifecycle.handleLifecycleEvent(Lifecycle.Event.ON_STOP);super.onStop();}
    @Override protected void onDestroy(){if(cameraProvider!=null)cameraProvider.unbindAll();sensors.close();thermal.close();analysisExecutor.shutdownNow();ioExecutor.shutdownNow();lifecycle.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY);super.onDestroy();}
}
