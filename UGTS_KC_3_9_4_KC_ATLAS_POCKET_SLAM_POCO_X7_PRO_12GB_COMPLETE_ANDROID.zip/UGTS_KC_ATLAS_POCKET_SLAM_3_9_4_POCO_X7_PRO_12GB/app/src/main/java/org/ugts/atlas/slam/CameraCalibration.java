package org.ugts.atlas.slam;

import android.content.Context;
import android.graphics.Rect;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.util.SizeF;
import org.ugts.atlas.slam.core.CameraModel;

final class CameraCalibration {
    private CameraCalibration(){}
    static CameraModel queryBackCamera(Context context,int outputWidth,int outputHeight){
        try{
            CameraManager manager=(CameraManager)context.getSystemService(Context.CAMERA_SERVICE);
            for(String id:manager.getCameraIdList()){
                CameraCharacteristics c=manager.getCameraCharacteristics(id);Integer facing=c.get(CameraCharacteristics.LENS_FACING);if(facing==null||facing!=CameraCharacteristics.LENS_FACING_BACK)continue;
                float[] focal=c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS);SizeF sensor=c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE);Rect active=c.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE);
                if(focal==null||focal.length==0||sensor==null||active==null||sensor.getWidth()<=0||sensor.getHeight()<=0)continue;
                // The analysis frame is portrait after LumaResampler. Use the long/short physical dimensions consistently.
                double imageAspect=(double)outputWidth/outputHeight;double sensorAspect=(double)sensor.getWidth()/sensor.getHeight();
                double sensorW=imageAspect<1?Math.min(sensor.getWidth(),sensor.getHeight()):Math.max(sensor.getWidth(),sensor.getHeight());
                double sensorH=imageAspect<1?Math.max(sensor.getWidth(),sensor.getHeight()):Math.min(sensor.getWidth(),sensor.getHeight());
                double fx=focal[0]/sensorW*outputWidth,fy=focal[0]/sensorH*outputHeight;
                return new CameraModel(outputWidth,outputHeight,fx,fy,(outputWidth-1)*0.5,(outputHeight-1)*0.5,true,"camera2_characteristics:"+id);
            }
        }catch(Exception ignored){}
        return CameraModel.declaredFallback(outputWidth,outputHeight);
    }
}
