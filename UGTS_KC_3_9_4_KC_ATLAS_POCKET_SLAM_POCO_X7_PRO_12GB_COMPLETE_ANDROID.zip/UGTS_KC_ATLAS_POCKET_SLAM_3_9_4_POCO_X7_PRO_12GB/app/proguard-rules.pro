# No reflection-based application model is used. CameraX consumer rules are retained.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
-keep class org.ugts.atlas.slam.MainActivity { *; }
-keep class org.ugts.atlas.slam.UgtsFileProvider { *; }
