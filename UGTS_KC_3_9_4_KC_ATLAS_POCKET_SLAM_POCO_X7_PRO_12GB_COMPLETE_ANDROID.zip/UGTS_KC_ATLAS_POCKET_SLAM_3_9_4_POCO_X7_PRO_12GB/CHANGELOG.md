# Changelog

## 3.9.4 — KC Atlas Pocket SLAM

- First native Android capture implementation for the Atlas 3.9.3 ledger.
- Added pure-Java monocular visual-inertial frontend and sparse/semi-dense map.
- Added POCO X7 Pro 12 GB thermal/memory profile.
- Added explicit metric-anchor workflow and uncertainty-preserving state.
- Added compact UG3D codec, `.ugtsscan` container, hashes, verifier and PLY decoder.
- Reused the supplied Grove Gradle wrapper/configuration where discoverable.
- Retained a lean upstream Android snapshot and complete input hash inventory.
