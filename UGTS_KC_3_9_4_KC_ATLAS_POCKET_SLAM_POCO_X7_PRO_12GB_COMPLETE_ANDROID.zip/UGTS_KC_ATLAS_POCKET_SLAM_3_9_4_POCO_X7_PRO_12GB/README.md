# UGTS-KC 3.9.4 — KC Atlas Pocket SLAM

Native, offline Android monocular visual-inertial 3D scanner, profiled for the
**POCO X7 Pro 12 GB RAM edition** and derived from the supplied Grove 3.9.2
Android package plus the Atlas 3.9.3 spatial-ledger contracts.

## What is implemented

- CameraX Y-plane capture with a bounded `KEEP_ONLY_LATEST` analysis queue.
- Rotation-vector and linear-acceleration timestamp sampling.
- Deterministic FAST-9 + 256-bit BRIEF visual frontend.
- LSH descriptor matching with mutual-best and ratio guards.
- IMU-rotation-compensated epipolar translation-direction estimation.
- Guarded two-view triangulation and keyframe-only semi-dense plane sweep.
- Confidence-weighted voxel fusion with a fixed active-map ceiling.
- Stable session/keyframe/event identity and an ordered commit ledger.
- Explicit **relative scale** state until a known-distance anchor is applied.
- Compact `.ugtsscan` export: quantized coordinates, delta/zigzag varints,
  DEFLATE level 3, no keyframe images by default, and SHA-256 entry hashes.
- Thermal-adaptive 15/10/6 Hz analysis policy.
- Offline operation with no Android network permission.
- R8/resource shrinking for release builds.

## Scan workflow

1. Hold the phone in portrait, press **Start**, and move slowly through textured
   areas. Translation is necessary; pure rotation cannot triangulate depth.
2. Use the top-right map and inlier/quality display to revisit weak regions.
3. For metric output, tap **Scale anchor**, move the camera by a measured
   straight-line distance, tap **Finish anchor**, and enter that distance.
4. Verify scale against a second known length. Press **Finish**, then
   **Export compact**.

The resulting map is a sparse/semi-dense evidence scan, not a dense neural
radiance field. It is intentionally small, deterministic, offline, and
inspectable. Monocular drift remains possible; unanchored output must never be
interpreted as metres.

## Build

```bash
./tools/run_host_tests.sh
./gradlew :app:assembleDebug
./gradlew :app:assembleRelease
```

Android Studio can open the package root directly. `compileSdk`, Android
Gradle Plugin, CameraX, and the Gradle wrapper are selected from/reused from
the supplied working baseline where available; exact resolved values are in
`provenance/derivation.json` and `BUILD_STATUS.json`.

## Desktop inspection

```bash
python tools/ugts_scan_tool.py scan.ugtsscan
python tools/ugts_scan_tool.py scan.ugtsscan --to-ply scan.ply
```

## Scope

This is an engineering capture implementation, not a structural-safety,
rescue, navigation, clinical, or legal-certification instrument. Physical
accuracy and thermal performance must be benchmarked on the named handset
against calibrated ground truth before any safety-critical deployment.
