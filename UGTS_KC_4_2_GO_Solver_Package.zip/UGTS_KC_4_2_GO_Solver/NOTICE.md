# Notice and evidence boundary

UGTS-KC 4.2 Go is an engineering extension prepared from the requester-supplied UGTS reports. It preserves their query-first terminology and deterministic event discipline but introduces a new Go-specific rules and search layer.

The package does **not** claim a game-theoretic solution of unrestricted standard 19x19 Go. It provides:

- a deterministic area-scoring Go rules engine;
- exact exhaustive solving for bounded finite states under positional or situational superko;
- verified solved fixtures, including the complete empty 2x2 game under the declared profile;
- a content-addressed solve certificate that can be checked by deterministic rerun;
- seeded MCTS and a browser board for larger-board exploration, explicitly marked non-exact.

The requester name is recorded only as project attribution. Identity, authorship, ownership, patentability, priority, and legal title are not independently verified by this package. No source PDF is redistributed inside the ZIP.
