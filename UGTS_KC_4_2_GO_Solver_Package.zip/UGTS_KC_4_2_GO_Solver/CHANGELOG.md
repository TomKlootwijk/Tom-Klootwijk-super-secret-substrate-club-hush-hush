# Changelog

## 4.2.0 - 2026-08-29

- Added a typed immutable Go state with exact half-point komi.
- Added captures, suicide policy, simple ko, positional superko, situational superko, pass termination, and area scoring.
- Added proposal/guard/commit event records with state hashes and lineage labels.
- Added exact alpha-beta minimax with exact superko-history state and optional D4 canonicalization.
- Added solve certificates with canonical JSON hashes and deterministic rerun verification.
- Added seeded MCTS as a non-proof search mode.
- Added SGF single-variation import/export and a self-contained HTML board.
- Added the M390-M449 mechanism catalog, JSON Schema, examples, 52 tests, validation captures, and SHA-256 manifest.
