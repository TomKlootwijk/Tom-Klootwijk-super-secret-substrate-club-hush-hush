from __future__ import annotations

import json
from pathlib import Path

from ugts_go import ExactSolver, Rules, initial_state
from ugts_go.certificate import create_certificate, write_certificate
from ugts_go.solver import format_pv

ROOT = Path(__file__).resolve().parents[1]

rows = []
for size, komi_half in [(1, 0), (1, 1), (2, 0), (2, 1), (2, 2), (2, 3)]:
    state = initial_state(Rules(size=size, komi_halfpoints=komi_half))
    solver = ExactSolver(use_symmetry=True)
    result = solver.solve(state)
    rows.append(
        {
            "size": size,
            "komi": komi_half / 2,
            "complete": result.complete,
            "black_margin": result.value_points,
            "winner": {1: "black", 2: "white", 0: "draw"}.get(result.winner),
            "best_move": None if result.best_move is None else result.best_move.point,
            "principal_variation": format_pv(result.principal_variation, size),
            "metrics": {
                "nodes": result.metrics.nodes,
                "table_entries": result.metrics.table_entries,
                "max_ply": result.metrics.max_ply,
                "elapsed_seconds": result.metrics.elapsed_seconds,
            },
        }
    )
    if size == 2 and komi_half == 1:
        certificate = create_certificate(state, result, solver)
        write_certificate(ROOT / "validation" / "solve_2x2_k0_5.json", certificate)

out = ROOT / "validation" / "solved_positions.json"
out.write_text(json.dumps(rows, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(out)
for row in rows:
    print(row)
