from __future__ import annotations

from ugts_go.model import BLACK, IllegalMove, Move, Rules
from ugts_go.rules import initial_state, play_move
from ugts_go.topology import board_to_ascii, coord_to_index, parse_ascii

board, size = parse_ascii(
    """
    .....
    ..XO.
    .XO.O
    ..XO.
    .....
    """
)
state = initial_state(Rules(size=size, ko_rule="positional-superko"), board=board, to_play=BLACK)
print("Before capture")
print(board_to_ascii(state.board, size))
state = play_move(state, Move(coord_to_index("D3", size))).state
print("\nAfter black D3")
print(board_to_ascii(state.board, size))
try:
    play_move(state, Move(coord_to_index("C3", size)))
except IllegalMove as exc:
    print(f"\nWhite C3 rejected: {exc.code}: {exc}")
