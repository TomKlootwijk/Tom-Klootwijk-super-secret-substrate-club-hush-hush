from __future__ import annotations

from ugts_go import MCTSSolver, Rules, initial_state
from ugts_go.topology import index_to_coord

state = initial_state(Rules(size=9, komi_halfpoints=15))
result = MCTSSolver(iterations=100, rollout_limit=128, seed=420042).solve(state)
print("exact:", result.exact)
print("best move:", index_to_coord(result.best_move.point, 9) if result.best_move else None)
print("estimated black win rate:", result.estimated_black_win_rate)
for move, visits, rate in result.child_statistics[:10]:
    print(index_to_coord(move.point, 9), visits, rate)
