"""Exact finite Go solver with alpha-beta, exact repetition state, and certificates.

This solver is intended for small boards and local bounded positions.  It does
not claim that a standard 19x19 opening has been game-theoretically solved.
"""

from __future__ import annotations

import hashlib
import json
import math
import sys
import time
from dataclasses import dataclass
from enum import Enum
from typing import Any, Iterable

from .model import BLACK, EMPTY, WHITE, GameState, Move, Transition
from .rules import legal_transitions, score_board, terminal_score
from .symmetry import transform_board, transform_repetition_code
from .topology import index_to_coord

sys.setrecursionlimit(max(sys.getrecursionlimit(), 100_000))

INF = 10**9


class Bound(str, Enum):
    EXACT = "exact"
    LOWER = "lower"
    UPPER = "upper"


@dataclass(frozen=True, slots=True)
class TTEntry:
    value_halfpoints: int
    bound: Bound


@dataclass(frozen=True, slots=True)
class SearchMetrics:
    nodes: int
    terminal_nodes: int
    transposition_hits: int
    cutoffs: int
    table_entries: int
    elapsed_seconds: float
    max_ply: int


@dataclass(frozen=True, slots=True)
class SolveResult:
    complete: bool
    value_halfpoints: int | None
    best_move: Move | None
    principal_variation: tuple[Move, ...]
    metrics: SearchMetrics
    reason: str

    @property
    def value_points(self) -> float | None:
        return None if self.value_halfpoints is None else self.value_halfpoints / 2.0

    @property
    def winner(self) -> int | None:
        if self.value_halfpoints is None:
            return None
        if self.value_halfpoints > 0:
            return BLACK
        if self.value_halfpoints < 0:
            return WHITE
        return EMPTY


class SearchLimitExceeded(RuntimeError):
    pass


class ExactSolver:
    """History-correct exact minimax solver.

    The transposition key includes the exact superko history.  Optional D4
    canonicalization transforms the board and every history element under the
    same symmetry, preserving legality.
    """

    def __init__(
        self,
        *,
        node_limit: int | None = None,
        time_limit_seconds: float | None = None,
        use_symmetry: bool = True,
    ) -> None:
        self.node_limit = node_limit
        self.time_limit_seconds = time_limit_seconds
        self.use_symmetry = use_symmetry
        self.table: dict[object, TTEntry] = {}
        self.nodes = 0
        self.terminal_nodes = 0
        self.transposition_hits = 0
        self.cutoffs = 0
        self.max_ply = 0
        self._started = 0.0
        self._root: GameState | None = None

    def reset(self) -> None:
        self.table.clear()
        self.nodes = 0
        self.terminal_nodes = 0
        self.transposition_hits = 0
        self.cutoffs = 0
        self.max_ply = 0
        self._started = 0.0
        self._root = None

    def _check_budget(self) -> None:
        if self.node_limit is not None and self.nodes > self.node_limit:
            raise SearchLimitExceeded(f"node limit {self.node_limit} exceeded")
        if (
            self.time_limit_seconds is not None
            and time.monotonic() - self._started > self.time_limit_seconds
        ):
            raise SearchLimitExceeded(
                f"time limit {self.time_limit_seconds:.3f}s exceeded"
            )

    def _raw_key(self, state: GameState) -> tuple[object, ...]:
        return (
            state.board,
            state.to_play,
            state.consecutive_passes,
            state.previous_board,
            state.history,
        )

    def _canonical_key(self, state: GameState) -> tuple[object, ...]:
        if not self.use_symmetry or state.rules.size == 1:
            return self._raw_key(state)
        size = state.rules.size
        candidates: list[tuple[object, ...]] = []
        for transform in range(8):
            board = transform_board(state.board, size, transform)
            previous = (
                None
                if state.previous_board is None
                else transform_board(state.previous_board, size, transform)
            )
            history = tuple(
                sorted(
                    transform_repetition_code(
                        key, size, transform,
                        situational=state.rules.ko_rule == "situational-superko"
                    )
                    for key in state.history
                )
            )
            candidates.append(
                (
                    board,
                    state.to_play,
                    state.consecutive_passes,
                    previous,
                    history,
                )
            )
        return min(candidates)

    def _ordered_transitions(self, state: GameState) -> list[Transition]:
        transitions = list(legal_transitions(state, compute_hash=False))

        def key(t: Transition) -> tuple[int, int, int, int]:
            event = t.event
            capture = len(event.captured) - len(event.self_removed)
            is_terminal = int(t.state.is_terminal)
            # Area score is only a move-ordering heuristic before terminality.
            margin = score_board(t.state.board, t.state.rules).black_margin_halfpoints
            point_key = event.move.point if not event.move.is_pass else state.rules.size**2
            if state.to_play == BLACK:
                return (-is_terminal, -capture, -margin, point_key)
            return (-is_terminal, -capture, margin, point_key)

        transitions.sort(key=key)
        return transitions

    def _search(self, state: GameState, alpha: int, beta: int, ply: int) -> int:
        self.nodes += 1
        self.max_ply = max(self.max_ply, ply)
        if self.node_limit is not None and self.nodes > self.node_limit:
            self._check_budget()
        elif (self.nodes & 0x3FF) == 0:
            self._check_budget()

        if state.is_terminal:
            self.terminal_nodes += 1
            return terminal_score(state).black_margin_halfpoints

        key = self._canonical_key(state)
        original_alpha, original_beta = alpha, beta
        entry = self.table.get(key)
        if entry is not None:
            self.transposition_hits += 1
            if entry.bound == Bound.EXACT:
                return entry.value_halfpoints
            if entry.bound == Bound.LOWER:
                alpha = max(alpha, entry.value_halfpoints)
            elif entry.bound == Bound.UPPER:
                beta = min(beta, entry.value_halfpoints)
            if alpha >= beta:
                return entry.value_halfpoints

        transitions = self._ordered_transitions(state)
        if not transitions:
            # Defensive fallback. Pass should always be legal in a nonterminal state.
            value = score_board(state.board, state.rules).black_margin_halfpoints
            self.table[key] = TTEntry(value, Bound.EXACT)
            return value

        if state.to_play == BLACK:
            value = -INF
            for transition in transitions:
                child = self._search(transition.state, alpha, beta, ply + 1)
                if child > value:
                    value = child
                alpha = max(alpha, value)
                if alpha >= beta:
                    self.cutoffs += 1
                    break
        else:
            value = INF
            for transition in transitions:
                child = self._search(transition.state, alpha, beta, ply + 1)
                if child < value:
                    value = child
                beta = min(beta, value)
                if alpha >= beta:
                    self.cutoffs += 1
                    break

        if value <= original_alpha:
            bound = Bound.UPPER
        elif value >= original_beta:
            bound = Bound.LOWER
        else:
            bound = Bound.EXACT
        self.table[key] = TTEntry(value, bound)
        return value

    def _exact_value(self, state: GameState) -> int:
        key = self._canonical_key(state)
        entry = self.table.get(key)
        if entry is not None and entry.bound == Bound.EXACT:
            return entry.value_halfpoints
        return self._search(state, -INF, INF, 0)

    def solve(self, state: GameState, *, pv_limit: int = 512) -> SolveResult:
        self.reset()
        if state.rules.ko_rule not in {"positional-superko", "situational-superko"}:
            metrics = SearchMetrics(0, 0, 0, 0, 0, 0.0, 0)
            return SolveResult(
                complete=False, value_halfpoints=None, best_move=None,
                principal_variation=(), metrics=metrics,
                reason="exact solver requires positional or situational superko to guarantee a finite game graph",
            )
        self._root = state
        self._started = time.monotonic()
        reason = "exhaustive search completed"
        complete = True
        value: int | None = None
        best_move: Move | None = None
        pv: tuple[Move, ...] = ()
        try:
            value = self._search(state, -INF, INF, 0)
            # Root search with a full window should be exact.
            self.table[self._canonical_key(state)] = TTEntry(value, Bound.EXACT)
            best_move = self.best_move(state, expected_value=value)
            pv = self.principal_variation(state, limit=pv_limit)
        except SearchLimitExceeded as exc:
            complete = False
            reason = str(exc)
        elapsed = time.monotonic() - self._started
        metrics = SearchMetrics(
            nodes=self.nodes,
            terminal_nodes=self.terminal_nodes,
            transposition_hits=self.transposition_hits,
            cutoffs=self.cutoffs,
            table_entries=len(self.table),
            elapsed_seconds=elapsed,
            max_ply=self.max_ply,
        )
        return SolveResult(
            complete=complete,
            value_halfpoints=value if complete else None,
            best_move=best_move if complete else None,
            principal_variation=pv if complete else (),
            metrics=metrics,
            reason=reason,
        )

    def best_move(self, state: GameState, *, expected_value: int | None = None) -> Move | None:
        if state.is_terminal:
            return None
        target = expected_value
        if target is None:
            target = self._exact_value(state)
        transitions = self._ordered_transitions(state)
        chosen: Move | None = None
        for transition in transitions:
            value = self._exact_value(transition.state)
            if value == target:
                chosen = transition.event.move
                break
        return chosen

    def principal_variation(self, state: GameState, *, limit: int = 512) -> tuple[Move, ...]:
        pv: list[Move] = []
        current = state
        for _ in range(limit):
            if current.is_terminal:
                break
            value = self._exact_value(current)
            move = self.best_move(current, expected_value=value)
            if move is None:
                break
            pv.append(move)
            for transition in self._ordered_transitions(current):
                if transition.event.move == move:
                    current = transition.state
                    break
            else:
                break
        return tuple(pv)

    def analyze_moves(self, state: GameState) -> tuple[tuple[Move, int], ...]:
        out: list[tuple[Move, int]] = []
        for transition in self._ordered_transitions(state):
            value = self._exact_value(transition.state)
            out.append((transition.event.move, value))
        if state.to_play == BLACK:
            out.sort(key=lambda item: (-item[1], item[0].point))
        else:
            out.sort(key=lambda item: (item[1], item[0].point))
        return tuple(out)

    def table_digest(self) -> str:
        """Stable digest of value/bound entries, independent of Python hashes."""

        rows: list[str] = []
        for key, entry in self.table.items():
            rows.append(
                json.dumps(
                    {
                        "key": _jsonable_key(key),
                        "value": entry.value_halfpoints,
                        "bound": entry.bound.value,
                    },
                    sort_keys=True,
                    separators=(",", ":"),
                )
            )
        digest = hashlib.sha256()
        for row in sorted(rows):
            digest.update(row.encode("utf-8"))
            digest.update(b"\n")
        return digest.hexdigest()


def _jsonable_key(value: object) -> object:
    if isinstance(value, bytes):
        return {"bytes": value.hex()}
    if isinstance(value, frozenset):
        return sorted(_jsonable_key(item) for item in value)  # type: ignore[arg-type]
    if isinstance(value, tuple):
        return [_jsonable_key(item) for item in value]
    if value is None or isinstance(value, (int, str, float, bool)):
        return value
    return repr(value)


def format_pv(pv: Iterable[Move], size: int) -> list[str]:
    return [index_to_coord(move.point, size) for move in pv]
