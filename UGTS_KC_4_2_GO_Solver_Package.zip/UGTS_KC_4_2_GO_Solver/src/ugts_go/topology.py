"""Board topology, groups, liberties, regions, and coordinate conversion."""

from __future__ import annotations

from functools import lru_cache
from typing import Iterable, Iterator, Sequence

from .model import BLACK, EMPTY, WHITE, Color

_COLUMNS = "ABCDEFGHJKLMNOPQRSTUVWXYZ"  # Go coordinates conventionally skip I.


@lru_cache(maxsize=32)
def neighbors_table(size: int) -> tuple[tuple[int, ...], ...]:
    if size < 1:
        raise ValueError("size must be positive")
    out: list[tuple[int, ...]] = []
    for p in range(size * size):
        x, y = p % size, p // size
        ns: list[int] = []
        if x > 0:
            ns.append(p - 1)
        if x + 1 < size:
            ns.append(p + 1)
        if y > 0:
            ns.append(p - size)
        if y + 1 < size:
            ns.append(p + size)
        out.append(tuple(ns))
    return tuple(out)


def neighbors(point: int, size: int) -> tuple[int, ...]:
    return neighbors_table(size)[point]


def group_and_liberties(
    board: Sequence[int], start: int, size: int
) -> tuple[frozenset[int], frozenset[int]]:
    color = board[start]
    if color not in (BLACK, WHITE):
        raise ValueError("group start must contain a stone")
    ns = neighbors_table(size)
    group: set[int] = {start}
    liberties: set[int] = set()
    stack = [start]
    while stack:
        p = stack.pop()
        for q in ns[p]:
            cell = board[q]
            if cell == EMPTY:
                liberties.add(q)
            elif cell == color and q not in group:
                group.add(q)
                stack.append(q)
    return frozenset(group), frozenset(liberties)


def all_groups(
    board: Sequence[int], size: int
) -> Iterator[tuple[Color, frozenset[int], frozenset[int]]]:
    seen: set[int] = set()
    for p, cell in enumerate(board):
        if cell in (BLACK, WHITE) and p not in seen:
            group, libs = group_and_liberties(board, p, size)
            seen.update(group)
            yield cell, group, libs  # type: ignore[misc]


def empty_region(
    board: Sequence[int], start: int, size: int
) -> tuple[frozenset[int], frozenset[int]]:
    if board[start] != EMPTY:
        raise ValueError("region start must be empty")
    ns = neighbors_table(size)
    region: set[int] = {start}
    border_colors: set[int] = set()
    stack = [start]
    while stack:
        p = stack.pop()
        for q in ns[p]:
            cell = board[q]
            if cell == EMPTY and q not in region:
                region.add(q)
                stack.append(q)
            elif cell in (BLACK, WHITE):
                border_colors.add(cell)
    return frozenset(region), frozenset(border_colors)


def connected_empty_regions(
    board: Sequence[int], size: int
) -> Iterator[tuple[frozenset[int], frozenset[int]]]:
    seen: set[int] = set()
    for p, cell in enumerate(board):
        if cell == EMPTY and p not in seen:
            region, border = empty_region(board, p, size)
            seen.update(region)
            yield region, border


def index_to_xy(point: int, size: int) -> tuple[int, int]:
    if not (0 <= point < size * size):
        raise ValueError("point outside board")
    return point % size, point // size


def xy_to_index(x: int, y: int, size: int) -> int:
    if not (0 <= x < size and 0 <= y < size):
        raise ValueError("coordinate outside board")
    return y * size + x


def index_to_coord(point: int, size: int) -> str:
    if point < 0:
        return "pass"
    x, y = index_to_xy(point, size)
    if x >= len(_COLUMNS):
        raise ValueError("coordinate formatter supports up to 25 columns")
    # Go diagrams count rows from the bottom.
    return f"{_COLUMNS[x]}{size - y}"


def coord_to_index(coord: str, size: int) -> int:
    token = coord.strip().upper()
    if token in {"PASS", "P", ""}:
        return -1
    if len(token) < 2:
        raise ValueError(f"invalid coordinate: {coord!r}")
    column = token[0]
    if column == "I" or column not in _COLUMNS[:size]:
        raise ValueError(f"invalid Go column: {column}")
    try:
        row = int(token[1:])
    except ValueError as exc:
        raise ValueError(f"invalid Go row: {token[1:]}") from exc
    if not (1 <= row <= size):
        raise ValueError(f"row must be in [1,{size}]")
    x = _COLUMNS.index(column)
    y = size - row
    return xy_to_index(x, y, size)


def board_to_ascii(board: Sequence[int], size: int) -> str:
    glyph = {EMPTY: ".", BLACK: "X", WHITE: "O"}
    lines: list[str] = []
    for y in range(size):
        row_number = size - y
        row = " ".join(glyph[board[y * size + x]] for x in range(size))
        lines.append(f"{row_number:>2} {row}")
    columns = " ".join(_COLUMNS[:size])
    lines.append(f"   {columns}")
    return "\n".join(lines)


def parse_ascii(diagram: str) -> tuple[bytes, int]:
    rows: list[list[int]] = []
    for raw in diagram.strip().splitlines():
        line = raw.strip().replace(" ", "")
        if not line or line.startswith("#"):
            continue
        values: list[int] = []
        for ch in line:
            if ch in ".+_":
                values.append(EMPTY)
            elif ch in "XxBb@":
                values.append(BLACK)
            elif ch in "OoWw0":
                values.append(WHITE)
            else:
                raise ValueError(f"unknown board character: {ch!r}")
        rows.append(values)
    if not rows or any(len(row) != len(rows) for row in rows):
        raise ValueError("ASCII board must be a non-empty square")
    size = len(rows)
    return bytes(cell for row in rows for cell in row), size
