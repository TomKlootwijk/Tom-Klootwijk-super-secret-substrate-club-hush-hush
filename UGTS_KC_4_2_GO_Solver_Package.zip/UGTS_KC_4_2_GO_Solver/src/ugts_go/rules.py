"""Deterministic Go rules, proposal verification, commit, and scoring."""

from __future__ import annotations

from dataclasses import replace
from typing import Iterable, Iterator

from .hashing import board_code, state_hash
from .model import (
    BLACK,
    EMPTY,
    PASS_POINT,
    WHITE,
    GameState,
    IllegalMove,
    Move,
    MoveEvent,
    Rules,
    Score,
    Transition,
    opponent,
)
from .topology import connected_empty_regions, group_and_liberties, neighbors_table


def _repetition_key(board: bytes, to_play: int, rules: Rules) -> int:
    code = board_code(board)
    if rules.ko_rule == "situational-superko":
        return code * 3 + to_play
    return code


def initial_state(rules: Rules, board: bytes | None = None, to_play: int = BLACK) -> GameState:
    if board is None:
        board = bytes([EMPTY]) * (rules.size * rules.size)
    if len(board) != rules.size * rules.size:
        raise ValueError("initial board has wrong size")
    history: frozenset[int]
    if rules.ko_rule in {"positional-superko", "situational-superko"}:
        history = frozenset({_repetition_key(board, to_play, rules)})
    else:
        history = frozenset()
    return GameState(rules=rules, board=board, to_play=to_play, history=history)


def _verify_repetition(state: GameState, resulting_board: bytes, next_to_play: int) -> None:
    rule = state.rules.ko_rule
    if rule == "none":
        return
    if rule == "simple-ko":
        if state.previous_board is not None and resulting_board == state.previous_board:
            raise IllegalMove("simple-ko", "move repeats the position from one ply earlier")
        return
    key = _repetition_key(resulting_board, next_to_play, state.rules)
    if key in state.history:
        raise IllegalMove(rule, "move violates the declared superko rule")


def play_move(state: GameState, move: Move, *, compute_hash: bool = True) -> Transition:
    """Verify and atomically commit one move proposal."""

    move.validate_for(state.rules.size)
    if state.is_terminal:
        raise IllegalMove("game-over", "the game has already ended after two passes")

    pre = state_hash(state) if compute_hash else ""
    color = state.to_play
    next_color = opponent(color)

    if move.is_pass:
        history = state.history
        if state.rules.ko_rule in {"positional-superko", "situational-superko"}:
            history = history | {
                _repetition_key(state.board, next_color, state.rules)
            }
        next_state = GameState(
            rules=state.rules,
            board=state.board,
            to_play=next_color,
            consecutive_passes=min(2, state.consecutive_passes + 1),
            move_number=state.move_number + 1,
            history=frozenset(history),
            previous_board=state.board if state.rules.ko_rule == "simple-ko" else state.previous_board,
        )
        post = state_hash(next_state) if compute_hash else ""
        event = MoveEvent(
            move=move,
            color=color,
            captured=(),
            self_removed=(),
            pre_hash=pre,
            post_hash=post,
            guard_status="pass-accepted",
            lineage_label=f"m{next_state.move_number}:{'B' if color == BLACK else 'W'}:pass",
        )
        return Transition(next_state, event)

    point = move.point
    if state.board[point] != EMPTY:
        raise IllegalMove("occupied", "the intersection is occupied")

    size = state.rules.size
    ns = neighbors_table(size)
    board = bytearray(state.board)
    board[point] = color
    captured: set[int] = set()

    for q in ns[point]:
        if board[q] == next_color:
            group, liberties = group_and_liberties(board, q, size)
            if not liberties:
                captured.update(group)
                for stone in group:
                    board[stone] = EMPTY

    own_group, own_liberties = group_and_liberties(board, point, size)
    self_removed: set[int] = set()
    if not own_liberties:
        if not state.rules.suicide_allowed:
            raise IllegalMove("suicide", "move leaves its own group without liberties")
        self_removed.update(own_group)
        for stone in own_group:
            board[stone] = EMPTY

    resulting_board = bytes(board)
    _verify_repetition(state, resulting_board, next_color)

    history = state.history
    if state.rules.ko_rule in {"positional-superko", "situational-superko"}:
        history = history | {
            _repetition_key(resulting_board, next_color, state.rules)
        }

    next_state = GameState(
        rules=state.rules,
        board=resulting_board,
        to_play=next_color,
        consecutive_passes=0,
        move_number=state.move_number + 1,
        history=frozenset(history),
        previous_board=state.board if state.rules.ko_rule == "simple-ko" else state.previous_board,
    )
    post = state_hash(next_state) if compute_hash else ""
    event = MoveEvent(
        move=move,
        color=color,
        captured=tuple(sorted(captured)),
        self_removed=tuple(sorted(self_removed)),
        pre_hash=pre,
        post_hash=post,
        guard_status="move-accepted",
        lineage_label=f"m{next_state.move_number}:{'B' if color == BLACK else 'W'}:{point}",
    )
    return Transition(next_state, event)


def is_legal(state: GameState, move: Move) -> bool:
    try:
        play_move(state, move)
    except IllegalMove:
        return False
    return True


def legal_transitions(
    state: GameState, *, include_pass: bool = True, compute_hash: bool = False
) -> Iterator[Transition]:
    if state.is_terminal:
        return
    for point, cell in enumerate(state.board):
        if cell != EMPTY:
            continue
        try:
            yield play_move(state, Move(point), compute_hash=compute_hash)
        except IllegalMove:
            continue
    if include_pass:
        yield play_move(state, Move.pass_move(), compute_hash=compute_hash)


def legal_moves(state: GameState, *, include_pass: bool = True) -> tuple[Move, ...]:
    return tuple(t.event.move for t in legal_transitions(state, include_pass=include_pass))


def score_board(board: bytes, rules: Rules) -> Score:
    if len(board) != rules.size * rules.size:
        raise ValueError("board length does not match rules")
    black_area = board.count(BLACK)
    white_area = board.count(WHITE)
    neutral = 0
    for region, border in connected_empty_regions(board, rules.size):
        if border == frozenset({BLACK}):
            black_area += len(region)
        elif border == frozenset({WHITE}):
            white_area += len(region)
        else:
            neutral += len(region)
    margin_half = 2 * (black_area - white_area) - rules.komi_halfpoints
    return Score(
        black_area=black_area,
        white_area=white_area,
        neutral_points=neutral,
        komi_halfpoints=rules.komi_halfpoints,
        black_margin_halfpoints=margin_half,
    )


def terminal_score(state: GameState) -> Score:
    if not state.is_terminal:
        raise ValueError("terminal_score requires two consecutive passes")
    return score_board(state.board, state.rules)


def replay(initial: GameState, moves: Iterable[Move]) -> tuple[GameState, tuple[MoveEvent, ...]]:
    state = initial
    events: list[MoveEvent] = []
    for move in moves:
        transition = play_move(state, move)
        state = transition.state
        events.append(transition.event)
    return state, tuple(events)
