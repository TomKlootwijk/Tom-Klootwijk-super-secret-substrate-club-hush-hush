"""Minimal deterministic SGF import/export for single-variation move lists."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Iterable

from .model import BLACK, WHITE, Move, Rules


@dataclass(frozen=True, slots=True)
class SGFGame:
    rules: Rules
    moves: tuple[tuple[int, Move], ...]


def _sgf_point_to_index(token: str, size: int) -> int:
    if token == "":
        return -1
    if len(token) != 2:
        raise ValueError("only two-character SGF points are supported")
    x = ord(token[0]) - ord("a")
    y = ord(token[1]) - ord("a")
    if not (0 <= x < size and 0 <= y < size):
        raise ValueError("SGF point outside board")
    return y * size + x


def _index_to_sgf_point(point: int, size: int) -> str:
    if point < 0:
        return ""
    x, y = point % size, point // size
    return chr(ord("a") + x) + chr(ord("a") + y)


def parse_sgf(text: str, *, ko_rule: str = "positional-superko") -> SGFGame:
    size_match = re.search(r"SZ\[(\d+)\]", text)
    size = int(size_match.group(1)) if size_match else 19
    komi_match = re.search(r"KM\[([+-]?\d+(?:\.\d+)?)\]", text)
    komi = float(komi_match.group(1)) if komi_match else 0.0
    komi_half = int(round(komi * 2))
    rules = Rules(size=size, komi_halfpoints=komi_half, ko_rule=ko_rule)  # type: ignore[arg-type]
    moves: list[tuple[int, Move]] = []
    for color_token, point_token in re.findall(r";([BW])\[([^\]]*)\]", text):
        color = BLACK if color_token == "B" else WHITE
        moves.append((color, Move(_sgf_point_to_index(point_token, size))))
    return SGFGame(rules=rules, moves=tuple(moves))


def export_sgf(rules: Rules, moves: Iterable[tuple[int, Move]], *, comment: str = "") -> str:
    escaped = comment.replace("\\", "\\\\").replace("]", "\\]")
    parts = [f"(;GM[1]FF[4]CA[UTF-8]SZ[{rules.size}]KM[{rules.komi:g}]"]
    if escaped:
        parts.append(f"C[{escaped}]")
    for color, move in moves:
        token = "B" if color == BLACK else "W"
        parts.append(f";{token}[{_index_to_sgf_point(move.point, rules.size)}]")
    parts.append(")")
    return "".join(parts)
