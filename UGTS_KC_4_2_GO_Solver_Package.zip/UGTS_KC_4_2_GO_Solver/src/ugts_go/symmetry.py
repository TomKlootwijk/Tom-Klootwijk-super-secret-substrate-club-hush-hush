"""D4 board symmetries for exact state canonicalization."""

from __future__ import annotations

from functools import lru_cache

from .hashing import board_code, board_from_code


@lru_cache(maxsize=32)
def transform_maps(size: int) -> tuple[tuple[int, ...], ...]:
    """Return eight old-index -> new-index maps."""

    def xy(transform: int, x: int, y: int) -> tuple[int, int]:
        n = size - 1
        if transform == 0:
            return x, y
        if transform == 1:
            return n - y, x
        if transform == 2:
            return n - x, n - y
        if transform == 3:
            return y, n - x
        if transform == 4:
            return n - x, y
        if transform == 5:
            return n - y, n - x
        if transform == 6:
            return x, n - y
        if transform == 7:
            return y, x
        raise ValueError(transform)

    maps: list[tuple[int, ...]] = []
    for t in range(8):
        mapping: list[int] = []
        for old in range(size * size):
            x, y = old % size, old // size
            nx, ny = xy(t, x, y)
            mapping.append(ny * size + nx)
        maps.append(tuple(mapping))
    return tuple(maps)


@lru_cache(maxsize=32)
def inverse_transform_ids(size: int) -> tuple[int, ...]:
    maps = transform_maps(size)
    inverses: list[int] = []
    identity = tuple(range(size * size))
    for a in range(8):
        for b in range(8):
            composed = tuple(maps[b][maps[a][i]] for i in range(size * size))
            if composed == identity:
                inverses.append(b)
                break
        else:
            raise RuntimeError("missing inverse symmetry")
    return tuple(inverses)


def transform_board(board: bytes, size: int, transform: int) -> bytes:
    mapping = transform_maps(size)[transform]
    out = bytearray(len(board))
    for old, value in enumerate(board):
        out[mapping[old]] = value
    return bytes(out)


def transform_point(point: int, size: int, transform: int) -> int:
    if point < 0:
        return point
    return transform_maps(size)[transform][point]


@lru_cache(maxsize=2_000_000)
def transform_board_code(code: int, size: int, transform: int) -> int:
    board = board_from_code(code, size * size)
    return board_code(transform_board(board, size, transform))


def transform_repetition_code(
    code: int, size: int, transform: int, *, situational: bool
) -> int:
    if situational:
        board_part, to_play = divmod(code, 3)
        return transform_board_code(board_part, size, transform) * 3 + to_play
    return transform_board_code(code, size, transform)
