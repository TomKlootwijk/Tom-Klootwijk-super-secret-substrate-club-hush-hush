"""UGTS-KC 4.2 Go: deterministic rules, exact small-board solving, and replay."""

from .certificate import create_certificate, rerun_verify, verify_certificate_hash
from .mcts import MCTSSolver, MCTSResult
from .model import BLACK, EMPTY, WHITE, GameState, Move, Rules, Score
from .rules import initial_state, legal_moves, play_move, replay, score_board
from .solver import ExactSolver, SolveResult

__all__ = [
    "BLACK",
    "EMPTY",
    "WHITE",
    "GameState",
    "Move",
    "Rules",
    "Score",
    "initial_state",
    "legal_moves",
    "play_move",
    "replay",
    "score_board",
    "ExactSolver",
    "SolveResult",
    "MCTSSolver",
    "MCTSResult",
    "create_certificate",
    "verify_certificate_hash",
    "rerun_verify",
]

__version__ = "4.2.0"
