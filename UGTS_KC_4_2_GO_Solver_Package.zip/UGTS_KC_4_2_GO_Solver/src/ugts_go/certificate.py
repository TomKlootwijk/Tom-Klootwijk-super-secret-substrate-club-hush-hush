"""Content-addressed small-board solve certificates."""

from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path
from typing import Any

from .hashing import canonical_json_bytes, sha256_hex, state_hash, state_record
from .model import GameState, Move, Rules
from .solver import ExactSolver, SolveResult, format_pv

CERTIFICATE_SCHEMA = "ugts-go-solve-certificate-4.2"


def _move_record(move: Move | None, size: int) -> dict[str, Any] | None:
    if move is None:
        return None
    from .topology import index_to_coord

    return {
        "point": move.point,
        "coordinate": index_to_coord(move.point, size),
        "pass": move.is_pass,
    }


def create_certificate(
    state: GameState, result: SolveResult, solver: ExactSolver
) -> dict[str, Any]:
    if not result.complete or result.value_halfpoints is None:
        raise ValueError("a certificate requires a complete exact search")
    payload: dict[str, Any] = {
        "schema": CERTIFICATE_SCHEMA,
        "runtime_version": "4.2.0",
        "claim_boundary": (
            "Exact for this serialized finite state and declared rules only; "
            "not a game-theoretic solution of unrestricted 19x19 Go."
        ),
        "root_state": state_record(state, include_history=True),
        "root_state_hash": state_hash(state),
        "result": {
            "black_margin_halfpoints": result.value_halfpoints,
            "black_margin_points": result.value_points,
            "winner": {1: "black", 2: "white", 0: "draw"}[result.winner or 0],
            "best_move": _move_record(result.best_move, state.rules.size),
            "principal_variation": format_pv(
                result.principal_variation, state.rules.size
            ),
        },
        "search": {
            "algorithm": "history-correct alpha-beta minimax",
            "d4_symmetry": solver.use_symmetry,
            "metrics": asdict(result.metrics),
            "transposition_table_digest": solver.table_digest(),
            "complete": result.complete,
        },
    }
    payload["certificate_hash"] = sha256_hex(canonical_json_bytes(payload))
    return payload


def verify_certificate_hash(certificate: dict[str, Any]) -> bool:
    supplied = certificate.get("certificate_hash")
    if not isinstance(supplied, str):
        return False
    content = dict(certificate)
    content.pop("certificate_hash", None)
    return supplied == sha256_hex(canonical_json_bytes(content))


def state_from_record(record: dict[str, Any]) -> GameState:
    rules_record = record["rules"]
    rules = Rules(
        size=int(rules_record["size"]),
        komi_halfpoints=int(rules_record["komi_halfpoints"]),
        ko_rule=rules_record["ko_rule"],
        suicide_allowed=bool(rules_record["suicide_allowed"]),
        scoring=rules_record["scoring"],
    )
    return GameState(
        rules=rules,
        board=bytes.fromhex(record["board_hex"]),
        to_play=int(record["to_play"]),
        consecutive_passes=int(record["consecutive_passes"]),
        move_number=int(record["move_number"]),
        history=frozenset(int(x) for x in record.get("history_codes", [])),
        previous_board=(
            None
            if record.get("previous_board_hex") is None
            else bytes.fromhex(record["previous_board_hex"])
        ),
    )


def rerun_verify(certificate: dict[str, Any]) -> tuple[bool, str]:
    if not verify_certificate_hash(certificate):
        return False, "certificate content hash mismatch"
    state = state_from_record(certificate["root_state"])
    d4 = bool(certificate["search"].get("d4_symmetry", True))
    solver = ExactSolver(use_symmetry=d4)
    result = solver.solve(state)
    if not result.complete:
        return False, "rerun did not complete"
    expected = int(certificate["result"]["black_margin_halfpoints"])
    if result.value_halfpoints != expected:
        return False, "minimax value mismatch"
    digest = certificate["search"].get("transposition_table_digest")
    if digest != solver.table_digest():
        return False, "transposition digest mismatch"
    return True, "certificate verified by deterministic exhaustive rerun"


def write_certificate(path: str | Path, certificate: dict[str, Any]) -> None:
    Path(path).write_text(
        json.dumps(certificate, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )


def read_certificate(path: str | Path) -> dict[str, Any]:
    return json.loads(Path(path).read_text(encoding="utf-8"))
