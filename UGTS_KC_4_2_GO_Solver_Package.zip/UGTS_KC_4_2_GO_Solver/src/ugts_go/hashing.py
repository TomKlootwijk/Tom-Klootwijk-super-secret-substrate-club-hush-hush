"""Canonical hashes and compact exact board codes."""

from __future__ import annotations

import hashlib
import json
from functools import lru_cache
from typing import Any

from .model import GameState


def canonical_json_bytes(value: Any) -> bytes:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    ).encode("utf-8")


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def board_hash(board: bytes) -> str:
    return sha256_hex(board)


@lru_cache(maxsize=1_000_000)
def board_code(board: bytes) -> int:
    """Exact base-3 encoding of an empty/black/white board."""
    value = 0
    factor = 1
    for cell in board:
        value += cell * factor
        factor *= 3
    return value


def board_from_code(code: int, points: int) -> bytes:
    if code < 0:
        raise ValueError("board code must be non-negative")
    cells = bytearray(points)
    value = code
    for i in range(points):
        value, cells[i] = divmod(value, 3)
    if value:
        raise ValueError("board code exceeds declared point count")
    return bytes(cells)


def state_record(state: GameState, *, include_history: bool = True) -> dict[str, Any]:
    record: dict[str, Any] = {
        "schema": "ugts-go-state-4.2",
        "rules": {
            "size": state.rules.size,
            "komi_halfpoints": state.rules.komi_halfpoints,
            "ko_rule": state.rules.ko_rule,
            "suicide_allowed": state.rules.suicide_allowed,
            "scoring": state.rules.scoring,
        },
        "board_hex": state.board.hex(),
        "board_code_base3": str(board_code(state.board)),
        "to_play": state.to_play,
        "consecutive_passes": state.consecutive_passes,
        "move_number": state.move_number,
        "previous_board_hex": state.previous_board.hex()
        if state.previous_board is not None
        else None,
    }
    if include_history:
        record["history_codes"] = [str(item) for item in sorted(state.history)]
    return record


def state_hash(state: GameState) -> str:
    return sha256_hex(canonical_json_bytes(state_record(state, include_history=True)))
