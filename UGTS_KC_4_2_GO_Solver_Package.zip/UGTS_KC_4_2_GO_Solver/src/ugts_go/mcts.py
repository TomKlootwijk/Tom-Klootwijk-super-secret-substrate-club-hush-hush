"""Deterministic seeded Monte Carlo tree search for boards beyond exact scope.

MCTS output is an estimate, never a proof certificate.
"""

from __future__ import annotations

import math
import random
from dataclasses import dataclass, field

from .model import BLACK, EMPTY, WHITE, GameState, IllegalMove, Move
from .rules import legal_transitions, play_move, score_board


@dataclass(slots=True)
class _Node:
    state: GameState
    parent: "_Node | None" = None
    move: Move | None = None
    children: list["_Node"] = field(default_factory=list)
    unexpanded: list[object] = field(default_factory=list)
    visits: int = 0
    value_sum: float = 0.0

    def mean(self) -> float:
        return 0.0 if self.visits == 0 else self.value_sum / self.visits


@dataclass(frozen=True, slots=True)
class MCTSResult:
    best_move: Move | None
    visits: int
    estimated_black_win_rate: float
    child_statistics: tuple[tuple[Move, int, float], ...]
    seed: int
    exact: bool = False


class MCTSSolver:
    def __init__(
        self,
        *,
        iterations: int = 1000,
        exploration: float = math.sqrt(2.0),
        rollout_limit: int = 256,
        rollout_candidates: int = 24,
        seed: int = 0,
    ) -> None:
        if iterations < 1:
            raise ValueError("iterations must be positive")
        self.iterations = iterations
        self.exploration = exploration
        self.rollout_limit = rollout_limit
        self.rollout_candidates = max(1, rollout_candidates)
        self.seed = seed
        self.rng = random.Random(seed)

    def _new_node(self, state: GameState, parent: _Node | None = None, move: Move | None = None) -> _Node:
        transitions = list(legal_transitions(state)) if not state.is_terminal else []
        return _Node(state=state, parent=parent, move=move, unexpanded=transitions)

    def _select(self, node: _Node) -> _Node:
        current = node
        while not current.state.is_terminal:
            if current.unexpanded:
                transition = current.unexpanded.pop(
                    self.rng.randrange(len(current.unexpanded))
                )
                child = self._new_node(
                    transition.state, parent=current, move=transition.event.move
                )
                current.children.append(child)
                return child
            if not current.children:
                return current
            log_parent = math.log(max(1, current.visits))
            to_play = current.state.to_play

            def uct(child: _Node) -> float:
                if child.visits == 0:
                    return float("inf")
                black_value = child.mean()
                exploitation = black_value if to_play == BLACK else -black_value
                return exploitation + self.exploration * math.sqrt(log_parent / child.visits)

            current = max(current.children, key=uct)
        return current

    def _rollout(self, state: GameState) -> float:
        current = state
        for _ in range(self.rollout_limit):
            if current.is_terminal:
                break
            # Rollouts are deliberately heuristic. Probe a bounded random subset
            # of empty points instead of enumerating every legal transition.
            if self.rng.random() < 0.06:
                current = play_move(current, Move.pass_move(), compute_hash=False).state
                continue
            empties = [p for p, cell in enumerate(current.board) if cell == EMPTY]
            self.rng.shuffle(empties)
            moved = False
            for point in empties[: self.rollout_candidates]:
                try:
                    current = play_move(current, Move(point), compute_hash=False).state
                    moved = True
                    break
                except IllegalMove:
                    continue
            if not moved:
                current = play_move(current, Move.pass_move(), compute_hash=False).state
        margin = score_board(current.board, current.rules).black_margin_halfpoints
        if margin > 0:
            return 1.0
        if margin < 0:
            return -1.0
        return 0.0

    def _backpropagate(self, node: _Node, value: float) -> None:
        current: _Node | None = node
        while current is not None:
            current.visits += 1
            current.value_sum += value
            current = current.parent

    def solve(self, state: GameState) -> MCTSResult:
        if state.is_terminal:
            margin = score_board(state.board, state.rules).black_margin_halfpoints
            rate = 1.0 if margin > 0 else 0.0 if margin < 0 else 0.5
            return MCTSResult(None, 0, rate, (), self.seed)
        root = self._new_node(state)
        for _ in range(self.iterations):
            leaf = self._select(root)
            value = self._rollout(leaf.state)
            self._backpropagate(leaf, value)
        if not root.children:
            return MCTSResult(None, root.visits, 0.5, (), self.seed)
        best = max(root.children, key=lambda child: (child.visits, child.mean()))
        stats = tuple(
            sorted(
                (
                    (child.move or Move.pass_move(), child.visits, (child.mean() + 1.0) / 2.0)
                    for child in root.children
                ),
                key=lambda item: (-item[1], item[0].point),
            )
        )
        return MCTSResult(
            best_move=best.move,
            visits=root.visits,
            estimated_black_win_rate=(root.mean() + 1.0) / 2.0,
            child_statistics=stats,
            seed=self.seed,
        )
