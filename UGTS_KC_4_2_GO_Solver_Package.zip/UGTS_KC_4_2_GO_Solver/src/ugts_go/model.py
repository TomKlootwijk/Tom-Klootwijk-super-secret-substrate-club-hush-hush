"""Typed state records for the UGTS-KC 4.2 Go profile.

The module intentionally keeps game-rule state separate from presentation.  A
GameState is immutable and hashable, which makes it suitable for deterministic
search, replay, content hashing, and proof-certificate generation.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable, Iterator, Literal

EMPTY = 0
BLACK = 1
WHITE = 2
PASS_POINT = -1

Color = Literal[1, 2]
KoRule = Literal["positional-superko", "situational-superko", "simple-ko", "none"]
ScoringRule = Literal["area"]


class GoError(ValueError):
    """Base class for deterministic rule errors."""


class IllegalMove(GoError):
    """Raised when a proposed move fails a declared guard."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


@dataclass(frozen=True, slots=True)
class Rules:
    """Versioned rules profile.

    Komi is represented in half-point units to avoid floating-point ambiguity.
    For example, 7.5 points is ``komi_halfpoints=15``.
    """

    size: int = 19
    komi_halfpoints: int = 15
    ko_rule: KoRule = "positional-superko"
    suicide_allowed: bool = False
    scoring: ScoringRule = "area"
    max_board_size: int = 25

    def __post_init__(self) -> None:
        if not (1 <= self.size <= self.max_board_size):
            raise ValueError(f"board size must be in [1,{self.max_board_size}]")
        if self.scoring != "area":
            raise ValueError("the exact 4.2 core implements area scoring only")
        if self.ko_rule not in {
            "positional-superko",
            "situational-superko",
            "simple-ko",
            "none",
        }:
            raise ValueError(f"unsupported ko rule: {self.ko_rule}")

    @property
    def komi(self) -> float:
        return self.komi_halfpoints / 2.0

    def key(self) -> tuple[object, ...]:
        return (
            self.size,
            self.komi_halfpoints,
            self.ko_rule,
            self.suicide_allowed,
            self.scoring,
        )


@dataclass(frozen=True, slots=True, order=True)
class Move:
    """A board point or pass proposal."""

    point: int = PASS_POINT

    @classmethod
    def pass_move(cls) -> "Move":
        return cls(PASS_POINT)

    @property
    def is_pass(self) -> bool:
        return self.point == PASS_POINT

    def validate_for(self, size: int) -> None:
        if self.is_pass:
            return
        if not (0 <= self.point < size * size):
            raise ValueError(f"point {self.point} is outside a {size}x{size} board")


@dataclass(frozen=True, slots=True)
class GameState:
    """Immutable authoritative Go state.

    ``history`` contains exact base-3 repetition codes, not probabilistic hashes.  It is
    used only by superko profiles.  ``previous_board`` is used by simple ko.
    """

    rules: Rules
    board: bytes
    to_play: Color = BLACK
    consecutive_passes: int = 0
    move_number: int = 0
    history: frozenset[int] = field(default_factory=frozenset)
    previous_board: bytes | None = None

    def __post_init__(self) -> None:
        points = self.rules.size * self.rules.size
        if len(self.board) != points:
            raise ValueError(f"board has {len(self.board)} cells; expected {points}")
        if any(cell not in (EMPTY, BLACK, WHITE) for cell in self.board):
            raise ValueError("board contains an invalid cell value")
        if self.to_play not in (BLACK, WHITE):
            raise ValueError("to_play must be BLACK or WHITE")
        if self.consecutive_passes not in (0, 1, 2):
            raise ValueError("consecutive_passes must be 0, 1, or 2")
        if self.move_number < 0:
            raise ValueError("move_number must be non-negative")
        if self.previous_board is not None and len(self.previous_board) != points:
            raise ValueError("previous_board has the wrong size")

    @property
    def is_terminal(self) -> bool:
        return self.consecutive_passes >= 2

    @property
    def opponent(self) -> Color:
        return WHITE if self.to_play == BLACK else BLACK

    def stones(self, color: Color) -> int:
        return self.board.count(color)

    def empty_points(self) -> Iterator[int]:
        return (i for i, cell in enumerate(self.board) if cell == EMPTY)


@dataclass(frozen=True, slots=True)
class MoveEvent:
    """Verified move transition record."""

    move: Move
    color: Color
    captured: tuple[int, ...]
    self_removed: tuple[int, ...]
    pre_hash: str
    post_hash: str
    guard_status: str
    lineage_label: str


@dataclass(frozen=True, slots=True)
class Transition:
    """Atomic result of a legal move proposal."""

    state: GameState
    event: MoveEvent


@dataclass(frozen=True, slots=True)
class Score:
    """Area score in exact half-point arithmetic."""

    black_area: int
    white_area: int
    neutral_points: int
    komi_halfpoints: int
    black_margin_halfpoints: int

    @property
    def black_margin(self) -> float:
        return self.black_margin_halfpoints / 2.0

    @property
    def winner(self) -> int:
        if self.black_margin_halfpoints > 0:
            return BLACK
        if self.black_margin_halfpoints < 0:
            return WHITE
        return EMPTY

    def winner_name(self) -> str:
        return {BLACK: "black", WHITE: "white", EMPTY: "draw"}[self.winner]


def opponent(color: Color) -> Color:
    return WHITE if color == BLACK else BLACK


def board_from_iterable(values: Iterable[int], size: int) -> bytes:
    board = bytes(values)
    if len(board) != size * size:
        raise ValueError("board length does not match size")
    if any(v not in (EMPTY, BLACK, WHITE) for v in board):
        raise ValueError("invalid board value")
    return board
