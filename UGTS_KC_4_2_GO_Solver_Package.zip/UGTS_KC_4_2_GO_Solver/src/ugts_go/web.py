"""Self-contained browser board builder."""

from __future__ import annotations

from pathlib import Path


def build_html(path: str | Path) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(_HTML, encoding="utf-8")
    return target


_HTML = r'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>UGTS-KC 4.2 Go Runtime</title>
<style>
:root{font-family:system-ui,sans-serif;color-scheme:dark;background:#09111f;color:#eef5ff}
body{margin:0;display:grid;grid-template-columns:minmax(280px,700px) minmax(240px,360px);gap:24px;padding:24px;max-width:1120px;margin:auto}
canvas{width:100%;aspect-ratio:1;background:#d9a95b;border-radius:16px;box-shadow:0 10px 40px #0008;touch-action:none}
.panel{background:#111d31;border:1px solid #29415f;border-radius:16px;padding:18px;height:max-content}
h1{margin-top:0;font-size:1.35rem}.row{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0}
button,select,input{background:#182a45;color:#eef5ff;border:1px solid #3d5f86;border-radius:8px;padding:9px 12px}
button:hover{background:#214069}pre{white-space:pre-wrap;background:#08101d;padding:12px;border-radius:10px;min-height:90px}
.small{font-size:.85rem;color:#b8c7db}.ok{color:#71e6aa}.warn{color:#ffd36f}@media(max-width:800px){body{grid-template-columns:1fr;padding:12px}}
</style>
</head><body>
<main><canvas id="board" width="900" height="900"></canvas></main>
<aside class="panel">
<h1>UGTS-KC 4.2 Go</h1>
<div class="small">Deterministic area scoring, captures, suicide guard, positional superko, pass termination, replay hashes. Browser AI is intentionally bounded and is not a proof solver.</div>
<div class="row"><label>Size <select id="size"><option>3</option><option selected>9</option><option>13</option><option>19</option></select></label><label>Komi <input id="komi" value="7.5" size="4"></label></div>
<div class="row"><button id="new">New</button><button id="pass">Pass</button><button id="undo">Undo</button><button id="hint">Seeded hint</button></div>
<pre id="status"></pre>
<div class="small">Open the Python package for exact small-board solving and certificate generation.</div>
</aside>
<script>
const C=document.querySelector('#board'),X=C.getContext('2d'),status=document.querySelector('#status');
let N=9, B=[], turn=1, passes=0, hist=[], stack=[], komi=7.5, seed=420042;
const opp=c=>3-c, idx=(x,y)=>y*N+x;
function boardKey(b=B){return b.join('')}
function ns(p){let x=p%N,y=(p/N)|0,a=[];if(x)a.push(p-1);if(x+1<N)a.push(p+1);if(y)a.push(p-N);if(y+1<N)a.push(p+N);return a}
function group(b,p){let c=b[p],g=new Set([p]),l=new Set(),q=[p];while(q.length){let a=q.pop();for(let z of ns(a)){if(b[z]===0)l.add(z);else if(b[z]===c&&!g.has(z)){g.add(z);q.push(z)}}}return[g,l]}
function tryMove(p,commit=false){if(p<0){let s={B:[...B],turn,passes,hist:[...hist]};if(commit){stack.push(s);passes++;turn=opp(turn);hist.push(boardKey());draw()}return true}
 if(B[p])return false;let b=[...B],c=turn,o=opp(c);b[p]=c;for(let z of ns(p))if(b[z]===o){let[g,l]=group(b,z);if(!l.size)for(let s of g)b[s]=0}
 let[g,l]=group(b,p);if(!l.size)return false;let k=boardKey(b);if(hist.includes(k))return false;if(commit){stack.push({B:[...B],turn,passes,hist:[...hist]});B=b;passes=0;turn=o;hist.push(k);draw()}return true}
function score(){let seen=new Set(),ba=B.filter(x=>x===1).length,wa=B.filter(x=>x===2).length,neutral=0;for(let p=0;p<B.length;p++)if(!B[p]&&!seen.has(p)){let r=new Set([p]),q=[p],border=new Set();seen.add(p);while(q.length){let a=q.pop();for(let z of ns(a)){if(!B[z]&&!seen.has(z)){seen.add(z);r.add(z);q.push(z)}else if(B[z])border.add(B[z])}}if(border.size===1){if(border.has(1))ba+=r.size;else wa+=r.size}else neutral+=r.size}return{ba,wa,neutral,margin:ba-wa-komi}}
function rng(){seed=(1664525*seed+1013904223)>>>0;return seed/4294967296}
function hint(){let legal=[];for(let p=0;p<B.length;p++)if(tryMove(p,false))legal.push(p);legal.push(-1);let best=legal[0],bestV=turn===1?-1e9:1e9;for(let p of legal){let old={B:[...B],turn,passes,hist:[...hist]};tryMove(p,true);let s=score().margin+(rng()-.5)*.02;B=old.B;turn=old.turn;passes=old.passes;hist=old.hist;stack.pop();if((turn===1&&s>bestV)||(turn===2&&s<bestV)){bestV=s;best=p}}status.textContent+='\nHint: '+(best<0?'pass':coord(best))+' (bounded area heuristic)'}
function coord(p){let cols='ABCDEFGHJKLMNOPQRSTUVWXYZ',x=p%N,y=(p/N)|0;return cols[x]+(N-y)}
function draw(){let w=C.width,m=w*.07,step=(w-2*m)/(N-1||1);X.clearRect(0,0,w,w);X.fillStyle='#d7a653';X.fillRect(0,0,w,w);X.strokeStyle='#3a2716';X.lineWidth=3;for(let i=0;i<N;i++){let a=m+i*step;X.beginPath();X.moveTo(m,a);X.lineTo(w-m,a);X.stroke();X.beginPath();X.moveTo(a,m);X.lineTo(a,w-m);X.stroke()}for(let p=0;p<B.length;p++)if(B[p]){let x=m+(p%N)*step,y=m+((p/N)|0)*step;let g=X.createRadialGradient(x-step*.12,y-step*.14,step*.05,x,y,step*.42);if(B[p]===1){g.addColorStop(0,'#626a75');g.addColorStop(.3,'#20242a');g.addColorStop(1,'#030405')}else{g.addColorStop(0,'#fff');g.addColorStop(.65,'#e6e7e8');g.addColorStop(1,'#92979e')}X.fillStyle=g;X.beginPath();X.arc(x,y,step*.43,0,Math.PI*2);X.fill()}
 let s=score();status.textContent=`Move ${stack.length} | ${turn===1?'Black':'White'} to play | passes ${passes}\nArea B ${s.ba} - W ${s.wa} | komi ${komi}\nCurrent black margin ${s.margin.toFixed(1)}\nHistory keys ${hist.length}`+(passes>=2?'\nGAME OVER':'')}
function reset(){N=+document.querySelector('#size').value;komi=+document.querySelector('#komi').value||0;B=Array(N*N).fill(0);turn=1;passes=0;stack=[];hist=[boardKey()];draw()}
C.addEventListener('pointerdown',e=>{if(passes>=2)return;let r=C.getBoundingClientRect(),x=(e.clientX-r.left)/r.width*C.width,y=(e.clientY-r.top)/r.height*C.height,m=C.width*.07,step=(C.width-2*m)/(N-1||1),ix=Math.round((x-m)/step),iy=Math.round((y-m)/step);if(ix>=0&&ix<N&&iy>=0&&iy<N)tryMove(idx(ix,iy),true)});
document.querySelector('#new').onclick=reset;document.querySelector('#pass').onclick=()=>passes<2&&tryMove(-1,true);document.querySelector('#undo').onclick=()=>{let s=stack.pop();if(s){B=s.B;turn=s.turn;passes=s.passes;hist=s.hist;draw()}};document.querySelector('#hint').onclick=hint;document.querySelector('#size').onchange=reset;reset();
</script></body></html>'''
