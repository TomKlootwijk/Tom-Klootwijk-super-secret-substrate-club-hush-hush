"""Command-line interface for deterministic Go analysis."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Iterable

from .certificate import (
    create_certificate,
    read_certificate,
    rerun_verify,
    write_certificate,
)
from .mcts import MCTSSolver
from .model import BLACK, Move, Rules
from .rules import initial_state, play_move, score_board
from .solver import ExactSolver, format_pv
from .topology import board_to_ascii, coord_to_index, index_to_coord
from .web import build_html


def _komi_half(value: str) -> int:
    number = float(value)
    doubled = number * 2
    if abs(doubled - round(doubled)) > 1e-9:
        raise argparse.ArgumentTypeError("komi must be a whole or half point")
    return int(round(doubled))


def _rules(args: argparse.Namespace) -> Rules:
    return Rules(
        size=args.size,
        komi_halfpoints=args.komi,
        ko_rule=args.ko,
        suicide_allowed=args.suicide,
    )


def _apply_moves(state, tokens: Iterable[str]):
    for token in tokens:
        point = coord_to_index(token, state.rules.size)
        state = play_move(state, Move(point)).state
    return state


def _add_common(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--size", type=int, default=3)
    parser.add_argument("--komi", type=_komi_half, default=1, help="points, e.g. 0.5")
    parser.add_argument(
        "--ko",
        choices=["positional-superko", "situational-superko", "simple-ko", "none"],
        default="positional-superko",
    )
    parser.add_argument("--suicide", action="store_true")
    parser.add_argument("--moves", default="", help="comma-separated Go coordinates or pass")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="ugts-go", description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)

    solve = sub.add_parser("solve", help="exactly solve a bounded finite position")
    _add_common(solve)
    solve.add_argument("--node-limit", type=int)
    solve.add_argument("--time-limit", type=float)
    solve.add_argument("--no-symmetry", action="store_true")
    solve.add_argument("--certificate")

    mcts = sub.add_parser("mcts", help="seeded heuristic analysis")
    _add_common(mcts)
    mcts.add_argument("--iterations", type=int, default=200)
    mcts.add_argument("--seed", type=int, default=420042)

    score = sub.add_parser("score", help="score the current board by area")
    _add_common(score)

    web = sub.add_parser("build-web", help="write a self-contained browser board")
    web.add_argument("output", nargs="?", default="go_ugts.html")

    verify = sub.add_parser("verify-certificate", help="hash-check and rerun a solve certificate")
    verify.add_argument("certificate")

    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "build-web":
        path = build_html(args.output)
        print(path)
        return 0
    if args.command == "verify-certificate":
        ok, message = rerun_verify(read_certificate(args.certificate))
        print(json.dumps({"valid": ok, "message": message}, indent=2))
        return 0 if ok else 2

    rules = _rules(args)
    state = initial_state(rules)
    tokens = [token.strip() for token in args.moves.split(",") if token.strip()]
    state = _apply_moves(state, tokens)

    if args.command == "score":
        score = score_board(state.board, rules)
        print(board_to_ascii(state.board, rules.size))
        print(json.dumps({
            "black_area": score.black_area,
            "white_area": score.white_area,
            "neutral": score.neutral_points,
            "black_margin": score.black_margin,
            "winner": score.winner_name(),
        }, indent=2))
        return 0

    if args.command == "mcts":
        solver = MCTSSolver(iterations=args.iterations, seed=args.seed)
        result = solver.solve(state)
        print(json.dumps({
            "exact": False,
            "best_move": None if result.best_move is None else index_to_coord(result.best_move.point, rules.size),
            "estimated_black_win_rate": result.estimated_black_win_rate,
            "visits": result.visits,
            "seed": result.seed,
            "children": [
                {
                    "move": index_to_coord(move.point, rules.size),
                    "visits": visits,
                    "estimated_black_win_rate": rate,
                }
                for move, visits, rate in result.child_statistics[:20]
            ],
        }, indent=2))
        return 0

    solver = ExactSolver(
        node_limit=args.node_limit,
        time_limit_seconds=args.time_limit,
        use_symmetry=not args.no_symmetry,
    )
    result = solver.solve(state)
    output = {
        "complete": result.complete,
        "reason": result.reason,
        "black_margin_halfpoints": result.value_halfpoints,
        "black_margin_points": result.value_points,
        "winner": None if result.winner is None else {BLACK: "black", 2: "white", 0: "draw"}[result.winner],
        "best_move": None if result.best_move is None else index_to_coord(result.best_move.point, rules.size),
        "principal_variation": format_pv(result.principal_variation, rules.size),
        "metrics": {
            "nodes": result.metrics.nodes,
            "terminal_nodes": result.metrics.terminal_nodes,
            "transposition_hits": result.metrics.transposition_hits,
            "cutoffs": result.metrics.cutoffs,
            "table_entries": result.metrics.table_entries,
            "elapsed_seconds": result.metrics.elapsed_seconds,
            "max_ply": result.metrics.max_ply,
        },
    }
    print(json.dumps(output, indent=2))
    if args.certificate and result.complete:
        certificate = create_certificate(state, result, solver)
        write_certificate(args.certificate, certificate)
    return 0 if result.complete else 3
