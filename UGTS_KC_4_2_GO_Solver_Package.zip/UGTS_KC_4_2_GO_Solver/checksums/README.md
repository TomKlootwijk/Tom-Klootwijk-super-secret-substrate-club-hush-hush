# Package checksums

`manifest_sha256.txt` contains SHA-256 entries for every distributable file in this directory tree except the manifest itself. Paths are relative to the package root and sorted bytewise.
