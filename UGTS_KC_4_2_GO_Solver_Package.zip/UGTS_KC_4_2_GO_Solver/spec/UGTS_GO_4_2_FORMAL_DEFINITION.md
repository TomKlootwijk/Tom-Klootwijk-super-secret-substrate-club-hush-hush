# UGTS-KC 4.2 Go - formal definition

## 1. Scope and claim boundary

UGTS-KC 4.2 Go is an additive application profile. It converts a finite Go ruleset into a typed query-and-event substrate and provides two distinct search modes:

1. **Exact mode**: exhaustive minimax under positional or situational superko, with exact history in the state key and a rerunnable certificate.
2. **Search mode**: seeded Monte Carlo tree search for larger boards; results are estimates and never promoted to exact proofs.

The package does not assert a game-theoretic solution of unrestricted 19x19 Go.

## 2. Typed state

For board size `n`, let `V = {0,...,n^2-1}` be the finite grid graph and `E` the orthogonal adjacency relation. The authoritative state is

```text
q_go = (R, B, p, c, m, H, B_prev, L)
```

where:

- `R` is the versioned rules profile;
- `B : V -> {empty, black, white}` is the board;
- `p` is the side to play;
- `c in {0,1,2}` is the consecutive-pass count;
- `m` is the move number;
- `H` is the exact repetition-key set for superko;
- `B_prev` is the previous board for simple ko;
- `L` is replay lineage represented by ordered move events and pre/post hashes.

Coordinates are not identity. State identity includes rules, side to play, pass state, repetition state, and lineage-relevant values.

## 3. Group and liberty relations

A color group is a connected component of equal-colored vertices in `(V,E)`. Its liberty set is the set of adjacent empty vertices. A placed stone is admitted only after opponent groups with zero liberties are removed, and then the placed stone's own group is checked against the suicide policy.

## 4. Move proposal and commit

For proposal `a`:

```text
verified(a,q) = in_board(a)
             and empty(a,B)
             and capture_resolution_defined
             and suicide_guard_passes
             and repetition_guard_passes
```

A pass proposal bypasses occupancy and superko rejection, toggles the side to play, and increments the pass counter. Two consecutive passes produce the terminal event.

A successful move commits atomically:

```text
placement + captures + optional self-removal
-> side toggle
-> pass reset
-> repetition history update
-> pre/post state hash
-> lineage event
```

## 5. Repetition profiles

- `positional-superko`: a non-pass move may not reproduce any prior board code.
- `situational-superko`: a non-pass move may not reproduce any prior `(board,next-player)` code.
- `simple-ko`: a move may not reproduce the board from one ply earlier.
- `none`: no repetition guard.

The exact solver accepts only the two superko profiles, because the full exact history makes every non-pass transition add a previously unseen repetition key and therefore bounds the game graph.

## 6. Area scoring

At terminality, each stone counts one point. Each connected empty region bordered by exactly one color is counted for that color; mixed or unbordered regions are neutral. Komi is represented in half-point integer units.

```text
black_margin_half = 2 * (black_area - white_area) - komi_half
```

A positive margin is a black win; a negative margin is a white win; zero is a draw.

## 7. Exact search

The exact solver performs alpha-beta minimax over the legal transition graph. The transposition key contains the exact repetition history. Optional D4 canonicalization transforms the current board, previous board, and every repetition key under the same symmetry before selecting the lexicographically minimal representative.

A completed result contains:

- exact black margin in half-points;
- exact best move under deterministic tie order;
- one principal variation;
- node, terminal, cutoff, table, elapsed-time, and maximum-ply metrics;
- a transposition-table digest.

A budget interruption returns `complete=false` and no exact value.

## 8. Certificate

A solve certificate contains the full root state, rules, exact result, search configuration, metrics, transposition digest, and a canonical SHA-256 content hash. Verification has two layers:

1. canonical JSON hash check;
2. deterministic exhaustive rerun and result/digest comparison.

This is an executable evidence artifact for the serialized state, not an independent formal proof assistant derivation.

## 9. Search mode

Seeded MCTS uses the same legal transition engine and area evaluator. It returns visits and an estimated black win rate. `exact=false` is hard-coded into the result type.

## 10. Canonical UGTS handoff

```text
local grid/group support
-> rules and ownership compatibility
-> occupancy/liberty/suicide/ko guard
-> verified move proposal
-> deterministic atomic board patch
-> state hash + lineage + replay
-> optional browser/SGF presentation
```

## 11. Acceptance and kill criteria

Reject or simplify the profile when:

- rules, komi, suicide, ko, or scoring conventions are implicit;
- history is omitted while claiming exact superko legality;
- a heuristic move filter is used in proof mode;
- floating-point komi changes score identity;
- a certificate is issued after a budget-limited search;
- D4 canonicalization transforms the current board but not the repetition history;
- MCTS estimates are described as exact;
- a large-board performance claim lacks a named device, workload, seed, rules profile, and error/proof boundary;
- a conventional Go engine is faster, simpler, or more accurate for the target requirement.
