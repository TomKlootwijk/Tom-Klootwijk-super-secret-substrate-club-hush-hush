# UGTS-KC 4.2 Go Solver

A deterministic, proof-oriented Go implementation built as an additive application profile over the supplied UGTS-KC substrate line.

## What “solve Go” means in this package

The package turns Go into the canonical UGTS sequence:

```text
board/group support
-> move and rules compatibility
-> occupancy/liberty/ko/suicide guards
-> verified move proposal
-> atomic capture/placement/pass commit
-> state hash + lineage + replay
-> terminal area score
```

`ExactSolver` exhaustively solves a **serialized finite state** when positional or situational superko makes the game graph finite and the search completes inside the declared budget. The checked-in validation solves the empty 1x1 and 2x2 games and a closed 3x3 end state. Standard 19x19 remains an analysis target in this release; MCTS output is an estimate, not a proof.

## Quick start

```bash
cd UGTS_KC_4_2_GO_Solver
PYTHONPATH=src python -m unittest discover -s tests -v

# Exact empty 2x2 solve, 0.5 komi
PYTHONPATH=src python -m ugts_go solve \
  --size 2 --komi 0.5 --certificate validation/solve_2x2_k0_5.json

# Deterministically re-run and verify the certificate
PYTHONPATH=src python -m ugts_go verify-certificate \
  validation/solve_2x2_k0_5.json

# Seeded, explicitly non-exact 9x9 analysis
PYTHONPATH=src python -m ugts_go mcts \
  --size 9 --komi 7.5 --iterations 200 --seed 420042

# Browser board; no CDN or network asset
PYTHONPATH=src python -m ugts_go build-web examples/web/go_ugts.html
```

## Rules profile

The exact reference profile uses finite square boards, area scoring, half-point integer arithmetic, two-pass termination, no suicide by default, and positional superko by default. Simple ko and no-ko profiles are implemented for rule testing, but the exact solver refuses them because they do not by themselves guarantee an acyclic finite search history.

## Package map

- `src/ugts_go/`: rules, topology, exact solver, MCTS, certificates, SGF, CLI, web builder.
- `spec/`: formal definition, JSON Schema, M390-M449 catalog, source-integration register.
- `tests/`: 52 dependency-free unit tests.
- `examples/`: exact solve, ko, MCTS, and browser demonstrations.
- `validation/`: captured tests, solved fixtures, certificate, metrics, wheel/browser checks, and PDF preflight evidence.
- `checksums/`: complete SHA-256 manifest for the distributable package.
- `report/`: PDF report and editable LaTeX source.

## Source integration

The Go-specific rules are engineering-derived. The structural mapping uses the supplied reports as follows:

- UGTS-KC 2.0: typed topology, support/compatibility/guard/event/lineage, explicit kill criteria.
- KC Two Hands 3.0: proposal verification, deterministic commit, state hashes, replay, and downstream presentation boundary.
- UGTS-KC 3.6: literal content-addressed definitions and explicit operation order.
- UGTS-KC 3.6.2 SCLP: finite packed addressing, radix refinement, bounded grammar, and guard intervals.
- UGTS-KC 3.9 KC Elizabeth: game project/runtime, deterministic snapshots, CLI, and self-contained HTML delivery.
- UGTS-GN 1.1: compact state/event records, pruning metrics, and performance/claim boundaries.

SARA 3.6.3 is not used because its wallet-specific cryptographic profile is unrelated to Go gameplay.
