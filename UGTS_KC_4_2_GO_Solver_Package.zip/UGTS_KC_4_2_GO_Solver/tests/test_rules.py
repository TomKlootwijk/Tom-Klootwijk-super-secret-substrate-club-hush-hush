from __future__ import annotations

import unittest

from ugts_go.model import BLACK, EMPTY, WHITE, IllegalMove, Move, Rules
from ugts_go.rules import (
    initial_state,
    legal_moves,
    play_move,
    replay,
    score_board,
    terminal_score,
)
from ugts_go.topology import coord_to_index, parse_ascii


class MoveRuleTests(unittest.TestCase):
    def test_01_place_on_empty(self):
        state = initial_state(Rules(size=3))
        transition = play_move(state, Move(4))
        self.assertEqual(transition.state.board[4], BLACK)
        self.assertEqual(transition.state.to_play, WHITE)

    def test_02_occupied_rejected(self):
        state = initial_state(Rules(size=3))
        state = play_move(state, Move(4)).state
        with self.assertRaises(IllegalMove) as ctx:
            play_move(state, Move(4))
        self.assertEqual(ctx.exception.code, "occupied")

    def test_03_single_capture(self):
        board, size = parse_ascii("""
        .X.
        XO.
        .X.
        """)
        state = initial_state(Rules(size=size), board=board, to_play=BLACK)
        transition = play_move(state, Move(coord_to_index("C2", size)))
        self.assertEqual(transition.state.board[4], EMPTY)
        self.assertEqual(transition.event.captured, (4,))

    def test_04_multi_stone_capture(self):
        board, size = parse_ascii("""
        .XX.
        XOO.
        .XX.
        ....
        """)
        state = initial_state(Rules(size=size), board=board, to_play=BLACK)
        transition = play_move(state, Move(coord_to_index("D3", size)))
        self.assertEqual(transition.event.captured, (5, 6))

    def test_05_suicide_rejected(self):
        board, size = parse_ascii("""
        .O.
        O.O
        .O.
        """)
        state = initial_state(Rules(size=size), board=board, to_play=BLACK)
        with self.assertRaises(IllegalMove) as ctx:
            play_move(state, Move(4))
        self.assertEqual(ctx.exception.code, "suicide")

    def test_06_suicide_allowed_removes_stone(self):
        board, size = parse_ascii("""
        .O.
        O.O
        .O.
        """)
        rules = Rules(size=size, suicide_allowed=True, ko_rule="none")
        state = initial_state(rules, board=board, to_play=BLACK)
        transition = play_move(state, Move(4))
        self.assertEqual(transition.state.board[4], EMPTY)
        self.assertEqual(transition.event.self_removed, (4,))

    def _ko_state(self, ko_rule: str):
        board, size = parse_ascii("""
        .....
        ..XO.
        .XO.O
        ..XO.
        .....
        """)
        return initial_state(Rules(size=size, ko_rule=ko_rule), board=board, to_play=BLACK)

    def test_07_simple_ko_rejects_immediate_retake(self):
        state = self._ko_state("simple-ko")
        state = play_move(state, Move(coord_to_index("D3", 5))).state
        with self.assertRaises(IllegalMove) as ctx:
            play_move(state, Move(coord_to_index("C3", 5)))
        self.assertEqual(ctx.exception.code, "simple-ko")

    def test_08_positional_superko_rejects_retake(self):
        state = self._ko_state("positional-superko")
        state = play_move(state, Move(coord_to_index("D3", 5))).state
        with self.assertRaises(IllegalMove) as ctx:
            play_move(state, Move(coord_to_index("C3", 5)))
        self.assertEqual(ctx.exception.code, "positional-superko")

    def test_09_pass_is_legal(self):
        state = initial_state(Rules(size=2))
        state = play_move(state, Move.pass_move()).state
        self.assertEqual(state.consecutive_passes, 1)
        self.assertEqual(state.to_play, WHITE)

    def test_10_two_passes_end_game(self):
        state = initial_state(Rules(size=2))
        state = play_move(state, Move.pass_move()).state
        state = play_move(state, Move.pass_move()).state
        self.assertTrue(state.is_terminal)
        self.assertIsNotNone(terminal_score(state))

    def test_11_move_after_game_end_rejected(self):
        state = initial_state(Rules(size=2))
        state = play_move(state, Move.pass_move()).state
        state = play_move(state, Move.pass_move()).state
        with self.assertRaises(IllegalMove) as ctx:
            play_move(state, Move(0))
        self.assertEqual(ctx.exception.code, "game-over")

    def test_12_empty_2x2_has_four_points_and_pass(self):
        moves = legal_moves(initial_state(Rules(size=2)))
        self.assertEqual(len(moves), 5)
        self.assertTrue(any(move.is_pass for move in moves))

    def test_13_replay_produces_event_chain(self):
        state = initial_state(Rules(size=3))
        final, events = replay(state, [Move(0), Move(1), Move.pass_move()])
        self.assertEqual(len(events), 3)
        self.assertEqual(events[0].post_hash, events[1].pre_hash)
        self.assertEqual(final.move_number, 3)

    def test_14_event_lineage_is_declared(self):
        state = initial_state(Rules(size=3))
        event = play_move(state, Move(0)).event
        self.assertTrue(event.lineage_label.startswith("m1:B:"))


class ScoreTests(unittest.TestCase):
    def test_15_black_enclosed_territory(self):
        board, size = parse_ascii("""
        XXX
        X.X
        XXX
        """)
        score = score_board(board, Rules(size=size, komi_halfpoints=0))
        self.assertEqual(score.black_area, 9)
        self.assertEqual(score.white_area, 0)

    def test_16_neutral_region(self):
        board, size = parse_ascii("""
        X.O
        ...
        ...
        """)
        score = score_board(board, Rules(size=size, komi_halfpoints=0))
        self.assertEqual(score.neutral_points, 7)

    def test_17_half_point_komi_avoids_draw(self):
        board = bytes(1)
        score = score_board(board, Rules(size=1, komi_halfpoints=1))
        self.assertEqual(score.black_margin_halfpoints, -1)
        self.assertEqual(score.winner, WHITE)


if __name__ == "__main__":
    unittest.main()
