from __future__ import annotations

import unittest

from ugts_go.hashing import board_code, board_from_code, state_hash
from ugts_go.model import BLACK, EMPTY, WHITE, GameState, Move, Rules
from ugts_go.rules import initial_state
from ugts_go.symmetry import (
    inverse_transform_ids,
    transform_board,
    transform_board_code,
    transform_maps,
    transform_point,
)
from ugts_go.topology import (
    board_to_ascii,
    coord_to_index,
    empty_region,
    group_and_liberties,
    index_to_coord,
    neighbors,
    parse_ascii,
)


class RulesAndStateTests(unittest.TestCase):
    def test_01_rules_defaults(self):
        rules = Rules()
        self.assertEqual(rules.size, 19)
        self.assertEqual(rules.komi, 7.5)
        self.assertEqual(rules.ko_rule, "positional-superko")

    def test_02_size_guard(self):
        with self.assertRaises(ValueError):
            Rules(size=0)
        with self.assertRaises(ValueError):
            Rules(size=26)

    def test_03_board_length_guard(self):
        with self.assertRaises(ValueError):
            GameState(Rules(size=3), bytes(8))

    def test_04_initial_history_is_exact_code(self):
        state = initial_state(Rules(size=3))
        self.assertEqual(state.history, frozenset({0}))

    def test_05_state_hash_is_stable(self):
        state = initial_state(Rules(size=2))
        self.assertEqual(state_hash(state), state_hash(state))


class CoordinateAndTopologyTests(unittest.TestCase):
    def test_06_coordinate_roundtrip(self):
        for size in (3, 9, 19):
            for point in (0, size - 1, size * (size - 1), size * size - 1):
                self.assertEqual(coord_to_index(index_to_coord(point, size), size), point)

    def test_07_i_column_is_skipped(self):
        self.assertEqual(index_to_coord(8, 19), "J19")
        with self.assertRaises(ValueError):
            coord_to_index("I10", 19)

    def test_08_corner_neighbors(self):
        self.assertEqual(set(neighbors(0, 3)), {1, 3})

    def test_09_center_neighbors(self):
        self.assertEqual(set(neighbors(4, 3)), {1, 3, 5, 7})

    def test_10_group_and_liberties(self):
        board, size = parse_ascii("""
        XX.
        X..
        ...
        """)
        group, liberties = group_and_liberties(board, 0, size)
        self.assertEqual(group, frozenset({0, 1, 3}))
        self.assertEqual(liberties, frozenset({2, 4, 6}))

    def test_11_empty_region_border(self):
        board, size = parse_ascii("""
        XXX
        X.X
        XXX
        """)
        region, border = empty_region(board, 4, size)
        self.assertEqual(region, frozenset({4}))
        self.assertEqual(border, frozenset({BLACK}))

    def test_12_ascii_roundtrip_shape(self):
        board, size = parse_ascii("""
        X.O
        .X.
        O..
        """)
        text = board_to_ascii(board, size)
        self.assertIn("X", text)
        self.assertIn("O", text)
        self.assertIn("A B C", text)


class PackingAndSymmetryTests(unittest.TestCase):
    def test_13_board_code_roundtrip(self):
        board = bytes([0, 1, 2, 2, 1, 0, 1, 0, 2])
        self.assertEqual(board_from_code(board_code(board), 9), board)

    def test_14_eight_symmetries_exist(self):
        maps = transform_maps(3)
        self.assertEqual(len(maps), 8)
        self.assertEqual(len(set(maps)), 8)

    def test_15_symmetry_inverse(self):
        board = bytes([1, 0, 2, 0, 1, 0, 2, 0, 0])
        for transform, inverse in enumerate(inverse_transform_ids(3)):
            moved = transform_board(board, 3, transform)
            self.assertEqual(transform_board(moved, 3, inverse), board)

    def test_16_transform_point_matches_board(self):
        board = bytearray(9)
        board[1] = BLACK
        for transform in range(8):
            moved = transform_board(bytes(board), 3, transform)
            self.assertEqual(moved[transform_point(1, 3, transform)], BLACK)

    def test_17_transform_board_code_matches_bytes(self):
        board = bytes([1, 0, 2, 0, 1, 0, 2, 0, 0])
        code = board_code(board)
        for transform in range(8):
            self.assertEqual(
                transform_board_code(code, 3, transform),
                board_code(transform_board(board, 3, transform)),
            )


if __name__ == "__main__":
    unittest.main()
