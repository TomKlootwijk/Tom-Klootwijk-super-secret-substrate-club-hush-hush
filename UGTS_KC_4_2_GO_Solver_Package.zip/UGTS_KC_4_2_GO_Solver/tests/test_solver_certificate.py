from __future__ import annotations

import copy
import json
import tempfile
import unittest
from pathlib import Path

from ugts_go.certificate import (
    create_certificate,
    read_certificate,
    rerun_verify,
    verify_certificate_hash,
    write_certificate,
)
from ugts_go.model import Move, Rules
from ugts_go.rules import initial_state, play_move
from ugts_go.solver import ExactSolver, format_pv
from ugts_go.topology import parse_ascii


class ExactSolverTests(unittest.TestCase):
    def test_01_one_by_one_is_white_by_half_point(self):
        state = initial_state(Rules(size=1, komi_halfpoints=1))
        result = ExactSolver().solve(state)
        self.assertTrue(result.complete)
        self.assertEqual(result.value_halfpoints, -1)
        self.assertTrue(result.best_move.is_pass)

    def test_02_two_by_two_exact_value(self):
        state = initial_state(Rules(size=2, komi_halfpoints=1))
        result = ExactSolver().solve(state)
        self.assertTrue(result.complete)
        self.assertEqual(result.value_halfpoints, 1)
        self.assertIn(result.best_move.point, range(4))
        self.assertGreater(result.metrics.nodes, 100)

    def test_03_two_by_two_symmetry_preserves_value(self):
        state = initial_state(Rules(size=2, komi_halfpoints=1))
        a = ExactSolver(use_symmetry=True).solve(state)
        b = ExactSolver(use_symmetry=False, node_limit=100000).solve(state)
        self.assertTrue(a.complete and b.complete)
        self.assertEqual(a.value_halfpoints, b.value_halfpoints)

    def test_04_principal_variation_ends_in_two_passes(self):
        state = initial_state(Rules(size=2, komi_halfpoints=1))
        result = ExactSolver().solve(state)
        self.assertGreaterEqual(len(result.principal_variation), 2)
        self.assertTrue(result.principal_variation[-1].is_pass)
        self.assertTrue(result.principal_variation[-2].is_pass)

    def test_05_non_superko_profile_is_not_claimed_exact(self):
        state = initial_state(Rules(size=3, ko_rule="simple-ko"))
        result = ExactSolver().solve(state)
        self.assertFalse(result.complete)
        self.assertIn("requires", result.reason)

    def test_06_node_limit_is_bounded(self):
        state = initial_state(Rules(size=2))
        result = ExactSolver(node_limit=1).solve(state)
        self.assertFalse(result.complete)

    def test_07_selected_three_by_three_endgame_solves(self):
        board, size = parse_ascii("""
        XXX
        XOX
        XXX
        """)
        state = initial_state(Rules(size=size, komi_halfpoints=1), board=board)
        result = ExactSolver(time_limit_seconds=10).solve(state)
        self.assertTrue(result.complete)
        self.assertIsNotNone(result.value_halfpoints)

    def test_08_format_pv(self):
        self.assertEqual(format_pv((Move(0), Move.pass_move()), 3), ["A3", "pass"])


class CertificateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.state = initial_state(Rules(size=2, komi_halfpoints=1))
        cls.solver = ExactSolver()
        cls.result = cls.solver.solve(cls.state)
        cls.certificate = create_certificate(cls.state, cls.result, cls.solver)

    def test_09_certificate_hash_valid(self):
        self.assertTrue(verify_certificate_hash(self.certificate))

    def test_10_tamper_is_detected(self):
        changed = copy.deepcopy(self.certificate)
        changed["result"]["black_margin_halfpoints"] = 999
        self.assertFalse(verify_certificate_hash(changed))

    def test_11_certificate_roundtrip_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "certificate.json"
            write_certificate(path, self.certificate)
            loaded = read_certificate(path)
            self.assertEqual(loaded, self.certificate)

    def test_12_rerun_verifies(self):
        ok, message = rerun_verify(self.certificate)
        self.assertTrue(ok, message)

    def test_13_certificate_contains_claim_boundary(self):
        self.assertIn("19x19", self.certificate["claim_boundary"])
        self.assertEqual(self.certificate["schema"], "ugts-go-solve-certificate-4.2")


if __name__ == "__main__":
    unittest.main()
