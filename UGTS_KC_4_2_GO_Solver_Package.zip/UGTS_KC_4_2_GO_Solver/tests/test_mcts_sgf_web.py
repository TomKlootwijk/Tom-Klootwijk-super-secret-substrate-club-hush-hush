from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from ugts_go.mcts import MCTSSolver
from ugts_go.model import BLACK, WHITE, Move, Rules
from ugts_go.rules import initial_state, is_legal
from ugts_go.sgf import export_sgf, parse_sgf
from ugts_go.web import build_html


class MCTSTests(unittest.TestCase):
    def test_01_seeded_run_is_deterministic(self):
        state = initial_state(Rules(size=3, komi_halfpoints=1))
        a = MCTSSolver(iterations=40, seed=123).solve(state)
        b = MCTSSolver(iterations=40, seed=123).solve(state)
        self.assertEqual(a.best_move, b.best_move)
        self.assertEqual(a.child_statistics, b.child_statistics)

    def test_02_best_move_is_legal(self):
        state = initial_state(Rules(size=3))
        result = MCTSSolver(iterations=20, seed=9).solve(state)
        self.assertIsNotNone(result.best_move)
        self.assertTrue(is_legal(state, result.best_move))
        self.assertFalse(result.exact)


class SGFTests(unittest.TestCase):
    def test_03_parse_basic_sgf(self):
        game = parse_sgf("(;GM[1]FF[4]SZ[9]KM[6.5];B[aa];W[bc];B[])")
        self.assertEqual(game.rules.size, 9)
        self.assertEqual(game.rules.komi_halfpoints, 13)
        self.assertEqual(game.moves[0], (BLACK, Move(0)))
        self.assertTrue(game.moves[-1][1].is_pass)

    def test_04_export_and_parse(self):
        rules = Rules(size=5, komi_halfpoints=1)
        text = export_sgf(rules, [(BLACK, Move(0)), (WHITE, Move(6)), (BLACK, Move.pass_move())], comment="UGTS")
        parsed = parse_sgf(text)
        self.assertEqual(parsed.rules.size, 5)
        self.assertEqual(parsed.moves[1], (WHITE, Move(6)))
        self.assertIn("C[UGTS]", text)


class WebTests(unittest.TestCase):
    def test_05_build_self_contained_html(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = build_html(Path(tmp) / "go.html")
            text = path.read_text(encoding="utf-8")
            self.assertIn("UGTS-KC 4.2 Go", text)
            self.assertIn("<canvas", text)
            self.assertNotIn("https://", text)
            self.assertNotIn("http://", text)


if __name__ == "__main__":
    unittest.main()
