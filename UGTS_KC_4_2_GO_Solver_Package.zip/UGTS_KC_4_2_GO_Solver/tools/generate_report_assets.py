from __future__ import annotations

import json
import math
import subprocess
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Circle, FancyArrowPatch, Rectangle

ROOT = Path(__file__).resolve().parents[1]
FIG = ROOT / "figures"
FIG.mkdir(exist_ok=True)
sys.path.insert(0, str(ROOT / "src"))

from ugts_go import Move, Rules, initial_state, play_move
from ugts_go.topology import coord_to_index

NAVY = "#0c1930"
NAVY2 = "#142746"
TEAL = "#20b5b8"
GOLD = "#e0ad25"
GREEN = "#52c987"
CORAL = "#e36f60"
PURPLE = "#8d73d1"
LIGHT = "#eef4fb"
MID = "#a9bdd5"
INK = "#111827"
WOOD = "#d5a45d"
WOOD_DARK = "#5f3c1f"


def save(fig, name: str):
    fig.savefig(FIG / name, dpi=200, bbox_inches="tight", facecolor=fig.get_facecolor())
    plt.close(fig)


def box(ax, xy, wh, text, color, textcolor="white", fontsize=9, lw=1.5):
    x, y = xy; w, h = wh
    patch = FancyBboxPatch((x,y),w,h,boxstyle="round,pad=0.015,rounding_size=0.025",
                           facecolor=color, edgecolor=color, linewidth=lw)
    ax.add_patch(patch)
    ax.text(x+w/2,y+h/2,text,ha="center",va="center",color=textcolor,fontsize=fontsize,fontweight="bold",wrap=True)
    return patch


def arrow(ax, a, b, color=GOLD, lw=2):
    ax.add_patch(FancyArrowPatch(a,b,arrowstyle="-|>",mutation_scale=14,color=color,linewidth=lw))


def architecture():
    fig, ax = plt.subplots(figsize=(14,6.4)); fig.patch.set_facecolor(NAVY); ax.set_facecolor(NAVY)
    ax.set_xlim(0,1); ax.set_ylim(0,1); ax.axis("off")
    ax.text(.035,.94,"UGTS-KC 4.2 Go architecture",color="white",fontsize=21,fontweight="bold")
    ax.text(.035,.895,"The Go-specific layer remains inside the canonical support - compatibility - guard - event discipline",color=MID,fontsize=10.5)
    labels=[
        ("BOARD SUPPORT\ngroups + liberties",.035,TEAL),
        ("COMPATIBILITY\nplayer + rules",.195,PURPLE),
        ("MOVE GUARDS\noccupied / suicide / ko",.355,GOLD),
        ("PROPOSAL\nplace or pass",.515,CORAL),
        ("ATOMIC COMMIT\ncapture + toggle + history",.675,GREEN),
        ("LINEAGE\nhash + replay + score",.835,PURPLE),
    ]
    y=.62; w=.13; h=.17
    for i,(t,x,c) in enumerate(labels):
        box(ax,(x,y),(w,h),t,c,fontsize=7.6,textcolor=INK if c==GOLD else "white")
        if i<len(labels)-1: arrow(ax,(x+w+.004,y+h/2),(labels[i+1][1]-.006,y+h/2))
    box(ax,(.12,.22),(.30,.20),"EXACT MODE\nalpha-beta minimax\nexact superko history\nD4 canonicalization",TEAL,fontsize=10)
    box(ax,(.58,.22),(.30,.20),"SEARCH MODE\nseeded MCTS\nbounded rollouts\nexact = false",PURPLE,fontsize=10)
    arrow(ax,(.42,.60),(.27,.43),GREEN); arrow(ax,(.58,.60),(.73,.43),CORAL)
    ax.text(.5,.08,"Only a completed exact search can emit a solve certificate.",ha="center",color=GOLD,fontsize=11,fontweight="bold")
    save(fig,"architecture.png")

def draw_board(ax, board, n, title="", liberty_points=None, last=None, labels=False):
    ax.set_aspect("equal"); ax.set_xlim(-.6,n-.4); ax.set_ylim(n-.4,-.6); ax.axis("off")
    ax.add_patch(Rectangle((-.45,-.45),n-.1,n-.1,facecolor=WOOD,edgecolor=WOOD_DARK,lw=2))
    for i in range(n):
        ax.plot([0,n-1],[i,i],color=WOOD_DARK,lw=1)
        ax.plot([i,i],[0,n-1],color=WOOD_DARK,lw=1)
    if liberty_points:
        for p in liberty_points:
            x=p%n; y=p//n
            ax.add_patch(Circle((x,y),.17,facecolor=GREEN,edgecolor="white",lw=1.5,zorder=3))
    for p,c in enumerate(board):
        if c:
            x=p%n; y=p//n
            fc="#11151c" if c==1 else "#f2f4f7"
            ec="#000000" if c==1 else "#7b8795"
            ax.add_patch(Circle((x,y),.39,facecolor=fc,edgecolor=ec,lw=1.3,zorder=4))
            if p==last:
                ax.add_patch(Circle((x,y),.11,facecolor=CORAL if c==1 else TEAL,edgecolor="none",zorder=5))
    if labels:
        cols="ABCDEFGHJKLMNOPQRSTUVWXYZ"
        for i in range(n):
            ax.text(i,n-.18,cols[i],ha="center",va="top",fontsize=7,color=INK)
            ax.text(-.52,i,str(n-i),ha="right",va="center",fontsize=7,color=INK)
    ax.set_title(title,fontsize=10,fontweight="bold",pad=8,color=INK)


def board_topology():
    board=[0]*81
    # black group around center-left, white neighboring stones
    for p in [29,30,38,47]: board[p]=1
    for p in [21,31,39,48,56]: board[p]=2
    liberties=[20,28,37,46]
    fig, ax=plt.subplots(figsize=(6.8,6.8)); fig.patch.set_facecolor("white")
    draw_board(ax,board,9,"One connected black group with four declared liberties",liberties,labels=True)
    ax.text(4,8.75,"Green markers are local support candidates; opponent stones are compatibility context.",ha="center",fontsize=8.5,color=INK)
    save(fig,"board_topology.png")


def ko_sequence():
    from ugts_go.topology import parse_ascii
    b,n=parse_ascii('''
.....
..XO.
.XO.O
..XO.
.....
''')
    s=initial_state(Rules(size=5,komi_halfpoints=0,ko_rule="positional-superko"),board=b,to_play=1)
    before=s.board
    s=play_move(s,Move(coord_to_index("D3",5)),compute_hash=False).state
    after=s.board
    fig, axes=plt.subplots(1,3,figsize=(11,3.8)); fig.patch.set_facecolor("white")
    draw_board(axes[0],before,5,"1. Before: C3 has one liberty",last=None)
    draw_board(axes[1],after,5,"2. Black D3 captures C3",last=coord_to_index("D3",5))
    draw_board(axes[2],after,5,"3. White C3 would repeat history",last=coord_to_index("D3",5))
    axes[2].add_patch(Circle((2,2),.25,fill=False,edgecolor=CORAL,lw=4,zorder=7))
    axes[2].plot([1.78,2.22],[1.78,2.22],color=CORAL,lw=3,zorder=8)
    axes[2].plot([2.22,1.78],[1.78,2.22],color=CORAL,lw=3,zorder=8)
    fig.suptitle("Ko is a repetition guard, not a visual exception",fontsize=15,fontweight="bold",color=INK)
    fig.text(.5,.02,"The exact state includes the prior board code, so the recapture proposal is rejected before commit.",ha="center",fontsize=9,color=INK)
    save(fig,"ko_sequence.png")


def search_ladder():
    fig, ax=plt.subplots(figsize=(11,5.5)); fig.patch.set_facecolor("white"); ax.axis("off"); ax.set_xlim(0,1); ax.set_ylim(0,1)
    ax.text(.04,.92,"One rules engine, two evidence levels",fontsize=18,fontweight="bold",color=INK)
    # left
    ax.add_patch(FancyBboxPatch((.04,.18),.42,.62,boxstyle="round,pad=.02,rounding_size=.03",facecolor="#e7f7f6",edgecolor=TEAL,lw=2))
    ax.text(.25,.72,"EXACT",ha="center",fontsize=17,fontweight="bold",color=TEAL)
    exact=["All legal moves","Exact superko history","Alpha-beta + bounds","Budget must complete","Certificate + rerun"]
    for i,t in enumerate(exact): ax.text(.10,.62-i*.09,"✓  "+t,fontsize=11,color=INK)
    ax.add_patch(FancyBboxPatch((.54,.18),.42,.62,boxstyle="round,pad=.02,rounding_size=.03",facecolor="#f1ecfb",edgecolor=PURPLE,lw=2))
    ax.text(.75,.72,"SEARCH",ha="center",fontsize=17,fontweight="bold",color=PURPLE)
    heur=["Legal moves only","Seeded randomness","UCT + bounded rollout","Scales farther","Always exact = false"]
    for i,t in enumerate(heur): ax.text(.60,.62-i*.09,"•  "+t,fontsize=11,color=INK)
    ax.text(.5,.08,"A node or time limit never converts an incomplete exact search into an estimate or a claim.",ha="center",fontsize=10,fontweight="bold",color=CORAL)
    save(fig,"search_ladder.png")


def pv_2x2():
    moves=['A2','B1','B2','A1','B2','A2','B2','A1','A2','pass','pass']
    s=initial_state(Rules(size=2,komi_halfpoints=1))
    states=[s.board]; titles=["Start"]
    selected={1,3,4,7,9,11}
    for i,m in enumerate(moves,1):
        s=play_move(s,Move(coord_to_index(m,2)),compute_hash=False).state
        if i in selected:
            states.append(s.board); titles.append(f"{i}. {m}")
    fig, axes=plt.subplots(2,4,figsize=(11,6)); fig.patch.set_facecolor("white")
    for ax in axes.flat: ax.axis("off")
    for ax,b,t in zip(axes.flat,states,titles): draw_board(ax,b,2,t,labels=True)
    axes.flat[-1].axis("off")
    fig.suptitle("Exact empty 2x2 principal variation, positional superko, komi 0.5",fontsize=15,fontweight="bold",color=INK)
    fig.text(.5,.02,"Black's exact final margin is +0.5. Repeated coordinates are legal only when the full board position is new.",ha="center",fontsize=9,color=INK)
    save(fig,"pv_2x2.png")


def validation_chart():
    summary=json.loads((ROOT/"validation"/"summary.json").read_text())
    labels=["Unit tests","Mechanisms","2x2 nodes","2x2 TT entries","3x3 bounded nodes"]
    values=[52,60,742,538,summary["empty_3x3_attempt"]["nodes"]]
    fig,ax=plt.subplots(figsize=(10,5.2)); fig.patch.set_facecolor("white")
    bars=ax.bar(labels,values,color=[TEAL,GOLD,GREEN,PURPLE,CORAL])
    ax.set_title("Release validation counts",fontsize=16,fontweight="bold",color=INK)
    ax.set_ylabel("count (linear scale)"); ax.grid(axis="y",alpha=.2)
    ax.tick_params(axis='x',labelrotation=18)
    for b,v in zip(bars,values): ax.text(b.get_x()+b.get_width()/2,b.get_height()+max(values)*.015,str(v),ha='center',fontweight='bold')
    ax.text(.99,.96,"52/52 tests pass | 0 schema errors | certificate rerun verified",transform=ax.transAxes,ha='right',va='top',fontsize=9,color=INK)
    save(fig,"validation_chart.png")


def storage_diagram():
    fig,ax=plt.subplots(figsize=(11,5.4)); fig.patch.set_facecolor("white"); ax.axis('off'); ax.set_xlim(0,1); ax.set_ylim(0,1)
    ax.text(.04,.92,"Proof-mode storage keeps semantics separate",fontsize=18,fontweight='bold',color=INK)
    box(ax,(.05,.57),(.23,.20),"BOARD\nbase-3 exact code\n3^(n^2) finite states",TEAL,fontsize=10)
    box(ax,(.39,.57),(.23,.20),"RULE STATE\nplayer + passes\nko profile + komi",PURPLE,fontsize=10)
    box(ax,(.72,.57),(.23,.20),"REPETITION\nexact prior codes\nno probabilistic omission",GOLD,fontsize=10,textcolor=INK)
    arrow(ax,(.28,.67),(.39,.67)); arrow(ax,(.62,.67),(.72,.67))
    box(ax,(.20,.22),(.26,.18),"STATE HASH\ncanonical JSON\nSHA-256 replay identity",GREEN,fontsize=10)
    box(ax,(.55,.22),(.26,.18),"SOLVE CERTIFICATE\nresult + metrics\nTT digest + rerun",CORAL,fontsize=10)
    arrow(ax,(.50,.57),(.33,.40),GREEN); arrow(ax,(.83,.57),(.68,.40),CORAL); arrow(ax,(.46,.31),(.55,.31),GOLD)
    ax.text(.5,.08,"A 64-bit checksum may index a cache, but it does not replace exact history in a proof claim.",ha='center',fontsize=10,fontweight='bold',color=CORAL)
    save(fig,"storage_diagram.png")


def screenshot_web():
    fig, ax=plt.subplots(figsize=(12.8,7.6)); fig.patch.set_facecolor("#09111f"); ax.set_facecolor("#09111f"); ax.axis('off'); ax.set_xlim(0,1); ax.set_ylim(0,1)
    # board panel
    ax.add_patch(FancyBboxPatch((.035,.055),.62,.89,boxstyle="round,pad=.01,rounding_size=.025",facecolor="#0f1b2d",edgecolor="#29415f",lw=2))
    bx0,by0,bw=.08,.10,.53
    ax.add_patch(FancyBboxPatch((bx0,by0),bw,.80,boxstyle="round,pad=.01,rounding_size=.02",facecolor=WOOD,edgecolor=WOOD_DARK,lw=3))
    n=9; margin=.045; x0=bx0+margin; y0=by0+margin; side=bw-2*margin; step=side/(n-1)
    for i in range(n):
        x=x0+i*step; y=y0+i*step
        ax.plot([x0,x0+side],[y,y],color=WOOD_DARK,lw=1)
        ax.plot([x,x],[y0,y0+side],color=WOOD_DARK,lw=1)
    stones=[(2,2,1),(5,2,2),(4,4,1),(3,5,2),(6,6,1),(1,7,2)]
    for x,y,c in stones:
        fc="#11151c" if c==1 else "#f0f3f7"; ec="#000" if c==1 else "#7b8795"
        ax.add_patch(Circle((x0+x*step,y0+(n-1-y)*step),step*.40,facecolor=fc,edgecolor=ec,lw=1.3,zorder=4))
    # side panel
    ax.add_patch(FancyBboxPatch((.69,.055),.275,.89,boxstyle="round,pad=.015,rounding_size=.025",facecolor="#111d31",edgecolor="#29415f",lw=2))
    ax.text(.72,.88,"UGTS-KC 4.2 Go",color="white",fontsize=18,fontweight='bold')
    ax.text(.72,.82,"Deterministic area scoring\npositional superko\nreplay hashes",color=MID,fontsize=10,va='top')
    for i,(label,color) in enumerate([("Size  9",PURPLE),("Komi  7.5",TEAL)]):
        ax.add_patch(FancyBboxPatch((.72,.66-i*.075),.20,.052,boxstyle="round,pad=.005,rounding_size=.01",facecolor=NAVY2,edgecolor=color,lw=1.2))
        ax.text(.735,.686-i*.075,label,color="white",fontsize=10,va='center')
    for i,label in enumerate(["New","Pass","Undo","Seeded hint"]):
        x=.72+(i%2)*.105; y=.49-(i//2)*.075
        ax.add_patch(FancyBboxPatch((x,y),.095,.052,boxstyle="round,pad=.005,rounding_size=.01",facecolor="#1b3151",edgecolor="#3d5f86",lw=1))
        ax.text(x+.0475,y+.026,label,ha='center',va='center',color='white',fontsize=8.5)
    ax.add_patch(FancyBboxPatch((.72,.18),.20,.18,boxstyle="round,pad=.008,rounding_size=.01",facecolor="#08101d",edgecolor="#223956",lw=1))
    ax.text(.735,.335,"Move 6 | Black to play\nArea B 3 - W 3\nCurrent margin -7.5\nHistory keys 7",color=LIGHT,fontsize=9,va='top',family='monospace')
    ax.text(.5,.015,"Self-contained HTML: no CDN, package manager, or network asset",ha='center',color=GOLD,fontsize=10,fontweight='bold')
    save(fig,"web_runtime.png")


if __name__ == "__main__":
    architecture(); board_topology(); ko_sequence(); search_ladder(); pv_2x2(); validation_chart(); storage_diagram(); screenshot_web()
    print("generated", len(list(FIG.glob('*.png'))), "figures")
