from __future__ import annotations

import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / "report"
REPORT.mkdir(exist_ok=True)

summary = json.loads((ROOT / "validation" / "summary.json").read_text(encoding="utf-8"))
solved = json.loads((ROOT / "validation" / "solved_positions.json").read_text(encoding="utf-8"))
cert = json.loads((ROOT / "validation" / "solve_2x2_k0_5.json").read_text(encoding="utf-8"))
mcts = json.loads((ROOT / "validation" / "mcts_9x9_seeded.json").read_text(encoding="utf-8"))
partial = json.loads((ROOT / "validation" / "bounded_empty_3x3_attempt.json").read_text(encoding="utf-8"))
with (ROOT / "spec" / "go_mechanisms_M390_M449.csv").open(encoding="utf-8", newline="") as handle:
    catalog = list(csv.DictReader(handle))


def esc(text: object) -> str:
    s = str(text)
    repl = {
        "\\": r"\textbackslash{}",
        "&": r"\&",
        "%": r"\%",
        "$": r"\$",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
        "~": r"\textasciitilde{}",
        "^": r"\textasciicircum{}",
    }
    return "".join(repl.get(ch, ch) for ch in s)


solved_rows = []
for row in solved:
    solved_rows.append(
        f"{row['size']}x{row['size']} & {row['komi']:.1f} & {esc(row['winner'])} & "
        f"{row['black_margin']:.1f} & {row['metrics']['nodes']} & {row['metrics']['table_entries']} & "
        f"{esc(', '.join(row['principal_variation'][:5]))}\\\\"
    )

catalog_rows = []
for row in catalog:
    catalog_rows.append(
        f"{esc(row['ID'])} & {esc(row['Domain'])} & {esc(row['Mechanism'])} & "
        f"{esc(row['Normalized technical definition'])} & {esc(row['Validation'])}\\\\"
        + "\n\\hline"
    )

template = r'''
\documentclass[10pt,a4paper]{{article}}
\usepackage[T1]{{fontenc}}
\usepackage[utf8]{{inputenc}}
\usepackage{{lmodern}}
\usepackage{{microtype}}
\usepackage[margin=17mm,headheight=15pt]{{geometry}}
\usepackage{{graphicx}}
\usepackage{{booktabs,longtable,array,tabularx,multirow}}
\usepackage{{xcolor}}
\usepackage{{hyperref}}
\usepackage{{fancyhdr,lastpage}}
\usepackage{{enumitem}}
\usepackage{{listings}}
\usepackage[most]{{tcolorbox}}
\usepackage{{titlesec}}
\usepackage{{caption,float}}
\usepackage{{amsmath,amssymb}}
\usepackage{{ragged2e}}

\definecolor{{navy}}{{HTML}}{{0C1930}}
\definecolor{{navyTwo}}{{HTML}}{{142746}}
\definecolor{{teal}}{{HTML}}{{20B5B8}}
\definecolor{{gold}}{{HTML}}{{E0AD25}}
\definecolor{{green}}{{HTML}}{{52C987}}
\definecolor{{coral}}{{HTML}}{{E36F60}}
\definecolor{{purple}}{{HTML}}{{8D73D1}}
\definecolor{{ice}}{{HTML}}{{EEF4FB}}
\definecolor{{mid}}{{HTML}}{{A9BDD5}}
\definecolor{{ink}}{{HTML}}{{111827}}

\hypersetup{{colorlinks=true,linkcolor=teal,urlcolor=purple,citecolor=teal,pdftitle={{UGTS-KC 4.2 Go Solver}},pdfauthor={{Prepared for Tom Klootwijk}}}}
\pagestyle{{fancy}}
\fancyhf{{}}
\fancyhead[L]{{\small\color{{navy}}UGTS-KC 4.2 Go Solver}}
\fancyhead[R]{{\small\color{{navy}}Exact finite solving and proof-oriented runtime}}
\fancyfoot[L]{{\small Prepared for Tom Klootwijk}}
\fancyfoot[R]{{\small Page \thepage\ of \pageref{{LastPage}}}}
\renewcommand{{\headrulewidth}}{{0.4pt}}
\renewcommand{{\footrulewidth}}{{0pt}}

\titleformat{{\section}}{{\Large\bfseries\color{{navy}}}}{{\thesection.}}{{0.5em}}{{}}
\titleformat{{\subsection}}{{\large\bfseries\color{{teal}}}}{{\thesubsection}}{{0.5em}}{{}}
\titleformat{{\subsubsection}}{{\normalsize\bfseries\color{{purple}}}}{{\thesubsubsection}}{{0.5em}}{{}}
\setlist[itemize]{{leftmargin=1.4em,itemsep=2pt,topsep=3pt}}
\setlist[enumerate]{{leftmargin=1.6em,itemsep=2pt,topsep=3pt}}
\setlength{{\parindent}}{{0pt}}
\setlength{{\parskip}}{{4pt}}

\newtcolorbox{{decisionbox}}{{enhanced,breakable,colback=green!9,colframe=green!75!black,title=FORMAL DECISION,fonttitle=\bfseries,coltitle=white}}
\newtcolorbox{{boundarybox}}{{enhanced,breakable,colback=coral!8,colframe=coral!85!black,title=EVIDENCE / CLAIM BOUNDARY,fonttitle=\bfseries,coltitle=white}}
\newtcolorbox{{resultbox}}{{enhanced,breakable,colback=teal!7,colframe=teal!80!black,title=VERIFIED RELEASE RESULT,fonttitle=\bfseries,coltitle=white}}
\newtcolorbox{{exactbox}}{{enhanced,breakable,colback=gold!10,colframe=gold!85!black,title=EXACTNESS CONDITION,fonttitle=\bfseries,coltitle=ink}}

\lstdefinestyle{{code}}{{basicstyle=\ttfamily\footnotesize,backgroundcolor=\color{{navy!4}},frame=single,rulecolor=\color{{navy!25}},breaklines=true,columns=fullflexible,showstringspaces=false}}
\captionsetup{{font=small,labelfont=bf}}

\begin{{document}}

\begin{{titlepage}}
\pagecolor{{navy}}
\color{{white}}
\vspace*{{8mm}}
{{\Huge\bfseries UGTS-KC 4.2 GO}}\\[3mm]
{{\LARGE\bfseries Exact Finite Solving, Proof Certificates,\\Scalable Search and Self-Contained Runtime}}\\[5mm]
{{\large An additive board-game application profile over the supplied UGTS substrate line}}\\[8mm]
\begin{{center}}
\includegraphics[width=0.98\textwidth]{{../figures/architecture.png}}
\end{{center}}
\vfill
\begin{{tabular}}{{@{{}}ll@{{}}}}
Prepared for & Tom Klootwijk \\
Version & 4.2.0 \\
Project schema & ugts-go-state-4.2 / ugts-go-solve-certificate-4.2 \\
Document date & 29 August 2026 \\
Status & Executable reference package with bounded exact evidence
\end{{tabular}}
\\[6mm]
{{\small\color{{mid}}Requester attribution is recorded as supplied and is not independently verified. This report is a technical design and validation artifact, not legal proof of identity, authorship, ownership, priority or patentability.}}
\end{{titlepage}}
\nopagecolor
\color{{ink}}

\section*{{Executive Summary}}
\addcontentsline{{toc}}{{section}}{{Executive Summary}}

\begin{{decisionbox}}
The requested objective is admitted as a proof-oriented Go profile: model every move as a verified UGTS event, make superko history part of exact state identity, solve bounded finite positions by exhaustive minimax, and separate exact certificates from seeded search estimates. The result is a coherent implementation and release package. It does \textbf{{not}} claim a game-theoretic solution of unrestricted standard 19x19 Go.
\end{{decisionbox}}

\begin{{resultbox}}
The package contains 60 new cataloged mechanisms, M390--M449; @@TESTCOUNT@@ dependency-free tests with @@TESTCOUNT@@/@@TESTCOUNT@@ passing; zero JSON Schema errors; a verified exact certificate for the empty 2x2 game at 0.5 komi; a deterministic 9x9 MCTS evidence run; a self-contained HTML board; SGF import/export; a wheel build; and a complete SHA-256 manifest.

Under the declared exact profile (area scoring, no suicide, positional superko, 0.5 komi), the empty 2x2 game has exact minimax value \textbf{{Black +0.5}}. The certificate hash is:
\begin{{center}}\ttfamily\small @@CERT_HASH@@\end{{center}}
\end{{resultbox}}

\begin{{boundarybox}}
``Solve'' has three different meanings that are kept separate:
\begin{{itemize}}
\item \textbf{{Rules solved}}: every legal move, capture, pass, repetition and score transition is deterministic and testable.
\item \textbf{{Position solved}}: an exhaustive search completed for one fully serialized finite state and rules profile.
\item \textbf{{Game solved}}: the initial standard board is proven under a complete rules profile. This release establishes the first two for bounded fixtures, not the third for 19x19.
\end{{itemize}}
\end{{boundarybox}}

\begin{{table}}[H]
\centering
\caption{{Release deliverables}}
\begin{{tabularx}}{{\textwidth}}{{>{\bfseries}p{{0.25\textwidth}} X p{{0.18\textwidth}}}}
\toprule
Deliverable & Contents & Status \\
\midrule
PDF technical report & Architecture, rules, solver, certificate, validation and catalog & Delivered \\
Python package & Deterministic rules, exact solver, MCTS, SGF, CLI, web builder & Tested \\
Exact evidence & 1x1 and 2x2 solved fixtures plus rerunnable certificate & Verified \\
Search evidence & Seeded 9x9 MCTS with explicit non-proof marker & Verified estimate \\
Self-contained browser & One HTML file; no CDN or network asset & Built \\
Machine-readable spec & JSON Schema, source map, M390--M449 CSV/JSON & Validated \\
\bottomrule
\end{{tabularx}}
\end{{table}}

\clearpage
\tableofcontents
\clearpage

\section{{Source Basis and Integration Discipline}}

The supplied files do not contain a Go solver. They do contain a consistent architecture that can be applied without replacing their evidence boundaries. The Go rules, scoring and search algorithms in this release are therefore visibly labeled \emph{{engineering-derived}}, while the surrounding state/event discipline is inherited.

\begin{{longtable}}{{p{{0.27\textwidth}} p{{0.52\textwidth}} p{{0.16\textwidth}}}}
\caption{{Suitable supplied substrate versions and their use}}\\
\toprule
Source & Used mechanisms & Treatment \\
\midrule
\endfirsthead
\toprule
Source & Used mechanisms & Treatment \\
\midrule
\endhead
UGTS-KC 2.0 & Query-first state, topology descriptors, support/compatibility/guard/event/lineage sequence, explicit numerical and performance kill criteria (especially pp. 3--15). & Architectural basis \\
KC Two Hands 3.0 & Verified proposals, deterministic commit, persistent constraints versus discrete events, state hashes, checkpoints and replay (pp. 11--16). & Production discipline \\
UGTS-KC 3.6 & Literal content-addressed definitions, resolvable dependencies, canonical hashing and normative operation order (pp. 1--14). & Referential discipline \\
UGTS-KC 3.6.2 SCLP & Finite packed addresses, radix refinement, explicit guard intervals and finite grammar budgets (pp. 1--15). & Packing discipline \\
UGTS-KC 3.9 KC Elizabeth & Deterministic game world, snapshots/hashes, project validation, CLI and self-contained HTML delivery (pp. 2--16). & Game-runtime basis \\
UGTS-GN 1.1 & Compact state/event records, pruning metrics, memory/compression contracts and strict physical-performance boundary (pp. 2--15). & Performance discipline \\
UGTS-KC 3.6.3 SARA & Wallet-specific cryptographic public-certificate profile. & Excluded as unrelated \\
\bottomrule
\end{{longtable}}

\subsection{{Source-derived versus engineering-derived}}

\begin{{tabularx}}{{\textwidth}}{{p{{0.22\textwidth}} X X}}
\toprule
Class & Included here & Examples \\
\midrule
Source-derived architecture & Terms and invariant order retained from the PDFs & typed state, support, compatibility, guard, verified event, transition, lineage, content hash, replay \\
Engineering-derived Go layer & New rules and algorithms required by the application & board graph, groups, liberties, captures, superko, area score, minimax, D4 canonicalization, MCTS, SGF \\
Measured package evidence & Outputs regenerated from this package & 52 tests, solved fixtures, certificate rerun, MCTS seed run, wheel, file hashes \\
Explicit non-claims & Results not established by the package & unrestricted 19x19 solution, production engine strength, physical-GPU advantage, universal rule-set equivalence \\
\bottomrule
\end{{tabularx}}

\section{{Formal Go State and Board Topology}}

For board size $n$, the board is a finite graph $G=(V,E)$ with $|V|=n^2$ and orthogonal adjacency. Every vertex contains exactly one value from $\{{\emptyset,B,W\}}$. The authoritative state is
\[
q_{go}=(R,B,p,c,m,H,B_{prev},L),
\]
where $R$ is the rules profile, $B$ the board, $p$ the player to move, $c$ the consecutive-pass count, $m$ the move number, $H$ the exact superko history, $B_{prev}$ the simple-ko board, and $L$ the ordered replay lineage.

\begin{{exactbox}}
Coordinates are presentation labels, not identity. A repeated coordinate can represent a legal capture cycle only when the complete resulting board position is new under the selected repetition profile. Exact state identity therefore includes the rules, side to move, pass state and repetition state.
\end{{exactbox}}

\begin{{figure}}[H]
\centering
\includegraphics[width=0.72\textwidth]{{../figures/board_topology.png}}
\caption{{Groups and liberties are finite graph relations. Green points are the black group's liberty set; neighboring white stones are compatibility context rather than part of the group.}}
\end{{figure}}

\subsection{{Group and liberty calculus}}
A group is a maximal same-color connected component. Its liberty set is the union of adjacent empty vertices. The implementation uses exact flood traversal over the precomputed neighbor table. This makes capture classification finite and deterministic:
\begin{{lstlisting}}[style=code]
place stone
for each adjacent opponent group:
    if liberties(group) == empty: remove group
if liberties(own_group) == empty:
    reject as suicide, or remove under an explicit suicide profile
apply repetition guard
commit atomically
\end{{lstlisting}}

\subsection{{Compact exact board identity}}
The board is also encoded as a collision-free base-3 integer
\[
K_B=\sum_{{i=0}}^{{n^2-1}} B_i 3^i,
\]
with empty $=0$, black $=1$ and white $=2$. This is finite packing, not lossy compression. It is used for exact repetition sets and can reconstruct the full board.

\section{{Move Proposal, Guard and Atomic Commit}}

A move is not accepted merely because a user clicked an empty-looking point. It becomes a verified event only after the declared guard sequence.

\begin{{figure}}[H]
\centering
\includegraphics[width=\textwidth]{{../figures/architecture.png}}
\caption{{Go-specific mechanics mapped into the canonical UGTS event sequence.}}
\end{{figure}}

For a non-pass proposal $a$:
\[
\mathrm{{verified}}(a,q)=\mathrm{{inboard}}\land\mathrm{{empty}}\land
\mathrm{{capture\_defined}}\land\mathrm{{suicide\_ok}}\land\mathrm{{repetition\_ok}}.
\]
A successful commit writes a new immutable state and a move event containing color, point/pass, captured stones, optional self-removal, guard status, pre/post hashes and a lineage label.

\begin{{table}}[H]
\centering
\caption{{Move-event fields}}
\begin{{tabularx}}{{\textwidth}}{{p{{0.24\textwidth}} X}}
\toprule
Field & Meaning \\
\midrule
move / color & Proposed point or pass and acting player \\
captured / self-removed & Exact ordered point sets changed by the rule patch \\
pre-hash / post-hash & SHA-256 of canonical state records including repetition history \\
guard status & move-accepted or pass-accepted; failures carry reason codes as exceptions \\
lineage label & Stable move number, color and point/pass marker for replay inspection \\
\bottomrule
\end{{tabularx}}
\end{{table}}

\section{{Ko, Superko and Finite Search}}

\begin{{figure}}[H]
\centering
\includegraphics[width=\textwidth]{{../figures/ko_sequence.png}}
\caption{{A positional-superko rejection is a relation over history, not a special-case pixel rule.}}
\end{{figure}}

\begin{{tabularx}}{{\textwidth}}{{p{{0.24\textwidth}} X p{{0.20\textwidth}}}}
\toprule
Profile & Guard & Exact-solver admission \\
\midrule
Positional superko & Resulting board code has not appeared before & Yes \\
Situational superko & Resulting board plus next player has not appeared before & Yes \\
Simple ko & Resulting board differs from one ply earlier & Rules engine only \\
No ko & No repetition restriction & Rules engine only \\
\bottomrule
\end{{tabularx}}

The exact solver refuses simple-ko and no-ko profiles. That refusal is not a missing feature disguised as a result: those profiles can admit longer cycles, so a finite exhaustive graph requires an additional cycle policy. Positional and situational superko add a new exact key after every legal non-pass move, which bounds the game length by the finite key space plus passes.

\section{{Area Scoring and Terminality}}

Two consecutive passes create the terminal event. Area scoring then counts stones plus single-color empty regions. Mixed or unbordered regions remain neutral. Komi is stored in integer half-points:
\[
M_B=2(A_B-A_W)-K_{{1/2}}.
\]
$M_B>0$ is a black win, $M_B<0$ is a white win, and $M_B=0$ is a draw. This avoids floating-point score drift after save/load or certificate serialization.

\begin{{boundarybox}}
The exact core implements area scoring only. Japanese-style territory scoring, dead-stone agreement, seki adjudication, handicap conventions and tournament-specific edge cases require separate versioned adapters. They are not silently merged into this profile.
\end{{boundarybox}}

\section{{Exact Solver Architecture}}

\begin{{figure}}[H]
\centering
\includegraphics[width=0.92\textwidth]{{../figures/search_ladder.png}}
\caption{{Exact and heuristic modes share legal transitions but have different evidence status.}}
\end{{figure}}

\subsection{{Minimax and alpha-beta}}
Black maximizes and White minimizes the exact terminal half-point margin. The solver uses alpha-beta pruning and a transposition table with exact, lower and upper bounds. Move ordering considers terminal passes, capture count, a non-authoritative intermediate area heuristic and point index. Ordering changes speed, not completeness.

\subsection{{History-correct transposition identity}}
A transposition entry is keyed by
\[
(B,p,c,B_{{prev}},H).
\]
Under optional D4 canonicalization, the current board, previous board and \emph{{every}} history code are transformed by the same rotation/reflection before the minimum representative is selected. Transforming only the current board would be incorrect because it could alter which future moves violate superko.

\subsection{{Budget semantics}}
Node and monotonic-time limits are first-class guards. If either limit is crossed, the solver returns \texttt{{complete=false}}, no minimax value, no best move and no certificate. The captured empty-3x3 run stopped at @@PARTIAL_NODES@@ nodes (@@PARTIAL_REASON@@) and correctly emitted no exact value.

\begin{{lstlisting}}[style=code]
result = ExactSolver(node_limit=2048).solve(empty_3x3)
assert result.complete is False
assert result.value_halfpoints is None
# No solve certificate is permitted.
\end{{lstlisting}}

\section{{Content-Addressed Solve Certificate}}

The certificate follows the 3.6 referential discipline: canonical JSON, explicit schema, stable IDs and SHA-256 content identity. It contains the full root state, exact result, best move, principal variation, solver mode, metrics, D4 setting, transposition-table digest and a claim boundary.

Verification occurs in two stages:
\begin{{enumerate}}
\item Remove the certificate hash field, canonicalize the remaining JSON and recompute SHA-256.
\item Reconstruct the root state, rerun exhaustive search and compare exact value plus transposition digest.
\end{{enumerate}}

\begin{{table}}[H]
\centering
\caption{{Verified 2x2 certificate identifiers}}
\begin{{tabularx}}{{\textwidth}}{{p{{0.28\textwidth}} X}}
\toprule
Identifier & Value \\
\midrule
Root state SHA-256 & \ttfamily\footnotesize @@ROOT_HASH@@ \\
Certificate SHA-256 & \ttfamily\footnotesize @@CERT_HASH@@ \\
Transposition digest & \ttfamily\footnotesize @@TT_DIGEST@@ \\
Search nodes / terminal nodes & @@CERT_NODES@@ / @@CERT_TERMINALS@@ \\
Table entries / cutoffs & @@CERT_ENTRIES@@ / @@CERT_CUTOFFS@@ \\
Maximum ply & @@CERT_MAXPLY@@ \\
Rerun status & verified by deterministic exhaustive rerun \\
\bottomrule
\end{{tabularx}}
\end{{table}}

\begin{{boundarybox}}
The certificate is executable evidence from this implementation. It is stronger than a screenshot or unsupported result string, but it is not a proof-assistant theorem and does not independently certify the Python interpreter, hardware or compiler.
\end{{boundarybox}}

\section{{Solved Fixtures}}

\begin{{table}}[H]
\centering
\caption{{Exact initial-board fixture results}}
\small
\begin{{tabular}}{{ccccccc}}
\toprule
Board & Komi & Winner & Black margin & Nodes & TT entries & PV prefix \\
\midrule
@@SOLVED_ROWS@@
\bottomrule
\end{{tabular}}
\end{{table}}

The empty 2x2 result is invariant under D4: any corner is equivalent as the first move. Deterministic tie order selects A2. The full principal variation is:
\begin{{center}}\ttfamily\small @@PV@@\end{{center}}

\begin{{figure}}[H]
\centering
\includegraphics[width=0.94\textwidth]{{../figures/pv_2x2.png}}
\caption{{Selected states from the exact empty-2x2 principal variation.}}
\end{{figure}}

The 1x1 result is a draw at zero komi and White by 0.5 at 0.5 komi. The 2x2 threshold under this profile is Black +1.0 before komi: zero komi gives Black +1.0, 1.0 komi gives a draw, and 1.5 komi gives White +0.5.

\section{{Scalable Search for Larger Boards}}

Exact history makes the reference solver intentionally conservative. For larger boards, the package supplies seeded MCTS using the same legal transition engine. Tree expansion never bypasses occupancy, capture, suicide or superko guards. Rollouts probe a bounded random subset of empty points and always report \texttt{{exact=false}}.

The captured 9x9 run used 100 iterations, rollout limit 128 and seed @@MCTS_SEED@@. It completed in @@MCTS_ELAPSED@@ seconds on the validation environment and selected @@MCTS_BEST@@; the estimated black win rate was @@MCTS_RATE@@. These values are reproducibility evidence, not playing-strength or solution claims.

\begin{{table}}[H]
\centering
\caption{{Top seeded 9x9 root children by visits}}
\begin{{tabular}}{{lrr}}
\toprule
Move & Visits & Estimated black win rate \\
\midrule
@@MCTS_ROWS@@
\bottomrule
\end{{tabular}}
\end{{table}}

\subsection{{Path toward proof-scale Go}}
A credible exact 19x19 program would require additive mechanisms beyond this reference implementation:
\begin{{itemize}}
\item proof-number or retrograde search specialized to win/loss thresholds;
\item mathematically safe decomposition of independent endgames and local life/death regions;
\item seki, ko-threat and global-temperature certificates that preserve cross-region coupling;
\item distributed content-addressed proof shards with deterministic merge rules;
\item verified transposition storage larger than RAM, with collision-free state reconstruction;
\item GPU kernels restricted to candidate generation or bound computation, while authoritative commit and proof checks remain deterministic;
\item independent verifier implementations and cross-platform differential testing.
\end{{itemize}}
None of these is silently claimed as complete here.

\section{{Storage, Compression and Reconstructibility}}

\begin{{figure}}[H]
\centering
\includegraphics[width=0.95\textwidth]{{../figures/storage_diagram.png}}
\caption{{Compact board identity does not erase rules state or repetition history.}}
\end{{figure}}

Base-3 board codes are exact and compact. A situational key packs the board code and player into one integer. SHA-256 hashes are used for content and replay integrity. However, proof mode retains the exact history set. A 64-bit checksum may index a cache, but it cannot replace exact history without a collision policy and independent reconstruction evidence.

The strongest compression opportunity is therefore not blind state truncation; it is structure:
\begin{{itemize}}
\item reuse immutable board records and symmetry classes;
\item store canonical rules once and reference them;
\item compact verified event logs when the initial state and transition function reconstruct every state;
\item shard exact histories by content address;
\item preserve full exceptions whenever external input, rule change or unresolved ambiguity breaks reconstruction.
\end{{itemize}}

\section{{Command-Line, SGF and Browser Delivery}}

The CLI exposes exact solve, seeded MCTS, score, web build and certificate verification:
\begin{{lstlisting}}[style=code]
PYTHONPATH=src python -m ugts_go solve \
  --size 2 --komi 0.5 \
  --certificate validation/solve_2x2_k0_5.json

PYTHONPATH=src python -m ugts_go verify-certificate \
  validation/solve_2x2_k0_5.json

PYTHONPATH=src python -m ugts_go mcts \
  --size 9 --komi 7.5 --iterations 200 --seed 420042

PYTHONPATH=src python -m ugts_go build-web examples/web/go_ugts.html
\end{{lstlisting}}

\begin{{figure}}[H]
\centering
\includegraphics[width=0.96\textwidth]{{../figures/web_runtime.png}}
\caption{{The included browser board is a single HTML file with local rules, score, pass, undo and a bounded seeded hint.}}
\end{{figure}}

The SGF adapter supports one variation with size, komi, black/white moves and passes. It is intentionally a downstream interchange subset, not a full SGF property engine or authoritative substitute for the serialized UGTS state.

\section{{Validation and Release Evidence}}

\begin{{figure}}[H]
\centering
\includegraphics[width=0.88\textwidth]{{../figures/validation_chart.png}}
\caption{{Measured release counts. The empty-3x3 bar is a bounded interrupted attempt, not a solved result.}}
\end{{figure}}

\begin{{tabularx}}{{\textwidth}}{{p{{0.27\textwidth}} p{{0.18\textwidth}} X}}
\toprule
Gate & Result & Established boundary \\
\midrule
Python compile & PASS & All source modules compile under Python @@PYTHON@@. \\
Unit tests & @@TESTCOUNT@@/@@TESTCOUNT@@ PASS & Rules, topology, packing, solver, certificates, MCTS, SGF and web builder satisfy included properties. \\
JSON Schema & 0 errors & Example state and exact certificate satisfy the supplied Draft 2020-12 schema. \\
Mechanism catalog & 60 contiguous & M390--M449 count and order machine-checked. \\
Exact certificate & PASS & Hash and deterministic rerun match. \\
Web output & @@WEB_BYTES@@ bytes & Contains Canvas runtime and no external HTTP resource. \\
Wheel build & PASS & Dependency-free wheel built and smoke-tested with build isolation disabled. \\
Large-board strength & NOT CLAIMED & Seeded MCTS evidence is not a benchmark against established Go engines. \\
19x19 exact solution & NOT CLAIMED & No root certificate exists in this release. \\
\bottomrule
\end{{tabularx}}

\section{{Kill Criteria and Explicit Non-Claims}}

The profile must be rejected, simplified or relabeled if any of the following occurs:
\begin{{itemize}}
\item rules, komi, suicide, ko or scoring conventions are implicit;
\item superko history is omitted while claiming exact legality;
\item a heuristic move filter is used in proof mode;
\item D4 canonicalization transforms the board but not all repetition state;
\item floating-point score spelling changes state identity;
\item an incomplete search emits a best move as exact or creates a certificate;
\item MCTS estimates are described as solved values;
\item cache hashes replace full proof state without collision/reconstruction evidence;
\item GPU or distributed workers mutate authoritative state without verified deterministic commit;
\item a conventional Go engine is cheaper, faster or more accurate for the target requirement.
\end{{itemize}}

\begin{{boundarybox}}
No universal O(1) game solver, zero-memory proof, infinite compression, one-bit complete state, perfect 19x19 play, native physical-GPU advantage, Japanese-rules equivalence, multiplayer service, tournament certification or legal ownership claim is introduced.
\end{{boundarybox}}

\section{{Final Definition}}

\begin{{decisionbox}}
UGTS-KC 4.2 Go is a finite, typed, event-authoritative application profile in which an orthogonal board graph supplies groups and liberties; rules compatibility selects player, ko, suicide and scoring conventions; occupancy, liberty and repetition become guards; a legal placement or pass becomes a verified proposal; capture, side toggle and history update commit atomically; terminal area score is represented in exact half-points; exact minimax retains complete superko state and may emit a content-addressed rerunnable certificate only after exhaustive completion; seeded MCTS remains a separately typed estimate; and SGF/browser output stays downstream of authoritative state and lineage.
\end{{decisionbox}}

Canonical shorthand:
\begin{{center}}
\texttt{{board/group support -> rules compatibility -> move guards -> verified proposal -> atomic commit -> hash/replay -> score/certificate}}
\end{{center}}

The release is technically coherent to the extent demonstrated by the bundled implementation and validation. The next research target is not to rename heuristic strength as a solution, but to add independently verifiable decomposition and proof-search machinery until larger roots can emit complete certificates.

\clearpage
\appendix
\section{{Mechanism Catalog M390--M449}}

The following 60 entries are engineering additions. They extend the combined catalog after M389 but do not rewrite the source-normalized or prior KC mechanisms.

\scriptsize
\setlength{{\tabcolsep}}{{3pt}}
\begin{{longtable}}{{p{{0.055\textwidth}} p{{0.12\textwidth}} p{{0.19\textwidth}} p{{0.43\textwidth}} p{{0.15\textwidth}}}}
\caption{{Complete UGTS-KC 4.2 Go delta catalog}}\\
\hline
\textbf{{ID}} & \textbf{{Domain}} & \textbf{{Mechanism}} & \textbf{{Normalized technical definition}} & \textbf{{Validation}} \\
\hline
\endfirsthead
\hline
\textbf{{ID}} & \textbf{{Domain}} & \textbf{{Mechanism}} & \textbf{{Normalized technical definition}} & \textbf{{Validation}} \\
\hline
\endhead
@@CATALOG_ROWS@@
\end{{longtable}}
\normalsize

\section{{Package Map}}

\begin{{longtable}}{{p{{0.31\textwidth}} p{{0.62\textwidth}}}}
\toprule
Path & Contents \\
\midrule
\endfirsthead
\toprule
Path & Contents \\
\midrule
\endhead
\texttt{{src/ugts\_go/}} & Immutable model, board topology, rules, hashes, D4 symmetries, exact solver, MCTS, certificates, SGF, web builder and CLI. \\
\texttt{{spec/}} & Formal definition, JSON Schema, source-integration register and M390--M449 CSV/JSON catalog. \\
\texttt{{tests/}} & 52 dependency-free tests. \\
\texttt{{examples/}} & Small-board exact solve, ko guard, 9x9 MCTS and self-contained HTML. \\
\texttt{{validation/}} & Captured test/compile/schema results, solved fixtures, exact certificate, bounded 3x3 attempt, MCTS evidence and package checks. \\
\texttt{{dist/}} & Installable Python wheel. \\
\texttt{{checksums/}} & Complete SHA-256 manifest for distributable files. \\
\texttt{{report/}} & This PDF, LaTeX source and report generation assets. \\
\bottomrule
\end{{longtable}}

\section{{Reproduction}}

From the package root:
\begin{{lstlisting}}[style=code]
PYTHONPATH=src python tools/build_catalog.py
PYTHONPATH=src python -m unittest discover -s tests -v
PYTHONPATH=src python tools/run_validation.py
PYTHONPATH=src python examples/solve_small_boards.py
python -m pip wheel . --no-deps --no-build-isolation -w dist
\end{{lstlisting}}

Report assets and PDF:
\begin{{lstlisting}}[style=code]
PYTHONPATH=src python tools/generate_report_assets.py
python tools/generate_report_tex.py
latexmk -pdf -interaction=nonstopmode -halt-on-error \
  report/UGTS_KC_4_2_GO_Solver.tex
\end{{lstlisting}}

\section{{Attribution and Evidence Notice}}
Prepared for Tom Klootwijk as an engineering artifact within the UGTS project. Requester attribution is recorded as supplied and remains independently unverified. This report and package are not legal proof of identity, authorship, ownership, patentability, priority, exclusive rights, licensing status or chain of title. The source PDFs are referenced by filename and technical role; they are not redistributed inside this package.

\end{{document}}
'''

mcts_rows = "\n".join(
    f"{esc(r['move'])} & {r['visits']} & {r['estimated_black_win_rate']:.3f}\\\\"
    for r in mcts['top_children'][:10]
)
values = {
    '@@TESTCOUNT@@': str(summary['tests']['count']),
    '@@CERT_HASH@@': cert['certificate_hash'],
    '@@PARTIAL_NODES@@': str(partial['nodes']),
    '@@PARTIAL_REASON@@': esc(partial['reason']),
    '@@ROOT_HASH@@': cert['root_state_hash'],
    '@@TT_DIGEST@@': cert['search']['transposition_table_digest'],
    '@@CERT_NODES@@': str(cert['search']['metrics']['nodes']),
    '@@CERT_TERMINALS@@': str(cert['search']['metrics']['terminal_nodes']),
    '@@CERT_ENTRIES@@': str(cert['search']['metrics']['table_entries']),
    '@@CERT_CUTOFFS@@': str(cert['search']['metrics']['cutoffs']),
    '@@CERT_MAXPLY@@': str(cert['search']['metrics']['max_ply']),
    '@@SOLVED_ROWS@@': "\n".join(solved_rows),
    '@@PV@@': esc(', '.join(cert['result']['principal_variation'])),
    '@@MCTS_SEED@@': str(mcts['seed']),
    '@@MCTS_ELAPSED@@': f"{mcts['elapsed_seconds']:.3f}",
    '@@MCTS_BEST@@': esc(mcts['best_move']),
    '@@MCTS_RATE@@': f"{mcts['estimated_black_win_rate']:.3f}",
    '@@MCTS_ROWS@@': mcts_rows,
    '@@PYTHON@@': esc(summary['python']),
    '@@WEB_BYTES@@': str(summary['web']['bytes']),
    '@@CATALOG_ROWS@@': "\n".join(catalog_rows),
}
tex = template.replace('{{', '{').replace('}}', '}')
for token, value in values.items():
    tex = tex.replace(token, value)
path = REPORT / "UGTS_KC_4_2_GO_Solver.tex"
path.write_text(tex, encoding="utf-8")
print(path)
