from __future__ import annotations

import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

rows = [
("M390","Board topology","Finite orthogonal board graph","Represent an n x n Go board as a finite vertex set with four-neighbor adjacency.","Supplies local support and exact group connectivity.","Implemented + tested"),
("M391","Board topology","Typed intersection state","Each vertex stores empty, black, or white as a closed three-value type.","Prevents presentation glyphs from becoming authority.","Implemented + tested"),
("M392","Board topology","Go coordinate chart","Map indices to letter-number coordinates while skipping I and retaining row orientation.","Human interface only; index remains canonical.","Implemented + tested"),
("M393","Board topology","Connected color group","Compute maximal same-color connected components under orthogonal adjacency.","Provides capture and life/death support.","Implemented + tested"),
("M394","Board topology","Liberty relation","A group liberty is an adjacent empty vertex; liberty sets are exact finite relations.","Primary move guard input.","Implemented + tested"),
("M395","Board topology","Empty-region decomposition","Partition empty vertices into connected regions and record bordering colors.","Supports area scoring and territory classification.","Implemented + tested"),
("M396","Board topology","Immutable board record","Store the board as immutable bytes and create a new record on commit.","Enables deterministic hashing, replay, and search keys.","Implemented + tested"),
("M397","Board topology","Base-3 exact board code","Encode all intersections in a collision-free base-3 integer.","Compact repetition history and finite addressing.","Implemented + tested"),

("M398","Move legality","Occupied-point guard","Reject placement when the target intersection is not empty.","Guard stage before board mutation.","Implemented + tested"),
("M399","Move legality","Opponent capture resolution","After placement, remove every adjacent opponent group with zero liberties.","Atomic capture patch.","Implemented + tested"),
("M400","Move legality","Self-liberty guard","After captures, require the placed stone's group to have a liberty unless suicide is enabled.","Separates capture order from suicide classification.","Implemented + tested"),
("M401","Move legality","Optional suicide removal","When enabled, remove the zero-liberty friendly group as an explicit rule profile.","Rule-specific patch, still subject to repetition.","Implemented + tested"),
("M402","Move legality","Simple-ko previous-board guard","Reject a move reproducing the board from one ply earlier.","Implements immediate ko without claiming finite global search.","Implemented + tested"),
("M403","Move legality","Positional-superko guard","Reject a non-pass move whose exact board code is already in history.","Makes exact proof mode history-aware and finite.","Implemented + tested"),
("M404","Move legality","Situational-superko guard","Reject a non-pass move whose board and next-player code is already in history.","Alternative finite repetition profile.","Implemented + tested"),
("M405","Move legality","Pass exception and side toggle","A pass changes side and pass count without occupancy or repetition rejection.","Preserves legal game termination.","Implemented + tested"),

("M406","Scoring/end","Two-pass terminal event","Two consecutive verified passes produce game terminality.","Explicit guard event rather than implicit UI state.","Implemented + tested"),
("M407","Scoring/end","Stone area count","Each on-board stone contributes one area point to its color.","Exact integer score component.","Implemented + tested"),
("M408","Scoring/end","Single-color empty-region territory","Assign an empty region only when its bordering color set contains exactly one color.","Exact finite territory classification.","Implemented + tested"),
("M409","Scoring/end","Neutral-region classification","Mixed or unbordered empty regions are explicitly neutral.","Prevents forced assignment of dame or open regions.","Implemented + tested"),
("M410","Scoring/end","Half-point komi arithmetic","Store komi and score margins in integer half-points.","Eliminates floating-point score identity drift.","Implemented + tested"),
("M411","Scoring/end","Winner relation","Positive black margin means black, negative means white, zero means draw.","Typed terminal result.","Implemented + tested"),
("M412","Scoring/end","Terminal score query","Score is authoritative only after terminality in exact game solving.","Separates intermediate heuristic evaluation from final result.","Implemented + tested"),
("M413","Scoring/end","Area-only core boundary","The exact core implements area scoring; territory/dead-stone adjudication is an adapter target.","Avoids silently mixing rule families.","Boundary enforced"),

("M414","Exact search","Finite-history minimax state","Search keys include board, player, pass state, previous board, and exact superko history.","Prevents illegal transposition merging.","Implemented + tested"),
("M415","Exact search","Alpha-beta minimax","Black maximizes and white minimizes exact terminal half-point margin.","Exact solution when search completes.","Implemented + tested"),
("M416","Exact search","Deterministic move ordering","Order terminal moves, captures, heuristic margins, and point indices deterministically.","Improves pruning without changing proof completeness.","Implemented + tested"),
("M417","Exact search","Transposition bound types","Store exact, lower, and upper values under standard alpha-beta semantics.","Reuses search results without overclaiming exactness after cutoff.","Implemented + tested"),
("M418","Exact search","Node budget guard","Abort exact mode when the declared node limit is exceeded.","Returns incomplete with no exact value or certificate.","Implemented + tested"),
("M419","Exact search","Time budget guard","Abort exact mode when the monotonic time budget is exceeded.","Explicit resource boundary.","Implemented + tested"),
("M420","Exact search","Principal variation reconstruction","Choose deterministic children matching the exact root value until terminality or a declared limit.","Human-inspectable witness line.","Implemented + tested"),
("M421","Exact search","Per-move exact analysis","Evaluate every legal child with exact minimax after a completed solve.","Move-value table for bounded positions.","Implemented"),
("M422","Exact search","Superko-only exact admission","Refuse simple-ko and no-ko profiles in proof mode because finiteness is not guaranteed by the profile.","Claim-boundary enforcement.","Implemented + tested"),
("M423","Exact search","Exact-versus-estimate type split","SolveResult.complete and MCTSResult.exact prevent heuristic output from masquerading as proof.","Governance and API boundary.","Implemented + tested"),

("M424","Symmetry/packing","D4 board transform family","Provide identity, rotations, and reflections as eight exact index maps.","Symmetry reduction and replay transformation.","Implemented + tested"),
("M425","Symmetry/packing","History-correct symmetry","Transform current board, previous board, and every superko key under one shared symmetry.","Preserves move legality under canonicalization.","Implemented + tested"),
("M426","Symmetry/packing","Lexicographic canonical state","Select the minimal transformed state/history tuple as the transposition representative.","Deterministic cache identity.","Implemented + tested"),
("M427","Symmetry/packing","Exact transform inverse","Every D4 transform has a tested inverse.","Supports coordinate and proof-line reconstruction.","Implemented + tested"),
("M428","Symmetry/packing","Compact situational code","Pack board code and player into one collision-free integer for situational superko.","Finite history storage.","Implemented + tested"),
("M429","Symmetry/packing","Canonical state SHA-256","Hash sorted canonical JSON including rules and repetition history.","Replay and certificate identity.","Implemented + tested"),
("M430","Symmetry/packing","Transposition-table digest","Hash sorted canonical entry records containing key, value, and bound.","Rerun evidence for exact solve certificates.","Implemented + tested"),
("M431","Symmetry/packing","Memory boundary","Exact history is retained even when it dominates memory; probabilistic hashes are not substituted in proof mode.","Correctness before compression.","Boundary enforced"),

("M432","Heuristic search","Seeded MCTS root","Use a declared pseudorandom seed for reproducible search estimates.","Scalable analysis mode with replayable randomness.","Implemented + tested"),
("M433","Heuristic search","UCT selection","Balance exploitation and exploration by visit-weighted upper confidence.","Tree policy only; no exactness claim.","Implemented"),
("M434","Heuristic search","Legal expansion","Expand only transitions accepted by the authoritative rules engine.","Heuristic search cannot bypass legality guards.","Implemented + tested"),
("M435","Heuristic search","Bounded rollout","Stop random playout after terminality or a declared ply budget.","Prevents unbounded heuristic work.","Implemented"),
("M436","Heuristic search","Area-evaluation rollout result","Convert rollout area margin to black win, white win, or draw value.","Declared approximate evaluator.","Implemented"),
("M437","Heuristic search","Visit-count move selection","Choose the most visited root child with deterministic tie behavior.","Stable user-facing hint.","Implemented + tested"),
("M438","Heuristic search","Child statistics report","Return move, visits, and estimated black win rate.","Inspectable estimate rather than opaque move.","Implemented"),
("M439","Heuristic search","Non-proof marker","Every MCTS result records exact=false.","Hard evidence boundary.","Implemented + tested"),

("M440","Project/runtime","Versioned rules record","Serialize size, komi, ko, suicide, and scoring as explicit project data.","Single source of rule truth.","Implemented + schema"),
("M441","Project/runtime","Move event record","Record color, move, captures, self-removal, guard status, hashes, and lineage label.","Proposal/commit replay.","Implemented + tested"),
("M442","Project/runtime","Replay executor","Apply an ordered move list and return final state plus ordered events.","Deterministic lineage reconstruction.","Implemented + tested"),
("M443","Project/runtime","Solve certificate","Serialize root state, exact result, metrics, table digest, and content hash.","Proof-oriented evidence artifact.","Implemented + tested"),
("M444","Project/runtime","Certificate hash verifier","Recompute canonical JSON SHA-256 after removing the certificate hash field.","Detects tampering.","Implemented + tested"),
("M445","Project/runtime","Deterministic rerun verifier","Re-solve the root state and compare value plus table digest.","Executable verification.","Implemented + tested"),
("M446","Project/runtime","SGF single-variation adapter","Import/export board size, komi, moves, and passes for one SGF variation.","Downstream interchange, not state authority.","Implemented + tested"),
("M447","Project/runtime","Self-contained browser board","Generate one HTML file with board, legal moves, score, undo, pass, and seeded hint.","No CDN or network asset.","Implemented + tested"),
("M448","Project/runtime","Command-line workflow","Expose solve, MCTS, score, web build, and certificate verification commands.","Reproducible authoring and validation.","Implemented"),
("M449","Project/runtime","Validation and manifest gate","Compile, test, solve fixtures, validate certificate, build package, and hash final files.","Release evidence boundary.","Implemented in validation"),
]

assert len(rows) == 60
assert [row[0] for row in rows] == [f"M{i}" for i in range(390, 450)]

fields = ["ID", "Domain", "Mechanism", "Normalized technical definition", "UGTS integration", "Validation"]
csv_path = ROOT / "spec" / "go_mechanisms_M390_M449.csv"
json_path = ROOT / "spec" / "go_mechanisms_M390_M449.json"
with csv_path.open("w", newline="", encoding="utf-8") as handle:
    writer = csv.writer(handle)
    writer.writerow(fields)
    writer.writerows(rows)
records = [dict(zip(fields, row)) for row in rows]
json_path.write_text(json.dumps(records, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print(csv_path)
print(json_path)
