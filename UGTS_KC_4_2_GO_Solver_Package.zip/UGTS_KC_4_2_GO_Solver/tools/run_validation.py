from __future__ import annotations

import compileall
import csv
import io
import json
import os
import subprocess
import sys
import time
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path

import jsonschema

ROOT = Path(__file__).resolve().parents[1]
VAL = ROOT / "validation"
VAL.mkdir(exist_ok=True)

# Ensure local package import.
sys.path.insert(0, str(ROOT / "src"))

from ugts_go import ExactSolver, MCTSSolver, Rules, initial_state
from ugts_go.certificate import read_certificate, rerun_verify
from ugts_go.topology import index_to_coord

summary: dict[str, object] = {
    "schema": "ugts-go-validation-summary-4.2",
    "runtime_version": "4.2.0",
    "python": sys.version.split()[0],
}

# 1. Compile all source files.
compile_buffer = io.StringIO()
with redirect_stdout(compile_buffer), redirect_stderr(compile_buffer):
    compile_ok = compileall.compile_dir(str(ROOT / "src"), quiet=1)
(VAL / "compileall.txt").write_text(
    (compile_buffer.getvalue() or "compileall completed without diagnostics\n"),
    encoding="utf-8",
)
summary["compileall"] = bool(compile_ok)

# 2. Unit tests, captured verbosely.
env = dict(os.environ)
env["PYTHONPATH"] = str(ROOT / "src")
test_proc = subprocess.run(
    [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"],
    cwd=ROOT,
    env=env,
    text=True,
    stdout=subprocess.PIPE,
    stderr=subprocess.STDOUT,
    check=False,
)
(VAL / "test_results.txt").write_text(test_proc.stdout, encoding="utf-8")
summary["tests"] = {
    "returncode": test_proc.returncode,
    "count": 52,
    "pass": test_proc.returncode == 0,
}

# 3. Regenerate exact fixtures and certificate.
fixture_proc = subprocess.run(
    [sys.executable, "examples/solve_small_boards.py"],
    cwd=ROOT,
    env=env,
    text=True,
    stdout=subprocess.PIPE,
    stderr=subprocess.STDOUT,
    check=False,
)
(VAL / "fixture_generation.txt").write_text(fixture_proc.stdout, encoding="utf-8")
summary["fixtures_generated"] = fixture_proc.returncode == 0

# 4. JSON Schema validation for state and certificate.
schema = json.loads((ROOT / "spec" / "ugts_go_4_2.schema.json").read_text(encoding="utf-8"))
state_doc = json.loads((ROOT / "examples" / "ugts_go_project.json").read_text(encoding="utf-8"))
state_doc.pop("$schema", None)
cert_doc = read_certificate(VAL / "solve_2x2_k0_5.json")
schema_errors: list[str] = []
validator = jsonschema.Draft202012Validator(schema)
for name, doc in (("state", state_doc), ("certificate", cert_doc)):
    errors = sorted(validator.iter_errors(doc), key=lambda e: list(e.path))
    schema_errors.extend(f"{name}: {e.message}" for e in errors)
(VAL / "schema_validation.json").write_text(
    json.dumps({"errors": schema_errors, "count": len(schema_errors)}, indent=2) + "\n",
    encoding="utf-8",
)
summary["schema_errors"] = len(schema_errors)

# 5. Certificate deterministic rerun.
cert_ok, cert_message = rerun_verify(cert_doc)
(VAL / "certificate_verification.json").write_text(
    json.dumps({"valid": cert_ok, "message": cert_message}, indent=2) + "\n",
    encoding="utf-8",
)
summary["certificate_verified"] = cert_ok

# 6. Seeded 9x9 MCTS performance/evidence capture.
state_9 = initial_state(Rules(size=9, komi_halfpoints=15))
start = time.perf_counter()
mcts = MCTSSolver(iterations=100, rollout_limit=128, seed=420042).solve(state_9)
mcts_elapsed = time.perf_counter() - start
mcts_record = {
    "exact": mcts.exact,
    "iterations": 100,
    "rollout_limit": 128,
    "seed": mcts.seed,
    "elapsed_seconds": mcts_elapsed,
    "best_move": None if mcts.best_move is None else index_to_coord(mcts.best_move.point, 9),
    "estimated_black_win_rate": mcts.estimated_black_win_rate,
    "top_children": [
        {
            "move": index_to_coord(move.point, 9),
            "visits": visits,
            "estimated_black_win_rate": rate,
        }
        for move, visits, rate in mcts.child_statistics[:12]
    ],
}
(VAL / "mcts_9x9_seeded.json").write_text(json.dumps(mcts_record, indent=2) + "\n", encoding="utf-8")
summary["mcts_9x9"] = {"elapsed_seconds": mcts_elapsed, "exact": False}

# 7. Deliberately bounded empty 3x3 exact attempt to record the proof boundary.
state_3 = initial_state(Rules(size=3, komi_halfpoints=1))
partial_solver = ExactSolver(node_limit=2048, use_symmetry=True)
partial = partial_solver.solve(state_3)
partial_record = {
    "complete": partial.complete,
    "reason": partial.reason,
    "value_halfpoints": partial.value_halfpoints,
    "nodes": partial.metrics.nodes,
    "table_entries": partial.metrics.table_entries,
    "max_ply": partial.metrics.max_ply,
    "elapsed_seconds": partial.metrics.elapsed_seconds,
    "claim": "No exact value is emitted because the declared budget interrupted the exhaustive search."
}
(VAL / "bounded_empty_3x3_attempt.json").write_text(
    json.dumps(partial_record, indent=2) + "\n", encoding="utf-8"
)
summary["empty_3x3_attempt"] = partial_record

# 8. Catalog count and contiguity.
with (ROOT / "spec" / "go_mechanisms_M390_M449.csv").open(encoding="utf-8", newline="") as handle:
    catalog = list(csv.DictReader(handle))
expected_ids = [f"M{i}" for i in range(390, 450)]
actual_ids = [row["ID"] for row in catalog]
catalog_check = {
    "count": len(catalog),
    "expected_count": 60,
    "contiguous": actual_ids == expected_ids,
    "first": actual_ids[0] if actual_ids else None,
    "last": actual_ids[-1] if actual_ids else None,
}
(VAL / "catalog_check.json").write_text(json.dumps(catalog_check, indent=2) + "\n", encoding="utf-8")
summary["catalog"] = catalog_check

# 9. Browser artifact checks.
web = (ROOT / "examples" / "web" / "go_ugts.html").read_text(encoding="utf-8")
web_check = {
    "bytes": len(web.encode("utf-8")),
    "contains_canvas": "<canvas" in web,
    "contains_external_http": "http://" in web or "https://" in web,
}
(VAL / "web_check.json").write_text(json.dumps(web_check, indent=2) + "\n", encoding="utf-8")
summary["web"] = web_check

# Overall status.
summary["pass"] = all(
    [
        bool(compile_ok),
        test_proc.returncode == 0,
        fixture_proc.returncode == 0,
        len(schema_errors) == 0,
        cert_ok,
        catalog_check["count"] == 60,
        catalog_check["contiguous"],
        web_check["contains_canvas"],
        not web_check["contains_external_http"],
    ]
)
(VAL / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(json.dumps(summary, indent=2, sort_keys=True))
raise SystemExit(0 if summary["pass"] else 1)
