# UGTS-KC 3.9.2 — K-Kij-T / Grove

Native Android 3D runtime.

Focus: Mali-G720 MC7 / POCO X7 Pro 12 GB juiciness with general Android fallback tiers.
