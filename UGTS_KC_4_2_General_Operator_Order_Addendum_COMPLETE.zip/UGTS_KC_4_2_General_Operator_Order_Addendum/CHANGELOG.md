# Changelog

## 4.2.0 - 28 August 2026

- Added the General Operator and Order Addendum (GOOA).
- Added 256 catalog entries, M630-M885, across 16 mathematical and substrate domains.
- Added content-addressed `OperatorSpec` and order-profile contracts.
- Added three precedence profiles and a 15-phase canonical evaluation schedule.
- Added a dependency-free Python reference runtime for canonicalization, safe expression evaluation, interval arithmetic, linear algebra, numerical calculus, statistics, graph queries, deterministic proposal commit and replay.
- Added a Draft 2020-12 JSON Schema and literal content-addressed example project.
- Added tests, deterministic demonstration output, diagrams, validation captures and SHA-256 manifests.
- Preserved the canonical authority chain: support -> compatibility -> guard -> verified proposal -> deterministic commit -> transition -> lineage.
