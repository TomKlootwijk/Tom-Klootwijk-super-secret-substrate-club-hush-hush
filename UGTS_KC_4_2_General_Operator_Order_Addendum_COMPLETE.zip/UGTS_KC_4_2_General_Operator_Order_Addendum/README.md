# UGTS-KC 4.2 - General Operator and Order Addendum

This release adds a general typed operator registry and explicit ordering calculus to the UGTS project line. It defines how mathematical operations are named, typed, grouped, composed, evaluated, certified, reduced, scheduled, committed and replayed without replacing the retained query-first event authority.

## What is included

- `report/` - PDF and editable DOCX release report.
- `spec/` - 256-entry M630-M885 catalog in JSON/CSV, JSON Schema, precedence profiles, phase schedule, formal definition and source register.
- `src/ugts_kc42/` - dependency-free Python reference runtime.
- `examples/` - literal project and deterministic demo output.
- `tests/` - executable unit tests.
- `docs/` - API, order profiles, migration, boundaries and reproduction notes.
- `validation/` - captured test/schema/catalog/demo/build evidence.
- `manifest/` and `checksums/` - final file inventory and SHA-256 release list.

## Design decision

The finite addendum does **not** claim to enumerate every future mathematical operator. Instead it provides:

1. a general `OperatorSpec` record;
2. operator-family generators and extension namespaces;
3. explicit syntax, precedence, associativity, dependency, phase, reduction and event-order contracts;
4. exactness, error, capability, effect and evidence metadata;
5. a canonical UGTS handoff for state-changing results.

## Quick start

```bash
cd UGTS_KC_4_2_General_Operator_Order_Addendum
PYTHONPATH=src python -m ugts_kc42 info
PYTHONPATH=src python -m ugts_kc42 catalog
PYTHONPATH=src python -m ugts_kc42 eval "2 + 3 * 4 ** 2" --trace
PYTHONPATH=src python -m ugts_kc42 validate examples/general_operator_order_project.json
PYTHONPATH=src python -m ugts_kc42 demo examples/demo_output.json
PYTHONPATH=src python -m unittest discover -s tests -v
```

## Canonical shorthand

```text
literal / operator definition
-> parse and explicit grouping
-> normalize units, symbols and profiles
-> resolve references and verify content hashes
-> type, shape, domain and effect checking
-> lawful rewrite under declared scopes
-> dependency, composition and reduction planning
-> evaluate under a bounded numeric/symbolic profile
-> certify exactness, residual, interval and budget status
-> local support -> compatibility -> guard classification
-> verified proposal -> deterministic commit
-> transition -> lineage/checkpoint/replay
-> optional projection, export or device adapter
```

See `NOTICE.md` and `docs/BOUNDARIES.md` before promoting any mathematical, physical, performance or legal claim.
