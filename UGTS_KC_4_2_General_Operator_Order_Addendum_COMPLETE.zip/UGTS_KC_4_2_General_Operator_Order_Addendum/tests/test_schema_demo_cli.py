from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from jsonschema import Draft202012Validator

from ugts_kc42.canonical import sha256_digest, verify_record_hash
from ugts_kc42.demo import run_demo, write_demo
from ugts_kc42.validation import load_and_validate_project, validate_default_catalog, validate_profiles, validate_project

ROOT = Path(__file__).resolve().parents[1]


class SchemaProjectTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.schema=json.loads((ROOT/'spec/ugts_kc_4_2_general_operator_order.schema.json').read_text())
        cls.project=json.loads((ROOT/'examples/general_operator_order_project.json').read_text())
    def test_001_schema_valid(self): self.assertEqual(list(Draft202012Validator(self.schema).iter_errors(self.project)), [])
    def test_002_runtime_validation(self): self.assertTrue(validate_project(self.project)["valid"])
    def test_003_definition_hashes(self): self.assertTrue(all(verify_record_hash(d) for d in self.project["definitions"]))
    def test_004_project_content_hash(self):
        expected=sha256_digest({k:v for k,v in self.project.items() if k!='content_hash'}); self.assertEqual(self.project["content_hash"],expected)
    def test_005_definition_count(self): self.assertEqual(validate_project(self.project)["definition_count"],12)
    def test_006_expression_count(self): self.assertEqual(validate_project(self.project)["expression_count"],4)
    def test_007_unknown_dependency(self):
        p=json.loads(json.dumps(self.project)); p["definitions"][0]["dependencies"]=["missing"]
        self.assertFalse(validate_project(p)["valid"])
    def test_008_bad_hash(self):
        p=json.loads(json.dumps(self.project)); p["definitions"][0]["content_hash"]="sha256:"+"0"*64
        self.assertFalse(validate_project(p)["valid"])
    def test_009_cycle(self):
        p=json.loads(json.dumps(self.project)); p["definitions"][0]["dependencies"]=[p["definitions"][-1]["id"]]; p["definitions"][-1]["dependencies"]=[p["definitions"][0]["id"]]
        self.assertFalse(validate_project(p)["valid"])
    def test_010_default_catalog_validation(self): self.assertTrue(validate_default_catalog()["valid"])
    def test_011_profile_validation(self): self.assertTrue(validate_profiles()["valid"])
    def test_012_load_validation(self): self.assertTrue(load_and_validate_project(ROOT/'examples/general_operator_order_project.json')["valid"])


class DemoTests(unittest.TestCase):
    def test_020_demo_schema(self): self.assertEqual(run_demo()["schema"],"ugts-kc-general-operator-demo-4.2")
    def test_021_demo_catalog(self): self.assertEqual(run_demo()["catalog"]["records"],256)
    def test_022_demo_expression(self): self.assertEqual(run_demo()["expression"]["result"],5.0)
    def test_023_demo_replay(self):
        d=run_demo(); self.assertEqual(d["events"]["final_hash"],d["events"]["replay_hash"])
    def test_024_demo_event_winner(self): self.assertEqual(run_demo()["events"]["accepted"][0]["proposal_id"],"p-high")
    def test_025_demo_root(self): self.assertAlmostEqual(run_demo()["calculus"]["sqrt2_root"]["root"],2**.5,places=10)
    def test_026_demo_phase_count(self): self.assertEqual(len(run_demo()["phase_ids"]),15)
    def test_027_write_demo(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'demo.json'; result=write_demo(path); self.assertTrue(path.exists()); self.assertEqual(json.loads(path.read_text())["content_hash"],result["content_hash"])


class CLITests(unittest.TestCase):
    def run_cli(self,*args):
        env=dict(**__import__('os').environ); env['PYTHONPATH']=str(ROOT/'src')
        return subprocess.run([sys.executable,'-m','ugts_kc42',*args],cwd=ROOT,env=env,capture_output=True,text=True,check=False)
    def test_030_info(self):
        r=self.run_cli('info'); self.assertEqual(r.returncode,0); self.assertEqual(json.loads(r.stdout)["operator_records"],256)
    def test_031_catalog(self):
        r=self.run_cli('catalog'); self.assertEqual(r.returncode,0); self.assertIn('Schema and typing: 16',r.stdout)
    def test_032_catalog_search(self):
        r=self.run_cli('catalog','--search','gradient','--json'); self.assertEqual(r.returncode,0); self.assertGreater(len(json.loads(r.stdout)),0)
    def test_033_eval(self):
        r=self.run_cli('eval','2 + 3 * 4'); self.assertEqual(r.returncode,0); self.assertEqual(json.loads(r.stdout),14)
    def test_034_eval_trace(self):
        r=self.run_cli('eval','2 + 3 * 4','--trace'); self.assertEqual(r.returncode,0); self.assertEqual(json.loads(r.stdout)["result"],14)
    def test_035_validate(self):
        r=self.run_cli('validate','examples/general_operator_order_project.json'); self.assertEqual(r.returncode,0); self.assertTrue(json.loads(r.stdout)["project"]["valid"])
    def test_036_hash(self):
        r=self.run_cli('hash','hello'); self.assertEqual(r.returncode,0); self.assertTrue(r.stdout.strip().startswith('sha256:'))
    def test_037_demo(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'demo.json'; r=self.run_cli('demo',str(path)); self.assertEqual(r.returncode,0); self.assertTrue(path.exists())


if __name__ == "__main__": unittest.main()
