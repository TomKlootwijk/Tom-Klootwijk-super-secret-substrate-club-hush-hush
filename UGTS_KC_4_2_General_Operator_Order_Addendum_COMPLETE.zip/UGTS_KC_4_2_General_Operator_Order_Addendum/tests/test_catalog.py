from __future__ import annotations

import json
import unittest
from importlib.resources import files

from ugts_kc42.canonical import verify_record_hash
from ugts_kc42.catalog import OperatorCatalog


class CatalogSummaryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.catalog = OperatorCatalog.load_default()

    def test_001_catalog_size(self) -> None:
        self.assertEqual(len(self.catalog.records), 256)

    def test_002_domain_count(self) -> None:
        self.assertEqual(len(self.catalog.domain_summary()), 16)
        self.assertEqual(set(self.catalog.domain_summary().values()), {16})

    def test_003_catalog_valid(self) -> None:
        self.assertEqual(self.catalog.validate(), [])

    def test_004_mechanism_range(self) -> None:
        self.assertEqual(self.catalog.records[0].mechanism_id, "M630")
        self.assertEqual(self.catalog.records[-1].mechanism_id, "M885")

    def test_005_unique_operator_ids(self) -> None:
        self.assertEqual(len(self.catalog.by_operator_id), 256)

    def test_006_unique_mechanism_ids(self) -> None:
        self.assertEqual(len(self.catalog.by_mechanism_id), 256)

    def test_007_status_partition(self) -> None:
        statuses = {r.status for r in self.catalog.records}
        self.assertEqual(statuses, {"implemented_reference", "specified_contract"})
        self.assertEqual(sum(r.status == "implemented_reference" for r in self.catalog.records), 194)
        self.assertEqual(sum(r.status == "specified_contract" for r in self.catalog.records), 62)

    def test_008_search(self) -> None:
        hits = self.catalog.search("gradient")
        self.assertGreaterEqual(len(hits), 5)
        self.assertTrue(any("gradient" in (h.name + h.definition).lower() for h in hits))

    def test_009_no_empty_required_text(self) -> None:
        for row in self.catalog.records:
            self.assertTrue(row.name.strip())
            self.assertTrue(row.signature.strip())
            self.assertTrue(row.definition.strip())
            self.assertTrue(row.domain.strip())

    def test_010_metadata(self) -> None:
        self.assertEqual(self.catalog.metadata["version"], "4.2.0")
        self.assertEqual(self.catalog.metadata["mechanism_range"], "M630-M885")
        self.assertIn("finite", self.catalog.metadata["evidence_boundary"].lower())

    def test_011_bundled_json_parse(self) -> None:
        path = files("ugts_kc42.data").joinpath("operator_catalog.json")
        obj = json.loads(path.read_text(encoding="utf-8"))
        self.assertEqual(obj["record_count"], 256)

    def test_012_domain_indices(self) -> None:
        groups = {}
        for rec in self.catalog.records:
            groups.setdefault(rec.raw["domain_index"], []).append(rec)
        self.assertEqual(sorted(groups), list(range(1, 17)))
        self.assertTrue(all(len(rows) == 16 for rows in groups.values()))


def _make_record_test(index: int):
    def test(self: unittest.TestCase) -> None:
        catalog = OperatorCatalog.load_default()
        rec = catalog.records[index]
        expected = f"M{630 + index}"
        self.assertEqual(rec.mechanism_id, expected)
        self.assertTrue(rec.operator_id.startswith("ugts42."))
        self.assertTrue(verify_record_hash(rec.raw))
        self.assertEqual(rec.raw["version"], "4.2.0")
        self.assertIn(rec.raw["arity"], {"family", "nullary", "unary", "binary", "ternary", "variadic", "higher_order"})
        self.assertIsInstance(rec.raw["source_basis"], list)
        self.assertGreaterEqual(len(rec.raw["source_basis"]), 1)
    return test


class CatalogRecordTests(unittest.TestCase):
    pass


for _index in range(256):
    setattr(CatalogRecordTests, f"test_record_{630 + _index:03d}", _make_record_test(_index))


if __name__ == "__main__":
    unittest.main()
