from __future__ import annotations

import copy
import unittest

from ugts_kc42.canonical import sha256_digest
from ugts_kc42.events import Proposal, commit_proposals, replay
from ugts_kc42.graph import normalize_graph, reachability, shortest_path, topological_sort


class GraphTests(unittest.TestCase):
    def test_001_normalize_mapping(self):
        self.assertEqual(normalize_graph({"a":{"b":2}}), {"a":[("b",2.0)]})
    def test_002_normalize_list(self):
        self.assertEqual(normalize_graph({"a":["b",("c",2)]}), {"a":[("b",1.0),("c",2.0)]})
    def test_003_reachability(self):
        self.assertEqual(reachability({"a":["b","c"],"b":["d"],"c":[],"d":[]},"a"), ["a","b","c","d"])
    def test_004_shortest_path(self):
        r=shortest_path({"a":{"b":1,"c":4},"b":{"c":1},"c":{}},"a","c"); self.assertEqual(r,{"status":"ok","path":["a","b","c"],"cost":2.0})
    def test_005_unreachable(self):
        self.assertEqual(shortest_path({"a":[],"b":[]},"a","b")["status"],"unreachable")
    def test_006_negative_rejected(self):
        with self.assertRaises(ValueError): shortest_path({"a":{"b":-1},"b":{}},"a","b")
    def test_007_topological_sort(self):
        self.assertEqual(topological_sort({"a":[],"b":["a"],"c":["b"]}), ["a","b","c"])
    def test_008_topological_tie(self):
        self.assertEqual(topological_sort({"b":[],"a":[]}), ["a","b"])
    def test_009_topological_priority(self):
        self.assertEqual(topological_sort({"a":[],"b":[]},{"a":2,"b":1}), ["b","a"])
    def test_010_cycle_rejected(self):
        with self.assertRaises(ValueError): topological_sort({"a":["b"],"b":["a"]})


class EventTests(unittest.TestCase):
    def setUp(self): self.initial={"world":{"value":0,"mode":"idle"}}
    def test_020_accept(self):
        r=commit_proposals(self.initial,[Proposal("p",1,"set","world",{"world.value":3})]); self.assertEqual(r.state["world"]["value"],3); self.assertEqual(len(r.accepted),1)
    def test_021_initial_not_mutated(self):
        original=copy.deepcopy(self.initial); commit_proposals(self.initial,[Proposal("p",1,"set","world",{"world.value":3})]); self.assertEqual(self.initial,original)
    def test_022_priority_order(self):
        ps=[Proposal("low",1,"set","world",{"world.value":1},priority=1),Proposal("high",1,"set","world",{"world.value":2},priority=5)]
        r=commit_proposals(self.initial,ps); self.assertEqual(r.state["world"]["value"],2); self.assertEqual(r.accepted[0]["proposal_id"],"high")
    def test_023_conflict_rejected(self):
        ps=[Proposal("a",1,"set","world",{"world.value":1},priority=2),Proposal("b",1,"set","world",{"world.value":2},priority=1)]
        r=commit_proposals(self.initial,ps); self.assertEqual(r.rejected[0]["reasons"],["patch_conflict"])
    def test_024_nonconflicting_same_time(self):
        ps=[Proposal("a",1,"set","world",{"world.value":1}),Proposal("b",1,"mode","world",{"world.mode":"active"})]
        r=commit_proposals(self.initial,ps); self.assertEqual(len(r.accepted),2); self.assertEqual(r.state["world"],{"value":1,"mode":"active"})
    def test_025_support_reject(self):
        r=commit_proposals(self.initial,[Proposal("p",1,"set","world",{"world.value":3},support_ok=False)]); self.assertEqual(r.rejected[0]["reasons"],["outside_support"])
    def test_026_compatibility_reject(self):
        r=commit_proposals(self.initial,[Proposal("p",1,"set","world",{"world.value":3},compatibility_ok=False)]); self.assertEqual(r.rejected[0]["reasons"],["incompatible"])
    def test_027_guard_reject(self):
        r=commit_proposals(self.initial,[Proposal("p",1,"set","world",{"world.value":3},guard_status="ambiguous")]); self.assertEqual(r.rejected[0]["reasons"],["guard_ambiguous"])
    def test_028_confidence_reject(self):
        r=commit_proposals(self.initial,[Proposal("p",1,"set","world",{"world.value":3},confidence=.2,confidence_floor=.5)]); self.assertEqual(r.rejected[0]["reasons"],["confidence_below_floor"])
    def test_029_error_reject(self):
        r=commit_proposals(self.initial,[Proposal("p",1,"set","world",{"world.value":3},numeric_error=.2,event_margin=.1)]); self.assertEqual(r.rejected[0]["reasons"],["numeric_error_exceeds_margin"])
    def test_030_nested_patch_created(self):
        r=commit_proposals({},[Proposal("p",1,"set","x",{"a.b.c":3})]); self.assertEqual(r.state,{"a":{"b":{"c":3}}})
    def test_031_bad_patch_path(self):
        with self.assertRaises(ValueError): commit_proposals({"a":1},[Proposal("p",1,"set","x",{"a.b":3})])
    def test_032_hash_chain(self):
        r=commit_proposals(self.initial,[Proposal("p",1,"set","world",{"world.value":3})]); self.assertEqual(r.accepted[0]["pre_hash"],sha256_digest(self.initial)); self.assertEqual(r.accepted[0]["post_hash"],sha256_digest(r.state))
    def test_033_replay(self):
        r=commit_proposals(self.initial,[Proposal("p",1,"set","world",{"world.value":3})]); self.assertEqual(replay(self.initial,r.accepted),r.state)
    def test_034_replay_divergence_pre(self):
        r=commit_proposals(self.initial,[Proposal("p",1,"set","world",{"world.value":3})]); bad=copy.deepcopy(r.accepted); bad[0]["pre_hash"]="sha256:"+"0"*64
        with self.assertRaises(ValueError): replay(self.initial,bad)
    def test_035_replay_divergence_post(self):
        r=commit_proposals(self.initial,[Proposal("p",1,"set","world",{"world.value":3})]); bad=copy.deepcopy(r.accepted); bad[0]["post_hash"]="sha256:"+"0"*64
        with self.assertRaises(ValueError): replay(self.initial,bad)
    def test_036_sequence_monotonic(self):
        ps=[Proposal("a",1,"set","world",{"world.value":1}),Proposal("b",2,"mode","world",{"world.mode":"active"})]
        r=commit_proposals(self.initial,ps); self.assertEqual([e["sequence"] for e in r.accepted],[1,2])
    def test_037_custom_guard_status(self):
        p=Proposal("p",1,"set","world",{"world.value":3},guard_status="tangency")
        r=commit_proposals(self.initial,[p],accepted_guard_statuses={"tangency"}); self.assertEqual(len(r.accepted),1)


if __name__ == "__main__": unittest.main()
