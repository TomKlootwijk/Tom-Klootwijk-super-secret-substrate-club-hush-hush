from __future__ import annotations

import math
import unittest

from ugts_kc42.evaluator import EvaluationError, SafeEvaluator, evaluate
from ugts_kc42.order import canonical_expression, expression_hash, load_evaluation_phases, load_precedence_profiles


class EvaluatorTests(unittest.TestCase):
    def test_001_precedence(self):
        self.assertEqual(evaluate("2 + 3 * 4 ** 2"), 50)

    def test_002_power_right_associative(self):
        self.assertEqual(evaluate("2 ** 3 ** 2"), 512)

    def test_003_unary_power_python_profile(self):
        self.assertEqual(evaluate("-3 ** 2"), -9)

    def test_004_parentheses(self):
        self.assertEqual(evaluate("(-3) ** 2"), 9)

    def test_005_boolean(self):
        self.assertTrue(evaluate("True and (False or True)"))

    def test_006_boolean_short_circuit(self):
        ev = SafeEvaluator()
        self.assertFalse(ev.evaluate("False and unknown"))

    def test_007_comparison_chain(self):
        self.assertTrue(evaluate("1 < 2 <= 2 < 5"))
        self.assertFalse(evaluate("1 < 2 > 3"))

    def test_008_conditional(self):
        self.assertEqual(evaluate("10 if 2 < 3 else 20"), 10)

    def test_009_lists_tuples_sets(self):
        self.assertEqual(evaluate("[1,2,3][1]"), 2)
        self.assertEqual(evaluate("(1,2,3)[0:2]"), (1, 2))
        self.assertEqual(evaluate("len({1,2,2})"), 2)

    def test_010_dict(self):
        self.assertEqual(evaluate("{'a': 1, 'b': 2}['b']"), 2)

    def test_011_math_functions(self):
        self.assertAlmostEqual(evaluate("sin(pi/2) + cos(0)"), 2)
        self.assertEqual(evaluate("gcd(12,18)"), 6)
        self.assertEqual(evaluate("comb(5,2)"), 10)

    def test_012_vector_functions(self):
        self.assertEqual(evaluate("dot([1,2,3],[4,5,6])"), 32)
        self.assertEqual(evaluate("cross([1,0,0],[0,1,0])"), [0,0,1])

    def test_013_matrix_functions(self):
        self.assertEqual(evaluate("det([[1,2],[3,4]])"), -2)
        self.assertEqual(evaluate("matmul([[1,2]], [[3],[4]])"), [[11]])

    def test_014_statistics(self):
        self.assertEqual(evaluate("mean([1,2,3])"), 2)
        self.assertEqual(evaluate("variance([1,2,3])"), 2/3)
        self.assertEqual(evaluate("entropy([0.5,0.5])"), 1)

    def test_015_sets(self):
        self.assertEqual(evaluate("union({1,2},{2,3})"), {1,2,3})
        self.assertEqual(evaluate("intersection({1,2},{2,3})"), {2})

    def test_016_variables(self):
        self.assertEqual(SafeEvaluator({"x": 7}).evaluate("x * 3"), 21)

    def test_017_unknown_name(self):
        with self.assertRaises(EvaluationError):
            evaluate("unknown + 1")

    def test_018_unknown_function(self):
        with self.assertRaises(EvaluationError):
            evaluate("open('x')")

    def test_019_attribute_access_rejected(self):
        with self.assertRaises(EvaluationError):
            evaluate("(1).__class__")

    def test_020_lambda_rejected(self):
        with self.assertRaises(EvaluationError):
            evaluate("(lambda x: x)(2)")

    def test_021_comprehension_rejected(self):
        with self.assertRaises(EvaluationError):
            evaluate("[x for x in [1,2]]")

    def test_022_trace_sequence(self):
        record = SafeEvaluator().result_record("2 + 3 * 4")
        seq = [row["sequence"] for row in record["trace"]]
        self.assertEqual(seq, list(range(1, len(seq)+1)))
        self.assertEqual(record["result"], 14)

    def test_023_hash_stability(self):
        self.assertEqual(expression_hash("2 + 3"), expression_hash("2+3"))

    def test_024_canonical_ast(self):
        ast = canonical_expression("2 + 3 * 4")
        self.assertEqual(ast["kind"], "expression")
        self.assertEqual(ast["body"]["operator"], "Add")

    def test_025_profiles(self):
        profiles = load_precedence_profiles()
        self.assertEqual(len(profiles["profiles"]), 3)
        ids = {p["id"] for p in profiles["profiles"]}
        self.assertIn("standard-math-4.2", ids)

    def test_026_phases(self):
        phases = load_evaluation_phases()["phases"]
        self.assertEqual(len(phases), 15)
        self.assertEqual(phases[0]["id"], "parse")
        self.assertEqual(phases[-1]["id"], "projection")

    def test_027_seeded_determinism(self):
        self.assertEqual(evaluate("seeded_samples(42, 5)"), evaluate("seeded_samples(42, 5)"))

    def test_028_approx(self):
        self.assertTrue(evaluate("approx(sqrt(2)**2, 2)"))

    def test_029_floor_div_mod_bitops(self):
        self.assertEqual(evaluate("17 // 5"), 3)
        self.assertEqual(evaluate("17 % 5"), 2)
        self.assertEqual(evaluate("(1 << 4) | 3"), 19)

    def test_030_invalid_operation_wrapped(self):
        with self.assertRaises(EvaluationError):
            evaluate("1 / 0")


if __name__ == "__main__":
    unittest.main()
