from __future__ import annotations

import math
import unittest

from ugts_kc42.linalg import cross, determinant, dot, kronecker, matmul, norm, normalize, rank, scalar_mul, solve, trace, transpose, vector_add
from ugts_kc42.numeric import bisection, clamp, convolution, correlation, covariance, derivative, entropy, gradient, gradient_descent, hessian, integrate_simpson, jacobian, kl_divergence, mean, mutual_information, seeded_samples, sign, variance


class LinearAlgebraTests(unittest.TestCase):
    def test_001_vector_add(self): self.assertEqual(vector_add([1,2],[3,4]), [4,6])
    def test_002_vector_add_mismatch(self):
        with self.assertRaises(ValueError): vector_add([1],[1,2])
    def test_003_scalar_mul(self): self.assertEqual(scalar_mul(3,[1,2]), [3,6])
    def test_004_dot(self): self.assertEqual(dot([1,2,3],[4,5,6]), 32)
    def test_005_complex_dot(self): self.assertEqual(dot([1+1j],[1+1j]), 2)
    def test_006_norm(self): self.assertEqual(norm([3,4]), 5)
    def test_007_inf_norm(self): self.assertEqual(norm([-3,2], math.inf), 3)
    def test_008_normalize(self):
        v=normalize([3,4]); self.assertAlmostEqual(v[0], .6); self.assertAlmostEqual(v[1], .8)
    def test_009_normalize_zero(self):
        with self.assertRaises(ValueError): normalize([0,0])
    def test_010_cross(self): self.assertEqual(cross([1,0,0],[0,1,0]), [0,0,1])
    def test_011_cross_bad(self):
        with self.assertRaises(ValueError): cross([1,0],[0,1])
    def test_012_transpose(self): self.assertEqual(transpose([[1,2],[3,4]]), [[1,3],[2,4]])
    def test_013_transpose_ragged(self):
        with self.assertRaises(ValueError): transpose([[1],[2,3]])
    def test_014_matmul(self): self.assertEqual(matmul([[1,2]], [[3],[4]]), [[11]])
    def test_015_matmul_bad(self):
        with self.assertRaises(ValueError): matmul([[1,2]], [[1,2]])
    def test_016_trace(self): self.assertEqual(trace([[1,2],[3,4]]), 5)
    def test_017_trace_bad(self):
        with self.assertRaises(ValueError): trace([[1,2]])
    def test_018_determinant(self): self.assertEqual(determinant([[1,2],[3,4]]), -2)
    def test_019_det_identity(self): self.assertEqual(determinant([]), 1)
    def test_020_det_singular(self): self.assertEqual(determinant([[1,2],[2,4]]), 0)
    def test_021_solve(self):
        x=solve([[3,2],[1,4]],[7,5]); self.assertAlmostEqual(x[0],1.8); self.assertAlmostEqual(x[1],.8)
    def test_022_solve_singular(self):
        with self.assertRaises(ValueError): solve([[1,2],[2,4]],[1,2])
    def test_023_rank(self): self.assertEqual(rank([[1,2],[2,4]]), 1)
    def test_024_rank_zero(self): self.assertEqual(rank([]), 0)
    def test_025_kronecker(self): self.assertEqual(kronecker([[1,2]], [[3,4],[5,6]]), [[3,4,6,8],[5,6,10,12]])


class NumericTests(unittest.TestCase):
    def test_030_sign(self): self.assertEqual([sign(-2),sign(0),sign(3)], [-1,0,1])
    def test_031_clamp(self): self.assertEqual(clamp(9,0,5), 5)
    def test_032_clamp_bad(self):
        with self.assertRaises(ValueError): clamp(1,2,0)
    def test_033_mean(self): self.assertEqual(mean([1,2,3]), 2)
    def test_034_mean_empty(self):
        with self.assertRaises(ValueError): mean([])
    def test_035_variance_population(self): self.assertAlmostEqual(variance([1,2,3]), 2/3)
    def test_036_variance_sample(self): self.assertEqual(variance([1,2,3], sample=True), 1)
    def test_037_covariance(self): self.assertEqual(covariance([1,2,3],[2,4,6]), 4/3)
    def test_038_derivative(self): self.assertAlmostEqual(derivative(math.sin,0), 1, places=8)
    def test_039_gradient(self):
        g=gradient(lambda x:x[0]**2+3*x[1], [2,1]); self.assertAlmostEqual(g[0],4,places=6); self.assertAlmostEqual(g[1],3,places=6)
    def test_040_jacobian(self):
        j=jacobian(lambda x:[x[0]+x[1],x[0]*x[1]],[2,3]); self.assertAlmostEqual(j[0][0],1,places=6); self.assertAlmostEqual(j[1][1],2,places=6)
    def test_041_hessian(self):
        h=hessian(lambda x:x[0]**2+3*x[1]**2,[1,1]); self.assertAlmostEqual(h[0][0],2,places=4); self.assertAlmostEqual(h[1][1],6,places=4)
    def test_042_simpson(self): self.assertAlmostEqual(integrate_simpson(lambda x:x*x,0,1,200), 1/3, places=10)
    def test_043_bisection(self):
        r=bisection(lambda x:x*x-2,1,2); self.assertEqual(r["status"],"converged"); self.assertAlmostEqual(r["root"],math.sqrt(2),places=10)
    def test_044_bisection_bad(self):
        with self.assertRaises(ValueError): bisection(lambda x:x*x+1,-1,1)
    def test_045_gradient_descent(self):
        r=gradient_descent(lambda x:(x[0]-3)**2,[0],step=.2,max_iterations=200); self.assertEqual(r["status"],"converged"); self.assertAlmostEqual(r["point"][0],3,places=6)
    def test_046_convolution(self): self.assertEqual(convolution([1,2],[3,4]), [3,10,8])
    def test_047_correlation(self): self.assertEqual(correlation([1,2],[3,4]), [4,11,6])
    def test_048_entropy(self): self.assertEqual(entropy([.5,.5]),1)
    def test_049_entropy_bad_sum(self):
        with self.assertRaises(ValueError): entropy([.2,.2])
    def test_050_kl(self): self.assertEqual(kl_divergence([.5,.5],[.5,.5]),0)
    def test_051_kl_infinite(self): self.assertTrue(math.isinf(kl_divergence([1,0],[0,1])))
    def test_052_mutual_information(self): self.assertEqual(mutual_information([[.5,0],[0,.5]]),1)
    def test_053_seeded_samples(self): self.assertEqual(seeded_samples(1,4), seeded_samples(1,4))
    def test_054_seeded_count(self): self.assertEqual(len(seeded_samples(1,7)),7)


if __name__ == "__main__": unittest.main()
