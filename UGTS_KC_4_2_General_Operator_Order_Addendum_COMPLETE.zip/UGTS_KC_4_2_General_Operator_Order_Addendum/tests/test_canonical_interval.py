from __future__ import annotations

import math
import unittest
from dataclasses import dataclass
from fractions import Fraction

from ugts_kc42.canonical import CanonicalizationError, canonical_json, normalize, record_hash, sha256_digest, verify_record_hash
from ugts_kc42.interval import Interval


@dataclass
class Pair:
    a: int
    b: float


class CanonicalTests(unittest.TestCase):
    def test_001_key_order(self):
        self.assertEqual(canonical_json({"b": 2, "a": 1}), '{"a":1,"b":2}')

    def test_002_integral_float(self):
        self.assertEqual(canonical_json({"x": 1.0}), '{"x":1}')

    def test_003_negative_zero(self):
        self.assertEqual(canonical_json(-0.0), '0')

    def test_004_fraction(self):
        self.assertEqual(normalize(Fraction(2, 3)), {"$fraction": [2, 3]})

    def test_005_complex(self):
        self.assertEqual(normalize(2 + 3j), {"$complex": [2, 3]})

    def test_006_bytes(self):
        self.assertEqual(normalize(b"\x00\xff"), {"$bytes_hex": "00ff"})

    def test_007_tuple_tagged(self):
        self.assertEqual(normalize((1, 2)), {"$tuple": [1, 2]})

    def test_008_set_sorted(self):
        self.assertEqual(canonical_json({3, 1, 2}), '{"$set":[1,2,3]}')

    def test_009_dataclass(self):
        self.assertEqual(normalize(Pair(1, 2.0)), {"a": 1, "b": 2})

    def test_010_non_string_key_rejected(self):
        with self.assertRaises(CanonicalizationError):
            canonical_json({1: "x"})

    def test_011_nonfinite_rejected(self):
        with self.assertRaises(CanonicalizationError):
            canonical_json(math.inf)

    def test_012_stable_digest(self):
        self.assertEqual(sha256_digest({"a": 1, "b": 2}), sha256_digest({"b": 2.0, "a": 1}))

    def test_013_record_hash(self):
        record = {"id": "x", "value": 3}
        record["content_hash"] = record_hash(record)
        self.assertTrue(verify_record_hash(record))

    def test_014_record_hash_changes(self):
        record = {"id": "x", "value": 3}
        record["content_hash"] = record_hash(record)
        record["value"] = 4
        self.assertFalse(verify_record_hash(record))


class IntervalTests(unittest.TestCase):
    def test_020_point(self):
        self.assertEqual(Interval.point(3), Interval(3, 3))

    def test_021_bad_order(self):
        with self.assertRaises(ValueError):
            Interval(2, 1)

    def test_022_nonfinite(self):
        with self.assertRaises(ValueError):
            Interval(0, math.inf)

    def test_023_width_midpoint(self):
        i = Interval(2, 6)
        self.assertEqual(i.width, 4)
        self.assertEqual(i.midpoint, 4)

    def test_024_contains_overlap(self):
        self.assertTrue(Interval(1, 2).contains(1.5))
        self.assertTrue(Interval(1, 2).overlaps(Interval(2, 3)))
        self.assertFalse(Interval(1, 2).overlaps(Interval(3, 4)))

    def test_025_hull(self):
        self.assertEqual(Interval.hull([Interval(1, 2), Interval(-1, 3)]), Interval(-1, 3))

    def test_026_empty_hull(self):
        with self.assertRaises(ValueError):
            Interval.hull([])

    def test_027_addition(self):
        self.assertEqual(Interval(1, 2) + Interval(3, 5), Interval(4, 7))

    def test_028_subtraction(self):
        self.assertEqual(Interval(1, 2) - Interval(3, 5), Interval(-4, -1))

    def test_029_reverse_subtraction(self):
        self.assertEqual(5 - Interval(1, 2), Interval(3, 4))

    def test_030_multiplication(self):
        self.assertEqual(Interval(-2, 3) * Interval(4, 5), Interval(-10, 15))

    def test_031_division(self):
        self.assertEqual(Interval(2, 4) / Interval(2, 2), Interval(1, 2))

    def test_032_divide_zero_rejected(self):
        with self.assertRaises(ZeroDivisionError):
            Interval(1, 2) / Interval(-1, 1)

    def test_033_square_cross_zero(self):
        self.assertEqual(Interval(-2, 3).square(), Interval(0, 9))

    def test_034_square_positive(self):
        self.assertEqual(Interval(2, 3).square(), Interval(4, 9))

    def test_035_sqrt(self):
        self.assertEqual(Interval(4, 9).sqrt(), Interval(2, 3))

    def test_036_sqrt_negative_rejected(self):
        with self.assertRaises(ValueError):
            Interval(-1, 4).sqrt()

    def test_037_exp_log(self):
        original = Interval(1, 2)
        back = original.exp().log()
        self.assertAlmostEqual(back.lower, 1)
        self.assertAlmostEqual(back.upper, 2)

    def test_038_classify_negative(self):
        self.assertEqual(Interval(-2, -1).classify_zero(0.1), "negative")

    def test_039_classify_positive(self):
        self.assertEqual(Interval(1, 2).classify_zero(0.1), "positive")

    def test_040_classify_exact(self):
        self.assertEqual(Interval(0, 0).classify_zero(), "exact_zero")

    def test_041_classify_ambiguous(self):
        self.assertEqual(Interval(-0.1, 0.2).classify_zero(0.01), "ambiguous_guard")

    def test_042_canonical(self):
        self.assertEqual(Interval(1, 3).to_canonical(), {"lower": 1, "upper": 3, "width": 2})


if __name__ == "__main__":
    unittest.main()
