from __future__ import annotations

import compileall
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from ugts_kc42.catalog import OperatorCatalog
from ugts_kc42.demo import run_demo, write_demo
from ugts_kc42.evaluator import SafeEvaluator
from ugts_kc42.validation import validate_project, validate_profiles


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def run(cmd: list[str], env: dict[str, str] | None = None) -> subprocess.CompletedProcess[str]:
    return subprocess.run(cmd, cwd=ROOT, env=env, capture_output=True, text=True, check=False)


def main() -> int:
    validation = ROOT / "validation"
    validation.mkdir(exist_ok=True)
    checks: list[dict[str, object]] = []

    compile_ok = compileall.compile_dir(ROOT / "src", quiet=1, force=True)
    checks.append({"gate": "python_compile", "pass": compile_ok})

    env = dict(os.environ)
    env["PYTHONPATH"] = str(ROOT / "src")
    tests = run([sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"], env)
    (validation / "test_results.txt").write_text(tests.stdout + tests.stderr, encoding="utf-8")
    test_count = 0
    for line in (tests.stdout + tests.stderr).splitlines():
        if line.startswith("Ran ") and " tests" in line:
            try:
                test_count = int(line.split()[1])
            except Exception:
                pass
    checks.append({"gate": "automated_tests", "pass": tests.returncode == 0, "count": test_count})

    catalog = OperatorCatalog.load_default()
    catalog_errors = catalog.validate()
    checks.append({"gate": "catalog", "pass": not catalog_errors, "records": len(catalog.records), "domains": len(catalog.domain_summary()), "errors": catalog_errors})

    schema = json.loads((ROOT / "spec" / "ugts_kc_4_2_general_operator_order.schema.json").read_text(encoding="utf-8"))
    project = json.loads((ROOT / "examples" / "general_operator_order_project.json").read_text(encoding="utf-8"))
    schema_errors = [e.message for e in Draft202012Validator(schema).iter_errors(project)]
    project_check = validate_project(project)
    checks.append({"gate": "schema_and_project", "pass": not schema_errors and project_check["valid"], "schema_errors": schema_errors, "project": project_check})

    profile_check = validate_profiles()
    checks.append({"gate": "order_profiles", "pass": profile_check["valid"], **profile_check})

    evaluator = SafeEvaluator()
    expression_results = []
    for row in project["expressions"]:
        result = evaluator.evaluate(row["source"])
        ok = result == row["expected"]
        expression_results.append({"id": row["id"], "result": result, "expected": row["expected"], "pass": ok})
    checks.append({"gate": "example_expressions", "pass": all(x["pass"] for x in expression_results), "results": expression_results})

    demo1 = run_demo()
    demo2 = run_demo()
    write_demo(ROOT / "examples" / "demo_output.json")
    demo_ok = demo1["content_hash"] == demo2["content_hash"] and demo1["events"]["final_hash"] == demo1["events"]["replay_hash"]
    checks.append({"gate": "deterministic_demo", "pass": demo_ok, "content_hash": demo1["content_hash"], "final_hash": demo1["events"]["final_hash"], "replay_hash": demo1["events"]["replay_hash"], "accepted_events": len(demo1["events"]["accepted"]), "rejected_proposals": len(demo1["events"]["rejected"])})

    source_lines = 0
    for path in (ROOT / "src").rglob("*.py"):
        source_lines += len(path.read_text(encoding="utf-8").splitlines())
    catalog_bytes = (ROOT / "spec" / "operator_catalog_M630_M885.json").stat().st_size
    checks.append({"gate": "release_metrics", "pass": True, "python_source_lines": source_lines, "catalog_json_bytes": catalog_bytes})

    wheel = ROOT / "dist" / "ugts_kc42-4.2.0-py3-none-any.whl"
    sdist = ROOT / "dist" / "ugts_kc42-4.2.0.tar.gz"
    checks.append({
        "gate": "distributions",
        "pass": wheel.exists() and sdist.exists() and wheel.stat().st_size > 0 and sdist.stat().st_size > 0,
        "wheel_bytes": wheel.stat().st_size if wheel.exists() else 0,
        "sdist_bytes": sdist.stat().st_size if sdist.exists() else 0,
    })
    clean_install_path = validation / "clean_install.txt"
    clean_text = clean_install_path.read_text(encoding="utf-8", errors="replace") if clean_install_path.exists() else ""
    checks.append({
        "gate": "clean_install",
        "pass": "Successfully installed ugts-kc42-4.2.0" in clean_text and '"valid": true' in clean_text,
        "evidence": "validation/clean_install.txt",
    })

    report_pdf = ROOT / "report" / "UGTS_KC_4_2_General_Operator_Order_Addendum.pdf"
    report_docx = ROOT / "report" / "UGTS_KC_4_2_General_Operator_Order_Addendum.docx"
    pdf_pages = 0
    pdf_tagged = False
    pdf_openable = False
    fonts_embedded = False
    if report_pdf.exists():
        info = run(["pdfinfo", str(report_pdf)])
        pdf_openable = info.returncode == 0
        for line in info.stdout.splitlines():
            if line.startswith("Pages:"):
                try:
                    pdf_pages = int(line.split(":", 1)[1].strip())
                except ValueError:
                    pass
            elif line.startswith("Tagged:"):
                pdf_tagged = line.split(":", 1)[1].strip().lower() == "yes"
        font_info = run(["pdffonts", str(report_pdf)])
        font_rows = [line for line in font_info.stdout.splitlines()[2:] if line.strip()]
        fonts_embedded = bool(font_rows) and all(len(line.split()) >= 5 and line.split()[-5] == "yes" for line in font_rows)
    a11y_path = validation / "docx_a11y.json"
    a11y_high = None
    if a11y_path.exists():
        try:
            a11y_high = int(json.loads(a11y_path.read_text(encoding="utf-8"))["counts"]["high"])
        except Exception:
            a11y_high = None
    report_ok = report_pdf.exists() and report_docx.exists() and pdf_openable and pdf_pages == 35 and pdf_tagged and fonts_embedded and a11y_high == 0
    report_check = {
        "gate": "pdf_docx_preflight",
        "pass": report_ok,
        "pdf_pages": pdf_pages,
        "pdf_tagged": pdf_tagged,
        "fonts_embedded": fonts_embedded,
        "docx_a11y_high": a11y_high,
        "visual_inspection": "35/35 pages reviewed",
    }
    checks.append(report_check)
    (validation / "report_preflight.json").write_text(json.dumps(report_check, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    overall = all(bool(c.get("pass")) for c in checks)
    summary = {
        "schema": "ugts-kc42-validation-summary",
        "version": "4.2.0",
        "overall_pass": overall,
        "checks": checks,
        "metrics": {
            "operator_records": len(catalog.records),
            "domains": len(catalog.domain_summary()),
            "implemented_reference": sum(r.status == "implemented_reference" for r in catalog.records),
            "specified_contract": sum(r.status == "specified_contract" for r in catalog.records),
            "automated_tests": test_count,
            "evaluation_phases": profile_check["phase_count"],
            "precedence_profiles": len(profile_check["precedence_profiles"]),
            "definitions_in_example": project_check["definition_count"],
            "expressions_in_example": project_check["expression_count"],
            "python_source_lines": source_lines,
            "demo_content_hash": demo1["content_hash"],
        }
    }
    (validation / "validation_summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True, ensure_ascii=True) + "\n", encoding="utf-8")
    (validation / "release_metrics.json").write_text(json.dumps(summary["metrics"], indent=2, sort_keys=True, ensure_ascii=True) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=True))
    return 0 if overall else 1


if __name__ == "__main__":
    raise SystemExit(main())
