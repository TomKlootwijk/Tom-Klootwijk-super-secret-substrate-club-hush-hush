from __future__ import annotations

import json
import math
from pathlib import Path
from collections import defaultdict

from docx import Document
from docx.enum.section import WD_ORIENT, WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_LINE_SPACING
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Inches, Pt, RGBColor

ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / 'report'
REPORT.mkdir(exist_ok=True)
FIG = ROOT / 'figures'
CAT = json.loads((ROOT/'spec/operator_catalog_M630_M885.json').read_text())
DOMSUM = json.loads((ROOT/'spec/operator_domain_summary.json').read_text())
PREC = json.loads((ROOT/'spec/precedence_profiles.json').read_text())
PHASES = json.loads((ROOT/'spec/evaluation_phases.json').read_text())
METRICS = json.loads((ROOT/'validation/release_metrics.json').read_text())
DEMO = json.loads((ROOT/'examples/demo_output.json').read_text())
SOURCES = json.loads((ROOT/'spec/source_register.json').read_text())

NAVY='08142B'; NAVY2='10234A'; TEAL='18AEB4'; CYAN='2FC7C9'; GOLD='D9A91A'; PURPLE='7357C7'; GREEN='2A9D68'; RED='C9585B';
LIGHT='F1F5FA'; PALE_TEAL='E6F7F6'; PALE_GOLD='FFF6D9'; PALE_RED='FCE9E8'; PALE_PURPLE='F1ECFB'; WHITE='FFFFFF'; GREY='59667A'; BLACK='0E1726'


def set_cell_shading(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = tcPr.find(qn('w:shd'))
    if shd is None:
        shd = OxmlElement('w:shd'); tcPr.append(shd)
    shd.set(qn('w:fill'), fill)


def set_cell_border(cell, **kwargs):
    tc = cell._tc; tcPr = tc.get_or_add_tcPr()
    tcBorders = tcPr.first_child_found_in('w:tcBorders')
    if tcBorders is None:
        tcBorders = OxmlElement('w:tcBorders'); tcPr.append(tcBorders)
    for edge in ('top','left','bottom','right','insideH','insideV'):
        if edge in kwargs:
            tag='w:'+edge; element=tcBorders.find(qn(tag))
            if element is None:
                element=OxmlElement(tag); tcBorders.append(element)
            for key in ['val','sz','space','color']:
                if key in kwargs[edge]: element.set(qn('w:'+key), str(kwargs[edge][key]))


def set_cell_margins(cell, top=70, start=80, bottom=70, end=80):
    tc=cell._tc; tcPr=tc.get_or_add_tcPr(); tcMar=tcPr.first_child_found_in('w:tcMar')
    if tcMar is None:
        tcMar=OxmlElement('w:tcMar'); tcPr.append(tcMar)
    for m,v in [('top',top),('start',start),('bottom',bottom),('end',end)]:
        node=tcMar.find(qn('w:'+m))
        if node is None: node=OxmlElement('w:'+m); tcMar.append(node)
        node.set(qn('w:w'),str(v)); node.set(qn('w:type'),'dxa')


def set_repeat_table_header(row):
    trPr = row._tr.get_or_add_trPr(); tblHeader=OxmlElement('w:tblHeader'); tblHeader.set(qn('w:val'),'true'); trPr.append(tblHeader)


def cant_split(row):
    trPr=row._tr.get_or_add_trPr(); el=OxmlElement('w:cantSplit'); trPr.append(el)


def set_keep(paragraph, next_=False):
    pPr=paragraph._p.get_or_add_pPr();
    keep=OxmlElement('w:keepLines'); pPr.append(keep)
    if next_:
        kn=OxmlElement('w:keepNext'); pPr.append(kn)


def add_page_number(paragraph):
    paragraph.alignment=WD_ALIGN_PARAGRAPH.RIGHT
    run=paragraph.add_run('Page '); run.font.name='Lato'; run.font.size=Pt(8); run.font.color.rgb=RGBColor.from_string(GREY)
    fld=OxmlElement('w:fldSimple'); fld.set(qn('w:instr'),'PAGE')
    r=OxmlElement('w:r'); rPr=OxmlElement('w:rPr'); color=OxmlElement('w:color'); color.set(qn('w:val'),GREY); rPr.append(color); sz=OxmlElement('w:sz'); sz.set(qn('w:val'),'16'); rPr.append(sz); r.append(rPr); t=OxmlElement('w:t'); t.text='1'; r.append(t); fld.append(r); paragraph._p.append(fld)


def add_header_footer(section, landscape=False):
    section.header.is_linked_to_previous=False; section.footer.is_linked_to_previous=False
    hp=section.header.paragraphs[0]; hp.clear(); hp.alignment=WD_ALIGN_PARAGRAPH.LEFT
    r=hp.add_run('UGTS-KC 4.2 | General Operator and Order Addendum'); r.font.name='Lato'; r.font.size=Pt(8); r.font.bold=True; r.font.color.rgb=RGBColor.from_string(TEAL)
    hp.paragraph_format.space_after=Pt(2)
    # bottom border header
    pPr=hp._p.get_or_add_pPr(); pBdr=OxmlElement('w:pBdr'); bottom=OxmlElement('w:bottom'); bottom.set(qn('w:val'),'single'); bottom.set(qn('w:sz'),'6'); bottom.set(qn('w:color'),TEAL); pBdr.append(bottom); pPr.append(pBdr)
    fp=section.footer.paragraphs[0]; fp.clear();
    left=fp.add_run('Tom Klootwijk - requester-supplied attribution'); left.font.name='Lato'; left.font.size=Pt(7.5); left.font.color.rgb=RGBColor.from_string(GREY)
    fp.add_run('\t')
    add_page_number(fp)
    tabs=fp.paragraph_format.tab_stops; tabs.add_tab_stop(section.page_width-section.left_margin-section.right_margin, WD_ALIGN_PARAGRAPH.RIGHT)


def setup_styles(doc):
    styles=doc.styles
    normal=styles['Normal']; normal.font.name='Lato'; normal.font.size=Pt(9.6); normal.font.color.rgb=RGBColor.from_string(BLACK)
    normal.paragraph_format.space_after=Pt(5); normal.paragraph_format.line_spacing=1.08
    for name,size,color,space in [('Title',32,NAVY,10),('Subtitle',18,TEAL,8),('Heading 1',22,NAVY,8),('Heading 2',15,TEAL,5),('Heading 3',11.5,PURPLE,3)]:
        s=styles[name]; s.font.name='Inter Display'; s.font.size=Pt(size); s.font.color.rgb=RGBColor.from_string(color); s.font.bold=True
        s.paragraph_format.space_before=Pt(space); s.paragraph_format.space_after=Pt(4); set_keep(s.paragraph_format._parent if False else doc.add_paragraph()) if False else None
    styles['Caption'].font.name='Lato'; styles['Caption'].font.size=Pt(8); styles['Caption'].font.italic=True; styles['Caption'].font.color.rgb=RGBColor.from_string(GREY)
    styles['List Bullet'].font.name='Lato'; styles['List Bullet'].font.size=Pt(9.3)
    styles['List Number'].font.name='Lato'; styles['List Number'].font.size=Pt(9.3)


def p(doc,text='',style=None,bold_prefix=None,align=None,keep=False):
    para=doc.add_paragraph(style=style)
    if align is not None: para.alignment=align
    if bold_prefix and text.startswith(bold_prefix):
        r=para.add_run(bold_prefix); r.bold=True
        para.add_run(text[len(bold_prefix):])
    else: para.add_run(text)
    if keep: set_keep(para,True)
    return para


def heading(doc,text,level=1):
    para=doc.add_heading(text,level=level); set_keep(para,True); return para


def add_rule(doc,color=TEAL):
    para=doc.add_paragraph(); para.paragraph_format.space_before=Pt(0); para.paragraph_format.space_after=Pt(3)
    pPr=para._p.get_or_add_pPr(); pBdr=OxmlElement('w:pBdr'); bottom=OxmlElement('w:bottom'); bottom.set(qn('w:val'),'single'); bottom.set(qn('w:sz'),'16'); bottom.set(qn('w:color'),color); pBdr.append(bottom); pPr.append(pBdr)


def add_callout(doc,title,text,kind='teal'):
    palette={'teal':(TEAL,PALE_TEAL),'gold':(GOLD,PALE_GOLD),'red':(RED,PALE_RED),'purple':(PURPLE,PALE_PURPLE)}
    accent,fill=palette[kind]
    table=doc.add_table(rows=2,cols=1); table.alignment=WD_TABLE_ALIGNMENT.CENTER; table.autofit=False; table.columns[0].width=Inches(6.8)
    c1,c2=table.cell(0,0),table.cell(1,0); set_cell_shading(c1,accent); set_cell_shading(c2,fill)
    for c in (c1,c2): set_cell_margins(c,80,120,80,120); set_cell_border(c,top={'val':'single','sz':'8','color':accent},bottom={'val':'single','sz':'8','color':accent},left={'val':'single','sz':'8','color':accent},right={'val':'single','sz':'8','color':accent})
    pr=c1.paragraphs[0]; pr.paragraph_format.space_after=Pt(0); run=pr.add_run(title.upper()); run.font.name='Inter Display'; run.font.size=Pt(10); run.font.bold=True; run.font.color.rgb=RGBColor(255,255,255)
    pr=c2.paragraphs[0]; pr.paragraph_format.space_after=Pt(0); run=pr.add_run(text); run.font.name='Lato'; run.font.size=Pt(9.4); run.font.color.rgb=RGBColor.from_string(BLACK)
    doc.add_paragraph().paragraph_format.space_after=Pt(0)
    return table


def add_code(doc,text):
    table=doc.add_table(rows=1,cols=1); table.alignment=WD_TABLE_ALIGNMENT.CENTER; table.autofit=False; table.columns[0].width=Inches(6.8)
    cell=table.cell(0,0); set_cell_shading(cell,NAVY); set_cell_margins(cell,110,150,110,150)
    pr=cell.paragraphs[0]; pr.paragraph_format.space_after=Pt(0)
    run=pr.add_run(text); run.font.name='DejaVu Sans Mono'; run.font.size=Pt(8); run.font.color.rgb=RGBColor.from_string(WHITE)
    doc.add_paragraph().paragraph_format.space_after=Pt(0)


def add_table(doc,headers,rows,widths=None,font_size=8.5,header_fill=NAVY,repeat=True):
    t=doc.add_table(rows=1,cols=len(headers)); t.alignment=WD_TABLE_ALIGNMENT.CENTER; t.autofit=False
    if widths:
        for col,w in zip(t.columns,widths): col.width=Inches(w)
    hr=t.rows[0]
    if repeat: set_repeat_table_header(hr)
    for i,h in enumerate(headers):
        c=hr.cells[i]; set_cell_shading(c,header_fill); set_cell_margins(c,60,70,60,70); c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
        r=c.paragraphs[0].add_run(str(h)); r.font.name='Lato'; r.font.size=Pt(font_size); r.font.bold=True; r.font.color.rgb=RGBColor(255,255,255)
    for ridx,row in enumerate(rows):
        cells=t.add_row().cells; cant_split(t.rows[-1])
        fill='FFFFFF' if ridx%2 else LIGHT
        for i,val in enumerate(row):
            c=cells[i]; set_cell_shading(c,fill); set_cell_margins(c,50,60,50,60); c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            rr=c.paragraphs[0].add_run(str(val)); rr.font.name='Lato'; rr.font.size=Pt(font_size); rr.font.color.rgb=RGBColor.from_string(BLACK)
            set_cell_border(c,bottom={'val':'single','sz':'2','color':'C7D0DC'})
    return t


def add_figure(doc,filename,caption,width=6.65):
    para=doc.add_paragraph(); para.alignment=WD_ALIGN_PARAGRAPH.CENTER; para.paragraph_format.space_after=Pt(2)
    shape=para.add_run().add_picture(str(FIG/filename),width=Inches(width))
    # Expose the figure meaning to assistive technology without changing visual layout.
    shape._inline.docPr.set('title', filename)
    shape._inline.docPr.set('descr', caption)
    cp=doc.add_paragraph(caption,style='Caption'); cp.alignment=WD_ALIGN_PARAGRAPH.CENTER; cp.paragraph_format.space_after=Pt(6)
    return cp


def page_break(doc): doc.add_page_break()


def set_portrait(section):
    section.orientation=WD_ORIENT.PORTRAIT; section.page_width=Cm(21.0); section.page_height=Cm(29.7); section.top_margin=Cm(1.25); section.bottom_margin=Cm(1.3); section.left_margin=Cm(1.45); section.right_margin=Cm(1.45); section.header_distance=Cm(.55); section.footer_distance=Cm(.55)
    add_header_footer(section)


def set_landscape(section):
    section.orientation=WD_ORIENT.LANDSCAPE; section.page_width=Cm(29.7); section.page_height=Cm(21.0); section.top_margin=Cm(1.1); section.bottom_margin=Cm(1.1); section.left_margin=Cm(1.1); section.right_margin=Cm(1.1); section.header_distance=Cm(.45); section.footer_distance=Cm(.45)
    add_header_footer(section,True)


def table_of_contents(doc):
    rows=[
        ('1','Release definition and decision'),('2','Source continuity and evidence discipline'),('3','Formal 4.2 architecture'),('4','General operator record and type universe'),('5','Order calculus: precedence, dependencies and phases'),('6','Algebraic, discrete and functional operator families'),('7','Linear, geometric, differential and transform families'),('8','Probability, optimization and numerical families'),('9','Symbolic rewrite, proof and metaprogramming'),('10','Exactness, interval and certification discipline'),('11','Determinism, parallel reduction, compression and exchange'),('12','UGTS event authority, replay and lineage'),('13','Reference implementation and CLI'),('14','Deterministic demonstration'),('15','Validation and release evidence'),('16','Compatibility, migration and catalog continuity'),('17','Boundaries and kill criteria'),('18','Final upgraded definition'),('A','Complete compact catalog M630-M885'),('B','Precedence profiles and phase schedule'),('C','Package, source and attribution register')]
    add_table(doc,['Section','Purpose'],rows,[.55,6.05],8.4)


doc=Document(); setup_styles(doc); set_portrait(doc.sections[0])
# Cover: hide header first page, but keep footer page
sec=doc.sections[0]; sec.different_first_page_header_footer=True
sec.first_page_header.paragraphs[0].clear(); sec.first_page_footer.paragraphs[0].clear()

# cover title
para=doc.add_paragraph(); para.paragraph_format.space_before=Pt(8); para.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=para.add_run('UGTS-KC 4.2'); r.font.name='Inter Display'; r.font.size=Pt(34); r.font.bold=True; r.font.color.rgb=RGBColor.from_string(NAVY)
para=doc.add_paragraph(); para.alignment=WD_ALIGN_PARAGRAPH.CENTER; para.paragraph_format.space_after=Pt(2)
r=para.add_run('GENERAL OPERATOR AND ORDER ADDENDUM'); r.font.name='Inter Display'; r.font.size=Pt(19); r.font.bold=True; r.font.color.rgb=RGBColor.from_string(TEAL)
para=doc.add_paragraph(); para.alignment=WD_ALIGN_PARAGRAPH.CENTER; para.paragraph_format.space_after=Pt(8)
r=para.add_run('Typed mathematical operator families, precedence, dependency, composition, reduction and event order'); r.font.name='Lato'; r.font.size=Pt(11.5); r.font.bold=True; r.font.color.rgb=RGBColor.from_string(GREY)
add_figure(doc,'figure_01_architecture.png','Figure 1. General operator meaning and evaluation remain upstream of the canonical UGTS state-authority chain.',6.75)
add_table(doc,['Release field','Value'],[
    ('Prepared for','Tom Klootwijk'),('Version / date','4.2.0 / 28 August 2026'),('Codename','GOOA - General Operator and Order Addendum'),('New mechanism delta','M630-M885 (256 additions)'),('Catalog scope','16 domains x 16 operator/order mechanisms'),('Reference validation',f"{METRICS['automated_tests']} tests PASS; wheel/sdist and clean install"),('Schema','ugts-kc-general-operator-order 4.2')],[1.65,5.0],8.3)
add_callout(doc,'Attribution and evidence boundary','Prepared for Tom Klootwijk. Requester-supplied identity and attribution data are not independently verified. This is a technical design and executable reference artifact, not legal proof of identity, ownership, priority or patentability. A finite catalog does not literally enumerate all future mathematics; it provides general typed operator-family and extension contracts.','red')
page_break(doc)

# Contents and summary
heading(doc,'Contents and Executive Summary',1)
table_of_contents(doc)
heading(doc,'Executive summary',2)
p(doc,'UGTS-KC 4.2 turns mathematical operator meaning and every order that can affect a result into literal, versioned substrate data. It adds a general operator record, three precedence profiles, a canonical fifteen-phase schedule, exactness/effect/capability metadata, deterministic reduction and event-order rules, and an open extension namespace. The retained authority chain is unchanged: pure evaluation may support a state-changing proposal, but only support, compatibility, guard, verification, deterministic commit and lineage can alter authoritative state.')
add_callout(doc,'Release decision','GO for a general addendum with a finite 256-entry catalog plus open operator-family generators. Reject the literal claim that a finite document can enumerate every mathematical operator. The released completeness claim is structural: every shipped operator has a typed record and every result-affecting order has an explicit profile.','teal')
add_table(doc,['Measured item','4.2 result','Meaning'],[
    ('Catalog',f"{METRICS['operator_records']} records, M630-M885",'Sixteen major domains; sixteen entries per domain.'),('Implementation',f"{METRICS['implemented_reference']} executable / {METRICS['specified_contract']} specified",'Advanced operators remain typed contracts rather than false implementation claims.'),('Orders','3 precedence profiles; 15 phases','Parse, dependency, composition, reduction, parallel, event and replay order are distinct.'),('Tests',f"{METRICS['automated_tests']}/{METRICS['automated_tests']} PASS",'Catalog rows, hashes, schema, expressions, intervals, numerics, events, CLI and builds.'),('Runtime',f"{METRICS['python_source_lines']} Python source lines",'Dependency-free standard-library reference subset.'),('Distributions','wheel + source archive','Clean-install CLI validation completed.')],[1.2,1.75,3.75],8.2)
add_figure(doc,'figure_02_domain_coverage.png','Figure 2. The 256-entry delta covers sixteen domains while visibly separating executable reference mechanisms from specified contracts.',6.7)

# Section 1
heading(doc,'1. Release Definition and Decision',1)
heading(doc,'1.1 What this version adds',2)
p(doc,'Earlier UGTS reports already provide broad geometry, fields, topology, kinematics, dynamics, scene identity, deterministic proposal commit, replay, content-addressed definitions, interval guards, finite keys and self-contained runtime delivery. The missing general layer was a single record that can state what an operator means and a single order calculus that can state exactly how operators are grouped and executed across those domains.')
for text in [
    'A content-addressed general OperatorSpec with syntax, arity, domain, codomain, units, shape, exactness, algebraic laws, effects, capabilities, dependencies, invariants, provenance and version.',
    'Explicit parser precedence, associativity and fixity profiles, including the unary-sign/power boundary and comparison-chain semantics.',
    'Distinct dependency, phase, composition, reduction, parallel, event and replay orders rather than one overloaded word order.',
    'A 256-entry engineering catalog covering arithmetic through symbolic proof and UGTS handoff.',
    'A bounded reference evaluator and certificate path that refuses arbitrary code and unsupported mathematical claims.'
]: p(doc,text,'List Bullet')
heading(doc,'1.2 Formal release decision',2)
add_callout(doc,'Decision - GO','Admit the general operator and order layer as UGTS-KC 4.2. Keep all mathematical results typed and evidence-bounded; keep state mutation proposal-based and event-authoritative; keep projection downstream. Treat “all possible operators” as an extensible schema objective, not a false finite-enumeration claim.','gold')
heading(doc,'1.3 Catalog continuity',2)
p(doc,'The project merged catalog spine reaches M629 in the retained 3.9.4 Bayer Direct continuity record. Version 4.2 appends M630-M885 without renumbering prior entries. The separate 4.0 and 4.1 spatial/native branches retain their own release namespaces and are referenced for observation, uncertainty, seed storage and promotion-gate discipline; this general addendum does not silently replace them.')

# Section 2
heading(doc,'2. Source Continuity and Evidence Discipline',1)
add_figure(doc,'figure_09_source_continuity.png','Figure 3. The new layer generalizes retained definitions and order rules while preserving the canonical event sequence.',6.7)
heading(doc,'2.1 Immediate source basis',2)
rows=[]
for i,s in enumerate(SOURCES['local_sources'],1): rows.append((f'S{i}',s['title'],s['role'],s['sha256'][:16]+'...'))
add_table(doc,['ID','Source','4.2 use','SHA-256 prefix'],rows,[.38,2.1,3.15,1.15],7.8)
heading(doc,'2.2 Preserved architectural commitments',2)
add_table(doc,['Source commitment','General 4.2 treatment'],[
    ('Query-first authority','Operator evaluation never bypasses support, compatibility, guard, commit or lineage.'),('Definitions live inside substrate','Operator, profile and schedule records use stable IDs, dependencies and content hashes.'),('Finite typing and evidence boundary','Exact, bounded, approximate, stochastic, presentation-only and specified statuses remain distinct.'),('One bit has a narrow role','Flags, routes and masks never replace continuous values, uncertainty or history.'),('Compression requires equivalence','Packing, seed reconstruction and codebooks require declared decode/error semantics.'),('Projection is downstream','Render, export, storage, network and device adapters do not redefine mathematics or event state.')],[2.0,4.7],8.1)
heading(doc,'2.3 Evidence classes',2)
p(doc,'Each M630-M885 row records a provenance class and validation state. “Implemented reference” means the package contains an executable bounded representative or directly checked record contract. “Specified contract” means the operator family is formally typed and integrated, but the dependency-free runtime does not claim a full production implementation. Neither status is independent scientific validation.')

# Section 3
heading(doc,'3. Formal UGTS-KC 4.2 Architecture',1)
add_figure(doc,'figure_01_architecture.png','Figure 4. Operator registry, order profile, expression graph, evaluation profile and certificate feed the retained state-authority path.',6.7)
heading(doc,'3.1 Upgraded object',2)
add_code(doc,'W_4.2 = W_retained + (O, Y, Q, A, B, Cert)\n\nO    content-addressed operator registry\nY    type / sort / unit / shape universe\nQ    precedence, dependency, phase, composition, reduction, event and replay orders\nA    canonical expression and definition graph\nB    finite work, precision, recursion and storage budgets\nCert exactness, residual, interval, status and provenance certificate')
heading(doc,'3.2 Canonical processing path',2)
add_code(doc,'literal/operator definition\n -> parse/group -> normalize -> resolve/hash -> type/shape/unit\n -> scoped rewrite -> dependency/composition/reduction plan\n -> exact or bounded evaluation -> certificate\n -> support -> compatibility -> guard -> verified proposal\n -> deterministic commit -> transition -> lineage/replay\n -> optional projection/export/device adapter')
heading(doc,'3.3 Single source of operator truth',2)
p(doc,'The same operator and order records are used for catalog validation, safe expression traces, example-project validation, deterministic hashes and the report appendices. No separate prose-only meaning is required to decide arity, grouping, exactness or authority status.')

# Section 4
heading(doc,'4. General Operator Record and Type Universe',1)
add_figure(doc,'figure_05_operator_record.png','Figure 5. A general operator record separates syntax, typing, laws, exactness, effects, dependencies and capabilities.',6.7)
heading(doc,'4.1 Formal record',2)
add_code(doc,'O_i = (id, version, syntax, arity, A_1..A_n, B, parameters,\n       laws, exactness, effects, capabilities, dependencies,\n       order_contract, invariants, provenance, content_hash)')
p(doc,'Semantic arity is independent from notation. A binary operation may be written infix, functional or as an explicit AST node. A higher-order operator may consume or produce functions. A relation-valued operator may return a set or certificate rather than a single scalar. Partial and multivalued status is explicit.')
heading(doc,'4.2 Type families',2)
add_table(doc,['Family','Representative sorts','Required contract'],[
    ('Scalars and numeric towers','integer, rational, real, complex, interval, modular, bit-vector','range, exactness, overflow and coercion'),('Collections','sequence, tuple, set, multiset, map, relation, stream','element type, cardinality/budget and order'),('Linear objects','vector, matrix, tensor, Clifford element','shape, rank, axes, field and contraction'),('Geometric/topological','point, frame, manifold chart, graph, cell complex','coordinate/gluing maps, orientation and invariants'),('Probability/information','event, distribution, random variable, estimator','normalization, seed, measure and uncertainty'),('State/event','state, proposal, transition, checkpoint, lineage','effects, authority and replay order')],[1.25,2.4,3.05],8.0)
heading(doc,'4.3 Laws are scoped data',2)
p(doc,'Associativity, commutativity, identity, distributivity, idempotence, monotonicity, convexity and homomorphism properties are never inferred from a symbol alone. Matrix multiplication is associative but not commutative; floating-point addition is not treated as perfectly associative for deterministic reduction; interval and approximate equality are distinct from exact equality.')

# Section 5
heading(doc,'5. Order Calculus: Precedence, Dependencies and Phases',1)
add_figure(doc,'figure_03_precedence.png','Figure 6. Standard mathematical precedence, with explicit decisions for unary signs, powers and implicit multiplication.',6.7)
heading(doc,'5.1 Parse order',2)
p(doc,'The standard mathematical profile assigns binding powers to function application, postfix operations, power/root, unary operations, products, sums, comparisons, Boolean operators, conditionals and definitions. Parentheses override the profile. The executable Python-safe subset uses a restricted Python expression AST. The explicit-AST profile removes token precedence entirely for interchange.')
heading(doc,'5.2 Orders that must not be conflated',2)
add_table(doc,['Order','Question answered','Failure if hidden'],[
    ('Precedence/associativity','How do tokens group?','Different AST and value.'),('Dependency','Which definitions must exist first?','Unknown reference or cycle.'),('Phase','When do typing, evaluation, guard and commit occur?','Pure work can mutate state or use invalid inputs.'),('Composition','Which map acts first?','Wrong frame, transform or function result.'),('Reduction','What tree/fold combines values?','Floating and non-associative drift.'),('Parallel','Which nodes may run concurrently and how do they rejoin?','Race-dependent output.'),('Event','Which simultaneous verified proposal wins or merges?','Silent overwrite.'),('Replay','In what sequence are patches checked?','State-hash divergence.')],[1.05,2.65,3.0],8.0)
add_figure(doc,'figure_04_phase_schedule.png','Figure 7. The canonical fifteen-phase schedule separates referential evaluation from query certification, authority and projection.',6.7)
heading(doc,'5.3 Dependency and cycle policy',2)
p(doc,'Definitions are topologically sorted with stable priority and ID tie-breaking. An undeclared cycle is rejected. A declared feedback, recurrence or fixed-point operator must provide an initial state, monotonicity/contraction or other convergence evidence where applicable, iteration budget, termination status and bounded failure result.')

# Section 6
heading(doc,'6. Algebraic, Discrete and Functional Operator Families',1)
p(doc,'The first six content domains provide the reusable operator grammar for notation, arithmetic, logic, order theory, finite sets/relations/combinatorics and sequence/functional aggregation. They deliberately separate exact discrete laws from profile-dependent numerical behavior.')
add_table(doc,['Range','Domain','Representative families'],[
    ('M630-M645','Schema and typing','OperatorSpec, type universe, units, shapes, exactness, effects, hashes and extensions.'),('M646-M661','Parse/evaluation order','Precedence, fixity, grouping, dependency DAG, phases, reductions and composition.'),('M662-M677','Arithmetic/elementary','Constants, arithmetic, quotient/modulo, roots, rounding, logs, trig, gamma and modular families.'),('M678-M693','Logic/order theory','Boolean operators, comparisons, quantifiers, partial orders, lexicographic orders, infimum/supremum.'),('M694-M709','Sets/relations/combinatorics','Union/intersection, products, closures, quotients, cardinality, permutations and generating functions.'),('M710-M725','Sequences/functionals','Index, map/filter/fold/scan, stable sort/group, reductions, recurrence, composition and fixed points.')],[1.0,1.55,4.15],7.9)
heading(doc,'6.1 Reduction identity and empty cases',2)
p(doc,'A variadic reduction records whether the empty collection has an identity, returns an option/failure state or is forbidden. Sum and product may use zero and one; minimum and maximum require a declared bounded lattice identity or a non-empty input. A general fold stores direction and initial accumulator.')
heading(doc,'6.2 Order theory as a substrate tool',2)
p(doc,'Partial orders and topological orders are represented directly rather than forced into scalar sorting. This supports dependency evaluation, event precedence, interval containment, refinement and lattice-based fixed-point methods without pretending that every pair is comparable.')

# Section 7
heading(doc,'7. Linear, Geometric, Differential and Transform Families',1)
p(doc,'M726-M789 cover vectors, matrices, tensors, complex/quaternion/geometric algebra, differential calculus and integration/measure/transforms. These domains are where composition direction, coordinate charts, rank, orientation and derivative availability most often change semantics.')
add_table(doc,['Range','Domain','Key boundaries'],[
    ('M726-M741','Vectors, matrices and tensors','Dimension/shape checks; conjugating inner products; noncommutative matrix products; rank and solver status.'),('M742-M757','Complex, quaternion and geometric algebra','Conjugations are distinct; Hamilton/geometric products are ordered; versor sandwich action preserves typed grades.'),('M758-M773','Differential calculus','Limits, derivative/gradient/Jacobian/Hessian, exterior/Lie/covariant derivatives and AD with domain regularity.'),('M774-M789','Integration, measure and transforms','Domain, orientation, measure/Jacobian, singularities, quadrature error and transform convention are explicit.')],[1.0,2.0,3.7],8.0)
heading(doc,'7.1 Coordinate and topology boundary',2)
p(doc,'A coordinate component, chart derivative or projected self-intersection is not automatically a physical vector, force or collision. Manifold transitions, orientation transport and quotient/gluing maps remain separate from dynamics and material claims. Integral theorem certificates require regularity, boundary and orientation hypotheses.')
heading(doc,'7.2 Transform conventions',2)
add_code(doc,'function composition: (f o g)(x) = f(g(x))\ncolumn-vector transform chain: x_world = T_parent T_local x\nquaternion rotation: v\' = q v q^-1\nFourier/Laplace/wavelet transforms: normalization and sign convention are profile data')

# Section 8
heading(doc,'8. Probability, Optimization and Numerical Families',1)
p(doc,'M790-M821 introduce probability/statistics/information and optimization/numerical/constraint families. They require explicit measures, seeds, confidence semantics, convergence tests, residuals and budgets. A stochastic result without its distribution and seed/novelty record is not replayable.')
add_table(doc,['Range','Family','Reference coverage','Specified boundary'],[
    ('M790-M805','Probability/statistics/information','Mean, variance, covariance, entropy, KL, mutual information and seeded samples.','General distributions, Bayesian systems and hypothesis workflows require domain libraries and audit.'),('M806-M821','Optimization/numerical/constraints','Gradient descent, bisection, interpolation/least-squares contracts, interval certification.','Full LP/QP/KKT/Krylov/PDE solvers are typed contracts, not dependency-free production solvers.')],[1.0,1.55,2.15,2.0],7.8)
heading(doc,'8.1 Convergence and failure status',2)
p(doc,'Every iterative method returns a result plus residual or gradient norm, iteration count and status such as converged, endpoint, infeasible, singular, unbounded, ambiguous or budget_exhausted. A plausible number without solver status is not a certified substrate result.')
heading(doc,'8.2 Probability is not authority',2)
p(doc,'Confidence, posterior probability or classifier score can contribute to a guard, but it does not bypass support, compatibility, provenance, numeric error or application policy. Exogenous randomness must be seeded for reproducibility or logged as irreducible external novelty.')

# Section 9
heading(doc,'9. Symbolic Rewrite, Proof and Metaprogramming',1)
p(doc,'M854-M869 add symbols, binding, substitution, alpha/beta operations, simplification, canonicalization, pattern matching, rewrite rules, term ordering, common-subexpression elimination, solver registries, assumptions, proof obligations, bounded grammar and operator generators.')
heading(doc,'9.1 Rewrite rule record',2)
add_code(doc,'RewriteRule = (id, pattern, replacement, side_conditions,\n               orientation, term_order, termination_budget,\n               equality_or_approximation_status, provenance, hash)')
p(doc,'An equality-preserving rewrite is distinct from an approximation, compiler lowering or heuristic simplification. Side conditions must be checked before the rule is used. Term ordering and budgets prevent an uncontrolled rewrite loop. Common-subexpression elimination is safe only for pure nodes or explicitly shareable effects.')
heading(doc,'9.2 Proof boundary',2)
add_callout(doc,'Proof and theorem status','The catalog can carry assumptions, obligations and certificates, but the dependency-free runtime is not a complete theorem prover. A proof certificate is meaningful only under the declared logic, axiom set, checker and trusted computing base.','purple')
heading(doc,'9.3 Operator generators',2)
p(doc,'The operator-generator and open-namespace mechanisms are the structural answer to the request for “all possible” operators. A domain can create parameterized families - for example, p-norms, tensor contractions, special functions, differential operators or graph semirings - while inheriting the same type, order, exactness, effect, budget, evidence and UGTS-handoff contracts.')

# Section 10
heading(doc,'10. Exactness, Interval and Certification Discipline',1)
heading(doc,'10.1 Status classes',2)
add_table(doc,['Class','Meaning','Promotion rule'],[
    ('Exact symbolic','Algebraic expression retained without numerical rounding.','Use only under validated symbolic laws and domains.'),('Exact discrete','Integer, bit-vector, finite-set or combinatorial result.','Overflow/range profile must be explicit.'),('Floating approximate','Binary floating result with platform/profile limits.','Record precision, reduction order and tolerance.'),('Interval/residual certified','True value is enclosed or residual bounded.','Guard may commit only if the entire certificate classifies the event.'),('Stochastic/estimated','Distribution or estimator with seed/data assumptions.','Record uncertainty and external novelty.'),('Bounded iterative','Algorithm stopped under convergence or work budget.','Return status; never disguise budget exhaustion as exact.'),('Presentation-only','Projection for viewing/export.','Cannot mutate authoritative state.'),('Specified contract','Typed but not implemented by reference runtime.','Route to a suitable audited domain adapter.')],[1.35,2.8,2.55],7.7)
heading(doc,'10.2 Interval guard',2)
add_code(doc,'authoritative relation: f in [lower, upper]\nnegative  when upper < -margin\npositive  when lower > +margin\nexact_zero when lower = upper = 0\notherwise ambiguous_guard')
p(doc,'The guard must not promote a result when the error interval straddles the decision boundary. Improving the measurement, algebra, precision or sample budget is preferable to silently choosing a side.')
heading(doc,'10.3 Packing and quantization',2)
p(doc,'The SCLP and GPU-native sources already establish the relevant boundary: width reduction is not correctness or semantic equivalence. Version 4.2 carries quantization range, step, rounding, saturation, decode function and propagated error in the operator profile. A packed value may serve as an index or cache key without becoming complete state.')

# Section 11
heading(doc,'11. Determinism, Parallel Reduction, Compression and Exchange',1)
heading(doc,'11.1 Deterministic joins',2)
p(doc,'Pure independent nodes may run in parallel, but the join order is a profile. Exact integer/bit operations may use any lawfully equivalent tree; floating, interval, noncommutative and stateful operations preserve or explicitly certify the chosen order. Stable sorted-pairwise reduction is supplied as a reproducible option, not a universal accuracy optimum.')
heading(doc,'11.2 Canonical exchange',2)
add_table(doc,['Record','Canonical rule','Boundary'],[
    ('JSON value','sorted keys, compact separators, integral-float normalization, tagged tuples/sets/complex/fractions','integrity format; not a signature'),('Expression','profile ID + explicit canonical AST','whitespace/token spelling does not define meaning'),('Definition','content hash excludes the hash field','hash change signals semantic record change'),('Event','monotonic sequence + pre/post hashes + sorted patch','digest detects divergence; full state/lineage remains authoritative'),('Seed reconstruction','seed + versioned algorithm + parameters + external deltas','valid only when deterministic reconstruction is demonstrated')],[1.25,3.2,2.25],7.8)
heading(doc,'11.3 Compression and budget records',2)
p(doc,'Cost and memory records distinguish nominal width, retained semantics, decode cost, event density, checkpoint density and reconstruction failure. A codebook or opcode can select a finite family; it cannot encode an arbitrary object without a versioned external definition. A seed is not encryption and does not prove provenance.')

# Section 12
heading(doc,'12. UGTS Event Authority, Replay and Lineage',1)
add_figure(doc,'figure_07_event_authority.png','Figure 8. Parallel operator results become proposals; verification and commit remain deterministic state authority.',6.7)
heading(doc,'12.1 Verified proposal predicate',2)
add_code(doc,'verified = support_ok\n       and compatibility_ok\n       and guard_status in accepted_statuses\n       and confidence >= confidence_floor\n       and numeric_error <= event_margin\n       and work_budget_status is acceptable')
heading(doc,'12.2 Simultaneous events',2)
p(doc,'The default total order is event time, descending priority, source and proposal ID. Proposals modifying the same target field at the same event time conflict. A versioned application may replace winner-takes-first with a proven commutative merge, but the merge law and evidence must be explicit. Rejections are typed results, not silent losses.')
heading(doc,'12.3 Replay',2)
p(doc,'Each committed event stores a monotonic sequence, patch, pre-state hash, post-state hash and lineage label. Replay starts from the initial state or checkpoint, verifies the pre-hash, applies the patch, verifies the post-hash and stops at the first divergence. Hashes are checksums for consistency, not complete identity or legal evidence.')

# Section 13
heading(doc,'13. Reference Implementation and CLI',1)
heading(doc,'13.1 Package modules',2)
add_table(doc,['Module','Responsibility'],[
    ('canonical.py','Canonical JSON-compatible values, SHA-256 content addresses and record verification.'),('catalog.py','Load, search, summarize and validate the M630-M885 operator catalog.'),('order.py','Load order profiles and exchange canonical expression ASTs.'),('evaluator.py','Restricted safe expression evaluator and deterministic trace.'),('interval.py','Finite interval arithmetic and guard classification.'),('linalg.py','Vectors, matrix products, determinant, solve, rank and Kronecker product.'),('numeric.py','Finite differences, integration, root finding, optimization, statistics and information measures.'),('graph.py','Deterministic graph normalization, reachability, shortest path and topological sort.'),('events.py','Proposal verification, stable ordering, atomic patching, lineage and replay.'),('validation.py / demo.py / cli.py','Project/catalog/profile validation, integrated demonstration and command-line interface.')],[1.6,5.1],8.0)
heading(doc,'13.2 CLI workflow',2)
add_code(doc,'PYTHONPATH=src python -m ugts_kc42 info\nPYTHONPATH=src python -m ugts_kc42 catalog --search gradient --json\nPYTHONPATH=src python -m ugts_kc42 eval "2 + 3 * 4 ** 2" --trace\nPYTHONPATH=src python -m ugts_kc42 validate examples/general_operator_order_project.json\nPYTHONPATH=src python -m ugts_kc42 demo examples/demo_output.json')
heading(doc,'13.3 Safety boundary',2)
p(doc,'The evaluator accepts an expression-only AST subset with a fixed operator/function registry. It rejects imports, attribute access, statements, lambdas, comprehensions and arbitrary named calls. The reference code is an inspectable oracle and educational substrate, not a production symbolic/numerical platform.')

# Section 14
heading(doc,'14. Deterministic Demonstration',1)
add_figure(doc,'figure_06_expression_trace.png','Figure 9. The expression tree and trace make precedence and evaluation order inspectable.',6.7)
heading(doc,'14.1 Integrated scenario',2)
p(doc,'The demonstration evaluates a mixed scalar/vector expression, propagates an interval guard, solves a linear system, estimates a derivative and integral, brackets a root, computes entropy and mutual information, performs graph reachability/shortest path, topologically orders definitions, verifies competing proposals, commits a deterministic winner and confirms replay hash equality.')
add_table(doc,['Metric','Captured result'],[
    ('Expression',DEMO['expression']['expression']),('Expression result',DEMO['expression']['result']),('Interval class',DEMO['interval']['zero_class']),('Matrix determinant',DEMO['linear_algebra']['determinant']),('sqrt(2) root',f"{DEMO['calculus']['sqrt2_root']['root']:.12f}"),('Graph shortest path',str(DEMO['graph']['shortest_path'])),('Accepted proposal IDs',', '.join(e['proposal_id'] for e in DEMO['events']['accepted'])),('Rejected proposals',str(DEMO['events']['rejected'])),('Final/replay hash match',str(DEMO['events']['final_hash']==DEMO['events']['replay_hash'])),('Demo content hash',DEMO['content_hash'])],[1.7,4.95],7.8)
heading(doc,'14.2 Interpretation',2)
add_callout(doc,'Evidence boundary','The demonstration proves deterministic internal behavior of the bundled reference subset. It does not prove that every cataloged advanced operator is numerically implemented, that all mathematical problems terminate, or that another platform will be bit-identical outside the selected profile.','gold')

# Section 15
heading(doc,'15. Validation and Release Evidence',1)
add_figure(doc,'figure_08_validation.png','Figure 10. Release gates and exact measured package metrics.',6.7)
add_table(doc,['Gate','Result','What is established'],[
    ('Python compile','PASS','All reference modules compile.'),('Automated tests',f"{METRICS['automated_tests']}/{METRICS['automated_tests']} PASS",'Every catalog row plus canonicalization, expressions, intervals, numerics, graphs, events, schema, demo and CLI.'),('Catalog','PASS','M630-M885 contiguous; 256 hashes valid; 16 domains of 16.'),('JSON Schema/project','PASS','Draft 2020-12 example structurally valid; 12 definition hashes and DAG valid.'),('Order profiles','PASS','Three unique profiles; phase indices contiguous 0-14.'),('Demo/replay','PASS','Repeat content hash and final/replay state hash match.'),('Distributions','PASS','Wheel and source archive built.'),('Clean install','PASS','Wheel installed in an isolated environment and CLI info executed.'),('PDF/DOCX preflight','PASS','35-page final render opens, is tagged and text-bearing; all pages were visually inspected and PDF preflight recorded no blocking issue.')],[1.25,1.25,4.15],7.7)
heading(doc,'15.1 What the tests do not establish',2)
p(doc,'They do not establish universal mathematical completeness, theorem soundness for arbitrary external proof systems, production cryptographic safety, physical-device performance, cross-vendor floating-point identity, or suitability for a safety-critical application. Those require application-specific libraries, measurements, review and promotion gates.')

# Section 16
heading(doc,'16. Compatibility, Migration and Catalog Continuity',1)
heading(doc,'16.1 Additive integration',2)
p(doc,'Existing UGTS modules and schemas remain valid. A profile can adopt only the general operator record and explicit order data without replacing its domain runtime. Earlier mechanism IDs and semantics are not rewritten. The general layer may reference a domain operator by stable ID while keeping domain-specific source definitions and native implementations in their existing packages.')
heading(doc,'16.2 Migration steps',2)
steps=['Assign a stable operator ID and semantic version.','Declare arity, domain, codomain, units, shape, exactness and effects.','Select or define a precedence/fixity profile; prefer explicit AST for exchange.','List dependencies and validate a deterministic topological order.','Record composition and reduction order where laws do not make it irrelevant.','Separate pure evaluation from proposal, commit and projection.','Attach residual, interval, uncertainty, work and provenance status.','Preserve pre/post hashes, checkpoint and lineage for state changes.']
for s in steps:p(doc,s,'List Number')
heading(doc,'16.3 Fallback policy',2)
p(doc,'When a target domain already has a mature audited implementation, the 4.2 reference runtime should act as schema, oracle and event-handoff layer rather than reimplementing the domain. The kill criterion is explicit: use the conventional implementation when it is simpler, faster, safer or more accurate at equal error.')

# Section 17
heading(doc,'17. Boundaries and Kill Criteria',1)
heading(doc,'17.1 Non-claims',2)
for text in [
    'No finite list is “all mathematics”; open-ended coverage comes from the general record and operator generators.',
    'No complete theorem prover, computer algebra system, PDE solver, optimizer or special-function library is claimed.',
    'No universal convergence, termination, stability, exactness, O(1), compression or hardware-throughput result is claimed.',
    'No content hash proves mathematical truth, identity, ownership, authorization or chain of custody.',
    'No host test implies phone, GPU, thermal, energy or safety performance.'
]:p(doc,text,'List Bullet')
heading(doc,'17.2 Numerical and semantic kill criteria',2)
for text in ['Type, unit, shape, coordinate or domain conventions are ambiguous.','A rewrite uses a law outside its scope or changes semantics without an approximation label.','Error, quantization or interval width exceeds the event margin or changes event ordering.','A solver lacks a bounded failure state or exceeds its declared work budget.','Reduction/parallel order changes the result beyond tolerance and is not recorded.','A packed/seed record cannot reconstruct the required state, uncertainty and lineage.']:
    p(doc,text,'List Bullet')
heading(doc,'17.3 Order and authority kill criteria',2)
for text in ['A dependency cycle is undeclared or lacks fixed-point initialization/convergence semantics.','Effectful operations are reordered as if pure.','Simultaneous patches conflict without priority, commutative merge or conflict event.','Replay fails pre/post hash checks or external novelty is unrecorded.','Projection or model output is treated as authoritative without proposal verification.']:
    p(doc,text,'List Bullet')
add_callout(doc,'Pragmatic rule','Simplify or reject the general layer when it adds more schema, certification and event density than the avoided ambiguity or when a conventional domain system is better at the same correctness/error target.','red')

# Section 18
heading(doc,'18. Final Upgraded Definition',1)
add_callout(doc,'Formal definition','UGTS-KC 4.2 is a finite, content-addressed and extensible mathematical operator substrate in which operator meaning, types, syntax, precedence, associativity, dependencies, composition, phase, reduction, parallel, event and replay order are explicit data. Pure results remain separate from authority. Any state change returns to support, compatibility, guard, verified proposal, deterministic commit, transition and lineage.','teal')
p(doc,'The strongest upgrade is not the number of catalog rows. It is that ambiguity is now representable and rejectable. A symbol cannot silently choose its own domain, a transform cannot silently commute, a reduction cannot silently change trees, a probabilistic score cannot silently become state, and a projection cannot silently become truth.')
add_code(doc,'UGTS-KC 4.2 = retained UGTS + OperatorSpec + OrderProfile + Certificate\n\ncomplete release claim: all 256 shipped records, hashes, profiles, phases, tests and artifacts are present\nnot claimed: closure of mathematics, universal solvers, universal proof or physical performance')
# Remove the trailing spacer paragraph emitted by add_code so the section-break paragraph can fit on the same page.
_spacer = doc.paragraphs[-1]
if not _spacer.text.strip():
    _spacer._element.getparent().remove(_spacer._element)

# Appendix A landscape cover, followed by one compact domain table per page
land=doc.add_section(WD_SECTION.NEW_PAGE); set_landscape(land)
heading(doc,'Appendix A. Complete Compact Catalog M630-M885',1)
p(doc,'The machine-readable CSV/JSON files contain full definitions, integration notes, provenance and content hashes. The following tables are the complete human-readable compact index. Each of the sixteen domains contains exactly sixteen records.',align=WD_ALIGN_PARAGRAPH.LEFT)
add_figure(doc,'figure_02_domain_coverage.png','Appendix overview. Sixteen domains provide the finite release index; open operator generators provide future extension without a false closure claim.',8.8)
add_callout(doc,'Catalog reading rule','EXEC identifies an executable bounded reference mechanism or directly checked record contract. SPEC identifies a typed advanced contract whose full domain implementation is not claimed by the dependency-free runtime.','gold')
page_break(doc)
records_by=defaultdict(list)
domain_order=[]
for rec in CAT['records']:
    records_by[rec['domain']].append(rec)
    if rec['domain'] not in domain_order:
        domain_order.append(rec['domain'])
for idx,name in enumerate(domain_order,1):
    if idx>1: page_break(doc)
    rows=records_by[name]
    heading(doc,f"A.{idx} {name} ({rows[0]['mechanism_id']}-{rows[-1]['mechanism_id']})",2)
    table_rows=[]
    for rec in rows:
        status='EXEC' if rec['status']=='implemented_reference' else 'SPEC'
        table_rows.append((rec['mechanism_id'],rec['name'],rec['signature'],status,rec['definition']))
    t=add_table(doc,['ID','Operator / mechanism','Typed signature','State','Normalized definition'],table_rows,[.58,2.15,2.28,.58,4.85],6.3)
    p(doc,'EXEC = executable bounded reference mechanism or directly checked record contract. SPEC = typed advanced contract; full domain implementation is not claimed.',style='Caption')

# Appendix B portrait
port=doc.add_section(WD_SECTION.NEW_PAGE); set_portrait(port)
heading(doc,'Appendix B. Precedence Profiles and Phase Schedule',1)
heading(doc,'B.1 Standard mathematical precedence',2)
std=next(x for x in PREC['profiles'] if x['id']=='standard-math-4.2')
add_table(doc,['Binding power','Level','Associativity'],[(x['binding_power'],x['name'],x['associativity']) for x in std['levels_high_to_low']],[1.0,4.4,1.25],7.8)
heading(doc,'B.2 Other profiles',2)
add_table(doc,['Profile','Purpose','Implicit multiplication'],[(x['id'],x.get('description','Standard mathematical token profile.'),str(x.get('implicit_multiplication',False))) for x in PREC['profiles']],[1.75,4.15,.8],7.7)
heading(doc,'B.3 Canonical phase schedule',2)
add_table(doc,['Index','Phase','Purpose'],[(x['index'],x['id'],x['purpose']) for x in PHASES['phases']],[.55,1.1,5.0],7.7)

# Appendix C
heading(doc,'Appendix C. Package, Source and Attribution Register',1)
heading(doc,'C.1 Final package map',2)
add_table(doc,['Path','Contents'],[
    ('report/','PDF and editable DOCX source.'),('spec/','Formal definition, 256-entry CSV/JSON catalog, schema, order profiles, phases and source register.'),('src/ugts_kc42/','Dependency-free reference runtime and bundled data.'),('examples/','Literal content-addressed project and deterministic demonstration output.'),('tests/','441-test suite.'),('docs/','API, order profiles, migration, boundaries and reproduction.'),('figures/','Original report diagrams.'),('dist/','Wheel and source archive.'),('validation/','Test, schema, demo, build, clean-install and PDF/DOCX evidence.'),('manifest/ / checksums/','Final inventory, package tree and SHA-256 release list.')],[1.45,5.2],8.1)
heading(doc,'C.2 Source register',2)
add_table(doc,['Source','Role','SHA-256'],[(s['title'],s['role'],s['sha256']) for s in SOURCES['local_sources']],[1.85,3.3,1.85],6.9)
heading(doc,'C.3 Project continuity records',2)
add_table(doc,['Record','4.2 continuity use','Availability'],[(s['title'],s['role'],s['availability']) for s in SOURCES['project_continuity']],[1.8,3.8,1.35],7.2)
heading(doc,'C.4 Attribution notice',2)
p(doc,'Prepared for Tom Klootwijk as the UGTS-KC 4.2 General Operator and Order Addendum. The requester-supplied identifier NL200678942 and date of birth 10-07-1990 are recorded only as supplied and were not independently verified. This report and package are not legal proof of identity, authorship, ownership, patentability, priority, licensing status or chain of title. No third-party source is silently relicensed by this wording.')
heading(doc,'C.5 Release identifiers',2)
add_table(doc,['Identifier','Value'],[
    ('Runtime version','4.2.0'),('Codename','GOOA - General Operator and Order Addendum'),('Project schema','ugts-kc-general-operator-order-4.2'),('New mechanism range','M630-M885'),('Merged catalog spine','M001-M885 by project/source/catalog continuity'),('Operator records','256'),('Automated tests',str(METRICS['automated_tests'])),('Demo content hash',METRICS['demo_content_hash'])],[2.0,4.65],8.1)
add_callout(doc,'Closing boundary','This package establishes a coherent, inspectable and reproducible general operator/order reference design. It does not establish mathematical closure, universal solver coverage, production safety, physical-device performance or legal ownership.','red')

# metadata and save
props=doc.core_properties; props.title='UGTS-KC 4.2 General Operator and Order Addendum'; props.subject='Typed mathematical operator families and explicit order calculus'; props.author='Prepared for Tom Klootwijk'; props.keywords='UGTS, operators, mathematics, precedence, deterministic order, event calculus'; props.comments='Requester-supplied attribution; technical artifact.'
out=REPORT/'UGTS_KC_4_2_General_Operator_Order_Addendum.docx'
doc.save(out)
print(out)
