from __future__ import annotations

import json
from pathlib import Path
import textwrap

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle
from matplotlib import font_manager

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'figures'
OUT.mkdir(parents=True, exist_ok=True)

NAVY = '#08142b'
NAVY2 = '#10234a'
TEAL = '#2fc7c9'
TEAL2 = '#77e2d1'
GOLD = '#f1c75b'
PURPLE = '#9f80ff'
GREEN = '#63d89b'
RED = '#ef767a'
WHITE = '#f7f9ff'
MUTED = '#9fb0cf'
GRID = '#274168'

for candidate in [
    '/usr/share/fonts/opentype/inter/InterDisplay-Regular.otf',
    '/usr/share/fonts/truetype/lato/Lato-Regular.ttf',
]:
    if Path(candidate).exists():
        font_manager.fontManager.addfont(candidate)
plt.rcParams.update({'font.family': 'Inter Display', 'font.size': 12})


def setup(title: str, subtitle: str = '', size=(16, 9)):
    fig, ax = plt.subplots(figsize=size, dpi=160)
    fig.patch.set_facecolor(NAVY)
    ax.set_facecolor(NAVY)
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis('off')
    ax.text(0.04, 0.94, title, color=WHITE, fontsize=26, fontweight='bold', va='top')
    if subtitle:
        ax.text(0.04, 0.89, subtitle, color=MUTED, fontsize=12, va='top')
    ax.plot([0.04, 0.96], [0.855, 0.855], color=GRID, lw=1.2)
    return fig, ax


def box(ax, x, y, w, h, label, color=TEAL, sub='', fs=13, fill=NAVY2, lw=1.7):
    p = FancyBboxPatch((x,y), w,h, boxstyle='round,pad=0.012,rounding_size=0.015',
                       ec=color, fc=fill, lw=lw)
    ax.add_patch(p)
    ax.text(x+w/2, y+h*0.58, label, color=color, ha='center', va='center', fontsize=fs, fontweight='bold')
    if sub:
        ax.text(x+w/2, y+h*0.28, sub, color=WHITE, ha='center', va='center', fontsize=max(fs-4,7))
    return p


def arrow(ax, a, b, color=GOLD, lw=1.6, connectionstyle='arc3'):
    ax.add_patch(FancyArrowPatch(a,b, arrowstyle='-|>', mutation_scale=14, lw=lw, color=color, connectionstyle=connectionstyle))


def save(fig, name):
    fig.savefig(OUT/name, facecolor=fig.get_facecolor(), bbox_inches='tight', pad_inches=0.12)
    plt.close(fig)


# 1 architecture
fig, ax = setup('UGTS-KC 4.2 General Operator and Order Architecture', 'Meaning, order and evidence stay upstream of state authority; projection remains replaceable.')
row1 = [
    (0.05,'Operator registry','types - laws - hashes',TEAL),
    (0.25,'Order profiles','precedence - DAG - phases',GOLD),
    (0.45,'Expression graph','AST - dependencies - sharing',PURPLE),
    (0.65,'Evaluation profile','exact - interval - bounded',GREEN),
    (0.82,'Certificate','status - residual - budget',RED),
]
for x,l,s,c in row1:
    w=.16 if x<.82 else .13
    box(ax,x,.67,w,.12,l,c,s,fs=12)
for i in range(len(row1)-1):
    x1=row1[i][0]+(.16 if row1[i][0]<.82 else .13)
    x2=row1[i+1][0]
    arrow(ax,(x1,.73),(x2,.73))

stages=[('Support','where can it matter?',TEAL),('Compatibility','can states couple?',PURPLE),('Guard','is change certified?',GOLD),('Verified proposal','candidate patch',GREEN),('Commit','atomic ordered patch',RED),('Lineage','pre/post hash + replay',PURPLE)]
xs=[.05,.205,.365,.51,.685,.83]
ws=[.13,.14,.12,.15,.12,.13]
for (lab,sub,c),x,w in zip(stages,xs,ws): box(ax,x,.39,w,.13,lab,c,sub,fs=12)
for i in range(len(stages)-1): arrow(ax,(xs[i]+ws[i],.455),(xs[i+1],.455))
box(ax,.24,.15,.23,.11,'Optional projection',TEAL,'render - export - device output',fs=12)
box(ax,.56,.15,.23,.11,'External novelty',GOLD,'recorded input - measurement - policy',fs=12)
arrow(ax,(.895,.39),(.675,.26),PURPLE,1.4,'arc3,rad=-.15')
arrow(ax,(.675,.39),(.355,.26),TEAL,1.4,'arc3,rad=.15')
ax.text(.5,.065,'Pure evaluation never bypasses support, compatibility, guard, deterministic commit or lineage.',ha='center',color=WHITE,fontsize=13,fontweight='bold')
save(fig,'figure_01_architecture.png')

# 2 domain coverage
catalog=json.loads((ROOT/'spec/operator_catalog_M630_M885.json').read_text())
domains=[]
seen=[]
for rec in catalog['records']:
    if rec['domain'] not in seen:
        seen.append(rec['domain'])
for d,name in enumerate(seen,1):
    rows=[r for r in catalog['records'] if r['domain']==name]
    domains.append((d, name, rows[0]['mechanism_id'], rows[-1]['mechanism_id'], sum(r['status']=='implemented_reference' for r in rows)))
fig,ax=setup('Sixteen-Domain Operator Coverage','M630-M885: sixteen records per domain; implemented reference contracts are separated from specified advanced contracts.')
cols=4; rowsn=4
colors=[TEAL,GOLD,PURPLE,GREEN]
for i,(idx,name,m0,m1,impl) in enumerate(domains):
    r=i//cols; c=i%cols
    x=.045+c*.237; y=.76-r*.17
    box(ax,x,y,.205,.12,f'{idx:02d}. {name}',colors[c],f'{m0}-{m1} | {impl}/16 executable',fs=9.6)
ax.text(.5,.055,'256 total operator/order mechanisms | 194 implemented reference | 62 specified contract',ha='center',color=WHITE,fontsize=14,fontweight='bold')
save(fig,'figure_02_domain_coverage.png')

# 3 precedence ladder
profiles=json.loads((ROOT/'spec/precedence_profiles.json').read_text())
standard=next(p for p in profiles['profiles'] if p['id']=='standard-math-4.2')
levels=standard['levels_high_to_low']
fig,ax=setup('Standard Mathematical Precedence Profile','Higher binding power is evaluated/grouped first. Parentheses always override the table.')
# levels already sorted high to low
n=len(levels)
for i,level in enumerate(levels):
    y=.80-i*.049
    width=.74-(i*.018)
    x=.08+(i*.009)
    c=[TEAL,GOLD,PURPLE,GREEN,RED][i%5]
    p=FancyBboxPatch((x,y),width,.035,boxstyle='round,pad=.004,rounding_size=.008',fc=NAVY2,ec=c,lw=1.2)
    ax.add_patch(p)
    ax.text(x+.012,y+.0175,f"{level['binding_power']:>3}",color=c,va='center',fontsize=9,fontweight='bold')
    ax.text(x+.07,y+.0175,level['name'],color=WHITE,va='center',fontsize=9.5,fontweight='bold')
    ax.text(x+width-.012,y+.0175,level.get('associativity',''),color=MUTED,va='center',ha='right',fontsize=8.5)
ax.text(.83,.67,'Key decisions',color=GOLD,fontsize=15,fontweight='bold')
notes=['-x^2 = -(x^2)','2^3^2 = 2^(3^2)','comparison chains share operands','implicit multiplication disabled','explicit AST removes token ambiguity']
for i,note in enumerate(notes): ax.text(.83,.61-i*.085,u'• '+note,color=WHITE,fontsize=10.5,va='top',wrap=True)
save(fig,'figure_03_precedence.png')

# 4 phases
phases=json.loads((ROOT/'spec/evaluation_phases.json').read_text())['phases']
fig,ax=setup('Canonical Fifteen-Phase Operation Schedule','Definition dependencies are topologically sorted inside phases; state authority begins only at proposal/commit.')
for i,p in enumerate(phases):
    r=0 if i<8 else 1
    c=i if r==0 else i-8
    count=8 if r==0 else 7
    x=.045+c*(.91/count)
    y=.61 if r==0 else .36
    w=.91/count-.012
    color=TEAL if i<4 else (PURPLE if i<8 else (GOLD if i<11 else (GREEN if i<13 else RED)))
    box(ax,x,y,w,.12,f"{i}. {p['id']}",color,textwrap.shorten(p['purpose'],width=28,placeholder='...'),fs=10)
    if c<count-1: arrow(ax,(x+w,y+.06),(x+w+.012,y+.06),GOLD,1.0)
arrow(ax,(.935,.61),(.045,.48),GOLD,1.2,'arc3,rad=-.18')
ax.text(.045,.21,'PURE / REFERENTIAL',color=TEAL,fontsize=11,fontweight='bold')
ax.text(.29,.21,'CERTIFIED / QUERY',color=GOLD,fontsize=11,fontweight='bold')
ax.text(.55,.21,'AUTHORITY',color=GREEN,fontsize=11,fontweight='bold')
ax.text(.75,.21,'PERSISTENCE / OUTPUT',color=RED,fontsize=11,fontweight='bold')
ax.text(.5,.10,'parse -> normalize -> resolve -> type -> rewrite -> plan -> evaluate -> certify -> support -> compatibility -> guard -> proposal -> commit -> lineage -> projection',color=WHITE,fontsize=10.5,ha='center')
save(fig,'figure_04_phase_schedule.png')

# 5 operator anatomy
fig,ax=setup('Anatomy of a General Operator Record','A reusable mathematical operation is more than a symbol or function name.')
box(ax,.33,.55,.34,.18,'OperatorSpec',GOLD,'stable ID + semantic version + content hash',fs=18)
items=[
 ('Syntax','fixity - token - precedence',TEAL,.05,.68),('Typing','arity - domain - codomain',PURPLE,.05,.48),('Shape / units','rank - axes - dimensions',GREEN,.05,.28),
 ('Laws','identity - associativity - monotonicity',TEAL,.72,.68),('Exactness','symbolic - discrete - interval - approximate',PURPLE,.72,.48),('Effects','pure - proposal - commit - projection',GREEN,.72,.28),
 ('Dependencies','explicit IDs + DAG',RED,.25,.22),('Capabilities','derivative - inverse - vectorize',GOLD,.52,.22)
]
for lab,sub,c,x,y in items:
    w=.23 if x in (.05,.72) else .22
    box(ax,x,y,w,.105,lab,c,sub,fs=11)
    start=(x+w,y+.052) if x<.33 else ((x,y+.052) if x>.67 else (x+w/2,y+.105))
    end=(.33,.64) if x<.33 else ((.67,.64) if x>.67 else (.5,.55))
    arrow(ax,start,end,c,1.1)
ax.text(.5,.075,'Unknown or unsupported semantics return a typed failure status; they are never guessed from notation.',ha='center',color=WHITE,fontsize=13,fontweight='bold')
save(fig,'figure_05_operator_record.png')

# 6 expression trace
fig,ax=setup('Expression Grouping and Deterministic Trace','Example: 2 + 3 * 4 ** 2 = 50 under the standard/Python-safe order profile.')
nodes={
 '2':(.12,.56),'3':(.30,.56),'4':(.48,.56),'2b':(.62,.56),'pow':(.55,.67),'mul':(.40,.76),'add':(.26,.84)
}
for key,(x,y) in nodes.items():
    if key in {'pow','mul','add'}:
        lab={'pow':'power **','mul':'multiply *','add':'add +'}[key]; color={'pow':PURPLE,'mul':GOLD,'add':TEAL}[key]
        box(ax,x,y,.14,.07,lab,color,fs=10)
    else:
        ax.add_patch(Circle((x,y),.035,ec=GREEN,fc=NAVY2,lw=1.5)); ax.text(x,y,key.replace('b',''),ha='center',va='center',color=WHITE,fontweight='bold')
arrow(ax,(.48,.595),(.57,.67),PURPLE); arrow(ax,(.62,.595),(.62,.67),PURPLE)
arrow(ax,(.30,.595),(.43,.76),GOLD); arrow(ax,(.62,.74),(.49,.76),GOLD)
arrow(ax,(.12,.595),(.29,.84),TEAL); arrow(ax,(.47,.83),(.37,.84),TEAL)
trace=[('1-4','literals','2, 3, 4, 2'),('5','power','4 ** 2 = 16'),('6','multiply','3 * 16 = 48'),('7','add','2 + 48 = 50')]
ax.text(.72,.74,'Trace',color=GOLD,fontsize=17,fontweight='bold')
for i,(seq,op,res) in enumerate(trace):
    y=.65-i*.12
    ax.text(.72,y,seq,color=TEAL,fontsize=10,fontweight='bold')
    ax.text(.77,y,op,color=WHITE,fontsize=11,fontweight='bold')
    ax.text(.77,y-.035,res,color=MUTED,fontsize=9.5)
ax.text(.05,.16,'Canonical AST hash',color=PURPLE,fontsize=11,fontweight='bold')
ax.text(.05,.115,'sha256 of {profile, explicit AST}; whitespace does not change identity',color=WHITE,fontsize=10.5)
ax.text(.54,.16,'Reduction boundary',color=RED,fontsize=11,fontweight='bold')
ax.text(.54,.115,'floating reductions must record their tree/order when exact associativity is unavailable',color=WHITE,fontsize=10.5)
save(fig,'figure_06_expression_trace.png')

# 7 events
fig,ax=setup('Parallel Proposals, Deterministic State Authority','Detection may be parallel. Verification, conflict policy, atomic patching and lineage remain ordered.')
box(ax,.05,.62,.16,.10,'CPU / symbolic',TEAL,'pure result or proposal',fs=11)
box(ax,.05,.43,.16,.10,'GPU / device',PURPLE,'bounded candidate',fs=11)
box(ax,.05,.24,.16,.10,'External input',GOLD,'recorded novelty',fs=11)
box(ax,.31,.45,.20,.18,'Verifier',GOLD,'support + compatibility + guard\nconfidence + error + budget',fs=13)
box(ax,.59,.55,.16,.10,'Stable order',TEAL,'time - priority - source - ID',fs=11)
box(ax,.59,.34,.16,.10,'Conflict policy',RED,'merge - winner - rejection',fs=11)
box(ax,.82,.45,.14,.18,'Atomic commit',GREEN,'state patch\npre/post hash',fs=13)
for y in [.67,.48,.29]: arrow(ax,(.21,y),(.31,.54),GOLD,1.3)
arrow(ax,(.51,.54),(.59,.60),TEAL); arrow(ax,(.67,.55),(.67,.44),RED); arrow(ax,(.75,.39),(.82,.54),GREEN)
box(ax,.63,.16,.25,.09,'Lineage + checkpoint + replay',PURPLE,'monotonic sequence and divergence detection',fs=11)
arrow(ax,(.89,.45),(.76,.25),PURPLE,1.4,'arc3,rad=.15')
ax.text(.5,.075,'Unchecked parallel writes never become authoritative state.',ha='center',color=RED,fontsize=14,fontweight='bold')
save(fig,'figure_07_event_authority.png')

# 8 validation
metrics=json.loads((ROOT/'validation/release_metrics.json').read_text())
fig,ax=setup('UGTS-KC 4.2 Validation Expansion','Executable and machine-readable release gates for the general operator/order addendum.')
rows=[('Operator records',metrics['operator_records'],'M630-M885'),('Domains',metrics['domains'],'16 records each'),('Automated tests',metrics['automated_tests'],'all pass'),('Reference contracts',metrics['implemented_reference'],'executable subset'),('Specified contracts',metrics['specified_contract'],'typed advanced boundary'),('Evaluation phases',metrics['evaluation_phases'],'canonical 0-14'),('Precedence profiles',metrics['precedence_profiles'],'standard, Python-safe, explicit AST'),('Python source',metrics['python_source_lines'],'dependency-free lines')]
for i,(lab,val,sub) in enumerate(rows):
    r=i//4;c=i%4
    x=.055+c*.235;y=.61-r*.25
    color=[TEAL,GOLD,PURPLE,GREEN][c]
    box(ax,x,y,.20,.16,lab,color,str(val),fs=12)
    ax.text(x+.10,y+.025,sub,color=MUTED,ha='center',fontsize=8.5)
ax.text(.5,.18,'Release gates: compile | 441 tests | catalog hashes | JSON Schema | project DAG | deterministic demo | replay hash | wheel/sdist | clean install',ha='center',color=WHITE,fontsize=11.5,fontweight='bold',wrap=True)
ax.text(.5,.10,'Internal consistency is established. Mathematical completeness, physical performance and universal convergence are not claimed.',ha='center',color=RED,fontsize=11.5,fontweight='bold')
save(fig,'figure_08_validation.png')

# 9 continuity
fig,ax=setup('Source Continuity and Generalization','The addendum preserves the mature query-first architecture while making operator meaning and order literal.')
labels=[('GN 1.1','authority + precision',TEAL),('KC 2.0','patterns + kinematics',GOLD),('Two Hands 3.0','identity + commit + replay',PURPLE),('KC 3.6','definitions + DAG + phases',GREEN),('SCLP 3.6.2','intervals + finite packing',RED),('KC 3.9','runtime + ordered systems',TEAL),('IQ/Bayer 3.9.3-4','catalog to M629',GOLD),('GOOA 4.2','M630-M885 general order',GREEN)]
for i,(lab,sub,c) in enumerate(labels):
    x=.055+i*.115
    box(ax,x,.48,.10,.16,lab,c,sub,fs=9)
    if i<len(labels)-1: arrow(ax,(x+.10,.56),(x+.115,.56),MUTED,1.0)
ax.plot([.06,.94],[.35,.35],color=GRID,lw=2)
ax.text(.06,.29,'Retained authority',color=TEAL,fontsize=12,fontweight='bold')
ax.text(.06,.24,'support -> compatibility -> guard -> verified proposal -> deterministic commit -> transition -> lineage',color=WHITE,fontsize=12)
ax.text(.06,.15,'4.2 addition',color=GOLD,fontsize=12,fontweight='bold')
ax.text(.06,.10,'typed operators + precedence + dependency + composition + reduction + parallel + event + replay order',color=WHITE,fontsize=12)
save(fig,'figure_09_source_continuity.png')

print(f'generated {len(list(OUT.glob("figure_*.png")))} figures in {OUT}')
