from __future__ import annotations

import csv
import hashlib
import json
import re
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
SPEC = ROOT / "spec"
DATA = ROOT / "src" / "ugts_kc42" / "data"
SPEC.mkdir(parents=True, exist_ok=True)
DATA.mkdir(parents=True, exist_ok=True)


def slug(text: str) -> str:
    text = text.lower().replace("+", " plus ").replace("/", " ")
    text = re.sub(r"[^a-z0-9]+", "-", text).strip("-")
    return text


def canonical_bytes(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")


def content_hash(obj: dict[str, Any]) -> str:
    stripped = {k: v for k, v in obj.items() if k != "content_hash"}
    return "sha256:" + hashlib.sha256(canonical_bytes(stripped)).hexdigest()

# Each domain contains exactly 16 operator/order mechanisms. The catalog is finite,
# while several entries are operator-family generators that cover infinite parameterized classes.
DOMAINS: list[tuple[str, str, list[dict[str, Any]]]] = [
    (
        "schema_typing",
        "Schema and typing",
        [
            {"name": "General operator record", "definition": "A mathematical operator is a content-addressed record carrying stable ID, arity, typed domain, codomain, parameters, laws, exactness, order contract, provenance and capabilities.", "signature": "OperatorSpec -> validated operator", "status": "implemented_reference"},
            {"name": "Type and sort universe", "definition": "Declares scalar, numeric tower, Boolean, bit-vector, interval, sequence, set, relation, function, vector, matrix, tensor, graph, manifold, distribution, state and event sorts with explicit parameters.", "signature": "TypeExpr -> normalized sort", "status": "implemented_reference"},
            {"name": "Arity and variadic contract", "definition": "Records nullary, unary, binary, ternary or variadic arity, minimum and maximum operand counts, and whether empty reduction has an identity.", "signature": "arity x operands -> admission", "status": "implemented_reference"},
            {"name": "Domain and codomain signature", "definition": "Every operand position and result has a declared type expression; polymorphic variables and constraints are explicit rather than inferred from prose.", "signature": "(A1,...,An) -> B", "status": "implemented_reference"},
            {"name": "Unit and dimension signature", "definition": "Physical or semantic dimensions are attached to operands and outputs; addition requires compatible dimensions and multiplication composes dimension exponents.", "signature": "units(Ai) -> units(B)", "status": "specified_contract"},
            {"name": "Shape, rank and broadcasting signature", "definition": "Array-like operands declare shape variables, rank, axis meaning, broadcast rules and output shape; silent shape collapse is rejected.", "signature": "shape(Ai) -> shape(B)", "status": "implemented_reference"},
            {"name": "Total, partial and multivalued status", "definition": "An operator declares whether it is total, partial, set-valued or relation-valued, plus domain guards and failure reason codes.", "signature": "input -> value | bounded failure", "status": "implemented_reference"},
            {"name": "Purity and effect class", "definition": "Separates pure mathematical evaluation from state read, proposal emission, authoritative mutation, I/O and downstream projection effects.", "signature": "operator -> effect class", "status": "implemented_reference"},
            {"name": "Exactness and error model", "definition": "Marks exact symbolic, exact discrete, floating, interval-bounded, stochastic, approximate or presentation-only semantics and carries an error contract.", "signature": "operator x profile -> error semantics", "status": "implemented_reference"},
            {"name": "Capability flags", "definition": "Declares available derivative, gradient, Jacobian, Hessian, adjoint, inverse, monotonicity, convexity, vectorization and serialization capabilities.", "signature": "operator -> capability set", "status": "implemented_reference"},
            {"name": "Algebraic law declaration", "definition": "Associativity, commutativity, identity, inverse, idempotence, distributivity, monotonicity and homomorphism laws are data and may be used only when their scope is satisfied.", "signature": "operator -> scoped laws", "status": "implemented_reference"},
            {"name": "Precondition, invariant and guard contract", "definition": "Domain restrictions, numerical floors, topology invariants and event margins are first-class predicates evaluated before promotion of a result.", "signature": "input x state -> guard status", "status": "implemented_reference"},
            {"name": "Content-addressed operator identity", "definition": "Canonical JSON excluding the hash field is SHA-256 hashed; the digest verifies unchanged semantics but does not prove legal authorship or mathematical truth.", "signature": "canonical operator record -> digest", "status": "implemented_reference"},
            {"name": "Explicit dependency edge", "definition": "Composite operators list stable IDs of definitions they depend on; missing references, duplicate IDs and undeclared cycles are validation failures.", "signature": "operator graph -> DAG or rejection", "status": "implemented_reference"},
            {"name": "Version and migration record", "definition": "A semantic change creates a new version and explicit migration; aliases cannot silently change precedence, units, domains, laws or numerical meaning.", "signature": "old schema x migration -> new schema", "status": "implemented_reference"},
            {"name": "Open extension namespace", "definition": "Profiles may add operators under collision-resistant namespaces while retaining the general record, order, evidence and UGTS handoff contracts.", "signature": "namespace x operator family -> extension", "status": "implemented_reference"},
        ],
    ),
    (
        "parse_evaluation_order",
        "Parse precedence and evaluation order",
        [
            {"name": "Token precedence table", "definition": "Maps every symbolic or keyword operator to a numeric binding power in a named parser profile; ambiguous symbols require an explicit profile.", "signature": "token x profile -> precedence", "status": "implemented_reference"},
            {"name": "Associativity contract", "definition": "Declares left, right, non-associative or variadic grouping; exponentiation is right-associative in the standard mathematical profile.", "signature": "operator -> associativity", "status": "implemented_reference"},
            {"name": "Fixity and mixfix contract", "definition": "Declares prefix, infix, postfix, function-call, indexing, delimiter or mixfix syntax independently from semantic arity.", "signature": "operator -> syntactic form", "status": "implemented_reference"},
            {"name": "Parenthesized grouping authority", "definition": "Explicit grouping overrides profile precedence without changing the underlying operator definitions; the resulting AST is authoritative.", "signature": "tokens -> grouped AST", "status": "implemented_reference"},
            {"name": "Function application precedence", "definition": "Function calls, indexing and explicit operator application bind more tightly than ordinary infix arithmetic unless a profile declares otherwise.", "signature": "f(args) -> application node", "status": "implemented_reference"},
            {"name": "Exponent and root grouping", "definition": "Power chains group according to the selected profile and unary signs are distinguished from signed literals; roots are explicit operators, not ambiguous fractional exponents.", "signature": "base x exponent -> power AST", "status": "implemented_reference"},
            {"name": "Unary sign versus power rule", "definition": "The standard profile parses -x^2 as -(x^2), while an alternate language profile may differ; the selected rule is stored in the trace.", "signature": "tokens -> unambiguous unary AST", "status": "implemented_reference"},
            {"name": "Multiplicative and additive levels", "definition": "Products, quotients and remainders bind more tightly than sums and differences; implicit multiplication is disabled by default to avoid symbol collisions.", "signature": "tokens -> arithmetic AST", "status": "implemented_reference"},
            {"name": "Comparison chain order", "definition": "A chain a < b <= c is represented as a conjunction sharing the middle operand and is not rewritten as nested Boolean-to-number comparison.", "signature": "comparison chain -> predicate", "status": "implemented_reference"},
            {"name": "Boolean precedence order", "definition": "The standard profile orders not above and above xor above or above implication; three-valued profiles preserve unknown propagation.", "signature": "Boolean tokens -> predicate AST", "status": "implemented_reference"},
            {"name": "Conditional and case order", "definition": "Piecewise, if-then-else and match/case constructs evaluate the selector before exactly one selected branch unless a symbolic profile requests branch retention.", "signature": "selector x branches -> selected value", "status": "implemented_reference"},
            {"name": "Dependency topological order", "definition": "Definitions are evaluated only after their declared dependencies; deterministic tie-breaking uses phase, priority and stable ID.", "signature": "definition DAG -> ordered IDs", "status": "implemented_reference"},
            {"name": "Normative phase schedule", "definition": "The general evaluator uses parse, normalize, resolve, type, rewrite, plan, evaluate, certify, support, compatibility, guard, proposal, commit, lineage and projection phases.", "signature": "program -> phase trace", "status": "implemented_reference"},
            {"name": "Stable equal-rank tie break", "definition": "When multiple independent nodes are eligible, the profile orders them by explicit priority then stable content ID, never by container hash or thread timing.", "signature": "ready set -> deterministic next node", "status": "implemented_reference"},
            {"name": "Reduction tree order", "definition": "A fold records left, right, pairwise, balanced, Kahan-like, exact or implementation-defined reduction order; floating reductions are never reordered silently.", "signature": "sequence x reduction profile -> result", "status": "implemented_reference"},
            {"name": "Composition order and trace", "definition": "For f o g the substrate records that g is applied first; noncommuting transformations preserve serialized order and intermediate values in the trace.", "signature": "operator sequence x input -> trace", "status": "implemented_reference"},
        ],
    ),
    (
        "arithmetic_elementary",
        "Arithmetic and elementary functions",
        [
            {"name": "Literal and named constant", "definition": "Nullary exact or profiled constants including integers, rationals, pi, e and declared application constants with explicit precision.", "signature": "{} -> scalar", "status": "implemented_reference"},
            {"name": "Unary plus and negation", "definition": "Identity and additive inverse over additive structures; negation is distinct from bitwise complement and Boolean not.", "signature": "A -> A", "status": "implemented_reference"},
            {"name": "Addition", "definition": "Binary or variadic addition over a declared additive structure with optional identity zero and no floating reassociation unless permitted.", "signature": "A x A -> A", "status": "implemented_reference"},
            {"name": "Subtraction", "definition": "Addition of an additive inverse where available; set difference and geometric subtraction remain separate operator IDs.", "signature": "A x A -> A", "status": "implemented_reference"},
            {"name": "Multiplication", "definition": "Product under a declared algebra, including scalar, elementwise or ring multiplication; matrix and geometric products use distinct records.", "signature": "A x A -> A", "status": "implemented_reference"},
            {"name": "Division", "definition": "Multiplication by an inverse on the guarded nonzero domain; quotient type and zero policy are explicit.", "signature": "A x A_nonzero -> B", "status": "implemented_reference"},
            {"name": "Quotient, modulo and remainder family", "definition": "Distinguishes Euclidean quotient/modulo, truncating division/remainder and language-specific sign conventions.", "signature": "integer x integer_nonzero -> integer pair", "status": "implemented_reference"},
            {"name": "Power and root family", "definition": "Integer, rational, real or complex exponentiation and explicit nth-root operators with branch and domain policy.", "signature": "base x exponent -> value", "status": "implemented_reference"},
            {"name": "Absolute value, magnitude and sign", "definition": "Returns an ordered magnitude/norm or sign-like unit under the declared scalar or algebraic type; zero sign policy is explicit.", "signature": "A -> ordered scalar or unit", "status": "implemented_reference"},
            {"name": "Floor, ceiling, truncation and rounding", "definition": "Quantization family with explicit tie policy, radix, precision and signed-zero behavior.", "signature": "real x policy -> discrete value", "status": "implemented_reference"},
            {"name": "Minimum, maximum and clamp", "definition": "Order-dependent selection with total/partial order policy, stable ties and interval-aware variants.", "signature": "ordered values -> selected value", "status": "implemented_reference"},
            {"name": "Exponential and logarithm family", "definition": "exp, log and log-base operators with branch/domain policy and exact symbolic capability metadata.", "signature": "scalar -> scalar", "status": "implemented_reference"},
            {"name": "Trigonometric family", "definition": "sin, cos, tan and reciprocal circular functions with angle-unit normalization and singularity guards.", "signature": "angle -> scalar", "status": "implemented_reference"},
            {"name": "Inverse and hyperbolic trigonometric family", "definition": "Inverse circular and hyperbolic functions with explicit principal branch and codomain interval.", "signature": "scalar -> angle or scalar", "status": "implemented_reference"},
            {"name": "Factorial, gamma and binomial family", "definition": "Discrete factorial and combinations plus gamma extension under declared domains; overflow and approximation status are visible.", "signature": "integer or scalar -> scalar", "status": "implemented_reference"},
            {"name": "GCD, LCM and modular arithmetic family", "definition": "Number-theoretic operators including gcd, lcm, modular reduction, modular inverse and modular exponentiation with exact integer semantics.", "signature": "integers -> integer", "status": "implemented_reference"},
        ],
    ),
    (
        "logic_order_theory",
        "Logic, comparison and order theory",
        [
            {"name": "Boolean and truth literal", "definition": "Nullary truth values under two-, three- or four-valued logic profiles; unknown and inconsistent are not silently coerced to false.", "signature": "{} -> truth value", "status": "implemented_reference"},
            {"name": "Logical negation", "definition": "Truth negation under the selected logic algebra, distinct from arithmetic sign and bit complement.", "signature": "Truth -> Truth", "status": "implemented_reference"},
            {"name": "Conjunction", "definition": "Logical and with declared short-circuit or symbolic evaluation and truth-table profile.", "signature": "Truth^n -> Truth", "status": "implemented_reference"},
            {"name": "Disjunction and exclusive disjunction", "definition": "Logical or and xor families with explicit n-ary parity semantics and short-circuit status.", "signature": "Truth^n -> Truth", "status": "implemented_reference"},
            {"name": "Implication and equivalence", "definition": "Material or profile-defined implication, biconditional and logical equivalence; proof implication remains separately typed.", "signature": "Truth x Truth -> Truth", "status": "implemented_reference"},
            {"name": "Exact equality and inequality", "definition": "Structural or mathematical equality under a declared type; hash equality is never substituted for semantic equality without a proof contract.", "signature": "A x A -> Truth", "status": "implemented_reference"},
            {"name": "Ordered comparison", "definition": "Less/greater and non-strict comparisons under a declared preorder, partial order or total order; incomparable is a possible result.", "signature": "A x A -> order status", "status": "implemented_reference"},
            {"name": "Approximate and interval equality", "definition": "Absolute, relative, ULP or interval-overlap comparison with explicit tolerance and transitivity warning.", "signature": "numeric x numeric x tolerance -> status", "status": "implemented_reference"},
            {"name": "Membership and containment", "definition": "Element-of, subset, proper subset and containment predicates across sets, intervals, spaces and supports.", "signature": "element x container -> Truth", "status": "implemented_reference"},
            {"name": "Predicate and characteristic operator", "definition": "Maps values to truth/status and optionally to an indicator in a declared codomain; predicate identity is retained.", "signature": "A -> Truth or indicator", "status": "implemented_reference"},
            {"name": "Universal and existential quantifier", "definition": "Finite, symbolic or measure-qualified forall/exists operators with explicit domain and bounded enumeration policy.", "signature": "domain x predicate -> Truth/status", "status": "specified_contract"},
            {"name": "Preorder, partial order and total order record", "definition": "Stores relation properties such as reflexive, antisymmetric, transitive and total, with executable finite validators when applicable.", "signature": "relation -> order certificate", "status": "implemented_reference"},
            {"name": "Strict and non-strict order conversion", "definition": "Converts between < and <= forms only when equality and order laws justify it; incomplete orders preserve incomparability.", "signature": "order relation -> paired relation", "status": "specified_contract"},
            {"name": "Lexicographic, product and shortlex order", "definition": "Constructs deterministic composite orders from component orders, including length-first and coordinatewise variants.", "signature": "component orders -> composite order", "status": "implemented_reference"},
            {"name": "Well-foundedness and topological order", "definition": "Records or checks absence of descending chains in bounded structures and provides deterministic topological ordering for finite DAGs.", "signature": "relation or DAG -> certificate/order", "status": "implemented_reference"},
            {"name": "Infimum, supremum and order statistics", "definition": "Computes lower/upper bounds, minima/maxima, ranks and quantiles under a declared order and existence policy.", "signature": "ordered collection -> bound/statistic", "status": "implemented_reference"},
        ],
    ),
    (
        "sets_relations_combinatorics",
        "Sets, relations and finite combinatorics",
        [
            {"name": "Set, multiset and finite-map literal", "definition": "Constructs unordered sets, counted multisets or key-value maps with canonical element/key encoding and duplicate policy.", "signature": "elements -> collection", "status": "implemented_reference"},
            {"name": "Union", "definition": "Set or multiset union with declared multiplicity rule; geometric CSG union is a separate field operator.", "signature": "Collection x Collection -> Collection", "status": "implemented_reference"},
            {"name": "Intersection", "definition": "Common membership under set or multiset semantics with deterministic representation.", "signature": "Collection x Collection -> Collection", "status": "implemented_reference"},
            {"name": "Difference and complement", "definition": "Relative difference or complement against an explicit universe; no implicit universal set is assumed.", "signature": "Collection x Collection/Universe -> Collection", "status": "implemented_reference"},
            {"name": "Symmetric difference", "definition": "Elements present in exactly one operand under set semantics, or a declared multiset parity/count rule.", "signature": "Collection x Collection -> Collection", "status": "implemented_reference"},
            {"name": "Cartesian product", "definition": "Ordered tuple construction over factor collections with finite budget and product-order metadata.", "signature": "A x B -> Set[(A,B)]", "status": "implemented_reference"},
            {"name": "Power set and finite subset family", "definition": "Enumerates or symbolically denotes subsets with explicit cardinality budget; unbounded materialization is rejected.", "signature": "finite set -> subset family", "status": "implemented_reference"},
            {"name": "Relation composition", "definition": "Composes typed binary relations by existentially matching the intermediate sort; ordering of composition is explicit.", "signature": "R:A<->B x S:B<->C -> A<->C", "status": "implemented_reference"},
            {"name": "Inverse and converse relation", "definition": "Swaps relation endpoints without claiming a functional inverse; multiplicity and provenance are retained.", "signature": "R:A<->B -> R^-1:B<->A", "status": "implemented_reference"},
            {"name": "Reflexive, symmetric and transitive closure", "definition": "Finite graph/relation closure operators with algorithm and budget; closure is not silently applied to authoritative data.", "signature": "relation -> closed relation", "status": "implemented_reference"},
            {"name": "Equivalence class and quotient set", "definition": "Forms classes only after an equivalence-relation certificate; representative selection and lineage are explicit.", "signature": "set x equivalence -> quotient", "status": "specified_contract"},
            {"name": "Cardinality and counting measure", "definition": "Returns exact finite size, symbolic cardinality or bounded count status; bytes and semantic information are distinct metrics.", "signature": "collection -> cardinal", "status": "implemented_reference"},
            {"name": "Permutation and combination", "definition": "Exact nPk, nCk and iterator families with order, repetition and budget policy.", "signature": "n x k x policy -> count/family", "status": "implemented_reference"},
            {"name": "Partition and composition family", "definition": "Integer/set partitions and ordered compositions under bounded generation with canonical ordering.", "signature": "object x constraints -> partition family", "status": "specified_contract"},
            {"name": "Inclusion-exclusion and Mobius inversion", "definition": "Finite combinatorial transforms over subset or poset incidence with explicit domain and exact arithmetic.", "signature": "finite family/function -> count/transformed function", "status": "specified_contract"},
            {"name": "Generating function and recurrence descriptor", "definition": "Represents ordinary/exponential generating functions and finite recurrences as typed definitions; convergence and coefficient extraction are separate capabilities.", "signature": "sequence/recurrence -> formal series", "status": "specified_contract"},
        ],
    ),
    (
        "sequences_functional_aggregation",
        "Sequences, functional operators and aggregation",
        [
            {"name": "Sequence, tuple and stream record", "definition": "Ordered finite or lazily bounded values with element type, length status, seed and traversal order.", "signature": "elements/generator -> sequence", "status": "implemented_reference"},
            {"name": "Indexing and slicing", "definition": "Selects elements or ranges with explicit base, negative-index, bounds and half-open/closed interval policy.", "signature": "sequence x index/range -> value/sequence", "status": "implemented_reference"},
            {"name": "Concatenation and interleave", "definition": "Joins ordered sequences or interleaves them by a declared schedule without losing source boundaries.", "signature": "sequences -> sequence", "status": "implemented_reference"},
            {"name": "Map", "definition": "Applies a pure operator elementwise while retaining element order and per-element failure status.", "signature": "(A->B) x Seq[A] -> Seq[B]", "status": "implemented_reference"},
            {"name": "Filter and partition", "definition": "Retains or splits elements by a predicate; stable input order is the default.", "signature": "predicate x Seq[A] -> Seq[A] or pair", "status": "implemented_reference"},
            {"name": "Fold and reduce", "definition": "Combines a sequence with explicit identity, direction and reduction tree; algebraic laws may permit optimized trees only under profile.", "signature": "binary op x identity x Seq[A] -> A", "status": "implemented_reference"},
            {"name": "Scan and prefix accumulation", "definition": "Returns all intermediate fold states with inclusive/exclusive and direction policy.", "signature": "op x identity x Seq[A] -> Seq[A]", "status": "implemented_reference"},
            {"name": "Zip, unzip and alignment", "definition": "Pairs or groups sequences by position, key, time or interpolation policy; truncation/padding is explicit.", "signature": "Seq[A] x Seq[B] -> Seq[(A,B)]", "status": "implemented_reference"},
            {"name": "Stable sort", "definition": "Orders values by a declared total/key order with stable equal-key behavior; partial-order sorting returns a linear-extension status.", "signature": "Seq[A] x order -> Seq[A]", "status": "implemented_reference"},
            {"name": "Unique, group-by and histogram", "definition": "Deduplicates or groups by exact/canonical key and produces counts or buckets with stable first-occurrence ordering.", "signature": "Seq[A] x key -> groups", "status": "implemented_reference"},
            {"name": "Sum and product reduction", "definition": "Specialized reductions with exact, pairwise, compensated or interval accumulation profiles and explicit empty identity.", "signature": "Seq[number] -> number", "status": "implemented_reference"},
            {"name": "Extremum and arg-extremum", "definition": "Returns min/max values and stable indices/keys under a declared order, with empty and incomparable policies.", "signature": "Seq[A] -> value/index", "status": "implemented_reference"},
            {"name": "Mean and weighted mean", "definition": "Arithmetic or profile-defined means with weight validation, accumulator order and exactness status.", "signature": "Seq[number] x weights? -> number", "status": "implemented_reference"},
            {"name": "Finite difference and recurrence step", "definition": "Builds discrete derivatives, cumulative sums or recurrence transitions with explicit boundary and step policy.", "signature": "Seq[A]/state -> Seq[A]/state", "status": "implemented_reference"},
            {"name": "Function composition and pipeline", "definition": "Creates a new operator by ordered composition, retaining intermediate type checks, effects and trace identities.", "signature": "(B->C) x (A->B) -> (A->C)", "status": "implemented_reference"},
            {"name": "Currying, partial application and bounded fixed point", "definition": "Transforms multi-argument operators, binds selected arguments, or iterates to a fixed point under a declared convergence/budget contract.", "signature": "operator x bindings/profile -> operator/result", "status": "implemented_reference"},
        ],
    ),
    (
        "linear_algebra_tensors",
        "Vectors, matrices and tensors",
        [
            {"name": "Vector construction and coordinates", "definition": "Builds finite vectors with dimension, basis, coordinate frame, scalar field and unit metadata.", "signature": "scalars -> Vector[n]", "status": "implemented_reference"},
            {"name": "Vector addition and scalar action", "definition": "Module operations with dimension/frame compatibility and explicit scalar field.", "signature": "Vector x Vector or Scalar x Vector -> Vector", "status": "implemented_reference"},
            {"name": "Dot and bilinear product", "definition": "Inner or general bilinear pairing with declared metric/form; Euclidean dot is one profile.", "signature": "V x V -> Scalar", "status": "implemented_reference"},
            {"name": "Cross, wedge and oriented area product", "definition": "Three-dimensional cross or exterior product under a declared orientation and dimension; no universal cross product is assumed.", "signature": "V x V -> V or Multivector", "status": "implemented_reference"},
            {"name": "Norm, seminorm and distance", "definition": "Lp, weighted, matrix and user-defined norms plus induced distances with metric-law status.", "signature": "V -> nonnegative scalar", "status": "implemented_reference"},
            {"name": "Normalize, project and reject", "definition": "Unit normalization and decomposition relative to a subspace/vector with zero and conditioning guards.", "signature": "V x subspace -> components", "status": "implemented_reference"},
            {"name": "Matrix construction, transpose and adjoint", "definition": "Builds shaped matrices and applies transpose, conjugate transpose or typed adjoint under an inner product.", "signature": "Matrix[m,n] -> Matrix[n,m]", "status": "implemented_reference"},
            {"name": "Matrix multiplication", "definition": "Ordered contraction over compatible inner dimensions; elementwise product remains a separate operator.", "signature": "Matrix[m,k] x Matrix[k,n] -> Matrix[m,n]", "status": "implemented_reference"},
            {"name": "Determinant and trace", "definition": "Square-matrix invariants with exact/symbolic/numerical algorithm status and conditioning metadata.", "signature": "Matrix[n,n] -> Scalar", "status": "implemented_reference"},
            {"name": "Inverse and linear solve", "definition": "Solves Ax=b or forms an inverse only under nonsingularity/conditioning policy; solve is preferred over explicit inverse.", "signature": "A x b -> x/status", "status": "implemented_reference"},
            {"name": "Rank, nullspace and range", "definition": "Exact or tolerance-profiled linear subspace queries returning basis plus numerical rank status.", "signature": "Matrix -> rank/subspaces", "status": "implemented_reference"},
            {"name": "Eigenvalue and eigenspace family", "definition": "Spectral decomposition with real/complex and defective-matrix status; eigenvectors retain normalization and ordering policy.", "signature": "Matrix[n,n] -> spectral record", "status": "specified_contract"},
            {"name": "SVD and pseudoinverse", "definition": "Singular-value decomposition and Moore-Penrose pseudoinverse with tolerance, rank and error certificate.", "signature": "Matrix -> U,S,Vt/pseudoinverse", "status": "specified_contract"},
            {"name": "Tensor and Kronecker product", "definition": "Forms multilinear products with explicit axis ordering, basis and output shape.", "signature": "Tensor[A] x Tensor[B] -> Tensor[A+B]", "status": "implemented_reference"},
            {"name": "Tensor contraction and Einstein expression", "definition": "Contracts named axes or an explicit einsum-like index expression; repeated-index meaning is parsed and validated.", "signature": "tensors x index spec -> tensor", "status": "specified_contract"},
            {"name": "Reshape, broadcast and axis permutation", "definition": "Changes representation without changing element count unless a declared broadcast/replication rule applies; axis lineage is retained.", "signature": "Tensor x shape/permutation -> Tensor", "status": "implemented_reference"},
        ],
    ),
    (
        "hypercomplex_geometric_algebra",
        "Complex, quaternion and geometric algebra",
        [
            {"name": "Complex construction and conjugation", "definition": "Constructs a+bi and applies conjugation under a declared complex field and precision profile.", "signature": "real x real -> complex; complex -> complex", "status": "implemented_reference"},
            {"name": "Complex magnitude and argument", "definition": "Returns modulus and principal or unwrapped phase with branch-cut and zero policy.", "signature": "complex -> nonnegative real/angle", "status": "implemented_reference"},
            {"name": "Complex arithmetic family", "definition": "Addition, multiplication, division, power, roots and elementary functions with explicit branch semantics.", "signature": "complex operands -> complex", "status": "implemented_reference"},
            {"name": "Euler and polar conversion", "definition": "Converts between rectangular and polar form while preserving selected phase lineage for repeated windings.", "signature": "complex <-> (radius,phase)", "status": "implemented_reference"},
            {"name": "Quaternion construction and conjugation", "definition": "Constructs scalar-vector quaternion records and applies conjugation with component ordering fixed by schema.", "signature": "R^4 -> Quaternion", "status": "implemented_reference"},
            {"name": "Hamilton quaternion product", "definition": "Noncommutative quaternion multiplication with ordered operands and exact component formula.", "signature": "Quaternion x Quaternion -> Quaternion", "status": "implemented_reference"},
            {"name": "Quaternion norm, inverse and normalization", "definition": "Norm-based inverse and unit normalization with zero/conditioning guards.", "signature": "Quaternion -> Quaternion/status", "status": "implemented_reference"},
            {"name": "Quaternion rotation and SLERP", "definition": "Applies unit-quaternion sandwich rotation and shortest-arc interpolation with antipodal and near-equality policy.", "signature": "Quaternion x Vector/time -> Vector/Quaternion", "status": "implemented_reference"},
            {"name": "Dual-number forward derivative", "definition": "Represents a+b epsilon with epsilon^2=0 so arithmetic propagates first derivatives under supported operators.", "signature": "Dual x Dual -> Dual", "status": "implemented_reference"},
            {"name": "Dual quaternion rigid transform", "definition": "Represents coupled rotation and translation using unit dual quaternions with normalization and composition order.", "signature": "Rigid transform <-> DualQuaternion", "status": "specified_contract"},
            {"name": "Clifford algebra basis and grade", "definition": "Declares signature (p,q,r), basis blades, grades and coefficient scalar field for a finite geometric algebra.", "signature": "signature -> algebra type", "status": "specified_contract"},
            {"name": "Geometric product", "definition": "Associative Clifford product combining symmetric inner and antisymmetric outer parts under the declared metric.", "signature": "Multivector x Multivector -> Multivector", "status": "specified_contract"},
            {"name": "Exterior wedge product", "definition": "Antisymmetric grade-raising product with dimension and orientation metadata.", "signature": "Multivector x Multivector -> Multivector", "status": "specified_contract"},
            {"name": "Inner and contraction products", "definition": "Left/right contraction and scalar products with explicit grade convention to avoid notation ambiguity.", "signature": "Multivector x Multivector -> Multivector/scalar", "status": "specified_contract"},
            {"name": "Reverse, involution and Clifford conjugate", "definition": "Grade-dependent sign transforms are distinct named operators and cannot be collapsed into one generic conjugation symbol.", "signature": "Multivector -> Multivector", "status": "specified_contract"},
            {"name": "Versor and sandwich action", "definition": "Applies ordered v x reverse(v) actions for reflections/rotations only when versor and invertibility guards hold.", "signature": "Versor x Multivector -> Multivector", "status": "specified_contract"},
        ],
    ),
    (
        "differential_calculus",
        "Differential calculus",
        [
            {"name": "Limit", "definition": "Symbolic, analytic, interval or numerical limit with approach side, topology and convergence status.", "signature": "function x point/direction -> value/status", "status": "specified_contract"},
            {"name": "Single-variable derivative", "definition": "Exact rule, automatic differentiation or bounded finite difference under a declared method and step/error profile.", "signature": "f:A->B x point -> linear/local derivative", "status": "implemented_reference"},
            {"name": "Partial derivative", "definition": "Derivative with respect to one named coordinate while other coordinates and chart are explicit.", "signature": "f:R^n->B x axis -> derivative", "status": "implemented_reference"},
            {"name": "Gradient", "definition": "Metric-dependent vector corresponding to a scalar differential; coordinate covector and physical force remain separately typed.", "signature": "scalar field x metric -> vector field", "status": "implemented_reference"},
            {"name": "Jacobian", "definition": "Matrix/linear map of first partial derivatives with input/output coordinate order fixed by schema.", "signature": "f:R^n->R^m -> Matrix[m,n]", "status": "implemented_reference"},
            {"name": "Hessian", "definition": "Second derivative bilinear form or coordinate matrix with symmetry and differentiability status.", "signature": "scalar field -> Matrix[n,n]", "status": "implemented_reference"},
            {"name": "Divergence", "definition": "Trace of a covariant/Jacobian derivative under a declared volume/metric structure.", "signature": "vector field -> scalar field", "status": "specified_contract"},
            {"name": "Curl and rotational derivative", "definition": "Three-dimensional curl or exterior-calculus analogue with orientation and metric conventions.", "signature": "vector/one-form field -> field", "status": "specified_contract"},
            {"name": "Laplacian and Laplace-Beltrami", "definition": "Scalar/vector Laplacian under Euclidean or manifold metric with boundary conditions separately declared.", "signature": "field -> field", "status": "specified_contract"},
            {"name": "Directional derivative", "definition": "Derivative along a declared tangent/vector field, normalized only when requested.", "signature": "f x direction -> derivative", "status": "implemented_reference"},
            {"name": "Lie derivative and bracket", "definition": "Differentiates tensors along a flow and defines vector-field commutator with chart and regularity contracts.", "signature": "field x tensor/field -> tensor/field", "status": "specified_contract"},
            {"name": "Exterior derivative", "definition": "Grade-raising differential on forms satisfying d(d(omega))=0 under a declared smooth structure.", "signature": "k-form -> (k+1)-form", "status": "specified_contract"},
            {"name": "Differential and pushforward", "definition": "Maps tangent vectors through a differentiable function; source and target tangent spaces are explicit.", "signature": "map x tangent vector -> tangent vector", "status": "specified_contract"},
            {"name": "Pullback", "definition": "Transports covectors/forms/tensors contravariantly through a map with composition order retained.", "signature": "map x target covariant object -> source object", "status": "specified_contract"},
            {"name": "Covariant derivative and connection", "definition": "Differentiates fields using an explicit connection; Christoffel data and coordinate transformation rules are part of the profile.", "signature": "connection x fields -> tensor", "status": "specified_contract"},
            {"name": "Forward and reverse automatic differentiation", "definition": "Evaluates primal values with tangent or adjoint traces; mutation/effects and unsupported primitives require explicit custom rules.", "signature": "operator graph x seed/cotangent -> derivative trace", "status": "implemented_reference"},
        ],
    ),
    (
        "integration_measure_transforms",
        "Integration, measure and transforms",
        [
            {"name": "Definite and indefinite integral", "definition": "Analytic antiderivative or bounded numerical integral with interval, orientation, singularity and error status.", "signature": "f x domain -> value/function", "status": "implemented_reference"},
            {"name": "Line integral", "definition": "Integrates a scalar or differential form along an oriented parameterized curve with explicit frame and domain.", "signature": "field x curve -> scalar", "status": "specified_contract"},
            {"name": "Surface and volume integral", "definition": "Integrates over oriented parameterized/implicit domains with measure/Jacobian and boundary contract.", "signature": "field x manifold/domain -> scalar", "status": "specified_contract"},
            {"name": "Measure and measurable-set operator", "definition": "Declares a measure space and evaluates measurable sets/functions; finite counting and weighted measures are executable subsets.", "signature": "measure x set -> nonnegative extended scalar", "status": "specified_contract"},
            {"name": "Quadrature and adaptive summation", "definition": "Trapezoid, Simpson, Gaussian or adaptive rules with sample budget and error estimate.", "signature": "f x interval x profile -> estimate", "status": "implemented_reference"},
            {"name": "Convolution", "definition": "Continuous, discrete, circular or group convolution with boundary, normalization and algorithm policy.", "signature": "f x g -> h", "status": "implemented_reference"},
            {"name": "Correlation", "definition": "Cross/auto-correlation with conjugation, lag, normalization and finite-boundary policy.", "signature": "f x g -> correlation", "status": "implemented_reference"},
            {"name": "Fourier transform", "definition": "Continuous/discrete Fourier transform with sign, normalization, sampling and frequency-order conventions.", "signature": "signal -> spectrum", "status": "specified_contract"},
            {"name": "Inverse Fourier transform", "definition": "Inverse transform paired with a declared forward convention and reconstruction/error status.", "signature": "spectrum -> signal", "status": "specified_contract"},
            {"name": "Laplace transform", "definition": "One/two-sided transform with region-of-convergence metadata and inverse capability status.", "signature": "time function -> complex function", "status": "specified_contract"},
            {"name": "Z transform", "definition": "Discrete-time transform with bilateral/unilateral and region-of-convergence profile.", "signature": "sequence -> complex formal function", "status": "specified_contract"},
            {"name": "Wavelet transform", "definition": "Continuous/discrete multiscale analysis with wavelet family, boundary and level budget.", "signature": "signal -> coefficient hierarchy", "status": "specified_contract"},
            {"name": "Hilbert transform and analytic signal", "definition": "Principal-value transform and analytic-signal construction with finite signal/filter approximation status.", "signature": "signal -> signal/complex signal", "status": "specified_contract"},
            {"name": "Radon and projection transform", "definition": "Integrates over hyperplanes/curves with sampling and reconstruction policy; projection data is not object identity.", "signature": "field -> projection family", "status": "specified_contract"},
            {"name": "Mellin and scale transform", "definition": "Multiplicative-scale transform with convergence strip and normalization metadata.", "signature": "positive-domain function -> complex function", "status": "specified_contract"},
            {"name": "Integral theorem certificate", "definition": "Green, Stokes and divergence theorem records relate interior and boundary integrals only when smoothness, orientation and domain hypotheses pass.", "signature": "domain x field x hypotheses -> equality certificate", "status": "specified_contract"},
        ],
    ),
    (
        "probability_statistics_information",
        "Probability, statistics and information",
        [
            {"name": "Probability space and event", "definition": "Declares sample space, sigma-algebra/profile and normalized measure; finite exact spaces are the reference executable subset.", "signature": "space x measure -> probability model", "status": "implemented_reference"},
            {"name": "Random variable and distribution", "definition": "A measurable map plus named distribution parameters, support and seed/source policy.", "signature": "sample -> value; parameters -> distribution", "status": "implemented_reference"},
            {"name": "PMF, PDF and CDF family", "definition": "Probability mass/density and cumulative operators with normalization, support and mixed-distribution status.", "signature": "distribution x value -> probability/density", "status": "implemented_reference"},
            {"name": "Expectation", "definition": "Finite sum, integral or estimator of a random variable with exactness and sampling error status.", "signature": "distribution x variable -> value", "status": "implemented_reference"},
            {"name": "Variance and covariance", "definition": "Second central moment and cross-moment with sample/population and numerical-stability profile.", "signature": "variables/distribution -> scalar/matrix", "status": "implemented_reference"},
            {"name": "Moment and cumulant family", "definition": "Raw, central and standardized moments plus cumulants with existence and estimator status.", "signature": "distribution x order -> value/status", "status": "specified_contract"},
            {"name": "Conditional probability and expectation", "definition": "Conditions on an event/sigma-field with zero-probability and regular-conditional policy visible.", "signature": "model x condition -> conditional model/value", "status": "implemented_reference"},
            {"name": "Bayesian update", "definition": "Combines prior and likelihood into normalized posterior with evidence/zero-normalizer and approximation status.", "signature": "prior x likelihood x data -> posterior", "status": "implemented_reference"},
            {"name": "Independence and dependence measure", "definition": "Declares/checks independence in finite models and computes correlation or other selected dependence diagnostics.", "signature": "variables/model -> status/measure", "status": "implemented_reference"},
            {"name": "Seeded sampling and random stream", "definition": "Deterministic pseudorandom or externally random sampling with algorithm, seed, stream ID and reproducibility status; randomness is not authority by itself.", "signature": "distribution x seed/state -> sample/state", "status": "implemented_reference"},
            {"name": "Likelihood and log-likelihood", "definition": "Evaluates parameterized model evidence for observed data with support and underflow-safe log profile.", "signature": "model x parameters x data -> scalar", "status": "implemented_reference"},
            {"name": "Estimator and confidence interval", "definition": "Point/interval estimators with assumptions, finite-sample/asymptotic status and confidence interpretation.", "signature": "data x model/profile -> estimate", "status": "implemented_reference"},
            {"name": "Hypothesis test and p-value record", "definition": "Test statistic, null/alternative, rejection rule, effect size and multiplicity policy are explicit; p-values are not posterior probabilities.", "signature": "data x hypotheses -> test record", "status": "specified_contract"},
            {"name": "Entropy and cross-entropy", "definition": "Shannon or declared entropy families over normalized distributions with log base and zero convention.", "signature": "distribution(s) -> scalar", "status": "implemented_reference"},
            {"name": "KL and Jensen-Shannon divergence", "definition": "Directed or symmetrized information divergence with absolute-continuity and zero-mass policy.", "signature": "P x Q -> nonnegative extended scalar", "status": "implemented_reference"},
            {"name": "Mutual information", "definition": "Information shared under a declared joint distribution; geometric overlap alone is not substituted for a distributional calculation.", "signature": "joint distribution -> scalar", "status": "implemented_reference"},
        ],
    ),
    (
        "optimization_numerics_constraints",
        "Optimization, numerical methods and constraints",
        [
            {"name": "Objective and feasible-set record", "definition": "Declares decision variables, objective direction, constraints, domains, scales and evaluation budget.", "signature": "model -> optimization problem", "status": "implemented_reference"},
            {"name": "Argmin and argmax", "definition": "Returns optimizer set/value under exact, finite or approximate search with tie and nonattainment status.", "signature": "function x domain -> optimizer record", "status": "implemented_reference"},
            {"name": "Gradient descent family", "definition": "Fixed, scheduled, momentum or adaptive first-order iteration with step, stopping and divergence contracts.", "signature": "objective x initial x profile -> iterate/status", "status": "implemented_reference"},
            {"name": "Newton and quasi-Newton family", "definition": "Uses Hessian/Jacobian or secant approximations with conditioning, damping and line-search safeguards.", "signature": "objective/system x initial -> iterate/status", "status": "specified_contract"},
            {"name": "Line search and trust region", "definition": "Selects accepted steps under sufficient-decrease/curvature or local-model radius rules and finite evaluation budget.", "signature": "model x direction -> step/status", "status": "specified_contract"},
            {"name": "Conjugate gradient and Krylov iteration", "definition": "Solves compatible linear systems using matrix-vector products with symmetry/positive-definite and residual contracts.", "signature": "A,b,initial -> x/status", "status": "specified_contract"},
            {"name": "Linear programming", "definition": "Linear objective and constraints with primal/dual feasibility, boundedness and certificate status.", "signature": "LP problem -> solution/certificate", "status": "specified_contract"},
            {"name": "Quadratic programming", "definition": "Quadratic objective with linear constraints and convexity/indefiniteness status.", "signature": "QP problem -> solution/status", "status": "specified_contract"},
            {"name": "Nonlinear constraint and KKT record", "definition": "Equality/inequality constraints, gradients, multipliers, complementarity and qualification status are explicit.", "signature": "problem x candidate -> KKT status", "status": "specified_contract"},
            {"name": "Lagrange multiplier and penalty family", "definition": "Builds constrained objectives through multipliers, augmented Lagrangians, barriers or penalties with parameter schedule.", "signature": "objective x constraints -> transformed problem", "status": "specified_contract"},
            {"name": "Root finding", "definition": "Bisection, secant, Newton or bracketed hybrid methods with interval, residual, derivative and termination certificate.", "signature": "f x bracket/initial -> root record", "status": "implemented_reference"},
            {"name": "Interpolation and approximation", "definition": "Piecewise linear, polynomial, spline or rational interpolation with node order, extrapolation and error/status contract.", "signature": "samples x query -> estimate", "status": "implemented_reference"},
            {"name": "Least squares and regression", "definition": "Linear/nonlinear fitting with weights, regularization, residuals, rank and validation status.", "signature": "design x observations -> model", "status": "implemented_reference"},
            {"name": "ODE and time-step solver", "definition": "Explicit/implicit single or multistep integration with local error, stability, event and step-budget profile.", "signature": "flow x state x time interval -> trajectory/status", "status": "implemented_reference"},
            {"name": "Interval arithmetic and certification", "definition": "Outward-bounded interval operations and relation classification prevent approximate values from crossing a guard unnoticed.", "signature": "interval operands -> enclosing interval", "status": "implemented_reference"},
            {"name": "Fixed-point iteration and convergence test", "definition": "Iterates x_{k+1}=F(x_k) with norm, contraction/monotonicity evidence, cycle detection and hard budget.", "signature": "F x initial x profile -> fixed-point status", "status": "implemented_reference"},
        ],
    ),
    (
        "geometry_topology_graphs",
        "Geometry, topology and graph operators",
        [
            {"name": "Affine transform", "definition": "Applies x -> A x + b with coordinate-frame, composition order and invertibility status.", "signature": "Affine x point/vector -> point/vector", "status": "implemented_reference"},
            {"name": "Rigid, similarity and projective transform", "definition": "Typed SE/Sim/projective maps with homogeneous-coordinate, normalization and orientation policy.", "signature": "transform x geometric object -> object", "status": "specified_contract"},
            {"name": "Metric and distance relation", "definition": "Declares a metric, pseudometric or general dissimilarity with executable law status and unit.", "signature": "point x point -> nonnegative scalar", "status": "implemented_reference"},
            {"name": "Implicit field and signed-distance relation", "definition": "Scalar inside/boundary/outside relation with exact-distance capability separately declared from generic implicit status.", "signature": "point -> residual/status", "status": "implemented_reference"},
            {"name": "Constructive solid geometry", "definition": "Union, intersection, difference and bounded smooth blends over field signs with exactness/topology status.", "signature": "fields -> field", "status": "implemented_reference"},
            {"name": "Curve and surface parameterization", "definition": "Maps parameter domains to ambient coordinates with derivative, regularity, periodicity and frame policy.", "signature": "parameters -> point", "status": "implemented_reference"},
            {"name": "Curvature, torsion and shape operator", "definition": "Local differential geometry with regularity, frame and numerical conditioning status.", "signature": "curve/surface x parameter -> geometric invariants", "status": "specified_contract"},
            {"name": "Manifold chart and transition map", "definition": "Stores local coordinates, overlap domains and cocycle-compatible transition functions; coordinates are not identity.", "signature": "chart x point -> coordinates; charts -> transition", "status": "specified_contract"},
            {"name": "Boundary, coboundary and incidence", "definition": "Cell/simplicial boundary and cochain coboundary maps with boundary-of-boundary zero validation.", "signature": "chain/cochain -> adjacent degree", "status": "implemented_reference"},
            {"name": "Homology, cohomology and persistence descriptor", "definition": "Bounded algebraic-topology summaries with coefficient ring, filtration and solver/certification status; they do not replace geometry or lineage.", "signature": "complex/filtration -> invariant record", "status": "specified_contract"},
            {"name": "Quotient, gluing and orientation transport", "definition": "Explicit port identification, coordinate map, sheet/orientation update and lineage patch; projected intersections are not automatic collisions.", "signature": "boundary event -> mapped state", "status": "implemented_reference"},
            {"name": "Graph, hypergraph and adjacency construction", "definition": "Stable node/edge identities, directedness, weights, labels and incidence are explicit.", "signature": "records -> graph", "status": "implemented_reference"},
            {"name": "Traversal, reachability and connected components", "definition": "Deterministic BFS/DFS and component queries with neighbor ordering, support and compatibility filters.", "signature": "graph x start/policy -> ordered reachability", "status": "implemented_reference"},
            {"name": "Shortest path and path algebra", "definition": "Dijkstra/Bellman-Ford/A* or semiring path evaluation with nonnegative/negative-cycle and heuristic contracts.", "signature": "graph x endpoints -> path/status", "status": "implemented_reference"},
            {"name": "Flow, cut and matching family", "definition": "Network flow, cut, bipartite matching and related finite combinatorial optimization with capacity/weight certificates.", "signature": "graph problem -> solution/status", "status": "specified_contract"},
            {"name": "Graph Laplacian and spectral operator", "definition": "Combinatorial/normalized Laplacian and spectral descriptors with ordering, multiplicity and numerical status.", "signature": "graph -> matrix/spectrum", "status": "specified_contract"},
        ],
    ),
    (
        "dynamics_control_events",
        "Dynamics, control and event operators",
        [
            {"name": "State-space model", "definition": "Typed state, input, output, parameters and time base for continuous or discrete dynamics.", "signature": "(state,input,time) -> derivative/next/output", "status": "implemented_reference"},
            {"name": "Continuous ODE flow", "definition": "Maps initial state through a declared differential flow analytically or with a bounded solver.", "signature": "flow x state x time -> state/status", "status": "implemented_reference"},
            {"name": "PDE operator and boundary conditions", "definition": "Spatial-temporal differential operator with domain, boundary/initial conditions, discretization and stability profile.", "signature": "field -> field evolution/status", "status": "specified_contract"},
            {"name": "Discrete map and recurrence", "definition": "State update x_{k+1}=F(x_k,u_k) with tick, seed, branch and lineage semantics.", "signature": "state x input -> next state", "status": "implemented_reference"},
            {"name": "Symplectic and structure-preserving step", "definition": "Integration profile intended to preserve selected geometric structure qualitatively/approximately under a declared step and error budget.", "signature": "Hamiltonian state x dt -> state", "status": "implemented_reference"},
            {"name": "Finite-state machine", "definition": "Finite modes, inputs, guards, transitions and outputs with deterministic priority and no hidden fallthrough.", "signature": "mode x input -> mode/output", "status": "implemented_reference"},
            {"name": "Hybrid automaton", "definition": "Continuous mode flows plus guarded discrete resets, priorities and invariant regions.", "signature": "hybrid state x time/input -> state/events", "status": "implemented_reference"},
            {"name": "Guard relation", "definition": "Scalar/Boolean/interval relation defines crossing, touch, tangency, coincidence or ambiguous status under a declared margin.", "signature": "state/time -> guard status", "status": "implemented_reference"},
            {"name": "Earliest event and root solver", "definition": "Finds the earliest certified guard event in a horizon after support and compatibility, with equal-time interval handling.", "signature": "trajectory x guards x horizon -> event/status", "status": "implemented_reference"},
            {"name": "Support predicate", "definition": "Finite local geometric, temporal, semantic or resource domain prunes irrelevant candidates before expensive relation work.", "signature": "candidate x query -> admission", "status": "implemented_reference"},
            {"name": "Compatibility predicate", "definition": "Typed mode, sheet, phase, orientation, ownership, policy, unit and schema conditions determine whether supported states may couple.", "signature": "state pair/context -> compatibility", "status": "implemented_reference"},
            {"name": "Event proposal record", "definition": "Candidate change contains ID, time/interval, type, source, priority, payload, guard status, error, confidence and lineage label.", "signature": "detector -> proposal", "status": "implemented_reference"},
            {"name": "Deterministic conflict resolution", "definition": "Verified proposals are stably ordered; incompatible same-target patches are merged only by a versioned commutative policy or explicitly rejected.", "signature": "proposal set -> accepted/rejected records", "status": "implemented_reference"},
            {"name": "Atomic transition and reset", "definition": "One verified patch updates state, route, topology or mode atomically and preserves declared invariants.", "signature": "state x event -> new state", "status": "implemented_reference"},
            {"name": "Checkpoint, replay and divergence detection", "definition": "Canonical snapshots plus ordered events reconstruct state and stop at the first pre/post hash mismatch.", "signature": "checkpoint x events -> state/divergence", "status": "implemented_reference"},
            {"name": "Lineage and irreducible novelty", "definition": "Persistent identity records seed/generative address, ordered transitions, external inputs and novelty that cannot be reconstructed from closed rules.", "signature": "event/patch -> lineage append", "status": "implemented_reference"},
        ],
    ),
    (
        "symbolic_proof_meta",
        "Symbolic rewrite, proof and metaprogramming",
        [
            {"name": "Symbol, binding and lexical scope", "definition": "Names bind to typed literals, variables or definitions in explicit scopes; capture and shadowing policies are serialized.", "signature": "environment x symbol -> binding", "status": "implemented_reference"},
            {"name": "Substitution", "definition": "Capture-avoiding replacement of free variables or pattern parameters with type and scope checks.", "signature": "term x substitution -> term", "status": "specified_contract"},
            {"name": "Alpha conversion", "definition": "Renames bound variables while preserving binding structure and semantic identity.", "signature": "term x fresh names -> equivalent term", "status": "specified_contract"},
            {"name": "Beta reduction and application", "definition": "Applies a function/lambda to arguments by capture-avoiding substitution under evaluation strategy and budget.", "signature": "function term x argument -> term", "status": "specified_contract"},
            {"name": "Simplification", "definition": "Applies scoped exact identities and neutral/absorbing rules without changing domain, branch or floating-order semantics.", "signature": "expression x law set -> expression", "status": "implemented_reference"},
            {"name": "Canonicalization", "definition": "Produces deterministic syntax/JSON form; commutative operand sorting occurs only when the type/law/exactness profile permits it.", "signature": "expression -> canonical expression", "status": "implemented_reference"},
            {"name": "Pattern matching", "definition": "Typed structural match with wildcards, guards, sequence variables and deterministic first/best-match policy.", "signature": "pattern x term -> bindings/status", "status": "specified_contract"},
            {"name": "Rewrite rule", "definition": "Directed equation with preconditions, priority, phase, termination hints and provenance; bidirectional equations are not silently oriented.", "signature": "term x rule -> term/status", "status": "implemented_reference"},
            {"name": "Term ordering", "definition": "Lexicographic path, degree/grade or custom well-founded order selects deterministic rewrite orientation and completion priorities.", "signature": "terms x order -> comparison", "status": "specified_contract"},
            {"name": "Common-subexpression elimination", "definition": "Identical pure content-addressed subgraphs share one node; effectful or context-dependent expressions are not merged.", "signature": "expression DAG -> shared DAG", "status": "implemented_reference"},
            {"name": "Differentiation and integration rule registry", "definition": "Operator definitions may expose symbolic derivative/antiderivative templates with branch and domain guards.", "signature": "operator x rule context -> transformed operator", "status": "specified_contract"},
            {"name": "Equation and inequality solving", "definition": "Returns exact, parameterized, interval or numerical solution sets with assumptions and completeness status.", "signature": "relations x variables -> solution record", "status": "specified_contract"},
            {"name": "Assumption and theorem context", "definition": "Stores hypotheses, axioms, definitions and imported certificates separately from conclusions and computational evidence.", "signature": "context x statement -> scoped statement", "status": "specified_contract"},
            {"name": "Proof obligation and certificate", "definition": "A transformation may emit law, type, domain, error or invariant obligations; discharge status is machine-readable and never inferred from confident prose.", "signature": "claim x context -> obligation/certificate", "status": "implemented_reference"},
            {"name": "Bounded recursion and grammar", "definition": "Recursive definitions require depth, symbol, stack, time or memory budgets and explicit cycle/fixed-point policy.", "signature": "seed x productions x budgets -> finite graph/status", "status": "implemented_reference"},
            {"name": "Operator generator and closure schema", "definition": "Meta-operators construct identity, constant, projection, composition, product, map, fold, derivative, adjoint, inverse and user-defined families, giving finite representation to open-ended operator classes.", "signature": "generator x definitions -> operator family", "status": "implemented_reference"},
        ],
    ),
    (
        "determinism_storage_exchange_ugts",
        "Determinism, compression, exchange and UGTS handoff",
        [
            {"name": "Canonical JSON and binary serialization", "definition": "Stable key order, number spelling, UTF-8 and typed binary profiles make records reproducible; NaN and implementation-specific objects require explicit encoding.", "signature": "record x profile -> bytes", "status": "implemented_reference"},
            {"name": "Definition and expression content hash", "definition": "SHA-256 over canonical records verifies identity and cache integrity; hashes are not semantic proofs or legal signatures.", "signature": "record -> digest", "status": "implemented_reference"},
            {"name": "DAG structural sharing", "definition": "Pure identical definitions and expressions are stored once and referenced by content address, preserving order and dependency lineage.", "signature": "graph -> deduplicated graph", "status": "implemented_reference"},
            {"name": "Seed plus parameter reconstruction", "definition": "Closed deterministic families may store seed, versioned operator graph and parameters instead of materialized samples; external novelty and checkpoints remain authoritative.", "signature": "seed x graph x params -> reconstructed state", "status": "implemented_reference"},
            {"name": "Opcode and codebook encoding", "definition": "Common operator IDs map to a versioned compact codebook; unknown codes reject and codebook changes require migration.", "signature": "operator IDs <-> compact words", "status": "implemented_reference"},
            {"name": "Exact round-trip contract", "definition": "Encode/decode must preserve canonical operator graph, order profile, parameters and required error metadata; size reduction alone is not compression proof.", "signature": "record -> bytes -> record", "status": "implemented_reference"},
            {"name": "Quantization profile", "definition": "Finite-width encoding declares range, step, saturation, special values and reconstruction error for every field.", "signature": "value x profile -> code/interval", "status": "implemented_reference"},
            {"name": "Interval and error propagation", "definition": "Operator-specific enclosures propagate uncertainty so support, compatibility and guard decisions can reject ambiguous results.", "signature": "input intervals x operator -> output interval", "status": "implemented_reference"},
            {"name": "Stable floating numerical profile", "definition": "Declares precision, rounding, fused-operation, signed-zero, denormal, transcendental and tolerance behavior; universal cross-platform bit identity is not assumed.", "signature": "runtime -> numerical capability record", "status": "implemented_reference"},
            {"name": "Parallel schedule and deterministic join", "definition": "Independent pure nodes may execute in parallel, but commits and reductions use recorded stable join/order policies and conflict checks.", "signature": "DAG x scheduler -> deterministic trace", "status": "implemented_reference"},
            {"name": "Capability and profile negotiation", "definition": "Peers or adapters exchange schema, operator IDs, exactness, order, precision and budget support before accepting an expression or replay.", "signature": "capability sets -> compatible profile/status", "status": "implemented_reference"},
            {"name": "Schema and catalog validation", "definition": "Validates required fields, unique IDs, contiguous merged mechanism range, content hashes, dependencies, precedence and example references.", "signature": "package records -> validation report", "status": "implemented_reference"},
            {"name": "Trace and explanation query", "definition": "Returns parse tree, resolved operators, types, phases, operand/result values, error status, proposal reasons and content hashes.", "signature": "evaluation -> deterministic trace", "status": "implemented_reference"},
            {"name": "Cost, memory and budget record", "definition": "Operators declare asymptotic class, bounded work, sample/iteration/depth limits and observed resource metrics separately from semantic output.", "signature": "operator/profile/run -> resource record", "status": "implemented_reference"},
            {"name": "Kill criteria and fallback policy", "definition": "Rejects or delegates when type/law/order is ambiguous, error exceeds margin, budgets overflow, performance loses at equal error or a conventional method is simpler.", "signature": "evaluation/profile -> continue/delegate/reject", "status": "implemented_reference"},
            {"name": "Canonical UGTS operator handoff", "definition": "Pure mathematical results and certificates feed local support, compatibility, guard classification, verified proposal, deterministic commit, transition and lineage; rendering and I/O remain downstream.", "signature": "operator result -> UGTS event sequence", "status": "implemented_reference", "provenance_class": "retained"},
        ],
    ),
]

assert len(DOMAINS) == 16
assert all(len(items) == 16 for _, _, items in DOMAINS)

# Common default metadata. Precedence is a semantic hint for symbolic entries and -1 otherwise.
PRECEDENCE_BY_DOMAIN = {
    "arithmetic_elementary": 60,
    "logic_order_theory": 30,
    "sets_relations_combinatorics": 50,
    "sequences_functional_aggregation": 95,
    "linear_algebra_tensors": 65,
    "hypercomplex_geometric_algebra": 65,
    "differential_calculus": 95,
    "integration_measure_transforms": 95,
    "probability_statistics_information": 95,
    "optimization_numerics_constraints": 95,
    "geometry_topology_graphs": 95,
    "dynamics_control_events": 10,
    "symbolic_proof_meta": 5,
    "determinism_storage_exchange_ugts": 0,
    "schema_typing": 0,
    "parse_evaluation_order": 0,
}

SOURCE_BASIS = {
    "schema_typing": ["UGTS-KC 3.6 definition records", "UGTS-KC 3.6.2 typed symbol separation"],
    "parse_evaluation_order": ["UGTS-KC 3.6 normative operation order", "KC Two Hands 3.0 deterministic system order"],
    "arithmetic_elementary": ["General mathematical normalization", "UGTS-GN numeric/encoding discipline"],
    "logic_order_theory": ["UGTS support/compatibility predicates", "UGTS-KC 2.0 event classification"],
    "sets_relations_combinatorics": ["UGTS finite grammar and relation algebra", "UGTS-KC 2.0 topology descriptors"],
    "sequences_functional_aggregation": ["UGTS finite ordered pipelines", "UGTS-KC 3.9 ordered systems"],
    "linear_algebra_tensors": ["UGTS-KC 2.0 kinematics and topology", "UGTS-KC 3.6.2 constraints and metrics"],
    "hypercomplex_geometric_algebra": ["UGTS-KC 2.0 quaternion/SE(3) calculus", "general algebra extension"],
    "differential_calculus": ["UGTS-KC 2.0 derivatives and frames", "UGTS-KC 3.6.2 log-polar calculus"],
    "integration_measure_transforms": ["UGTS field/signal extension", "general transform extension"],
    "probability_statistics_information": ["UGTS uncertainty/confidence records", "general statistical extension"],
    "optimization_numerics_constraints": ["UGTS-KC 2.0 numerical/event solving", "UGTS-KC 3.6.2 rank/nullity and intervals"],
    "geometry_topology_graphs": ["UGTS-KC 2.0 geometry/topology", "UGTS-KC 3.6.2 explicit gluing"],
    "dynamics_control_events": ["Canonical UGTS event calculus", "UGTS-KC 2.0 hybrid automata", "KC Two Hands 3.0 proposal/commit"],
    "symbolic_proof_meta": ["UGTS-KC 3.6 literal definitions and dependency graph", "general symbolic extension"],
    "determinism_storage_exchange_ugts": ["UGTS-GN precision/compression boundary", "UGTS-KC 3.6 content hashes", "KC Two Hands 3.0 replay", "UGTS-KC 4.1 seed storage discipline"],
}

records: list[dict[str, Any]] = []
mechanism = 630
for domain_key, domain_title, items in DOMAINS:
    for index, item in enumerate(items, start=1):
        name = item["name"]
        operator_id = f"ugts42.{domain_key}.{slug(name)}.v1"
        rec: dict[str, Any] = {
            "mechanism_id": f"M{mechanism}",
            "operator_id": operator_id,
            "domain_key": domain_key,
            "domain": domain_title,
            "domain_index": index,
            "name": name,
            "symbol": item.get("symbol", ""),
            "arity": item.get("arity", "family"),
            "signature": item.get("signature", "typed operands -> typed result/status"),
            "fixity": item.get("fixity", "functional_or_profile_defined"),
            "precedence": item.get("precedence", PRECEDENCE_BY_DOMAIN[domain_key]),
            "associativity": item.get("associativity", "profile_defined_or_not_applicable"),
            "laws": item.get("laws", []),
            "exactness": item.get("exactness", "typed_profile"),
            "evaluation_class": item.get("evaluation_class", "pure_or_declared_effect"),
            "definition": item["definition"],
            "integration": item.get(
                "integration",
                "Stored as a versioned literal definition, evaluated under the declared order profile, and handed to the canonical UGTS authority chain only when state change is requested.",
            ),
            "status": item.get("status", "specified_contract"),
            "provenance_class": item.get("provenance_class", "engineering-derived"),
            "source_basis": item.get("source_basis", SOURCE_BASIS[domain_key]),
            "version": "4.2.0",
        }
        rec["content_hash"] = content_hash(rec)
        records.append(rec)
        mechanism += 1

assert len(records) == 256
assert records[0]["mechanism_id"] == "M630"
assert records[-1]["mechanism_id"] == "M885"
assert len({r["operator_id"] for r in records}) == 256
assert len({r["content_hash"] for r in records}) == 256

catalog_obj = {
    "schema": "ugts-kc-general-operator-catalog-4.2",
    "version": "4.2.0",
    "title": "UGTS-KC 4.2 General Operator and Order Addendum catalog",
    "scope": "256 typed operator/order mechanisms across 16 domains; finite catalog plus open operator-family generators.",
    "mechanism_range": "M630-M885",
    "record_count": len(records),
    "evidence_boundary": "The catalog is a general engineering specification. It does not claim a finite document literally enumerates every future mathematical operator; open-ended coverage is provided by typed operator generators and extension namespaces.",
    "records": records,
}

for path in [SPEC / "operator_catalog_M630_M885.json", DATA / "operator_catalog.json"]:
    path.write_text(json.dumps(catalog_obj, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")

csv_fields = [
    "mechanism_id", "operator_id", "domain", "name", "signature", "fixity", "precedence",
    "associativity", "exactness", "evaluation_class", "status", "provenance_class",
    "definition", "integration", "source_basis", "content_hash"
]
with (SPEC / "operator_catalog_M630_M885.csv").open("w", encoding="utf-8", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=csv_fields)
    writer.writeheader()
    for rec in records:
        row = {k: rec.get(k, "") for k in csv_fields}
        row["source_basis"] = " | ".join(rec["source_basis"])
        writer.writerow(row)

summary = []
for domain_key, domain_title, _ in DOMAINS:
    subset = [r for r in records if r["domain_key"] == domain_key]
    summary.append({
        "domain_key": domain_key,
        "domain": domain_title,
        "range": f"{subset[0]['mechanism_id']}-{subset[-1]['mechanism_id']}",
        "count": len(subset),
        "implemented_reference": sum(r["status"] == "implemented_reference" for r in subset),
        "specified_contract": sum(r["status"] == "specified_contract" for r in subset),
        "representative": [r["name"] for r in subset[:4]],
    })
(SPEC / "operator_domain_summary.json").write_text(json.dumps({"version": "4.2.0", "domains": summary}, indent=2) + "\n", encoding="utf-8")

precedence_profiles = {
    "schema": "ugts-kc-precedence-profiles-4.2",
    "version": "4.2.0",
    "profiles": [
        {
            "id": "standard-math-4.2",
            "implicit_multiplication": False,
            "unary_minus_below_power": True,
            "levels_high_to_low": [
                {"name": "delimiters_application_indexing", "binding_power": 100, "associativity": "left"},
                {"name": "postfix_factorial_transpose", "binding_power": 90, "associativity": "left"},
                {"name": "power_root", "binding_power": 80, "associativity": "right"},
                {"name": "unary_sign_bitnot", "binding_power": 70, "associativity": "right"},
                {"name": "multiplication_division_modulo_contraction", "binding_power": 60, "associativity": "left"},
                {"name": "addition_subtraction", "binding_power": 50, "associativity": "left"},
                {"name": "set_relation_comparison_chain", "binding_power": 40, "associativity": "nonassociative_or_chain"},
                {"name": "logical_not", "binding_power": 35, "associativity": "right"},
                {"name": "logical_and", "binding_power": 30, "associativity": "left"},
                {"name": "logical_xor", "binding_power": 25, "associativity": "left"},
                {"name": "logical_or", "binding_power": 20, "associativity": "left"},
                {"name": "implication_equivalence", "binding_power": 15, "associativity": "right"},
                {"name": "conditional_case", "binding_power": 10, "associativity": "right"},
                {"name": "definition_assignment", "binding_power": 5, "associativity": "right"},
            ],
        },
        {
            "id": "python-safe-subset-4.2",
            "implicit_multiplication": False,
            "unary_minus_below_power": True,
            "description": "Uses the Python expression AST only as a safe syntactic carrier; calls are restricted to the bundled registry and no attribute access, comprehensions or arbitrary code execution is allowed.",
        },
        {
            "id": "explicit-ast-4.2",
            "implicit_multiplication": False,
            "description": "No precedence dependence: every expression is a JSON node with operator_id and ordered argument list. This is the canonical exchange profile.",
        },
    ],
}
for path in [SPEC / "precedence_profiles.json", DATA / "precedence_profiles.json"]:
    path.write_text(json.dumps(precedence_profiles, indent=2) + "\n", encoding="utf-8")

phases = {
    "schema": "ugts-kc-evaluation-schedule-4.2",
    "version": "4.2.0",
    "phases": [
        {"index": 0, "id": "parse", "purpose": "Parse literals, symbols and explicit grouping into an AST or load canonical AST."},
        {"index": 1, "id": "normalize", "purpose": "Normalize numbers, units, sign conventions, profiles and symbol aliases."},
        {"index": 2, "id": "resolve", "purpose": "Resolve operator/definition IDs, verify content hashes and reject missing references or undeclared cycles."},
        {"index": 3, "id": "type", "purpose": "Infer/check sorts, shapes, units, arity, domains and effect classes."},
        {"index": 4, "id": "rewrite", "purpose": "Apply only scoped exact rewrites and canonicalization permitted by declared laws."},
        {"index": 5, "id": "plan", "purpose": "Topologically order dependencies, choose kernels/algorithms and record reduction/composition order."},
        {"index": 6, "id": "evaluate", "purpose": "Evaluate pure exact and bounded approximate operator nodes with a deterministic trace."},
        {"index": 7, "id": "certify", "purpose": "Propagate intervals/error, discharge available proof obligations and classify numerical status."},
        {"index": 8, "id": "support", "purpose": "Prune by finite local geometric, temporal, semantic or resource support."},
        {"index": 9, "id": "compatibility", "purpose": "Check sheet, phase, mode, orientation, ownership, units, schema and application policy."},
        {"index": 10, "id": "guard", "purpose": "Classify crossing, touch, tangency, coincidence, interior, exterior or ambiguous relation status."},
        {"index": 11, "id": "proposal", "purpose": "Emit a typed candidate event or patch without mutating authority."},
        {"index": 12, "id": "commit", "purpose": "Deterministically order verified proposals, resolve conflicts and apply one atomic patch."},
        {"index": 13, "id": "lineage", "purpose": "Append pre/post hashes, transition identity, external novelty and replay information."},
        {"index": 14, "id": "projection", "purpose": "Optionally render, export, store or actuate downstream; projection never becomes mathematical or event authority."},
    ],
}
for path in [SPEC / "evaluation_phases.json", DATA / "evaluation_phases.json"]:
    path.write_text(json.dumps(phases, indent=2) + "\n", encoding="utf-8")

print(f"generated {len(records)} records: {records[0]['mechanism_id']}..{records[-1]['mechanism_id']}")
