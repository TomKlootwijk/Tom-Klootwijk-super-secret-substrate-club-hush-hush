from __future__ import annotations

import csv
import hashlib
import json
import os
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT_DIR = ROOT.parent
ZIP_PATH = OUT_DIR / f"{ROOT.name}_COMPLETE.zip"
PDF_COPY = OUT_DIR / "UGTS_KC_4_2_General_Operator_Order_Addendum.pdf"
DOCX_COPY = OUT_DIR / "UGTS_KC_4_2_General_Operator_Order_Addendum.docx"
SUMMARY_COPY = OUT_DIR / "UGTS_KC_4_2_General_Operator_Order_Addendum_RELEASE_SUMMARY.json"

SKIP_DIRS = {"__pycache__", ".git", ".pytest_cache", "build"}
SKIP_SUFFIXES = {".pyc", ".pyo", ".tmp", ".swp"}


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def included(path: Path) -> bool:
    rel = path.relative_to(ROOT)
    if any(part in SKIP_DIRS for part in rel.parts):
        return False
    if path.suffix in SKIP_SUFFIXES:
        return False
    return path.is_file()


def list_files(exclude_roots: tuple[str, ...] = ()) -> list[Path]:
    files: list[Path] = []
    for path in ROOT.rglob("*"):
        if not included(path):
            continue
        rel = path.relative_to(ROOT).as_posix()
        if any(rel == x or rel.startswith(x.rstrip("/") + "/") for x in exclude_roots):
            continue
        files.append(path)
    return sorted(files, key=lambda p: p.relative_to(ROOT).as_posix())


def main() -> None:
    manifest_dir = ROOT / "manifest"
    checksum_dir = ROOT / "checksums"
    manifest_dir.mkdir(exist_ok=True)
    checksum_dir.mkdir(exist_ok=True)
    for folder in (manifest_dir, checksum_dir):
        for p in folder.iterdir():
            if p.is_file():
                p.unlink()

    substantive = list_files(("manifest", "checksums"))
    rows = []
    for path in substantive:
        rel = path.relative_to(ROOT).as_posix()
        rows.append({"path": rel, "bytes": path.stat().st_size, "sha256": sha256_file(path)})

    manifest_json = {
        "schema": "ugts-kc42-file-manifest",
        "version": "4.2.0",
        "generated_utc": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "root": ROOT.name,
        "file_count_excluding_manifest_and_checksums": len(rows),
        "total_bytes_excluding_manifest_and_checksums": sum(r["bytes"] for r in rows),
        "files": rows,
    }
    (manifest_dir / "file_manifest.json").write_text(
        json.dumps(manifest_json, indent=2, sort_keys=True, ensure_ascii=True) + "\n",
        encoding="utf-8",
    )
    with (manifest_dir / "file_manifest.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["path", "bytes", "sha256"])
        writer.writeheader()
        writer.writerows(rows)

    current_files = list_files(("checksums",))
    tree_lines = [ROOT.name + "/"]
    for path in current_files:
        tree_lines.append("  " + path.relative_to(ROOT).as_posix())
    tree_lines.append("  checksums/SHA256SUMS.txt")
    (manifest_dir / "package_tree.txt").write_text("\n".join(tree_lines) + "\n", encoding="utf-8")

    all_except_checksum = list_files(("checksums/SHA256SUMS.txt",))
    checksum_lines = [
        f"{sha256_file(path)}  {path.relative_to(ROOT).as_posix()}"
        for path in all_except_checksum
    ]
    (checksum_dir / "SHA256SUMS.txt").write_text("\n".join(checksum_lines) + "\n", encoding="utf-8")

    # Verify the generated checksum list before packaging.
    for line in checksum_lines:
        digest, rel = line.split("  ", 1)
        if sha256_file(ROOT / rel) != digest:
            raise RuntimeError(f"checksum verification failed: {rel}")

    final_files = list_files()
    if ZIP_PATH.exists():
        ZIP_PATH.unlink()
    with zipfile.ZipFile(ZIP_PATH, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for path in final_files:
            arcname = f"{ROOT.name}/{path.relative_to(ROOT).as_posix()}"
            zf.write(path, arcname)

    source_pdf = ROOT / "report" / "UGTS_KC_4_2_General_Operator_Order_Addendum.pdf"
    source_docx = ROOT / "report" / "UGTS_KC_4_2_General_Operator_Order_Addendum.docx"
    PDF_COPY.write_bytes(source_pdf.read_bytes())
    DOCX_COPY.write_bytes(source_docx.read_bytes())

    validation_summary = json.loads((ROOT / "validation" / "validation_summary.json").read_text(encoding="utf-8"))
    release_summary = {
        "schema": "ugts-kc42-delivery-summary",
        "version": "4.2.0",
        "codename": "GOOA - General Operator and Order Addendum",
        "mechanism_range": "M630-M885",
        "operator_records": 256,
        "domains": 16,
        "automated_tests": validation_summary["metrics"]["automated_tests"],
        "overall_validation_pass": validation_summary["overall_pass"],
        "pdf": {
            "path": str(PDF_COPY),
            "bytes": PDF_COPY.stat().st_size,
            "sha256": sha256_file(PDF_COPY),
            "pages": 35,
        },
        "docx": {
            "path": str(DOCX_COPY),
            "bytes": DOCX_COPY.stat().st_size,
            "sha256": sha256_file(DOCX_COPY),
        },
        "zip": {
            "path": str(ZIP_PATH),
            "bytes": ZIP_PATH.stat().st_size,
            "sha256": sha256_file(ZIP_PATH),
            "file_count": len(final_files),
        },
        "boundary": "Finite 256-entry release plus open typed extension contracts; not a literal closure of all mathematics.",
    }
    SUMMARY_COPY.write_text(json.dumps(release_summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(release_summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
