from __future__ import annotations

import hashlib
import json
import math
from dataclasses import asdict, is_dataclass
from fractions import Fraction
from typing import Any


class CanonicalizationError(ValueError):
    """Raised when a value cannot be represented by the canonical profile."""


def _normalize_number(value: float) -> int | float:
    if not math.isfinite(value):
        raise CanonicalizationError("non-finite floats require an explicit tagged encoding")
    if value == 0.0:
        return 0
    if value.is_integer() and abs(value) <= 2**53:
        return int(value)
    return value


def normalize(value: Any) -> Any:
    """Normalize supported values into a deterministic JSON-compatible tree.

    Integral floats are normalized to integers, mappings are string-keyed and sorted
    by the serializer, sets receive a tagged deterministic encoding, and dataclasses
    are converted through ``asdict``. This is an integrity format, not a legal or
    cryptographic-signature scheme.
    """

    if is_dataclass(value):
        value = asdict(value)
    if value is None or isinstance(value, (bool, int, str)):
        return value
    if isinstance(value, float):
        return _normalize_number(value)
    if isinstance(value, Fraction):
        return {"$fraction": [value.numerator, value.denominator]}
    if isinstance(value, complex):
        return {"$complex": [normalize(value.real), normalize(value.imag)]}
    if isinstance(value, bytes):
        return {"$bytes_hex": value.hex()}
    if isinstance(value, tuple):
        return {"$tuple": [normalize(v) for v in value]}
    if isinstance(value, list):
        return [normalize(v) for v in value]
    if isinstance(value, (set, frozenset)):
        normalized = [normalize(v) for v in value]
        normalized.sort(key=lambda item: canonical_json(item))
        return {"$set": normalized}
    if isinstance(value, dict):
        result: dict[str, Any] = {}
        for key, item in value.items():
            if not isinstance(key, str):
                raise CanonicalizationError("canonical JSON mappings require string keys")
            result[key] = normalize(item)
        return result
    if hasattr(value, "to_canonical"):
        return normalize(value.to_canonical())
    raise CanonicalizationError(f"unsupported canonical value type: {type(value).__name__}")


def canonical_json(value: Any) -> str:
    return json.dumps(
        normalize(value),
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    )


def canonical_bytes(value: Any) -> bytes:
    return canonical_json(value).encode("utf-8")


def sha256_digest(value: Any) -> str:
    return "sha256:" + hashlib.sha256(canonical_bytes(value)).hexdigest()


def record_hash(record: dict[str, Any], hash_field: str = "content_hash") -> str:
    return sha256_digest({k: v for k, v in record.items() if k != hash_field})


def verify_record_hash(record: dict[str, Any], hash_field: str = "content_hash") -> bool:
    expected = record.get(hash_field)
    return isinstance(expected, str) and expected == record_hash(record, hash_field=hash_field)
