"""UGTS-KC 4.2 General Operator and Order Addendum reference runtime."""

from .canonical import canonical_json, sha256_digest
from .catalog import OperatorCatalog, OperatorRecord
from .evaluator import SafeEvaluator, evaluate
from .events import Proposal, commit_proposals, replay
from .interval import Interval

__all__ = [
    "OperatorCatalog",
    "OperatorRecord",
    "SafeEvaluator",
    "evaluate",
    "Interval",
    "Proposal",
    "commit_proposals",
    "replay",
    "canonical_json",
    "sha256_digest",
]

__version__ = "4.2.0"
