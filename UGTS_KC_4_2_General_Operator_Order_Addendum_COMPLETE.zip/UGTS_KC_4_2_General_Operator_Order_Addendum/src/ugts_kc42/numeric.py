from __future__ import annotations

import math
import random
from typing import Callable, Iterable, Sequence

Number = int | float


def sign(value: Number) -> int:
    return 1 if value > 0 else (-1 if value < 0 else 0)


def clamp(value: Number, lower: Number, upper: Number) -> Number:
    if lower > upper:
        raise ValueError("clamp lower bound exceeds upper bound")
    return min(max(value, lower), upper)


def mean(values: Sequence[Number]) -> float:
    if not values:
        raise ValueError("mean requires at least one value")
    return math.fsum(values) / len(values)


def variance(values: Sequence[Number], sample: bool = False) -> float:
    if not values:
        raise ValueError("variance requires at least one value")
    if sample and len(values) < 2:
        raise ValueError("sample variance requires at least two values")
    mu = mean(values)
    denom = len(values) - 1 if sample else len(values)
    return math.fsum((x - mu) ** 2 for x in values) / denom


def covariance(a: Sequence[Number], b: Sequence[Number], sample: bool = False) -> float:
    if len(a) != len(b) or not a:
        raise ValueError("covariance requires equal non-empty sequences")
    if sample and len(a) < 2:
        raise ValueError("sample covariance requires at least two observations")
    ma, mb = mean(a), mean(b)
    denom = len(a) - 1 if sample else len(a)
    return math.fsum((x - ma) * (y - mb) for x, y in zip(a, b)) / denom


def derivative(f: Callable[[float], float], x: float, h: float = 1e-6) -> float:
    if h <= 0:
        raise ValueError("derivative step must be positive")
    return (f(x + h) - f(x - h)) / (2.0 * h)


def gradient(f: Callable[[Sequence[float]], float], x: Sequence[float], h: float = 1e-6) -> list[float]:
    result = []
    base = list(map(float, x))
    for i in range(len(base)):
        plus = base.copy(); plus[i] += h
        minus = base.copy(); minus[i] -= h
        result.append((f(plus) - f(minus)) / (2.0 * h))
    return result


def jacobian(f: Callable[[Sequence[float]], Sequence[float]], x: Sequence[float], h: float = 1e-6) -> list[list[float]]:
    base = list(map(float, x))
    y0 = list(map(float, f(base)))
    result = [[0.0 for _ in base] for _ in y0]
    for j in range(len(base)):
        plus = base.copy(); plus[j] += h
        minus = base.copy(); minus[j] -= h
        yp = list(map(float, f(plus)))
        ym = list(map(float, f(minus)))
        if len(yp) != len(y0) or len(ym) != len(y0):
            raise ValueError("function output dimension changed during Jacobian evaluation")
        for i in range(len(y0)):
            result[i][j] = (yp[i] - ym[i]) / (2.0 * h)
    return result


def hessian(f: Callable[[Sequence[float]], float], x: Sequence[float], h: float = 1e-4) -> list[list[float]]:
    base = list(map(float, x))
    n = len(base)
    out = [[0.0] * n for _ in range(n)]
    f0 = f(base)
    for i in range(n):
        xp = base.copy(); xp[i] += h
        xm = base.copy(); xm[i] -= h
        out[i][i] = (f(xp) - 2.0 * f0 + f(xm)) / (h * h)
        for j in range(i + 1, n):
            xpp = base.copy(); xpp[i] += h; xpp[j] += h
            xpm = base.copy(); xpm[i] += h; xpm[j] -= h
            xmp = base.copy(); xmp[i] -= h; xmp[j] += h
            xmm = base.copy(); xmm[i] -= h; xmm[j] -= h
            value = (f(xpp) - f(xpm) - f(xmp) + f(xmm)) / (4.0 * h * h)
            out[i][j] = out[j][i] = value
    return out


def integrate_simpson(f: Callable[[float], float], a: float, b: float, steps: int = 256) -> float:
    if steps <= 0:
        raise ValueError("steps must be positive")
    if steps % 2:
        steps += 1
    h = (b - a) / steps
    total = f(a) + f(b)
    for i in range(1, steps):
        total += (4 if i % 2 else 2) * f(a + i * h)
    return total * h / 3.0


def bisection(f: Callable[[float], float], lower: float, upper: float, tolerance: float = 1e-12, max_iterations: int = 200) -> dict[str, float | int | str]:
    fl, fu = f(lower), f(upper)
    if fl == 0:
        return {"root": lower, "residual": 0.0, "iterations": 0, "status": "endpoint"}
    if fu == 0:
        return {"root": upper, "residual": 0.0, "iterations": 0, "status": "endpoint"}
    if fl * fu > 0:
        raise ValueError("bisection requires a sign-changing bracket")
    mid = lower
    fm = fl
    for iteration in range(1, max_iterations + 1):
        mid = (lower + upper) / 2.0
        fm = f(mid)
        if abs(fm) <= tolerance or (upper - lower) / 2.0 <= tolerance:
            return {"root": mid, "residual": fm, "iterations": iteration, "status": "converged"}
        if fl * fm <= 0:
            upper, fu = mid, fm
        else:
            lower, fl = mid, fm
    return {"root": mid, "residual": fm, "iterations": max_iterations, "status": "budget_exhausted"}


def gradient_descent(
    f: Callable[[Sequence[float]], float],
    initial: Sequence[float],
    step: float = 0.1,
    tolerance: float = 1e-9,
    max_iterations: int = 1000,
) -> dict[str, object]:
    if step <= 0:
        raise ValueError("step must be positive")
    x = list(map(float, initial))
    for iteration in range(max_iterations + 1):
        g = gradient(f, x)
        gnorm = math.sqrt(math.fsum(v * v for v in g))
        if gnorm <= tolerance:
            return {"point": x, "value": f(x), "gradient_norm": gnorm, "iterations": iteration, "status": "converged"}
        x = [xi - step * gi for xi, gi in zip(x, g)]
    return {"point": x, "value": f(x), "gradient_norm": gnorm, "iterations": max_iterations, "status": "budget_exhausted"}


def convolution(a: Sequence[Number], b: Sequence[Number]) -> list[float]:
    if not a or not b:
        return []
    out = [0.0] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            out[i + j] += x * y
    return out


def correlation(a: Sequence[Number], b: Sequence[Number]) -> list[float]:
    return convolution(a, list(reversed(b)))


def entropy(probabilities: Sequence[float], base: float = 2.0) -> float:
    if base <= 0 or base == 1:
        raise ValueError("invalid logarithm base")
    if any(p < 0 for p in probabilities):
        raise ValueError("negative probability")
    total = math.fsum(probabilities)
    if abs(total - 1.0) > 1e-9:
        raise ValueError("probabilities must sum to one")
    return -math.fsum(p * math.log(p, base) for p in probabilities if p > 0)


def kl_divergence(p: Sequence[float], q: Sequence[float], base: float = 2.0) -> float:
    if len(p) != len(q):
        raise ValueError("distribution lengths differ")
    if any(x < 0 for x in p) or any(x < 0 for x in q):
        raise ValueError("negative probability")
    if abs(math.fsum(p) - 1.0) > 1e-9 or abs(math.fsum(q) - 1.0) > 1e-9:
        raise ValueError("probabilities must sum to one")
    value = 0.0
    for pi, qi in zip(p, q):
        if pi == 0:
            continue
        if qi == 0:
            return math.inf
        value += pi * math.log(pi / qi, base)
    return value


def mutual_information(joint: Sequence[Sequence[float]], base: float = 2.0) -> float:
    if not joint or not joint[0]:
        raise ValueError("joint distribution cannot be empty")
    cols = len(joint[0])
    if any(len(row) != cols for row in joint):
        raise ValueError("ragged joint distribution")
    if any(p < 0 for row in joint for p in row):
        raise ValueError("negative probability")
    total = math.fsum(p for row in joint for p in row)
    if abs(total - 1.0) > 1e-9:
        raise ValueError("joint probabilities must sum to one")
    px = [math.fsum(row) for row in joint]
    py = [math.fsum(joint[i][j] for i in range(len(joint))) for j in range(cols)]
    mi = 0.0
    for i, row in enumerate(joint):
        for j, pxy in enumerate(row):
            if pxy > 0:
                mi += pxy * math.log(pxy / (px[i] * py[j]), base)
    return mi


def seeded_samples(seed: int, count: int) -> list[float]:
    if count < 0:
        raise ValueError("count must be non-negative")
    rng = random.Random(seed)
    return [rng.random() for _ in range(count)]
