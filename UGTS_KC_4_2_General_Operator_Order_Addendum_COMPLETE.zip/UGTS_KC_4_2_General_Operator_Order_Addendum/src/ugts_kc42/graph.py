from __future__ import annotations

import heapq
from collections import deque
from typing import Any, Hashable, Iterable, Mapping

Node = Hashable


def normalize_graph(graph: Mapping[Node, Any]) -> dict[Node, list[tuple[Node, float]]]:
    result: dict[Node, list[tuple[Node, float]]] = {}
    for node, neighbors in graph.items():
        entries: list[tuple[Node, float]] = []
        if isinstance(neighbors, Mapping):
            for target, weight in neighbors.items():
                entries.append((target, float(weight)))
        else:
            for item in neighbors:
                if isinstance(item, (tuple, list)) and len(item) == 2:
                    target, weight = item
                    entries.append((target, float(weight)))
                else:
                    entries.append((item, 1.0))
        entries.sort(key=lambda pair: (str(pair[0]), pair[1]))
        result[node] = entries
    return result


def reachability(graph: Mapping[Node, Any], start: Node) -> list[Node]:
    g = normalize_graph(graph)
    seen = {start}
    q = deque([start])
    order: list[Node] = []
    while q:
        node = q.popleft()
        order.append(node)
        for neighbor, _ in g.get(node, []):
            if neighbor not in seen:
                seen.add(neighbor)
                q.append(neighbor)
    return order


def shortest_path(graph: Mapping[Node, Any], start: Node, goal: Node) -> dict[str, object]:
    g = normalize_graph(graph)
    queue: list[tuple[float, str, Node]] = [(0.0, str(start), start)]
    distance: dict[Node, float] = {start: 0.0}
    previous: dict[Node, Node] = {}
    while queue:
        dist, _, node = heapq.heappop(queue)
        if dist != distance.get(node):
            continue
        if node == goal:
            break
        for neighbor, weight in g.get(node, []):
            if weight < 0:
                raise ValueError("reference Dijkstra path requires non-negative weights")
            candidate = dist + weight
            old = distance.get(neighbor)
            if old is None or candidate < old - 1e-15 or (abs(candidate - old) <= 1e-15 and str(node) < str(previous.get(neighbor, "~"))):
                distance[neighbor] = candidate
                previous[neighbor] = node
                heapq.heappush(queue, (candidate, str(neighbor), neighbor))
    if goal not in distance:
        return {"status": "unreachable", "path": [], "cost": None}
    path = [goal]
    while path[-1] != start:
        path.append(previous[path[-1]])
    path.reverse()
    return {"status": "ok", "path": path, "cost": distance[goal]}


def topological_sort(dependencies: Mapping[str, Iterable[str]], priorities: Mapping[str, int] | None = None) -> list[str]:
    priorities = priorities or {}
    nodes = set(dependencies)
    for deps in dependencies.values():
        nodes.update(deps)
    indegree = {n: 0 for n in nodes}
    outgoing = {n: [] for n in nodes}
    for node, deps in dependencies.items():
        for dep in deps:
            indegree[node] += 1
            outgoing[dep].append(node)
    ready = [(priorities.get(n, 0), n) for n, degree in indegree.items() if degree == 0]
    heapq.heapify(ready)
    result: list[str] = []
    while ready:
        _, node = heapq.heappop(ready)
        result.append(node)
        for target in sorted(outgoing[node]):
            indegree[target] -= 1
            if indegree[target] == 0:
                heapq.heappush(ready, (priorities.get(target, 0), target))
    if len(result) != len(nodes):
        cyclic = sorted(n for n, degree in indegree.items() if degree > 0)
        raise ValueError(f"dependency cycle detected: {cyclic}")
    return result
