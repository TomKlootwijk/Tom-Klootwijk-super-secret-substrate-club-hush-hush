from __future__ import annotations

import ast
import json
from importlib.resources import files
from typing import Any

from .canonical import sha256_digest


def load_precedence_profiles() -> dict[str, Any]:
    path = files("ugts_kc42.data").joinpath("precedence_profiles.json")
    return json.loads(path.read_text(encoding="utf-8"))


def load_evaluation_phases() -> dict[str, Any]:
    path = files("ugts_kc42.data").joinpath("evaluation_phases.json")
    return json.loads(path.read_text(encoding="utf-8"))


def ast_to_canonical(node: ast.AST) -> Any:
    if isinstance(node, ast.Expression):
        return {"kind": "expression", "body": ast_to_canonical(node.body)}
    if isinstance(node, ast.Constant):
        return {"kind": "literal", "value": node.value}
    if isinstance(node, ast.Name):
        return {"kind": "name", "id": node.id}
    if isinstance(node, ast.List):
        return {"kind": "list", "items": [ast_to_canonical(x) for x in node.elts]}
    if isinstance(node, ast.Tuple):
        return {"kind": "tuple", "items": [ast_to_canonical(x) for x in node.elts]}
    if isinstance(node, ast.Set):
        return {"kind": "set", "items": [ast_to_canonical(x) for x in node.elts]}
    if isinstance(node, ast.Dict):
        return {"kind": "dict", "items": [[ast_to_canonical(k), ast_to_canonical(v)] for k, v in zip(node.keys, node.values)]}
    if isinstance(node, ast.BinOp):
        return {"kind": "binary", "operator": type(node.op).__name__, "left": ast_to_canonical(node.left), "right": ast_to_canonical(node.right)}
    if isinstance(node, ast.UnaryOp):
        return {"kind": "unary", "operator": type(node.op).__name__, "operand": ast_to_canonical(node.operand)}
    if isinstance(node, ast.BoolOp):
        return {"kind": "boolean", "operator": type(node.op).__name__, "values": [ast_to_canonical(v) for v in node.values]}
    if isinstance(node, ast.Compare):
        return {"kind": "comparison_chain", "left": ast_to_canonical(node.left), "operators": [type(op).__name__ for op in node.ops], "comparators": [ast_to_canonical(x) for x in node.comparators]}
    if isinstance(node, ast.IfExp):
        return {"kind": "conditional", "test": ast_to_canonical(node.test), "then": ast_to_canonical(node.body), "else": ast_to_canonical(node.orelse)}
    if isinstance(node, ast.Call):
        if not isinstance(node.func, ast.Name):
            raise ValueError("only direct named calls are canonical in the safe subset")
        return {"kind": "call", "function": node.func.id, "args": [ast_to_canonical(a) for a in node.args], "keywords": [[kw.arg, ast_to_canonical(kw.value)] for kw in node.keywords]}
    if isinstance(node, ast.Subscript):
        return {"kind": "subscript", "value": ast_to_canonical(node.value), "slice": ast_to_canonical(node.slice)}
    if isinstance(node, ast.Slice):
        return {"kind": "slice", "lower": ast_to_canonical(node.lower) if node.lower else None, "upper": ast_to_canonical(node.upper) if node.upper else None, "step": ast_to_canonical(node.step) if node.step else None}
    raise ValueError(f"unsupported AST node for canonical exchange: {type(node).__name__}")


def parse_expression(expression: str) -> ast.Expression:
    tree = ast.parse(expression, mode="eval")
    if not isinstance(tree, ast.Expression):
        raise ValueError("expected an expression")
    return tree


def canonical_expression(expression: str) -> dict[str, Any]:
    return ast_to_canonical(parse_expression(expression))


def expression_hash(expression: str, profile: str = "python-safe-subset-4.2") -> str:
    return sha256_digest({"profile": profile, "ast": canonical_expression(expression)})
