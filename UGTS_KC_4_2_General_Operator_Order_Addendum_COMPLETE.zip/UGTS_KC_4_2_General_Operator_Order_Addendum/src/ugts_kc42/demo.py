from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any

from .canonical import record_hash, sha256_digest
from .catalog import OperatorCatalog
from .evaluator import SafeEvaluator
from .events import Proposal, commit_proposals, replay
from .graph import reachability, shortest_path, topological_sort
from .interval import Interval
from .linalg import determinant, solve
from .numeric import bisection, derivative, entropy, integrate_simpson, mutual_information
from .order import expression_hash, load_evaluation_phases
from .validation import validate_default_catalog, validate_profiles


def run_demo() -> dict[str, Any]:
    catalog = OperatorCatalog.load_default()
    expression = "clamp(dot([1, 2, 3], [4, 5, 6]) / 8 + sin(pi / 2) ** 2, 0, 10)"
    evaluator = SafeEvaluator()
    expression_record = evaluator.result_record(expression)

    interval_result = (Interval(1.0, 1.1) * Interval(2.0, 2.2) - 2.1).to_canonical()
    interval_class = Interval(interval_result["lower"], interval_result["upper"]).classify_zero(margin=0.01)

    matrix = [[3.0, 2.0], [1.0, 4.0]]
    linear = {
        "matrix": matrix,
        "determinant": determinant(matrix),
        "solve_b_[7,5]": solve(matrix, [7.0, 5.0]),
    }

    calculus = {
        "derivative_sin_at_0": derivative(math.sin, 0.0),
        "integral_x2_0_1": integrate_simpson(lambda x: x * x, 0.0, 1.0, 200),
        "sqrt2_root": bisection(lambda x: x * x - 2.0, 1.0, 2.0),
    }

    statistics = {
        "entropy_fair_bit": entropy([0.5, 0.5]),
        "mutual_information_perfect_bit": mutual_information([[0.5, 0.0], [0.0, 0.5]]),
    }

    graph = {
        "A": {"B": 1.0, "C": 4.0},
        "B": {"C": 1.0, "D": 5.0},
        "C": {"D": 1.0},
        "D": {},
    }
    graph_result = {
        "reachability": reachability(graph, "A"),
        "shortest_path": shortest_path(graph, "A", "D"),
    }

    dependencies = {"parse": [], "type": ["parse"], "evaluate": ["type"], "certify": ["evaluate"], "commit": ["certify"]}
    dependency_order = topological_sort(dependencies)

    initial_state = {"world": {"value": 0, "mode": "idle"}}
    proposals = [
        Proposal("p-low", 1.0, "set", "world", {"world.value": 7}, source="beta", priority=1, lineage_label="low"),
        Proposal("p-high", 1.0, "set", "world", {"world.value": 9}, source="alpha", priority=5, lineage_label="winner"),
        Proposal("p-mode", 1.0, "mode", "world", {"world.mode": "active"}, source="alpha", priority=2, lineage_label="mode"),
        Proposal("p-bad", 2.0, "set", "world", {"world.value": 12}, support_ok=False, lineage_label="rejected"),
    ]
    committed = commit_proposals(initial_state, proposals)
    replayed = replay(initial_state, committed.accepted)
    events = {
        "initial_hash": sha256_digest(initial_state),
        "accepted": committed.accepted,
        "rejected": committed.rejected,
        "final_state": committed.state,
        "final_hash": sha256_digest(committed.state),
        "replay_hash": sha256_digest(replayed),
    }

    phases = load_evaluation_phases()["phases"]
    result = {
        "schema": "ugts-kc-general-operator-demo-4.2",
        "version": "4.2.0",
        "catalog": {
            "records": len(catalog.records),
            "domains": catalog.domain_summary(),
            "catalog_validation": validate_default_catalog(),
            "profile_validation": validate_profiles(),
        },
        "expression": expression_record,
        "expression_hash_repeat": expression_hash(expression),
        "interval": {"result": interval_result, "zero_class": interval_class},
        "linear_algebra": linear,
        "calculus": calculus,
        "statistics": statistics,
        "graph": graph_result,
        "dependency_order": dependency_order,
        "events": events,
        "phase_ids": [p["id"] for p in phases],
    }
    result["content_hash"] = sha256_digest(result)
    return result


def write_demo(path: str | Path) -> dict[str, Any]:
    result = run_demo()
    Path(path).write_text(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=True) + "\n", encoding="utf-8")
    return result
