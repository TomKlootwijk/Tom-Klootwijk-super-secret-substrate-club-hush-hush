from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Sequence

from .canonical import sha256_digest
from .catalog import OperatorCatalog
from .demo import write_demo
from .evaluator import SafeEvaluator
from .validation import load_and_validate_project, validate_default_catalog, validate_profiles


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="ugts-kc42", description="UGTS-KC 4.2 general operator/order reference CLI")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("info", help="print release and catalog information")

    p_catalog = sub.add_parser("catalog", help="search or summarize the 256-entry catalog")
    p_catalog.add_argument("--search", default="")
    p_catalog.add_argument("--json", action="store_true")

    p_eval = sub.add_parser("eval", help="evaluate a safe mathematical expression")
    p_eval.add_argument("expression")
    p_eval.add_argument("--trace", action="store_true")

    p_validate = sub.add_parser("validate", help="validate default catalogs/profiles or a project JSON")
    p_validate.add_argument("project", nargs="?")

    p_hash = sub.add_parser("hash", help="hash literal text or a JSON file")
    p_hash.add_argument("value")
    p_hash.add_argument("--json-file", action="store_true")

    p_demo = sub.add_parser("demo", help="write the deterministic demonstration JSON")
    p_demo.add_argument("output")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "info":
        catalog = OperatorCatalog.load_default()
        payload = {
            "version": "4.2.0",
            "codename": "General Operator and Order Addendum",
            "operator_records": len(catalog.records),
            "domain_count": len(catalog.domain_summary()),
            "mechanism_range": "M630-M885",
            "canonical_handoff": "support -> compatibility -> guard -> verified proposal -> deterministic commit -> transition -> lineage",
        }
        print(json.dumps(payload, indent=2))
        return 0
    if args.command == "catalog":
        catalog = OperatorCatalog.load_default()
        if args.search:
            records = catalog.search(args.search)
            payload = [r.raw for r in records]
        else:
            payload = catalog.domain_summary()
        if args.json:
            print(json.dumps(payload, indent=2, ensure_ascii=True))
        else:
            if isinstance(payload, dict):
                for key, value in payload.items():
                    print(f"{key}: {value}")
            else:
                for row in payload:
                    print(f"{row['mechanism_id']} {row['operator_id']} - {row['name']}")
        return 0
    if args.command == "eval":
        evaluator = SafeEvaluator()
        if args.trace:
            print(json.dumps(evaluator.result_record(args.expression), indent=2, default=str, ensure_ascii=True))
        else:
            print(json.dumps(evaluator.evaluate(args.expression), default=str, ensure_ascii=True))
        return 0
    if args.command == "validate":
        payload = {
            "catalog": validate_default_catalog(),
            "profiles": validate_profiles(),
        }
        if args.project:
            payload["project"] = load_and_validate_project(args.project)
        print(json.dumps(payload, indent=2))
        return 0 if all(v.get("valid", False) for v in payload.values()) else 1
    if args.command == "hash":
        value = json.loads(Path(args.value).read_text(encoding="utf-8")) if args.json_file else args.value
        print(sha256_digest(value))
        return 0
    if args.command == "demo":
        result = write_demo(args.output)
        print(json.dumps({"output": args.output, "content_hash": result["content_hash"]}, indent=2))
        return 0
    return 2
