from __future__ import annotations

import math
from typing import Iterable, Sequence

Number = int | float | complex
Vector = Sequence[Number]
Matrix = Sequence[Sequence[Number]]


def _same_length(a: Sequence[object], b: Sequence[object]) -> None:
    if len(a) != len(b):
        raise ValueError("dimension mismatch")


def vector_add(a: Vector, b: Vector) -> list[Number]:
    _same_length(a, b)
    return [x + y for x, y in zip(a, b)]


def scalar_mul(s: Number, v: Vector) -> list[Number]:
    return [s * x for x in v]


def dot(a: Vector, b: Vector) -> Number:
    _same_length(a, b)
    return sum((x.conjugate() if isinstance(x, complex) else x) * y for x, y in zip(a, b))


def norm(v: Vector, p: float = 2.0) -> float:
    if p <= 0:
        raise ValueError("p must be positive")
    if p == math.inf:
        return max((abs(x) for x in v), default=0.0)
    return float(sum(abs(x) ** p for x in v) ** (1.0 / p))


def normalize(v: Vector, floor: float = 1e-15) -> list[Number]:
    n = norm(v)
    if n <= floor:
        raise ValueError("cannot normalize a near-zero vector")
    return [x / n for x in v]


def cross(a: Vector, b: Vector) -> list[Number]:
    if len(a) != 3 or len(b) != 3:
        raise ValueError("the reference cross product requires 3D vectors")
    return [
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    ]


def transpose(a: Matrix) -> list[list[Number]]:
    if not a:
        return []
    width = len(a[0])
    if any(len(row) != width for row in a):
        raise ValueError("ragged matrix")
    return [list(col) for col in zip(*a)]


def matmul(a: Matrix, b: Matrix) -> list[list[Number]]:
    if not a or not b:
        return []
    bt = transpose(b)
    if len(a[0]) != len(b):
        raise ValueError("matrix inner dimensions do not match")
    return [[sum(x * y for x, y in zip(row, col)) for col in bt] for row in a]


def trace(a: Matrix) -> Number:
    if any(len(row) != len(a) for row in a):
        raise ValueError("trace requires a square matrix")
    return sum(a[i][i] for i in range(len(a)))


def determinant(a: Matrix) -> Number:
    n = len(a)
    if any(len(row) != n for row in a):
        raise ValueError("determinant requires a square matrix")
    if n == 0:
        return 1
    m = [list(map(complex, row)) for row in a]
    det: complex = 1 + 0j
    sign = 1
    for col in range(n):
        pivot = max(range(col, n), key=lambda r: abs(m[r][col]))
        if abs(m[pivot][col]) <= 1e-15:
            return 0
        if pivot != col:
            m[col], m[pivot] = m[pivot], m[col]
            sign *= -1
        pv = m[col][col]
        det *= pv
        for row in range(col + 1, n):
            factor = m[row][col] / pv
            for j in range(col + 1, n):
                m[row][j] -= factor * m[col][j]
    det *= sign
    if abs(det.imag) <= 1e-12:
        real = det.real
        return int(round(real)) if abs(real - round(real)) <= 1e-12 else real
    return det


def solve(a: Matrix, b: Vector) -> list[Number]:
    n = len(a)
    if len(b) != n or any(len(row) != n for row in a):
        raise ValueError("solve requires square A and matching b")
    m = [list(map(complex, row)) + [complex(bi)] for row, bi in zip(a, b)]
    for col in range(n):
        pivot = max(range(col, n), key=lambda r: abs(m[r][col]))
        if abs(m[pivot][col]) <= 1e-15:
            raise ValueError("singular matrix")
        m[col], m[pivot] = m[pivot], m[col]
        pv = m[col][col]
        m[col] = [x / pv for x in m[col]]
        for row in range(n):
            if row == col:
                continue
            factor = m[row][col]
            m[row] = [x - factor * y for x, y in zip(m[row], m[col])]
    result: list[Number] = []
    for row in m:
        value = row[-1]
        if abs(value.imag) <= 1e-12:
            real = value.real
            result.append(int(round(real)) if abs(real - round(real)) <= 1e-12 else real)
        else:
            result.append(value)
    return result


def rank(a: Matrix, tolerance: float = 1e-12) -> int:
    if not a:
        return 0
    m = [list(map(float, row)) for row in a]
    rows, cols = len(m), len(m[0])
    if any(len(row) != cols for row in m):
        raise ValueError("ragged matrix")
    r = 0
    for c in range(cols):
        pivot = max(range(r, rows), key=lambda i: abs(m[i][c]), default=r)
        if r >= rows or abs(m[pivot][c]) <= tolerance:
            continue
        m[r], m[pivot] = m[pivot], m[r]
        pv = m[r][c]
        m[r] = [x / pv for x in m[r]]
        for i in range(rows):
            if i != r:
                factor = m[i][c]
                m[i] = [x - factor * y for x, y in zip(m[i], m[r])]
        r += 1
        if r == rows:
            break
    return r


def kronecker(a: Matrix, b: Matrix) -> list[list[Number]]:
    if not a or not b:
        return []
    return [
        [aij * bij for aij in arow for bij in brow]
        for arow in a
        for brow in b
    ]
