from __future__ import annotations

import json
from dataclasses import dataclass
from importlib.resources import files
from typing import Any, Iterable

from .canonical import verify_record_hash
from .graph import topological_sort


@dataclass(frozen=True)
class OperatorRecord:
    mechanism_id: str
    operator_id: str
    domain: str
    name: str
    signature: str
    definition: str
    status: str
    content_hash: str
    raw: dict[str, Any]

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "OperatorRecord":
        return cls(
            mechanism_id=data["mechanism_id"],
            operator_id=data["operator_id"],
            domain=data["domain"],
            name=data["name"],
            signature=data["signature"],
            definition=data["definition"],
            status=data["status"],
            content_hash=data["content_hash"],
            raw=data,
        )


class OperatorCatalog:
    def __init__(self, records: Iterable[dict[str, Any]], metadata: dict[str, Any] | None = None) -> None:
        self.metadata = metadata or {}
        self.records = [OperatorRecord.from_dict(dict(r)) for r in records]
        self.by_operator_id = {r.operator_id: r for r in self.records}
        self.by_mechanism_id = {r.mechanism_id: r for r in self.records}

    @classmethod
    def load_default(cls) -> "OperatorCatalog":
        path = files("ugts_kc42.data").joinpath("operator_catalog.json")
        obj = json.loads(path.read_text(encoding="utf-8"))
        return cls(obj["records"], metadata={k: v for k, v in obj.items() if k != "records"})

    def validate(self) -> list[str]:
        errors: list[str] = []
        if len(self.records) != 256:
            errors.append(f"expected 256 records, found {len(self.records)}")
        if len(self.by_operator_id) != len(self.records):
            errors.append("duplicate operator_id")
        if len(self.by_mechanism_id) != len(self.records):
            errors.append("duplicate mechanism_id")
        numeric_ids = []
        for rec in self.records:
            if not verify_record_hash(rec.raw):
                errors.append(f"bad content hash: {rec.operator_id}")
            if not rec.mechanism_id.startswith("M") or not rec.mechanism_id[1:].isdigit():
                errors.append(f"bad mechanism ID: {rec.mechanism_id}")
            else:
                numeric_ids.append(int(rec.mechanism_id[1:]))
        if numeric_ids and numeric_ids != list(range(630, 886)):
            errors.append("mechanism IDs are not contiguous M630-M885")
        return errors

    def domain_summary(self) -> dict[str, int]:
        result: dict[str, int] = {}
        for record in self.records:
            result[record.domain] = result.get(record.domain, 0) + 1
        return dict(sorted(result.items()))

    def search(self, text: str) -> list[OperatorRecord]:
        query = text.casefold()
        return [
            r for r in self.records
            if query in r.name.casefold() or query in r.definition.casefold() or query in r.domain.casefold()
        ]

    def dependency_order(self, operator_ids: Iterable[str]) -> list[str]:
        selected = set(operator_ids)
        deps: dict[str, list[str]] = {}
        for oid in selected:
            rec = self.by_operator_id[oid]
            deps[oid] = [d for d in rec.raw.get("dependencies", []) if d in selected]
        return topological_sort(deps)
