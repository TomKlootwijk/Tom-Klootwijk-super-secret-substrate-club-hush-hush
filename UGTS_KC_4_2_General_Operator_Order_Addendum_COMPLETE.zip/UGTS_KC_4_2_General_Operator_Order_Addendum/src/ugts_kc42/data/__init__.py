"""Bundled machine-readable operator and order profiles."""
