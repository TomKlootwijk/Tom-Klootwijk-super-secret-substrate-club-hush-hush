from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable

from .canonical import sha256_digest


@dataclass(frozen=True)
class Proposal:
    proposal_id: str
    event_time: float
    event_type: str
    target: str
    patch: dict[str, Any]
    source: str = "reference"
    priority: int = 0
    support_ok: bool = True
    compatibility_ok: bool = True
    guard_status: str = "crossing"
    confidence: float = 1.0
    confidence_floor: float = 0.0
    numeric_error: float = 0.0
    event_margin: float = 0.0
    lineage_label: str = ""

    def verification_reasons(self, accepted_guard_statuses: set[str]) -> list[str]:
        reasons = []
        if not self.support_ok:
            reasons.append("outside_support")
        if not self.compatibility_ok:
            reasons.append("incompatible")
        if self.guard_status not in accepted_guard_statuses:
            reasons.append(f"guard_{self.guard_status}")
        if self.confidence < self.confidence_floor:
            reasons.append("confidence_below_floor")
        if self.numeric_error > self.event_margin:
            reasons.append("numeric_error_exceeds_margin")
        return reasons


@dataclass
class CommitResult:
    state: dict[str, Any]
    accepted: list[dict[str, Any]] = field(default_factory=list)
    rejected: list[dict[str, Any]] = field(default_factory=list)
    lineage: list[dict[str, Any]] = field(default_factory=list)


def _set_path(state: dict[str, Any], path: str, value: Any) -> None:
    parts = path.split(".") if path else []
    if not parts:
        raise ValueError("patch path cannot be empty")
    cursor: dict[str, Any] = state
    for part in parts[:-1]:
        next_value = cursor.get(part)
        if next_value is None:
            next_value = {}
            cursor[part] = next_value
        if not isinstance(next_value, dict):
            raise ValueError(f"patch path crosses non-mapping field: {part}")
        cursor = next_value
    cursor[parts[-1]] = value


def commit_proposals(
    initial_state: dict[str, Any],
    proposals: Iterable[Proposal],
    accepted_guard_statuses: set[str] | None = None,
) -> CommitResult:
    accepted_guard_statuses = accepted_guard_statuses or {"crossing", "touch", "exact_zero"}
    state = _deepcopy_json(initial_state)
    result = CommitResult(state=state)
    ordered = sorted(proposals, key=lambda p: (p.event_time, -p.priority, p.source, p.proposal_id))
    claimed: dict[tuple[float, str, str], str] = {}
    sequence = 0
    for proposal in ordered:
        reasons = proposal.verification_reasons(accepted_guard_statuses)
        if reasons:
            result.rejected.append({"proposal_id": proposal.proposal_id, "reasons": reasons})
            continue
        conflicts = []
        for path in proposal.patch:
            key = (proposal.event_time, proposal.target, path)
            if key in claimed:
                conflicts.append({"path": path, "winner": claimed[key]})
        if conflicts:
            result.rejected.append({"proposal_id": proposal.proposal_id, "reasons": ["patch_conflict"], "conflicts": conflicts})
            continue
        pre_hash = sha256_digest(state)
        for path, value in sorted(proposal.patch.items()):
            _set_path(state, path, value)
            claimed[(proposal.event_time, proposal.target, path)] = proposal.proposal_id
        post_hash = sha256_digest(state)
        sequence += 1
        event = {
            "sequence": sequence,
            "proposal_id": proposal.proposal_id,
            "event_time": proposal.event_time,
            "event_type": proposal.event_type,
            "target": proposal.target,
            "patch": dict(sorted(proposal.patch.items())),
            "pre_hash": pre_hash,
            "post_hash": post_hash,
            "lineage_label": proposal.lineage_label,
        }
        result.accepted.append(event)
        result.lineage.append({"sequence": sequence, "proposal_id": proposal.proposal_id, "pre_hash": pre_hash, "post_hash": post_hash, "label": proposal.lineage_label})
    return result


def replay(initial_state: dict[str, Any], events: Iterable[dict[str, Any]]) -> dict[str, Any]:
    state = _deepcopy_json(initial_state)
    for event in sorted(events, key=lambda e: e["sequence"]):
        if sha256_digest(state) != event["pre_hash"]:
            raise ValueError(f"replay divergence before sequence {event['sequence']}")
        for path, value in event["patch"].items():
            _set_path(state, path, value)
        if sha256_digest(state) != event["post_hash"]:
            raise ValueError(f"replay divergence after sequence {event['sequence']}")
    return state


def _deepcopy_json(value: Any) -> Any:
    if isinstance(value, dict):
        return {k: _deepcopy_json(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_deepcopy_json(v) for v in value]
    if isinstance(value, tuple):
        return tuple(_deepcopy_json(v) for v in value)
    return value
