from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Iterable


@dataclass(frozen=True, order=True)
class Interval:
    lower: float
    upper: float

    def __post_init__(self) -> None:
        if not math.isfinite(self.lower) or not math.isfinite(self.upper):
            raise ValueError("interval endpoints must be finite in the reference profile")
        if self.lower > self.upper:
            raise ValueError("interval lower endpoint exceeds upper endpoint")

    @classmethod
    def point(cls, value: float) -> "Interval":
        return cls(float(value), float(value))

    @classmethod
    def hull(cls, intervals: Iterable["Interval"]) -> "Interval":
        items = list(intervals)
        if not items:
            raise ValueError("cannot form the hull of an empty interval collection")
        return cls(min(i.lower for i in items), max(i.upper for i in items))

    @property
    def width(self) -> float:
        return self.upper - self.lower

    @property
    def midpoint(self) -> float:
        return (self.lower + self.upper) / 2.0

    def contains(self, value: float) -> bool:
        return self.lower <= value <= self.upper

    def overlaps(self, other: "Interval") -> bool:
        return not (self.upper < other.lower or other.upper < self.lower)

    def classify_zero(self, margin: float = 0.0) -> str:
        if margin < 0:
            raise ValueError("margin must be non-negative")
        if self.upper < -margin:
            return "negative"
        if self.lower > margin:
            return "positive"
        if self.lower == 0.0 and self.upper == 0.0:
            return "exact_zero"
        return "ambiguous_guard"

    def __add__(self, other: float | "Interval") -> "Interval":
        other = other if isinstance(other, Interval) else Interval.point(other)
        return Interval(self.lower + other.lower, self.upper + other.upper)

    __radd__ = __add__

    def __neg__(self) -> "Interval":
        return Interval(-self.upper, -self.lower)

    def __sub__(self, other: float | "Interval") -> "Interval":
        other = other if isinstance(other, Interval) else Interval.point(other)
        return self + (-other)

    def __rsub__(self, other: float | "Interval") -> "Interval":
        return Interval.point(other) - self

    def __mul__(self, other: float | "Interval") -> "Interval":
        other = other if isinstance(other, Interval) else Interval.point(other)
        products = (
            self.lower * other.lower,
            self.lower * other.upper,
            self.upper * other.lower,
            self.upper * other.upper,
        )
        return Interval(min(products), max(products))

    __rmul__ = __mul__

    def reciprocal(self) -> "Interval":
        if self.contains(0.0):
            raise ZeroDivisionError("interval division crosses zero")
        values = (1.0 / self.lower, 1.0 / self.upper)
        return Interval(min(values), max(values))

    def __truediv__(self, other: float | "Interval") -> "Interval":
        other = other if isinstance(other, Interval) else Interval.point(other)
        return self * other.reciprocal()

    def square(self) -> "Interval":
        if self.contains(0.0):
            return Interval(0.0, max(self.lower * self.lower, self.upper * self.upper))
        values = (self.lower * self.lower, self.upper * self.upper)
        return Interval(min(values), max(values))

    def sqrt(self) -> "Interval":
        if self.lower < 0:
            raise ValueError("sqrt interval crosses the negative domain")
        return Interval(math.sqrt(self.lower), math.sqrt(self.upper))

    def exp(self) -> "Interval":
        return Interval(math.exp(self.lower), math.exp(self.upper))

    def log(self) -> "Interval":
        if self.lower <= 0:
            raise ValueError("log interval crosses non-positive values")
        return Interval(math.log(self.lower), math.log(self.upper))

    def to_canonical(self) -> dict[str, object]:
        return {"lower": self.lower, "upper": self.upper, "width": self.width}
