from __future__ import annotations

import ast
import math
import operator
from dataclasses import dataclass, asdict
from functools import reduce
from typing import Any, Callable, Mapping

from .canonical import sha256_digest
from .linalg import cross, determinant, dot, kronecker, matmul, norm, normalize, rank, solve, trace as matrix_trace, transpose
from .numeric import clamp, convolution, correlation, covariance, entropy, kl_divergence, mean, mutual_information, seeded_samples, sign, variance
from .order import canonical_expression, expression_hash, parse_expression


class EvaluationError(ValueError):
    pass


@dataclass
class TraceEntry:
    sequence: int
    node: str
    operator: str
    inputs: Any
    result: Any
    result_type: str


SAFE_CONSTANTS: dict[str, Any] = {
    "pi": math.pi,
    "e": math.e,
    "tau": math.tau,
    "inf": math.inf,
    "True": True,
    "False": False,
    "None": None,
}


def _prod(values: Any, start: Any = 1) -> Any:
    return math.prod(values, start=start)


def _lcm(*values: int) -> int:
    return math.lcm(*values)


def _choose(n: int, k: int) -> int:
    return math.comb(n, k)


def _approx(a: float, b: float, abs_tol: float = 1e-9, rel_tol: float = 1e-9) -> bool:
    return math.isclose(a, b, abs_tol=abs_tol, rel_tol=rel_tol)


def _set_union(*values: set[Any]) -> set[Any]:
    result: set[Any] = set()
    for value in values:
        result |= set(value)
    return result


def _set_intersection(first: set[Any], *rest: set[Any]) -> set[Any]:
    result = set(first)
    for value in rest:
        result &= set(value)
    return result


SAFE_FUNCTIONS: dict[str, Callable[..., Any]] = {
    "abs": abs,
    "min": min,
    "max": max,
    "round": round,
    "floor": math.floor,
    "ceil": math.ceil,
    "trunc": math.trunc,
    "sqrt": math.sqrt,
    "exp": math.exp,
    "log": math.log,
    "log2": math.log2,
    "log10": math.log10,
    "sin": math.sin,
    "cos": math.cos,
    "tan": math.tan,
    "asin": math.asin,
    "acos": math.acos,
    "atan": math.atan,
    "atan2": math.atan2,
    "sinh": math.sinh,
    "cosh": math.cosh,
    "tanh": math.tanh,
    "factorial": math.factorial,
    "gamma": math.gamma,
    "gcd": math.gcd,
    "lcm": _lcm,
    "comb": _choose,
    "clamp": clamp,
    "sign": sign,
    "sum": sum,
    "prod": _prod,
    "mean": mean,
    "variance": variance,
    "covariance": covariance,
    "dot": dot,
    "cross": cross,
    "norm": norm,
    "normalize": normalize,
    "transpose": transpose,
    "matmul": matmul,
    "det": determinant,
    "trace": matrix_trace,
    "solve": solve,
    "rank": rank,
    "kronecker": kronecker,
    "convolution": convolution,
    "correlation": correlation,
    "entropy": entropy,
    "kl": kl_divergence,
    "mutual_information": mutual_information,
    "seeded_samples": seeded_samples,
    "approx": _approx,
    "union": _set_union,
    "intersection": _set_intersection,
    "len": len,
    "sorted": sorted,
    "set": set,
    "tuple": tuple,
    "list": list,
}

BINOPS: dict[type[ast.operator], Callable[[Any, Any], Any]] = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
    ast.BitOr: operator.or_,
    ast.BitAnd: operator.and_,
    ast.BitXor: operator.xor,
    ast.LShift: operator.lshift,
    ast.RShift: operator.rshift,
}
UNARYOPS: dict[type[ast.unaryop], Callable[[Any], Any]] = {
    ast.UAdd: operator.pos,
    ast.USub: operator.neg,
    ast.Not: operator.not_,
    ast.Invert: operator.invert,
}
CMPOPS: dict[type[ast.cmpop], Callable[[Any, Any], bool]] = {
    ast.Eq: operator.eq,
    ast.NotEq: operator.ne,
    ast.Lt: operator.lt,
    ast.LtE: operator.le,
    ast.Gt: operator.gt,
    ast.GtE: operator.ge,
    ast.In: lambda a, b: a in b,
    ast.NotIn: lambda a, b: a not in b,
    ast.Is: operator.is_,
    ast.IsNot: operator.is_not,
}


class SafeEvaluator:
    """Evaluate a restricted expression AST with deterministic left-to-right traces."""

    def __init__(self, variables: Mapping[str, Any] | None = None, functions: Mapping[str, Callable[..., Any]] | None = None) -> None:
        self.variables = dict(variables or {})
        self.functions = dict(SAFE_FUNCTIONS)
        if functions:
            self.functions.update(functions)
        self.trace: list[TraceEntry] = []
        self._sequence = 0

    def evaluate(self, expression: str) -> Any:
        tree = parse_expression(expression)
        result = self._eval(tree.body)
        return result

    def result_record(self, expression: str) -> dict[str, Any]:
        self.trace.clear()
        self._sequence = 0
        result = self.evaluate(expression)
        return {
            "expression": expression,
            "profile": "python-safe-subset-4.2",
            "canonical_ast": canonical_expression(expression),
            "expression_hash": expression_hash(expression),
            "result": result,
            "result_hash": sha256_digest(result),
            "trace": [asdict(entry) for entry in self.trace],
        }

    def _record(self, node: ast.AST, operator_name: str, inputs: Any, result: Any) -> Any:
        self._sequence += 1
        self.trace.append(TraceEntry(
            sequence=self._sequence,
            node=type(node).__name__,
            operator=operator_name,
            inputs=inputs,
            result=result,
            result_type=type(result).__name__,
        ))
        return result

    def _eval(self, node: ast.AST) -> Any:
        if isinstance(node, ast.Constant):
            return self._record(node, "literal", [], node.value)
        if isinstance(node, ast.Name):
            if node.id in self.variables:
                value = self.variables[node.id]
            elif node.id in SAFE_CONSTANTS:
                value = SAFE_CONSTANTS[node.id]
            else:
                raise EvaluationError(f"unknown name: {node.id}")
            return self._record(node, "name", [node.id], value)
        if isinstance(node, ast.List):
            values = [self._eval(x) for x in node.elts]
            return self._record(node, "list", values, values)
        if isinstance(node, ast.Tuple):
            values = tuple(self._eval(x) for x in node.elts)
            return self._record(node, "tuple", list(values), values)
        if isinstance(node, ast.Set):
            values = [self._eval(x) for x in node.elts]
            return self._record(node, "set", values, set(values))
        if isinstance(node, ast.Dict):
            keys = [self._eval(k) for k in node.keys]
            values = [self._eval(v) for v in node.values]
            if any(not isinstance(k, (str, int, float, bool, tuple)) for k in keys):
                raise EvaluationError("unsupported dictionary key type")
            result = dict(zip(keys, values))
            return self._record(node, "dict", list(zip(keys, values)), result)
        if isinstance(node, ast.BinOp):
            fn = BINOPS.get(type(node.op))
            if fn is None:
                raise EvaluationError(f"unsupported binary operator: {type(node.op).__name__}")
            left = self._eval(node.left)
            right = self._eval(node.right)
            try:
                result = fn(left, right)
            except Exception as exc:
                raise EvaluationError(str(exc)) from exc
            return self._record(node, type(node.op).__name__, [left, right], result)
        if isinstance(node, ast.UnaryOp):
            fn = UNARYOPS.get(type(node.op))
            if fn is None:
                raise EvaluationError(f"unsupported unary operator: {type(node.op).__name__}")
            value = self._eval(node.operand)
            return self._record(node, type(node.op).__name__, [value], fn(value))
        if isinstance(node, ast.BoolOp):
            if isinstance(node.op, ast.And):
                values = []
                result: Any = True
                for child in node.values:
                    result = self._eval(child)
                    values.append(result)
                    if not result:
                        break
                return self._record(node, "And", values, result)
            if isinstance(node.op, ast.Or):
                values = []
                result = False
                for child in node.values:
                    result = self._eval(child)
                    values.append(result)
                    if result:
                        break
                return self._record(node, "Or", values, result)
            raise EvaluationError("unsupported Boolean operator")
        if isinstance(node, ast.Compare):
            left = self._eval(node.left)
            inputs = [left]
            result = True
            current = left
            for op_node, comparator_node in zip(node.ops, node.comparators):
                right = self._eval(comparator_node)
                inputs.append(right)
                fn = CMPOPS.get(type(op_node))
                if fn is None:
                    raise EvaluationError(f"unsupported comparison: {type(op_node).__name__}")
                if not fn(current, right):
                    result = False
                    break
                current = right
            return self._record(node, "ComparisonChain", inputs, result)
        if isinstance(node, ast.IfExp):
            test = self._eval(node.test)
            result = self._eval(node.body if test else node.orelse)
            return self._record(node, "IfExp", [test], result)
        if isinstance(node, ast.Call):
            if not isinstance(node.func, ast.Name):
                raise EvaluationError("only direct named function calls are allowed")
            name = node.func.id
            fn = self.functions.get(name)
            if fn is None:
                raise EvaluationError(f"function is not in the operator registry: {name}")
            args = [self._eval(arg) for arg in node.args]
            kwargs = {}
            for kw in node.keywords:
                if kw.arg is None:
                    raise EvaluationError("dictionary argument expansion is not allowed")
                kwargs[kw.arg] = self._eval(kw.value)
            try:
                result = fn(*args, **kwargs)
            except Exception as exc:
                raise EvaluationError(f"{name}: {exc}") from exc
            return self._record(node, f"call:{name}", {"args": args, "kwargs": kwargs}, result)
        if isinstance(node, ast.Subscript):
            value = self._eval(node.value)
            key = self._eval_slice(node.slice)
            result = value[key]
            return self._record(node, "subscript", [value, key], result)
        raise EvaluationError(f"unsupported syntax node: {type(node).__name__}")

    def _eval_slice(self, node: ast.AST) -> Any:
        if isinstance(node, ast.Slice):
            lower = self._eval(node.lower) if node.lower else None
            upper = self._eval(node.upper) if node.upper else None
            step = self._eval(node.step) if node.step else None
            return slice(lower, upper, step)
        return self._eval(node)


def evaluate(expression: str, variables: Mapping[str, Any] | None = None) -> Any:
    return SafeEvaluator(variables=variables).evaluate(expression)
