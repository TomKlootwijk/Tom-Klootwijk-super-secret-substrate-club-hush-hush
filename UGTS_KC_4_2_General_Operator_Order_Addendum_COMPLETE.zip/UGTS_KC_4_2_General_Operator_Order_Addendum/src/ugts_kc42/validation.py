from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .canonical import record_hash, verify_record_hash
from .catalog import OperatorCatalog
from .graph import topological_sort
from .order import load_evaluation_phases, load_precedence_profiles


REQUIRED_PROJECT_FIELDS = {"schema_version", "substrate_id", "metadata", "order_profile", "definitions", "expressions", "pipeline"}
REQUIRED_DEFINITION_FIELDS = {"id", "kind", "domain", "codomain", "evaluation_phase", "dependencies", "parameters", "content_hash"}


def validate_default_catalog() -> dict[str, Any]:
    catalog = OperatorCatalog.load_default()
    errors = catalog.validate()
    return {
        "valid": not errors,
        "errors": errors,
        "record_count": len(catalog.records),
        "domain_count": len(catalog.domain_summary()),
        "mechanism_range": [catalog.records[0].mechanism_id, catalog.records[-1].mechanism_id],
    }


def validate_profiles() -> dict[str, Any]:
    precedence = load_precedence_profiles()
    phases = load_evaluation_phases()
    errors: list[str] = []
    profile_ids = [p["id"] for p in precedence.get("profiles", [])]
    if len(profile_ids) != len(set(profile_ids)):
        errors.append("duplicate precedence profile ID")
    phase_rows = phases.get("phases", [])
    if [p.get("index") for p in phase_rows] != list(range(15)):
        errors.append("evaluation phases must be contiguous 0..14")
    if len({p.get("id") for p in phase_rows}) != len(phase_rows):
        errors.append("duplicate evaluation phase ID")
    return {"valid": not errors, "errors": errors, "precedence_profiles": profile_ids, "phase_count": len(phase_rows)}


def validate_project(project: dict[str, Any]) -> dict[str, Any]:
    errors: list[str] = []
    missing = sorted(REQUIRED_PROJECT_FIELDS - set(project))
    if missing:
        errors.append(f"missing project fields: {missing}")
    definitions = project.get("definitions", [])
    if not isinstance(definitions, list):
        errors.append("definitions must be a list")
        definitions = []
    ids: list[str] = []
    dependencies: dict[str, list[str]] = {}
    for index, definition in enumerate(definitions):
        if not isinstance(definition, dict):
            errors.append(f"definition {index} is not an object")
            continue
        missing_def = sorted(REQUIRED_DEFINITION_FIELDS - set(definition))
        if missing_def:
            errors.append(f"definition {index} missing fields: {missing_def}")
            continue
        did = definition["id"]
        ids.append(did)
        dependencies[did] = list(definition.get("dependencies", []))
        if not verify_record_hash(definition):
            errors.append(f"bad definition content hash: {did}")
    if len(ids) != len(set(ids)):
        errors.append("duplicate definition IDs")
    known = set(ids)
    for did, deps in dependencies.items():
        unknown = sorted(set(deps) - known)
        if unknown:
            errors.append(f"definition {did} has unknown dependencies: {unknown}")
    try:
        order = topological_sort(dependencies)
    except ValueError as exc:
        errors.append(str(exc))
        order = []
    expression_ids = [e.get("id") for e in project.get("expressions", []) if isinstance(e, dict)]
    if len(expression_ids) != len(set(expression_ids)):
        errors.append("duplicate expression IDs")
    return {
        "valid": not errors,
        "errors": errors,
        "definition_count": len(definitions),
        "definition_order": order,
        "expression_count": len(expression_ids),
    }


def load_and_validate_project(path: str | Path) -> dict[str, Any]:
    project = json.loads(Path(path).read_text(encoding="utf-8"))
    return validate_project(project)
