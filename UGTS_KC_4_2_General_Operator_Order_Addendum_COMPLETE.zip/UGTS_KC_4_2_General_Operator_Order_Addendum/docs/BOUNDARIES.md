# Boundaries, non-claims and kill criteria

## Explicit non-claims

- No finite catalog is claimed to enumerate every possible mathematical operator.
- No complete theorem prover, computer algebra system, special-function library, PDE solver, optimizer, probabilistic-programming system or category-theory assistant is claimed.
- No universal termination, convergence, stability, exactness, O(1), compression, memory or hardware-throughput claim is made.
- No arbitrary Python/code execution is exposed by the safe evaluator.
- No content hash proves authorship, ownership, truth, authorization or legal chain of custody.
- No physical-device, GPU, phone, energy, thermal or latency result is implied by host tests.
- No domain-specific profile, including security/cryptographic operators, authorizes secret search or other prohibited actions.

## Numerical kill criteria

Simplify or reject an operator/profile when:

- types, units, shapes, domains or coordinate conventions are ambiguous;
- a rewrite uses a law outside its scope;
- floating/quantized error exceeds a guard or changes event ordering;
- an interval remains too wide to classify the required predicate;
- an iterative solver exceeds its declared work budget or lacks a bounded failure state;
- reduction order changes a result beyond the selected tolerance and is not recorded;
- an ostensibly exact distance, inverse, derivative or integral lacks the required conditions.

## Order and determinism kill criteria

- dependency cycles appear without an explicit fixed-point/feedback profile;
- effectful operations are reordered as if they were pure;
- simultaneous proposals overwrite the same field without priority, commutative merge or conflict event;
- platform behavior changes the canonical trace or event order outside the selected tolerance profile;
- replay cannot reproduce pre/post hashes;
- nondeterministic input is neither seeded nor recorded as external novelty.

## Performance and storage kill criteria

- catalog lookup, type checking, certification or event logging costs more than a conventional implementation at equal error;
- event, branch, checkpoint or provenance density removes the storage advantage;
- packed or seed reconstruction loses required state, uncertainty or lineage;
- a conventional domain library is simpler, safer, faster or more accurate for the target workload.
