# Migration and compatibility

## Additive status

UGTS-KC 4.2 does not replace earlier geometry, topology, scene, game, spatial-ledger, native-device or domain-specific profiles. It supplies a general operator/order layer that those profiles may reference.

## Recommended migration

1. Give every reusable operation a stable operator ID and version.
2. Declare domain, codomain, arity, units, shape, exactness, effects and failure status.
3. Move parser precedence and associativity into a named order profile.
4. Record dependencies and topologically validate them.
5. Separate pure evaluation from proposal and authoritative commit.
6. Declare reduction and parallel order where non-associativity or effects matter.
7. Attach interval/residual/error and work-budget certificates.
8. Preserve pre/post hashes, event sequence and lineage for replay.
9. Keep rendering, file output, network and physical devices downstream unless the application explicitly promotes them through a verified event contract.

## Catalog continuity

This general addendum appends M630-M885 after the project’s merged M001-M629 catalog spine. Branch-specific 4.0/4.1 catalogs remain valid in their own release namespaces and are not silently renumbered by this package.
