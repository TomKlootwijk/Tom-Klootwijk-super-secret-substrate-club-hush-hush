# Reference API overview

The Python runtime uses only the standard library.

## Catalog

```python
from ugts_kc42.catalog import OperatorCatalog
catalog = OperatorCatalog.load_default()
errors = catalog.validate()
records = catalog.search("gradient")
```

## Canonicalization

```python
from ugts_kc42.canonical import canonical_json, sha256_digest, verify_record_hash
```

Integral floats normalize to integers, non-finite floats are rejected unless explicitly tagged, sets/tuples/complex/fractions use tagged encodings and mapping keys must be strings.

## Safe expression evaluation

```python
from ugts_kc42.evaluator import SafeEvaluator
record = SafeEvaluator().result_record("2 + 3 * 4 ** 2")
```

The evaluator accepts literals, lists, tuples, sets, dictionaries, arithmetic, Boolean operations, comparison chains, conditional expressions, indexing/slicing and a fixed registry of mathematical functions.

## Intervals

```python
from ugts_kc42.interval import Interval
status = (Interval(1, 1.1) * Interval(2, 2.2) - 2.1).classify_zero(0.01)
```

## Linear algebra and numerics

`linalg.py` supplies vector products, matrix multiplication, determinant, solve, rank and Kronecker product. `numeric.py` supplies finite-difference derivatives, gradient/Jacobian/Hessian, Simpson integration, bisection, gradient descent, convolution, covariance and information measures.

## Graph and event order

`graph.py` supplies deterministic reachability, Dijkstra and topological ordering. `events.py` verifies, sorts, commits and replays proposals with pre/post state hashes.
