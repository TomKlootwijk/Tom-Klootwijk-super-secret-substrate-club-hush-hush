# Order profiles

## Why multiple orders are necessary

The word “order” is overloaded. UGTS-KC 4.2 separates parser precedence, definition dependency, evaluation phase, composition direction, reduction tree, parallel schedule, event commit and replay sequence.

## Standard mathematical profile

Highest binding to lowest:

1. function application and indexing;
2. postfix operators;
3. power and explicit roots;
4. prefix unary operators;
5. multiplication, division and remainder;
6. addition and subtraction;
7. comparisons;
8. Boolean `not`;
9. Boolean `and`;
10. Boolean `xor`;
11. Boolean `or`;
12. implication/equivalence;
13. conditional/case;
14. assignment/definition.

The standard profile interprets `-x^2` as `-(x^2)`. Exponentiation is right-associative. Parentheses are authoritative. Implicit multiplication is disabled by default.

## Python-safe-subset profile

The executable expression evaluator follows the relevant Python AST rules for a restricted, non-executing expression subset. No attribute access, imports, comprehensions, lambdas, statements or arbitrary function calls are permitted.

## Explicit-AST profile

Every operation is represented as a content-addressed AST node. This profile is preferred for interchange, proofs, editor tooling and cross-language replay because token ambiguity is absent.

## Reduction profiles

- `left_fold`: stable sequential order.
- `right_fold`: explicit right-associated order.
- `balanced_tree`: logarithmic-depth pure reduction, not automatically bit-identical for floating arithmetic.
- `sorted_pairwise`: stable pairwise reduction after canonical key ordering.
- `exact_symbolic`: defer numerical rounding where supported.
- `profile_defined`: custom versioned reduction with evidence.
