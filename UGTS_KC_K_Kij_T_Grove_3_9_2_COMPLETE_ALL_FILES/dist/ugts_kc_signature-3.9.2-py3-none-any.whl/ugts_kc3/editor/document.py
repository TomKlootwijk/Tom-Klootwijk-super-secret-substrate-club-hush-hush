"""Editor-facing project document and undoable model mutations.

The editor deliberately talks to the public :mod:`ugts_kc3.project` and
:mod:`ugts_kc3.mobile3d` records instead of maintaining a second authoring
format.  A small amount of unknown top-level JSON is retained so newer Grove
extensions survive an edit/save cycle in this version of the editor.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
import copy
import json
import math
from pathlib import Path
import re
from typing import Any, Mapping
import unicodedata

from PySide6.QtCore import QObject, Signal

from ..game import Transform2D
from ..game_input import InputFrame
from ..mobile3d import (
    InputFrame3D,
    Mobile3DProject,
    Node3DRecord,
    Transform3DRecord,
)
from ..project import EntitySpec, GameProject, GameSceneSpec
from ..visual_graph import VisualGraph


GRAPHS_KEY = "visual_graphs"
BINDING_KEY = "visual_graph"


def friendly_rule_name(value: str) -> str:
    """Turn an internal rule key into a short phrase for learner messages."""

    return value.replace("_", " ").replace("-", " ").strip().casefold()


@dataclass(frozen=True)
class SelectionRef:
    """Stable reference used by the hierarchy, viewport, and inspector."""

    kind: str
    object_id: str
    scene_id: str | None = None


def quaternion_to_euler_degrees(rotation: tuple[float, float, float, float]) -> tuple[float, float, float]:
    """Convert the engine's ``(w, x, y, z)`` quaternion to XYZ Euler degrees."""

    w, x, y, z = (float(value) for value in rotation)
    length = math.sqrt(w * w + x * x + y * y + z * z) or 1.0
    w, x, y, z = w / length, x / length, y / length, z / length
    sinr_cosp = 2.0 * (w * x + y * z)
    cosr_cosp = 1.0 - 2.0 * (x * x + y * y)
    roll = math.atan2(sinr_cosp, cosr_cosp)
    sinp = max(-1.0, min(1.0, 2.0 * (w * y - z * x)))
    pitch = math.asin(sinp)
    siny_cosp = 2.0 * (w * z + x * y)
    cosy_cosp = 1.0 - 2.0 * (y * y + z * z)
    yaw = math.atan2(siny_cosp, cosy_cosp)
    return tuple(math.degrees(value) for value in (roll, pitch, yaw))  # type: ignore[return-value]


def euler_degrees_to_quaternion(rotation: tuple[float, float, float]) -> tuple[float, float, float, float]:
    """Convert XYZ Euler degrees to the engine's normalized quaternion order."""

    roll, pitch, yaw = (math.radians(float(value)) * 0.5 for value in rotation)
    cr, sr = math.cos(roll), math.sin(roll)
    cp, sp = math.cos(pitch), math.sin(pitch)
    cy, sy = math.cos(yaw), math.sin(yaw)
    result = (
        cr * cp * cy + sr * sp * sy,
        sr * cp * cy - cr * sp * sy,
        cr * sp * cy + sr * cp * sy,
        cr * cp * sy - sr * sp * cy,
    )
    length = math.sqrt(sum(value * value for value in result)) or 1.0
    return tuple(value / length for value in result)  # type: ignore[return-value]


class EditorDocument(QObject):
    """A loaded 2D or mobile-3D project with editor-friendly signals."""

    projectLoaded = Signal()
    documentChanged = Signal(bool)
    sceneChanged = Signal(str)
    selectionChanged = Signal(object)
    transformChanged = Signal(object)
    graphChanged = Signal()
    structureChanged = Signal()

    def __init__(self, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self.project: GameProject | Mobile3DProject | None = None
        self.kind: str | None = None
        self.path: Path | None = None
        self.current_scene_id: str | None = None
        self.selection: SelectionRef | None = None
        self._dirty = False
        self._extra_top_level: dict[str, Any] = {}
        self._runtime_world: Any | None = None
        self._previous_input: InputFrame | None = None
        self.play_warnings: list[str] = []

    @property
    def is_loaded(self) -> bool:
        return self.project is not None

    @property
    def is_dirty(self) -> bool:
        return self._dirty

    @property
    def display_name(self) -> str:
        if isinstance(self.project, GameProject):
            return self.project.metadata.title
        if isinstance(self.project, Mobile3DProject):
            return self.project.title
        return "No project"

    @property
    def object_count(self) -> int:
        if isinstance(self.project, GameProject):
            return sum(len(scene.entities) for scene in self.project.scenes.values())
        if isinstance(self.project, Mobile3DProject):
            return len(self.project.nodes)
        return 0

    def load(self, path: str | Path, *, as_copy: bool = False) -> None:
        source = Path(path).expanduser().resolve()
        raw = json.loads(source.read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            raise ValueError("A project file must contain one JSON object.")

        if "schema" in raw and ("nodes" in raw or str(raw.get("schema", "")).startswith("ugts-kc-mobile-3d")):
            project: GameProject | Mobile3DProject = Mobile3DProject.from_dict(raw, validate=False)
            kind = "3d"
        elif "$schema" in raw or "scenes" in raw:
            project = GameProject.from_dict(raw, validate=False)
            kind = "2d"
        else:
            raise ValueError("This does not look like a UGTS 2D or Mobile 3D project.")

        known = set(project.to_dict())
        self._extra_top_level = {
            str(key): copy.deepcopy(value) for key, value in raw.items() if key not in known
        }
        self.project = project
        self.kind = kind
        self.path = None if as_copy else source
        self.current_scene_id = project.start_scene if isinstance(project, GameProject) else None
        self.selection = None
        self._runtime_world = None
        self._previous_input = None
        self._dirty = bool(as_copy)
        self.projectLoaded.emit()
        self.documentChanged.emit(self._dirty)
        if self.current_scene_id:
            self.sceneChanged.emit(self.current_scene_id)
        self.selectionChanged.emit(None)

    def create(self, project: GameProject | Mobile3DProject) -> None:
        """Adopt a freshly generated project as an unsaved editor document."""

        if not isinstance(project, (GameProject, Mobile3DProject)):
            raise TypeError("EditorDocument.create needs a GameProject or Mobile3DProject.")
        self.project = project
        self.kind = "2d" if isinstance(project, GameProject) else "3d"
        self.path = None
        self.current_scene_id = project.start_scene if isinstance(project, GameProject) else None
        self.selection = None
        self._runtime_world = None
        self._previous_input = None
        self._extra_top_level = {}
        self._dirty = True
        self.projectLoaded.emit()
        self.documentChanged.emit(True)
        if self.current_scene_id:
            self.sceneChanged.emit(self.current_scene_id)
        self.selectionChanged.emit(None)

    def serialize(self) -> dict[str, Any]:
        if self.project is None:
            raise RuntimeError("No project is open.")
        data = copy.deepcopy(self._extra_top_level)
        data.update(self.project.to_dict())
        return data

    def validate(self):
        if self.project is None:
            raise RuntimeError("No project is open.")
        return self.project.validate(raise_on_error=False)

    def save(self, path: str | Path | None = None) -> Path:
        if self.project is None:
            raise RuntimeError("No project is open.")
        destination = Path(path).expanduser().resolve() if path is not None else self.path
        if destination is None:
            raise ValueError("Choose a file name before saving this project.")
        report = self.validate()
        if not report.passed:
            issues = getattr(report, "issues", ())
            message = "; ".join(getattr(issue, "message", str(issue)) for issue in issues)
            raise ValueError(message or "The project has validation errors.")
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(
            json.dumps(self.serialize(), indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        self.path = destination
        self.set_dirty(False)
        return destination

    def set_dirty(self, dirty: bool = True) -> None:
        dirty = bool(dirty)
        if dirty == self._dirty:
            return
        self._dirty = dirty
        self.documentChanged.emit(dirty)

    def set_current_scene(self, scene_id: str) -> None:
        if not isinstance(self.project, GameProject) or scene_id not in self.project.scenes:
            return
        if scene_id == self.current_scene_id:
            return
        self.current_scene_id = scene_id
        self.set_selection(None)
        self.sceneChanged.emit(scene_id)

    def set_selection(self, selection: SelectionRef | None) -> None:
        if selection == self.selection:
            return
        self.selection = selection
        self.selectionChanged.emit(selection)

    def scene(self, scene_id: str | None = None) -> GameSceneSpec | None:
        if not isinstance(self.project, GameProject):
            return None
        key = scene_id or self.current_scene_id
        return self.project.scenes.get(key or "")

    def entity(self, selection: SelectionRef | None = None) -> EntitySpec | Node3DRecord | None:
        selection = selection or self.selection
        if selection is None or self.project is None:
            return None
        if isinstance(self.project, GameProject):
            scene = self.project.scenes.get(selection.scene_id or self.current_scene_id or "")
            if scene is None:
                return None
            return next((entity for entity in scene.entities if entity.id == selection.object_id), None)
        return next((node for node in self.project.nodes if node.id == selection.object_id), None)

    def scene_objects(
        self, scene_id: str | None = None
    ) -> tuple[EntitySpec, ...] | tuple[Node3DRecord, ...]:
        """Return the editable records for one scene without changing the project."""

        if isinstance(self.project, GameProject):
            scene = self.scene(scene_id)
            return () if scene is None else scene.entities
        if isinstance(self.project, Mobile3DProject):
            return self.project.nodes
        return ()

    @staticmethod
    def _friendly_id_base(label: str, fallback: str = "new_object") -> str:
        ascii_label = unicodedata.normalize("NFKD", str(label)).encode("ascii", "ignore").decode("ascii")
        base = re.sub(r"[^a-z0-9]+", "_", ascii_label.casefold()).strip("_")
        if not base:
            base = fallback
        if not base[0].isalpha():
            base = f"object_{base}"
        return base[:56].rstrip("_") or fallback

    def collision_free_object_id(self, label: str, scene_id: str | None = None) -> str:
        """Make a readable, stable id that cannot collide in the active scene."""

        base = self._friendly_id_base(label)
        used = {record.id for record in self.scene_objects(scene_id)}
        if base not in used:
            return base
        suffix = 2
        while f"{base}_{suffix}" in used:
            suffix += 1
        return f"{base}_{suffix}"

    def new_object_record(self) -> EntitySpec | Node3DRecord:
        """Create a small visible object that uses resources already in the project."""

        if isinstance(self.project, GameProject):
            scene = self.scene()
            if scene is None:
                raise ValueError("Choose a 2D scene before adding an object.")
            count = len(scene.entities)
            width, height = scene.world_size
            position = (
                width * 0.5 + ((count % 5) - 2) * 28.0,
                height * 0.5 + (((count // 5) % 5) - 2) * 28.0,
            )
            components: dict[str, dict[str, Any]] = {
                "transform": {
                    "position": [float(position[0]), float(position[1])],
                    "rotation": 0.0,
                    "scale": [1.0, 1.0],
                }
            }
            asset_id = next(iter(sorted(self.project.vector_assets.assets)), None)
            if asset_id is not None:
                components["vector_renderer"] = {
                    "asset_id": asset_id,
                    "z_index": 0,
                    "visible": True,
                    "opacity": 1.0,
                }
            record = EntitySpec(
                self.collision_free_object_id("new_object"),
                components,
                frozenset({"new_object"}),
                True,
                {"description": "A new object made in UGTS Studio"},
            )
            record.validate()
            return record

        if isinstance(self.project, Mobile3DProject):
            mesh_id = next(
                (key for key in ("cube", "sphere", "pyramid") if key in self.project.meshes),
                next(iter(sorted(self.project.meshes)), ""),
            )
            material_id = next(
                (key for key in ("accent", "default", "player") if key in self.project.materials),
                next(iter(sorted(self.project.materials)), ""),
            )
            if not mesh_id or not material_id:
                raise ValueError(
                    "This 3D project needs at least one mesh and material before an object can be added."
                )
            count = len(self.project.nodes)
            record = Node3DRecord(
                self.collision_free_object_id("new_object"),
                mesh_id,
                material_id,
                Transform3DRecord(
                    (((count % 5) - 2) * 1.5, 1.0, ((count // 5) % 5) * -1.5)
                ),
                tags=("new_object",),
                metadata={"description": "A new object made in UGTS Studio"},
            )
            record.validate()
            return record
        raise RuntimeError("Open a project before adding an object.")

    def duplicate_object_record(
        self, selection: SelectionRef | None = None
    ) -> EntitySpec | Node3DRecord:
        """Deep-copy one selected record, changing only its id and placement."""

        selection = selection or self.selection
        source = self.entity(selection)
        if source is None:
            raise ValueError("Choose an object in the Scene Tree before making a copy.")
        new_id = self.collision_free_object_id(f"{source.id}_copy", selection.scene_id if selection else None)
        if isinstance(source, EntitySpec):
            components = copy.deepcopy({name: dict(value) for name, value in source.components.items()})
            transform = components.get("transform")
            if isinstance(transform, Mapping):
                updated_transform = copy.deepcopy(dict(transform))
                position = updated_transform.get("position", (0.0, 0.0))
                updated_transform["position"] = [float(position[0]) + 32.0, float(position[1]) + 32.0]
                components["transform"] = updated_transform
            record = replace(
                source,
                id=new_id,
                components=components,
                metadata=copy.deepcopy(dict(source.metadata)),
            )
            record.validate()
            return record
        if isinstance(source, Node3DRecord):
            x, y, z = source.transform.translation
            record = replace(
                source,
                id=new_id,
                transform=replace(source.transform, translation=(x + 1.0, y, z + 1.0)),
                metadata=copy.deepcopy(source.metadata),
            )
            record.validate()
            return record
        raise ValueError("Only 2D entities and 3D objects can be copied.")

    @staticmethod
    def _contains_entity_reference(value: Any, object_id: str) -> bool:
        if not isinstance(value, Mapping):
            return False
        for key, child in value.items():
            normalized_key = str(key).casefold()
            if (
                normalized_key.endswith(("_entity", "_entity_id"))
                or normalized_key in {"follow_entity", "target_entity", "owner_entity"}
            ) and child == object_id:
                return True
            if isinstance(child, Mapping) and EditorDocument._contains_entity_reference(child, object_id):
                return True
            if isinstance(child, (list, tuple)) and any(
                isinstance(item, Mapping)
                and EditorDocument._contains_entity_reference(item, object_id)
                for item in child
            ):
                return True
        return False

    def deletion_problem(self, selection: SelectionRef | None = None) -> str | None:
        """Explain why a selected record must remain, or return ``None``."""

        selection = selection or self.selection
        source = self.entity(selection)
        if source is None or selection is None:
            return "Choose an object in the Scene Tree before deleting it."
        records = self.scene_objects(selection.scene_id)
        if len(records) <= 1:
            return "Keep at least one object in the scene so there is always something to edit."
        if isinstance(source, EntitySpec):
            scene = self.scene(selection.scene_id)
            if scene is None:
                return "Choose a 2D scene before deleting an object."
            for key, value in scene.rules.items():
                normalized_key = str(key).casefold()
                if value == source.id and (normalized_key.endswith("_id") or normalized_key == "player"):
                    return (
                        f"{source.id} is the scene's {friendly_rule_name(str(key))}. "
                        "Choose a different object in the scene rules before deleting it."
                    )
            for other in scene.entities:
                if other.id != source.id and self._contains_entity_reference(other.components, source.id):
                    return (
                        f"{other.id} still points to {source.id}. Change that reference before deleting it."
                    )
        return None

    def replace_scene_objects(
        self,
        records: tuple[EntitySpec, ...] | tuple[Node3DRecord, ...],
        selection: SelectionRef | None,
        scene_id: str | None = None,
    ) -> None:
        """Apply one validated object-list snapshot and notify every editor surface."""

        snapshot = copy.deepcopy(tuple(records))
        if isinstance(self.project, GameProject):
            key = scene_id or self.current_scene_id or ""
            scene = self.project.scenes.get(key)
            if scene is None or not all(isinstance(record, EntitySpec) for record in snapshot):
                raise ValueError("The 2D scene object list is not valid.")
            candidate = replace(scene, entities=snapshot)
            candidate.validate()
            self.project.scenes[key] = candidate
        elif isinstance(self.project, Mobile3DProject):
            if not all(isinstance(record, Node3DRecord) for record in snapshot):
                raise ValueError("The 3D scene object list is not valid.")
            ids = [record.id for record in snapshot]
            if len(ids) != len(set(ids)):
                raise ValueError("Every 3D object needs a unique name.")
            for record in snapshot:
                record.validate()
                if record.mesh_id not in self.project.meshes:
                    raise ValueError(f"{record.id} uses a missing mesh: {record.mesh_id}")
                if record.material_id not in self.project.materials:
                    raise ValueError(f"{record.id} uses a missing material: {record.material_id}")
            self.project.nodes = snapshot
        else:
            raise RuntimeError("Open a project before editing its scene.")
        self._runtime_world = None
        self.set_dirty(True)
        self.structureChanged.emit()
        self.set_selection(selection)

    def record_with_resource(
        self,
        selection: SelectionRef,
        resource_kind: str,
        resource_id: str,
    ) -> EntitySpec | Node3DRecord:
        """Return one validated record with an existing visual resource selected."""

        selected = self.entity(selection)
        resource_id = str(resource_id).strip()
        if not resource_id:
            raise ValueError("Choose a project resource first.")
        if isinstance(self.project, GameProject) and isinstance(selected, EntitySpec):
            if resource_kind != "vector_asset":
                raise ValueError("A 2D object can only choose a vector picture here.")
            if resource_id not in self.project.vector_assets.assets:
                raise ValueError(f"That vector picture is not in this project: {resource_id}")
            components = copy.deepcopy(
                {name: dict(value) for name, value in selected.components.items()}
            )
            renderer = components.get("vector_renderer")
            if not isinstance(renderer, Mapping):
                raise ValueError(f"{selected.id} does not have a picture to change.")
            updated_renderer = copy.deepcopy(dict(renderer))
            updated_renderer["asset_id"] = resource_id
            components["vector_renderer"] = updated_renderer
            updated = replace(selected, components=components)
            updated.validate()
            return updated
        if isinstance(self.project, Mobile3DProject) and isinstance(selected, Node3DRecord):
            if resource_kind == "mesh":
                if resource_id not in self.project.meshes:
                    raise ValueError(f"That 3D shape is not in this project: {resource_id}")
                updated = replace(selected, mesh_id=resource_id)
            elif resource_kind == "material":
                if resource_id not in self.project.materials:
                    raise ValueError(f"That material is not in this project: {resource_id}")
                updated = replace(selected, material_id=resource_id)
            else:
                raise ValueError("A 3D object can only choose a shape or material here.")
            updated.validate()
            return updated
        raise ValueError("Choose a scene object before changing its appearance.")

    def transform(self, selection: SelectionRef | None = None) -> dict[str, Any] | None:
        selected = self.entity(selection)
        if isinstance(selected, EntitySpec):
            value = selected.components.get("transform")
            if not isinstance(value, Mapping):
                return None
            return {
                "position": tuple(float(v) for v in value.get("position", (0, 0))),
                "rotation": float(value.get("rotation", 0.0)),
                "scale": tuple(float(v) for v in value.get("scale", (1, 1))),
            }
        if isinstance(selected, Node3DRecord):
            return {
                "translation": tuple(selected.transform.translation),
                "rotation": tuple(selected.transform.rotation),
                "scale": tuple(selected.transform.scale),
            }
        return None

    @staticmethod
    def _safe_scale(values: tuple[float, ...]) -> tuple[float, ...]:
        return tuple(0.0001 if abs(float(value)) < 0.0001 else float(value) for value in values)

    def set_transform(self, selection: SelectionRef, transform: Mapping[str, Any]) -> None:
        """Replace a transform through the authoritative project record model."""

        if isinstance(self.project, GameProject):
            scene_id = selection.scene_id or self.current_scene_id or ""
            scene = self.project.scenes.get(scene_id)
            if scene is None:
                raise KeyError(scene_id)
            replacement: list[EntitySpec] = []
            found = False
            for entity in scene.entities:
                if entity.id != selection.object_id:
                    replacement.append(entity)
                    continue
                found = True
                components = copy.deepcopy({name: dict(value) for name, value in entity.components.items()})
                previous = dict(components.get("transform", {}))
                previous.update(
                    {
                        "position": [float(v) for v in transform["position"]],
                        "rotation": float(transform["rotation"]),
                        "scale": list(self._safe_scale(tuple(transform["scale"]))),
                    }
                )
                components["transform"] = previous
                updated = replace(entity, components=components)
                updated.validate()
                replacement.append(updated)
            if not found:
                raise KeyError(selection.object_id)
            self.project.scenes[scene_id] = replace(scene, entities=tuple(replacement))
        elif isinstance(self.project, Mobile3DProject):
            replacement_nodes: list[Node3DRecord] = []
            found = False
            for node in self.project.nodes:
                if node.id != selection.object_id:
                    replacement_nodes.append(node)
                    continue
                found = True
                record = Transform3DRecord(
                    tuple(float(v) for v in transform["translation"]),  # type: ignore[arg-type]
                    tuple(float(v) for v in transform["rotation"]),  # type: ignore[arg-type]
                    self._safe_scale(tuple(transform["scale"])),  # type: ignore[arg-type]
                )
                record.validate()
                replacement_nodes.append(replace(node, transform=record))
            if not found:
                raise KeyError(selection.object_id)
            self.project.nodes = tuple(replacement_nodes)
        else:
            raise RuntimeError("No project is open.")
        self.set_dirty(True)
        self.transformChanged.emit(selection)

    def object_details(self, selection: SelectionRef | None = None) -> dict[str, Any]:
        selected = self.entity(selection)
        if isinstance(selected, EntitySpec):
            return selected.to_dict()
        if isinstance(selected, Node3DRecord):
            return selected.to_dict()
        return {}

    def graph_data(self) -> dict[str, Any]:
        if isinstance(self.project, GameProject):
            scene = self.scene()
            values = [] if scene is None else scene.rules.get(GRAPHS_KEY, [])
            legacy = None if scene is None else scene.rules.get(BINDING_KEY)
        elif isinstance(self.project, Mobile3DProject):
            values = self.project.metadata.get(GRAPHS_KEY, [])
            legacy = self.project.metadata.get(BINDING_KEY)
        else:
            values, legacy = [], None
        if not isinstance(values, (list, tuple)):
            values = []
        if not values and isinstance(legacy, Mapping):
            values = [legacy]
        binding = None
        selected = self.entity()
        if isinstance(selected, (EntitySpec, Node3DRecord)):
            binding = selected.metadata.get(BINDING_KEY)
        candidate = next(
            (item for item in values if isinstance(item, Mapping) and item.get("id") == binding),
            next((item for item in values if isinstance(item, Mapping)), None),
        )
        if candidate is None:
            base = self.current_scene_id or getattr(self.project, "id", "scene")
            return VisualGraph(id=f"{base}_logic").to_dict()
        raw = copy.deepcopy(dict(candidate))
        # One early editor preview used connections/from_node keys. Migrate it in memory.
        if "connections" in raw and "links" not in raw:
            raw["links"] = [
                {
                    "source_node": item.get("from_node"), "source_port": item.get("from_port"),
                    "target_node": item.get("to_node"), "target_port": item.get("to_port"),
                }
                for item in raw.get("connections", []) if isinstance(item, Mapping)
            ]
            raw.pop("connections", None)
        raw.setdefault("schema", VisualGraph.SCHEMA)
        raw.setdefault("id", f"{self.current_scene_id or 'scene'}_logic")
        raw.setdefault("metadata", {})
        return VisualGraph.from_dict(raw).to_dict()

    def set_graph_data(self, graph: Mapping[str, Any]) -> None:
        payload = VisualGraph.from_dict(graph).to_dict()
        graph_id = str(payload["id"])
        if isinstance(self.project, GameProject):
            scene = self.scene()
            if scene is None:
                return
            rules = copy.deepcopy(dict(scene.rules))
            existing_graph_ids = {
                str(item.get("id")) for item in rules.get(GRAPHS_KEY, [])
                if isinstance(item, Mapping) and item.get("id") is not None
            }
            should_bind = graph_id not in existing_graph_ids
            graphs = [
                copy.deepcopy(dict(item)) for item in rules.get(GRAPHS_KEY, [])
                if isinstance(item, Mapping) and item.get("id") != graph_id
            ]
            graphs.append(payload)
            rules[GRAPHS_KEY] = graphs
            rules.pop(BINDING_KEY, None)
            binding_id = None
            if should_bind and self.selection is not None and self.selection.scene_id in (None, scene.id):
                binding_id = self.selection.object_id
            if should_bind and binding_id is None:
                wanted = str(scene.rules.get("player_id", ""))
                binding_id = wanted if any(item.id == wanted for item in scene.entities) else None
            if should_bind and binding_id is None:
                binding_id = next((item.id for item in scene.entities if "transform" in item.components), None)
            entities: list[EntitySpec] = []
            for entity in scene.entities:
                if entity.id == binding_id:
                    metadata = copy.deepcopy(dict(entity.metadata))
                    metadata[BINDING_KEY] = graph_id
                    entity = replace(entity, metadata=metadata)
                entities.append(entity)
            self.project.scenes[scene.id] = replace(scene, rules=rules, entities=tuple(entities))
        elif isinstance(self.project, Mobile3DProject):
            metadata = copy.deepcopy(self.project.metadata)
            existing_graph_ids = {
                str(item.get("id")) for item in metadata.get(GRAPHS_KEY, [])
                if isinstance(item, Mapping) and item.get("id") is not None
            }
            should_bind = graph_id not in existing_graph_ids
            graphs = [
                copy.deepcopy(dict(item)) for item in metadata.get(GRAPHS_KEY, [])
                if isinstance(item, Mapping) and item.get("id") != graph_id
            ]
            graphs.append(payload)
            metadata[GRAPHS_KEY] = graphs
            metadata.pop(BINDING_KEY, None)
            self.project.metadata = metadata
            binding_id = self.selection.object_id if should_bind and self.selection is not None else None
            if should_bind and binding_id is None:
                binding_id = next((node.id for node in self.project.nodes if "player" in node.tags), None)
            if should_bind and binding_id is None and self.project.nodes:
                binding_id = self.project.nodes[0].id
            nodes: list[Node3DRecord] = []
            for node in self.project.nodes:
                if node.id == binding_id:
                    node_metadata = copy.deepcopy(node.metadata)
                    node_metadata[BINDING_KEY] = graph_id
                    node = replace(node, metadata=node_metadata)
                nodes.append(node)
            self.project.nodes = tuple(nodes)
        else:
            return
        self.set_dirty(True)
        self.graphChanged.emit()

    def begin_play(self) -> None:
        self.play_warnings = []
        if isinstance(self.project, GameProject):
            self._runtime_world = self.project.instantiate_world(self.current_scene_id)
        elif isinstance(self.project, Mobile3DProject):
            self._runtime_world = self.project.instantiate_world()
        else:
            raise RuntimeError("Open a project before pressing Play.")
        self._previous_input = None

    def stop_play(self) -> None:
        self._runtime_world = None
        self._previous_input = None

    def step_play(self, pressed_keys: set[str]) -> tuple[dict[str, dict[str, Any]], tuple[Any, ...]]:
        """Advance the real reference runtime and return render-friendly transforms."""

        if self._runtime_world is None:
            return {}, ()
        left = "left" in pressed_keys or "a" in pressed_keys
        right = "right" in pressed_keys or "d" in pressed_keys
        up = "up" in pressed_keys or "w" in pressed_keys
        down = "down" in pressed_keys or "s" in pressed_keys
        if isinstance(self.project, GameProject):
            values = {
                "move_x": float(right) - float(left),
                "move_y": float(down) - float(up),
                "dash": float("space" in pressed_keys),
                "jump": float("space" in pressed_keys),
                "action": float("enter" in pressed_keys),
            }
            frame = self.project.input_map.frame_from_actions(values, self._previous_input)
            self._previous_input = frame
            events = self._runtime_world.step(frame)
            state: dict[str, dict[str, Any]] = {}
            for entity_id, entity in self._runtime_world.entities.items():
                transform = entity.components.get("transform")
                if isinstance(transform, Transform2D) and entity.active:
                    state[entity_id] = {
                        "position": transform.position,
                        "rotation": transform.rotation,
                        "scale": transform.scale,
                    }
            state["__world__"] = copy.deepcopy(self._runtime_world.state)
            return state, events
        frame3d = InputFrame3D(
            float(right) - float(left),
            float(down) - float(up),
            jump=bool({"space", "j"} & pressed_keys),
            action=bool({"space", "enter", "shift"} & pressed_keys),
        )
        events = self._runtime_world.step(frame3d)
        state = {
            entity_id: {
                "translation": entity.position,
                "rotation": entity.rotation,
                "scale": entity.scale,
            }
            for entity_id, entity in self._runtime_world.entities.items()
            if entity.alive
        }
        state["__world__"] = copy.deepcopy(self._runtime_world.state)
        return state, events


__all__ = [
    "BINDING_KEY",
    "EditorDocument",
    "GRAPHS_KEY",
    "SelectionRef",
    "euler_degrees_to_quaternion",
    "quaternion_to_euler_degrees",
]
