"""Serializable, typed and bounded visual scripting for :mod:`ugts_kc3.game`.

The graph format deliberately contains data only.  Runtime behaviour lives in a
registry, so saved projects never pickle or import user code.  Built-in nodes use
the small public ``GameWorld`` surface and this module does not import the game
runtime, which keeps it useful to editor and conversion tools on its own.
"""
from __future__ import annotations

from collections import deque
import copy
from dataclasses import dataclass, field, fields, is_dataclass, replace
from enum import Enum
import hashlib
import json
import math
from typing import Any, Callable, ClassVar, Iterable, Iterator, Mapping, MutableMapping, Sequence


class FrozenDict(Mapping[str, Any]):
    """A tiny recursively-frozen mapping used by graph records.

    It prevents a caller from changing a frozen dataclass through a retained
    dictionary reference while remaining a normal ``Mapping`` to consumers.
    """

    __slots__ = ("_data", "_hash")

    def __init__(self, values: Mapping[str, Any] | None = None):
        self._data = dict(values or {})
        self._hash: int | None = None

    def __getitem__(self, key: str) -> Any:
        return self._data[key]

    def __iter__(self) -> Iterator[str]:
        return iter(self._data)

    def __len__(self) -> int:
        return len(self._data)

    def __repr__(self) -> str:
        return f"FrozenDict({self._data!r})"

    def __hash__(self) -> int:
        if self._hash is None:
            self._hash = hash(tuple(sorted((key, _hashable(value)) for key, value in self._data.items())))
        return self._hash


def _hashable(value: Any) -> Any:
    if isinstance(value, Mapping):
        return tuple(sorted((str(key), _hashable(item)) for key, item in value.items()))
    if isinstance(value, (tuple, list)):
        return tuple(_hashable(item) for item in value)
    return value


def _freeze_json(value: Any, path: str = "value") -> Any:
    if value is None or isinstance(value, (str, bool, int)):
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError(f"{path} must not contain NaN or infinity")
        return value
    if isinstance(value, Mapping):
        frozen: dict[str, Any] = {}
        for key, item in value.items():
            if not isinstance(key, str):
                raise TypeError(f"{path} uses a non-text key: {key!r}")
            frozen[key] = _freeze_json(item, f"{path}.{key}")
        return FrozenDict(frozen)
    if isinstance(value, (tuple, list)):
        return tuple(_freeze_json(item, f"{path}[{index}]") for index, item in enumerate(value))
    raise TypeError(f"{path} contains unsupported {type(value).__name__}; graph values must be JSON-compatible")


def _thaw(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): _thaw(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_thaw(item) for item in value]
    return value


def _runtime_snapshot(value: Any, seen: set[int] | None = None) -> Any:
    """Make trace values JSON-safe without affecting values passed between nodes."""

    if value is None or isinstance(value, (str, bool, int)):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else repr(value)
    if seen is None:
        seen = set()
    identity = id(value)
    if identity in seen:
        return "<recursive>"
    if isinstance(value, Mapping):
        seen.add(identity)
        result = {str(key): _runtime_snapshot(item, seen) for key, item in sorted(value.items(), key=lambda pair: str(pair[0]))}
        seen.remove(identity)
        return result
    if isinstance(value, (tuple, list, set, frozenset)):
        seen.add(identity)
        items = [_runtime_snapshot(item, seen) for item in value]
        seen.remove(identity)
        return items
    if is_dataclass(value):
        seen.add(identity)
        result = {item.name: _runtime_snapshot(getattr(value, item.name), seen) for item in fields(value)}
        seen.remove(identity)
        return result
    return f"<{type(value).__name__}>"


def _canonical_bytes(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False).encode("utf-8")


@dataclass(frozen=True, slots=True)
class GraphNode:
    """An editor node. ``properties`` are literals and editor configuration."""

    id: str
    type: str
    properties: Mapping[str, Any] = field(default_factory=FrozenDict)
    position: tuple[float, float] = (0.0, 0.0)

    def __post_init__(self) -> None:
        node_id = str(self.id).strip()
        node_type = str(self.type).strip()
        if not node_id:
            raise ValueError("a graph node needs a non-empty id")
        if not node_type:
            raise ValueError(f"node {node_id!r} needs a node type")
        if len(self.position) != 2:
            raise ValueError(f"node {node_id!r} position needs x and y values")
        position = (float(self.position[0]), float(self.position[1]))
        if not all(math.isfinite(value) for value in position):
            raise ValueError(f"node {node_id!r} position must be finite")
        object.__setattr__(self, "id", node_id)
        object.__setattr__(self, "type", node_type)
        object.__setattr__(self, "properties", _freeze_json(dict(self.properties), f"node {node_id} properties"))
        object.__setattr__(self, "position", position)

    @property
    def type_id(self) -> str:
        return self.type

    @property
    def kind(self) -> str:
        return self.type

    def to_dict(self) -> dict[str, Any]:
        return {"id": self.id, "type": self.type, "properties": _thaw(self.properties), "position": list(self.position)}

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "GraphNode":
        node_type = data.get("type", data.get("type_id", data.get("kind")))
        if node_type is None:
            raise ValueError(f"node {data.get('id', '<unknown>')!r} is missing its type")
        properties = data.get("properties", data.get("parameters", {}))
        return cls(str(data["id"]), str(node_type), dict(properties), tuple(data.get("position", (0.0, 0.0))))  # type: ignore[arg-type]


@dataclass(frozen=True, slots=True)
class GraphLink:
    """A directed connection from one output port to one input port."""

    source_node: str
    source_port: str
    target_node: str
    target_port: str

    def __post_init__(self) -> None:
        for field_name in ("source_node", "source_port", "target_node", "target_port"):
            value = str(getattr(self, field_name)).strip()
            if not value:
                raise ValueError(f"a graph link needs a non-empty {field_name.replace('_', ' ')}")
            object.__setattr__(self, field_name, value)

    @property
    def id(self) -> str:
        return f"{self.source_node}:{self.source_port}->{self.target_node}:{self.target_port}"

    def to_dict(self) -> dict[str, str]:
        return {
            "source_node": self.source_node,
            "source_port": self.source_port,
            "target_node": self.target_node,
            "target_port": self.target_port,
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "GraphLink":
        if isinstance(data.get("source"), Mapping) and isinstance(data.get("target"), Mapping):
            source, target = data["source"], data["target"]
            return cls(str(source["node"]), str(source["port"]), str(target["node"]), str(target["port"]))
        return cls(str(data["source_node"]), str(data["source_port"]), str(data["target_node"]), str(data["target_port"]))


@dataclass(frozen=True, slots=True)
class VisualGraph:
    """Immutable-ish graph document with canonical serialization hooks."""

    SCHEMA: ClassVar[str] = "ugts-visual-graph-1"

    id: str = "graph"
    nodes: tuple[GraphNode, ...] = ()
    links: tuple[GraphLink, ...] = ()
    metadata: Mapping[str, Any] = field(default_factory=FrozenDict)

    def __post_init__(self) -> None:
        graph_id = str(self.id).strip()
        if not graph_id:
            raise ValueError("a visual graph needs a non-empty id")
        nodes = tuple(sorted(
            (item if isinstance(item, GraphNode) else GraphNode.from_dict(item) for item in self.nodes),
            key=lambda item: item.id,
        ))
        links = tuple(sorted(
            (item if isinstance(item, GraphLink) else GraphLink.from_dict(item) for item in self.links),
            key=lambda item: (item.source_node, item.source_port, item.target_node, item.target_port),
        ))
        object.__setattr__(self, "id", graph_id)
        object.__setattr__(self, "nodes", nodes)
        object.__setattr__(self, "links", links)
        object.__setattr__(self, "metadata", _freeze_json(dict(self.metadata), "graph metadata"))

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": self.SCHEMA,
            "id": self.id,
            "nodes": [node.to_dict() for node in self.nodes],
            "links": [link.to_dict() for link in self.links],
            "metadata": _thaw(self.metadata),
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "VisualGraph":
        schema = data.get("schema", cls.SCHEMA)
        if schema != cls.SCHEMA:
            raise ValueError(f"unsupported visual graph schema {schema!r}; expected {cls.SCHEMA!r}")
        return cls(
            str(data.get("id", "graph")),
            tuple(GraphNode.from_dict(item) for item in data.get("nodes", ())),
            tuple(GraphLink.from_dict(item) for item in data.get("links", ())),
            dict(data.get("metadata", {})),
        )

    def canonical_bytes(self) -> bytes:
        """Return the stable, whitespace-free UTF-8 representation."""

        return _canonical_bytes(self.canonical_dict())

    def canonical_dict(self) -> dict[str, Any]:
        """Return the deterministic document used for storage and hashing."""

        return self.to_dict()

    def content_hash(self) -> str:
        return hashlib.sha256(self.canonical_bytes()).hexdigest()

    def to_json(self, *, pretty: bool = False) -> str:
        if pretty:
            return json.dumps(self.to_dict(), indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False) + "\n"
        return self.canonical_bytes().decode("utf-8")

    @classmethod
    def from_json(cls, text: str | bytes | bytearray) -> "VisualGraph":
        return cls.from_dict(json.loads(text))

    def with_node(self, node: GraphNode, *, replace_existing: bool = False) -> "VisualGraph":
        existing = {item.id for item in self.nodes}
        if node.id in existing and not replace_existing:
            raise ValueError(f"node id {node.id!r} already exists")
        nodes = tuple(item for item in self.nodes if item.id != node.id) + (node,)
        return replace(self, nodes=nodes)

    def without_node(self, node_id: str) -> "VisualGraph":
        if node_id not in {node.id for node in self.nodes}:
            raise KeyError(node_id)
        return replace(
            self,
            nodes=tuple(node for node in self.nodes if node.id != node_id),
            links=tuple(link for link in self.links if node_id not in (link.source_node, link.target_node)),
        )

    def with_link(self, link: GraphLink) -> "VisualGraph":
        if link in self.links:
            raise ValueError(f"link {link.id} already exists")
        return replace(self, links=self.links + (link,))

    def without_link(self, link: GraphLink) -> "VisualGraph":
        if link not in self.links:
            raise KeyError(link.id)
        return replace(self, links=tuple(item for item in self.links if item != link))

    def validation_issues(self, registry: "NodeRegistry | None" = None) -> tuple["GraphValidationIssue", ...]:
        return _validation_issues(self, registry or BUILTIN_NODE_REGISTRY)

    def validate(self, registry: "NodeRegistry | None" = None) -> None:
        issues = self.validation_issues(registry)
        if issues:
            raise GraphValidationError(issues)

    def data_order(self, registry: "NodeRegistry | None" = None) -> tuple[str, ...]:
        active_registry = registry or BUILTIN_NODE_REGISTRY
        self.validate(active_registry)
        return _data_order(self, active_registry)[0]


class PortDirection(str, Enum):
    INPUT = "input"
    OUTPUT = "output"


class PortKind(str, Enum):
    FLOW = "flow"
    DATA = "data"


class _NoDefault:
    __slots__ = ()

    def __repr__(self) -> str:
        return "NO_DEFAULT"


NO_DEFAULT = _NoDefault()


@dataclass(frozen=True, slots=True)
class PortDefinition:
    name: str
    direction: PortDirection | str
    kind: PortKind | str
    data_type: str = "any"
    required: bool = False
    default: Any = NO_DEFAULT
    description: str = ""
    allow_multiple: bool = False

    def __post_init__(self) -> None:
        name = str(self.name).strip()
        if not name:
            raise ValueError("a port needs a non-empty name")
        try:
            direction = PortDirection(self.direction)
        except ValueError as error:
            raise ValueError(f"port {name!r} direction must be 'input' or 'output'") from error
        try:
            kind = PortKind(self.kind)
        except ValueError as error:
            raise ValueError(f"port {name!r} kind must be 'flow' or 'data'") from error
        data_type = "flow" if kind is PortKind.FLOW else str(self.data_type).strip().lower()
        if not data_type:
            raise ValueError(f"data port {name!r} needs a type")
        if self.default is not NO_DEFAULT:
            object.__setattr__(self, "default", _freeze_json(self.default, f"port {name} default"))
        object.__setattr__(self, "name", name)
        object.__setattr__(self, "direction", direction)
        object.__setattr__(self, "kind", kind)
        object.__setattr__(self, "data_type", data_type)

    @property
    def has_default(self) -> bool:
        return self.default is not NO_DEFAULT


@dataclass(frozen=True, slots=True)
class NodeResult:
    """Values and flow outputs returned by a registered node executor."""

    values: Mapping[str, Any] = field(default_factory=dict)
    flow: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(self, "values", dict(self.values))
        object.__setattr__(self, "flow", tuple(str(item) for item in self.flow))


NodeExecutor = Callable[["GraphContext", GraphNode, Mapping[str, Any]], NodeResult | Mapping[str, Any] | None]


@dataclass(frozen=True, slots=True)
class NodeDefinition:
    """Editor metadata, typed ports and runtime function for one node type."""

    type: str
    label: str
    category: str
    description: str
    ports: tuple[PortDefinition, ...]
    executor: NodeExecutor = field(repr=False, compare=False)
    default_properties: Mapping[str, Any] = field(default_factory=FrozenDict)
    event: str | None = None

    def __post_init__(self) -> None:
        type_id = str(self.type).strip()
        if not type_id:
            raise ValueError("a node definition needs a type id")
        if not str(self.label).strip():
            raise ValueError(f"node definition {type_id!r} needs an editor label")
        ports = tuple(self.ports)
        identities = [(port.direction, port.name) for port in ports]
        if len(identities) != len(set(identities)):
            raise ValueError(f"node definition {type_id!r} repeats a port name in the same direction")
        if not callable(self.executor):
            raise TypeError(f"node definition {type_id!r} needs an executor function")
        object.__setattr__(self, "type", type_id)
        object.__setattr__(self, "label", str(self.label).strip())
        object.__setattr__(self, "category", str(self.category).strip() or "Other")
        object.__setattr__(self, "description", str(self.description).strip())
        object.__setattr__(self, "ports", ports)
        object.__setattr__(self, "default_properties", _freeze_json(dict(self.default_properties), f"{type_id} defaults"))
        object.__setattr__(self, "event", None if self.event is None else str(self.event))

    @property
    def type_id(self) -> str:
        return self.type

    @property
    def inputs(self) -> tuple[PortDefinition, ...]:
        return tuple(port for port in self.ports if port.direction is PortDirection.INPUT)

    @property
    def outputs(self) -> tuple[PortDefinition, ...]:
        return tuple(port for port in self.ports if port.direction is PortDirection.OUTPUT)

    @property
    def is_data_node(self) -> bool:
        return not any(port.kind is PortKind.FLOW for port in self.ports)

    def port(self, direction: PortDirection | str, name: str) -> PortDefinition | None:
        wanted = PortDirection(direction)
        return next((port for port in self.ports if port.direction is wanted and port.name == name), None)


class NodeRegistry:
    """Mutable registry. Graph documents store type ids, never callables."""

    def __init__(self, definitions: Iterable[NodeDefinition] = ()):
        self._definitions: dict[str, NodeDefinition] = {}
        for definition in definitions:
            self.register(definition)

    def register(self, definition: NodeDefinition, *, replace_existing: bool = False) -> NodeDefinition:
        if definition.type in self._definitions and not replace_existing:
            raise ValueError(f"node type {definition.type!r} is already registered")
        self._definitions[definition.type] = definition
        return definition

    def definition(self, type_id: str) -> NodeDefinition:
        try:
            return self._definitions[type_id]
        except KeyError as error:
            raise KeyError(f"unknown node type {type_id!r}; register it before loading this graph") from error

    def get(self, type_id: str) -> NodeDefinition | None:
        return self._definitions.get(type_id)

    def __contains__(self, type_id: object) -> bool:
        return type_id in self._definitions

    def __iter__(self) -> Iterator[NodeDefinition]:
        for type_id in sorted(self._definitions):
            yield self._definitions[type_id]

    @property
    def types(self) -> tuple[str, ...]:
        return tuple(sorted(self._definitions))

    @property
    def definitions(self) -> tuple[NodeDefinition, ...]:
        return tuple(iter(self))

    def copy(self) -> "NodeRegistry":
        return NodeRegistry(self)


@dataclass(frozen=True, slots=True)
class GraphValidationIssue:
    code: str
    message: str
    node_id: str | None = None
    link_index: int | None = None

    def __str__(self) -> str:
        return self.message


class GraphValidationError(ValueError):
    def __init__(self, issues: Sequence[GraphValidationIssue]):
        self.issues = tuple(issues)
        count = len(self.issues)
        lines = "\n".join(f"  - {issue.message}" for issue in self.issues)
        super().__init__(f"visual graph has {count} problem{'s' if count != 1 else ''}:\n{lines}")


class GraphCycleError(GraphValidationError):
    pass


def _types_connect(source: str, target: str) -> bool:
    return source == "any" or target == "any" or source == target


def _value_matches_type(value: Any, data_type: str) -> bool:
    if data_type == "any":
        return True
    if data_type == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(float(value))
    if data_type in {"string", "entity"}:
        return isinstance(value, str) or (data_type == "entity" and (value is None or hasattr(value, "id")))
    if data_type == "boolean":
        return isinstance(value, bool)
    if data_type == "mapping":
        return isinstance(value, Mapping)
    if data_type == "vector2":
        return (
            isinstance(value, (tuple, list))
            and len(value) == 2
            and all(isinstance(item, (int, float)) and not isinstance(item, bool) and math.isfinite(float(item)) for item in value)
        )
    return True  # Custom symbolic types are enforced by their registered executor.


def _node_property(definition: NodeDefinition, node: GraphNode, name: str, port: PortDefinition) -> tuple[bool, Any]:
    if name in node.properties:
        return True, node.properties[name]
    if name in definition.default_properties:
        return True, definition.default_properties[name]
    if port.has_default:
        return True, port.default
    return False, None


def _validation_issues(graph: VisualGraph, registry: NodeRegistry) -> tuple[GraphValidationIssue, ...]:
    issues: list[GraphValidationIssue] = []
    nodes: dict[str, GraphNode] = {}
    for node in graph.nodes:
        if node.id in nodes:
            issues.append(GraphValidationIssue("duplicate_node", f"Node id {node.id!r} is used more than once. Give every node a unique id.", node.id))
        else:
            nodes[node.id] = node
        if registry.get(node.type) is None:
            issues.append(GraphValidationIssue("unknown_node_type", f"Node {node.id!r} uses unknown type {node.type!r}.", node.id))

    incoming_data: dict[tuple[str, str], list[int]] = {}
    seen_links: dict[GraphLink, int] = {}
    valid_data_links: list[GraphLink] = []
    for index, link in enumerate(graph.links):
        if link in seen_links:
            issues.append(GraphValidationIssue("duplicate_link", f"Link {link.id} is duplicated (links {seen_links[link]} and {index}).", link_index=index))
            continue
        seen_links[link] = index
        source_node, target_node = nodes.get(link.source_node), nodes.get(link.target_node)
        if source_node is None:
            issues.append(GraphValidationIssue("missing_source", f"Link {index} starts at missing node {link.source_node!r}.", link_index=index))
        if target_node is None:
            issues.append(GraphValidationIssue("missing_target", f"Link {index} ends at missing node {link.target_node!r}.", link_index=index))
        if source_node is None or target_node is None:
            continue
        source_definition, target_definition = registry.get(source_node.type), registry.get(target_node.type)
        if source_definition is None or target_definition is None:
            continue
        source_port = source_definition.port(PortDirection.OUTPUT, link.source_port)
        target_port = target_definition.port(PortDirection.INPUT, link.target_port)
        if source_port is None:
            issues.append(GraphValidationIssue("missing_source_port", f"Node {source_node.id!r} has no output port named {link.source_port!r}.", source_node.id, index))
        if target_port is None:
            issues.append(GraphValidationIssue("missing_target_port", f"Node {target_node.id!r} has no input port named {link.target_port!r}.", target_node.id, index))
        if source_port is None or target_port is None:
            continue
        if source_port.kind is not target_port.kind:
            issues.append(
                GraphValidationIssue(
                    "port_kind_mismatch",
                    f"Link {link.id} connects a {source_port.kind.value} port to a {target_port.kind.value} port. Connect flow to flow or data to data.",
                    link_index=index,
                )
            )
            continue
        if source_port.kind is PortKind.DATA:
            if not _types_connect(source_port.data_type, target_port.data_type):
                issues.append(
                    GraphValidationIssue(
                        "data_type_mismatch",
                        f"Link {link.id} sends {source_port.data_type} into {target_port.data_type}; those data types do not match.",
                        link_index=index,
                    )
                )
                continue
            incoming_data.setdefault((link.target_node, link.target_port), []).append(index)
            valid_data_links.append(link)

    for (node_id, port_name), indexes in sorted(incoming_data.items()):
        node, definition = nodes[node_id], registry.get(nodes[node_id].type)
        port = None if definition is None else definition.port(PortDirection.INPUT, port_name)
        if port is not None and len(indexes) > 1 and not port.allow_multiple:
            issues.append(
                GraphValidationIssue(
                    "multiple_data_sources",
                    f"Input {node_id}.{port_name} has {len(indexes)} links. A data input accepts one source; remove all but one.",
                    node.id,
                    indexes[1],
                )
            )

    for node_id in sorted(nodes):
        node, definition = nodes[node_id], registry.get(nodes[node_id].type)
        if definition is None:
            continue
        for port in definition.inputs:
            if port.kind is not PortKind.DATA:
                continue
            linked = (node.id, port.name) in incoming_data
            supplied, literal = _node_property(definition, node, port.name, port)
            if port.required and not linked and not supplied:
                issues.append(
                    GraphValidationIssue(
                        "missing_input",
                        f"Node {node.id!r} needs a value for input {port.name!r}. Connect it or set it in the node properties.",
                        node.id,
                    )
                )
            if not linked and supplied and not _value_matches_type(literal, port.data_type):
                issues.append(
                    GraphValidationIssue(
                        "literal_type_mismatch",
                        f"Node {node.id!r} property {port.name!r} must be {port.data_type}, not {type(literal).__name__}.",
                        node.id,
                    )
                )

    _, cyclic = _data_order(graph, registry, valid_data_links)
    if cyclic:
        names = ", ".join(repr(node_id) for node_id in cyclic)
        issues.append(GraphValidationIssue("data_cycle", f"Data links form a cycle through {names}. Insert state or remove a backward data link."))
    return tuple(issues)


def _data_order(
    graph: VisualGraph,
    registry: NodeRegistry,
    known_links: Sequence[GraphLink] | None = None,
) -> tuple[tuple[str, ...], tuple[str, ...]]:
    node_ids = sorted({node.id for node in graph.nodes})
    node_map = {node.id: node for node in graph.nodes}
    dependencies: dict[str, set[str]] = {node_id: set() for node_id in node_ids}
    links = graph.links if known_links is None else known_links
    for link in links:
        source_node, target_node = node_map.get(link.source_node), node_map.get(link.target_node)
        if source_node is None or target_node is None:
            continue
        source_definition, target_definition = registry.get(source_node.type), registry.get(target_node.type)
        if source_definition is None or target_definition is None:
            continue
        source_port = source_definition.port(PortDirection.OUTPUT, link.source_port)
        target_port = target_definition.port(PortDirection.INPUT, link.target_port)
        if source_port is not None and target_port is not None and source_port.kind is target_port.kind is PortKind.DATA:
            dependencies[target_node.id].add(source_node.id)
    incoming = {node_id: set(items) for node_id, items in dependencies.items()}
    ready = sorted(node_id for node_id, items in incoming.items() if not items)
    result: list[str] = []
    while ready:
        node_id = ready.pop(0)
        result.append(node_id)
        for other in node_ids:
            if node_id in incoming[other]:
                incoming[other].remove(node_id)
                if not incoming[other] and other not in result and other not in ready:
                    ready.append(other)
                    ready.sort()
    cyclic = tuple(sorted(node_id for node_id, items in incoming.items() if items))
    return tuple(result), cyclic


@dataclass(frozen=True, slots=True)
class GraphContext:
    """Per-dispatch bridge to a ``GameWorld`` and its current entity/input."""

    world: Any
    entity_id: str | None = None
    input_frame: Any = None
    dt: float = 0.0
    event_name: str = ""
    payload: Mapping[str, Any] = field(default_factory=FrozenDict)

    def __post_init__(self) -> None:
        dt = float(self.dt)
        if not math.isfinite(dt) or dt < 0:
            raise ValueError("graph context dt must be finite and non-negative")
        object.__setattr__(self, "entity_id", None if self.entity_id is None else str(self.entity_id))
        object.__setattr__(self, "dt", dt)
        object.__setattr__(self, "event_name", str(self.event_name))
        object.__setattr__(self, "payload", _freeze_json(dict(self.payload), "graph event payload"))

    @property
    def entity(self) -> Any:
        if self.entity_id is None:
            return None
        return getattr(self.world, "entities", {}).get(self.entity_id)

    def for_event(self, event_name: str, payload: Mapping[str, Any] | None = None) -> "GraphContext":
        return replace(self, event_name=str(event_name), payload=self.payload if payload is None else payload)


@dataclass(frozen=True, slots=True)
class TraceEntry:
    step: int
    node_id: str
    node_type: str
    flow_input: str | None
    inputs: Mapping[str, Any]
    outputs: Mapping[str, Any]
    flow_outputs: tuple[str, ...]
    status: str = "ok"
    error: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "inputs", _freeze_json(_runtime_snapshot(self.inputs), "trace inputs"))
        object.__setattr__(self, "outputs", _freeze_json(_runtime_snapshot(self.outputs), "trace outputs"))
        object.__setattr__(self, "flow_outputs", tuple(self.flow_outputs))

    def to_dict(self) -> dict[str, Any]:
        result = {
            "step": self.step,
            "node_id": self.node_id,
            "node_type": self.node_type,
            "flow_input": self.flow_input,
            "inputs": _thaw(self.inputs),
            "outputs": _thaw(self.outputs),
            "flow_outputs": list(self.flow_outputs),
            "status": self.status,
        }
        if self.error is not None:
            result["error"] = self.error
        return result


@dataclass(frozen=True, slots=True)
class ExecutionResult:
    trigger: str
    steps: int
    trace: tuple[TraceEntry, ...]
    completed: bool = True

    @property
    def traces(self) -> tuple[TraceEntry, ...]:
        return self.trace

    def to_dict(self) -> dict[str, Any]:
        return {"trigger": self.trigger, "steps": self.steps, "completed": self.completed, "trace": [item.to_dict() for item in self.trace]}


class GraphExecutionError(RuntimeError):
    def __init__(self, message: str, trace: Sequence[TraceEntry] = ()):
        self.trace = tuple(trace)
        super().__init__(message)


class GraphStepLimitError(GraphExecutionError):
    def __init__(self, limit: int, node_id: str, trace: Sequence[TraceEntry]):
        self.limit = int(limit)
        self.node_id = node_id
        super().__init__(
            f"Visual graph stopped before node {node_id!r}: it reached the {limit}-step safety limit. Check for a flow loop or raise max_steps deliberately.",
            trace,
        )


class GraphNodeExecutionError(GraphExecutionError):
    def __init__(self, node: GraphNode, reason: str, trace: Sequence[TraceEntry]):
        self.node_id = node.id
        self.node_type = node.type
        super().__init__(f"Node {node.id!r} ({node.type}) could not run: {reason}", trace)


@dataclass(slots=True)
class _RunState:
    trigger: str
    context: GraphContext
    max_steps: int
    steps: int = 0
    trace: list[TraceEntry] = field(default_factory=list)
    last_outputs: dict[str, Mapping[str, Any]] = field(default_factory=dict)


class GraphRuntime:
    """Validated graph plan with deterministic, bounded event dispatch."""

    def __init__(self, graph: VisualGraph, registry: NodeRegistry | None = None, *, max_steps: int = 1024):
        if not isinstance(max_steps, int) or isinstance(max_steps, bool) or max_steps < 1:
            raise ValueError("max_steps must be a positive integer")
        self.graph = graph
        self.registry = registry or BUILTIN_NODE_REGISTRY
        graph.validate(self.registry)
        self.max_steps = max_steps
        self.order = graph.data_order(self.registry)
        self._rank = {node_id: index for index, node_id in enumerate(self.order)}
        self._nodes = {node.id: node for node in graph.nodes}
        self._incoming_data: dict[tuple[str, str], GraphLink] = {}
        self._outgoing_flow: dict[tuple[str, str], tuple[GraphLink, ...]] = {}
        outgoing: dict[tuple[str, str], list[GraphLink]] = {}
        for link in graph.links:
            source = self.registry.definition(self._nodes[link.source_node].type).port(PortDirection.OUTPUT, link.source_port)
            if source is not None and source.kind is PortKind.DATA:
                self._incoming_data[(link.target_node, link.target_port)] = link
            elif source is not None:
                outgoing.setdefault((link.source_node, link.source_port), []).append(link)
        for key, links in outgoing.items():
            self._outgoing_flow[key] = tuple(sorted(links, key=lambda item: (self._rank.get(item.target_node, 0), item.target_node, item.target_port, item.id)))
        self.last_result: ExecutionResult | None = None
        self.last_trace: tuple[TraceEntry, ...] = ()

    def execute(self, trigger: str, context: GraphContext, *, max_steps: int | None = None) -> ExecutionResult:
        """Dispatch ``ready``, ``tick``, input, or another registered event."""

        trigger_name = str(trigger).strip()
        if not trigger_name:
            raise ValueError("graph trigger name must not be empty")
        limit = self.max_steps if max_steps is None else max_steps
        if not isinstance(limit, int) or isinstance(limit, bool) or limit < 1:
            raise ValueError("max_steps must be a positive integer")
        state = _RunState(trigger_name, context.for_event(trigger_name), limit)
        queue: deque[tuple[str, str | None]] = deque()
        roots = []
        for node in self.graph.nodes:
            event = self.registry.definition(node.type).event
            if event == trigger_name or (trigger_name == "tick" and event == "input_pressed"):
                roots.append(node.id)
        for node_id in sorted(roots, key=lambda item: (self._rank[item], item)):
            queue.append((node_id, None))
        try:
            while queue:
                node_id, flow_input = queue.popleft()
                outcome = self._evaluate(node_id, flow_input, state, {})
                state.last_outputs[node_id] = outcome.values
                for flow_port in outcome.flow:
                    links = self._outgoing_flow.get((node_id, flow_port), ())
                    if len(queue) + len(links) > state.max_steps:
                        raise GraphStepLimitError(state.max_steps, links[0].target_node if links else node_id, state.trace)
                    for link in links:
                        queue.append((link.target_node, link.target_port))
        except GraphExecutionError:
            self.last_trace = tuple(state.trace)
            self.last_result = ExecutionResult(trigger_name, state.steps, self.last_trace, False)
            raise
        result = ExecutionResult(trigger_name, state.steps, tuple(state.trace), True)
        self.last_trace, self.last_result = result.trace, result
        return result

    dispatch = execute
    run = execute

    def ready(self, world: Any, *, entity_id: str | None = None, payload: Mapping[str, Any] | None = None) -> ExecutionResult:
        return self.execute("ready", GraphContext(world, entity_id, dt=0.0, payload=payload or {}))

    def tick(
        self,
        world: Any,
        dt: float | None = None,
        input_frame: Any = None,
        *,
        entity_id: str | None = None,
        payload: Mapping[str, Any] | None = None,
    ) -> ExecutionResult:
        step_dt = float(getattr(world, "fixed_dt", 0.0) if dt is None else dt)
        return self.execute("tick", GraphContext(world, entity_id, input_frame, step_dt, payload=payload or {}))

    def event(
        self,
        trigger: str,
        world: Any,
        *,
        entity_id: str | None = None,
        input_frame: Any = None,
        dt: float = 0.0,
        payload: Mapping[str, Any] | None = None,
    ) -> ExecutionResult:
        """Dispatch a named world event with an explicit, immutable payload."""
        return self.execute(
            trigger,
            GraphContext(world, entity_id, input_frame, dt, payload=payload or {}),
        )

    def _evaluate(
        self,
        node_id: str,
        flow_input: str | None,
        state: _RunState,
        data_cache: dict[str, NodeResult],
        stack: tuple[str, ...] = (),
    ) -> NodeResult:
        if node_id in data_cache:
            return data_cache[node_id]
        node = self._nodes[node_id]
        definition = self.registry.definition(node.type)
        if state.steps >= state.max_steps:
            raise GraphStepLimitError(state.max_steps, node_id, state.trace)
        if node_id in stack:
            raise GraphNodeExecutionError(node, "a data link recursively requested this node", state.trace)
        inputs: dict[str, Any] = {}
        try:
            for port in definition.inputs:
                if port.kind is PortKind.FLOW:
                    continue
                link = self._incoming_data.get((node_id, port.name))
                if link is not None:
                    source_node = self._nodes[link.source_node]
                    source_definition = self.registry.definition(source_node.type)
                    if source_node.id in state.last_outputs:
                        source_values = state.last_outputs[source_node.id]
                    elif source_definition.is_data_node:
                        source_values = self._evaluate(source_node.id, None, state, data_cache, stack + (node_id,)).values
                    else:
                        raise ValueError(
                            f"input {port.name!r} reads {source_node.id}.{link.source_port}, but that flow node has not run yet"
                        )
                    if link.source_port not in source_values:
                        raise ValueError(f"source {source_node.id}.{link.source_port} did not produce a value")
                    value = source_values[link.source_port]
                else:
                    supplied, value = _node_property(definition, node, port.name, port)
                    if not supplied:
                        if port.required:
                            raise ValueError(f"required input {port.name!r} has no value")
                        value = None
                if not _value_matches_type(value, port.data_type):
                    raise TypeError(f"input {port.name!r} expected {port.data_type}, received {type(value).__name__}")
                inputs[port.name] = value
            state.steps += 1
            raw_outcome = definition.executor(state.context, node, inputs)
            if raw_outcome is None:
                outcome = NodeResult()
            elif isinstance(raw_outcome, NodeResult):
                outcome = raw_outcome
            elif isinstance(raw_outcome, Mapping):
                outcome = NodeResult(raw_outcome)
            else:
                raise TypeError(f"executor returned unsupported {type(raw_outcome).__name__}")
            for name in outcome.values:
                port = definition.port(PortDirection.OUTPUT, name)
                if port is None or port.kind is not PortKind.DATA:
                    raise ValueError(f"executor produced undeclared data output {name!r}")
                if not _value_matches_type(outcome.values[name], port.data_type):
                    raise TypeError(f"output {name!r} promised {port.data_type}, produced {type(outcome.values[name]).__name__}")
            for name in outcome.flow:
                port = definition.port(PortDirection.OUTPUT, name)
                if port is None or port.kind is not PortKind.FLOW:
                    raise ValueError(f"executor activated undeclared flow output {name!r}")
            state.trace.append(
                TraceEntry(state.steps, node.id, node.type, flow_input, inputs, outcome.values, outcome.flow)
            )
            if definition.is_data_node:
                data_cache[node_id] = outcome
            return outcome
        except GraphExecutionError:
            raise
        except Exception as error:
            if state.steps == 0 or not state.trace or state.trace[-1].node_id != node.id:
                state.trace.append(TraceEntry(state.steps, node.id, node.type, flow_input, inputs, {}, (), "error", str(error)))
            raise GraphNodeExecutionError(node, str(error), state.trace) from error


@dataclass(slots=True)
class GraphBinding:
    """A graph registered as a normal ``GameWorld`` update system."""

    runtime: GraphRuntime
    world: Any
    entity_id: str | None
    phase: str
    name: str
    ready_result: ExecutionResult | None = None
    last_result: ExecutionResult | None = None
    last_input_frame: Any = None

    def run_ready(self) -> ExecutionResult:
        self.ready_result = self.runtime.ready(self.world, entity_id=self.entity_id)
        return self.ready_result

    def owner_is_active(self) -> bool:
        """World graphs always run; entity graphs follow their owner's lifecycle."""
        if self.entity_id is None:
            return True
        entities = getattr(self.world, "entities", None)
        if not isinstance(entities, Mapping):
            return False
        entity = entities.get(self.entity_id)
        return bool(
            entity is not None
            and getattr(entity, "alive", True)
            and getattr(entity, "active", True)
        )

    def update(self, world: Any, dt: float, input_frame: Any) -> None:
        if self.owner_is_active():
            self.last_input_frame = input_frame
            self.last_result = self.runtime.tick(world, dt, input_frame, entity_id=self.entity_id)

    def handle_trigger(self, event: Any) -> None:
        """Dispatch player/sensor transitions to world or matching sensor graphs."""
        trigger = str(getattr(event, "kind", ""))
        if trigger not in {"trigger_enter", "trigger_exit"}:
            return
        sensor = getattr(event, "entity_a", getattr(event, "source", None))
        player = getattr(event, "entity_b", getattr(event, "target", None))
        if self.entity_id is not None and str(sensor) != self.entity_id:
            return
        if not self.owner_is_active():
            return
        raw_payload = getattr(event, "data", getattr(event, "payload", {}))
        payload = dict(raw_payload) if isinstance(raw_payload, Mapping) else {}
        payload.update({"sensor": None if sensor is None else str(sensor), "player": None if player is None else str(player)})
        settings = getattr(self.world, "settings", None)
        dt = float(getattr(settings, "fixed_dt", getattr(self.world, "fixed_dt", 0.0)))
        self.last_result = self.runtime.event(
            trigger,
            self.world,
            entity_id=self.entity_id,
            input_frame=self.last_input_frame,
            dt=dt,
            payload=payload,
        )


def attach_graph(
    world: Any,
    graph: VisualGraph | GraphRuntime,
    *,
    entity_id: str | None = None,
    phase: str = "update",
    priority: int = 0,
    name: str | None = None,
    registry: NodeRegistry | None = None,
    max_steps: int = 1024,
    run_ready: bool = True,
) -> GraphBinding:
    """Attach a graph without changing ``GameWorld`` or requiring a component."""

    if not hasattr(world, "add_system"):
        raise TypeError("attach_graph needs a GameWorld-like object with add_system()")
    runtime = graph if isinstance(graph, GraphRuntime) else GraphRuntime(graph, registry, max_steps=max_steps)
    binding_name = name or f"visual_graph:{runtime.graph.id}:{entity_id or 'world'}"
    binding = GraphBinding(runtime, world, entity_id, phase, binding_name)
    world.add_system(binding.update, phase=phase, priority=int(priority), name=binding_name)
    if hasattr(world, "on"):
        world.on("trigger_enter", binding.handle_trigger)
        world.on("trigger_exit", binding.handle_trigger)
    if run_ready:
        binding.run_ready()
    return binding


def _in_flow(name: str = "in", description: str = "Runs this node when a flow arrives.") -> PortDefinition:
    return PortDefinition(name, PortDirection.INPUT, PortKind.FLOW, description=description, allow_multiple=True)


def _out_flow(name: str = "out", description: str = "Continues to the next connected node.") -> PortDefinition:
    return PortDefinition(name, PortDirection.OUTPUT, PortKind.FLOW, description=description, allow_multiple=True)


def _in_data(
    name: str,
    data_type: str = "any",
    *,
    required: bool = False,
    default: Any = NO_DEFAULT,
    description: str = "",
) -> PortDefinition:
    return PortDefinition(name, PortDirection.INPUT, PortKind.DATA, data_type, required, default, description)


def _out_data(name: str, data_type: str = "any", description: str = "") -> PortDefinition:
    return PortDefinition(name, PortDirection.OUTPUT, PortKind.DATA, data_type, description=description, allow_multiple=True)


def _entity_id(context: GraphContext, value: Any) -> str:
    resolved = context.entity_id if value in (None, "") else getattr(value, "id", value)
    if resolved is None or not str(resolved):
        raise ValueError("no entity was supplied; set the entity input or bind this graph to an entity")
    entity_id = str(resolved)
    if entity_id not in getattr(context.world, "entities", {}):
        raise KeyError(f"entity {entity_id!r} does not exist")
    return entity_id


def _read_field(value: Any, path: str, default: Any = NO_DEFAULT) -> Any:
    if not path:
        return value
    current = value
    try:
        for part in path.split("."):
            if not part or part.startswith("_"):
                raise ValueError("component field names cannot be empty or private")
            if isinstance(current, Mapping):
                current = current[part]
            elif isinstance(current, (tuple, list)) and part.isdigit():
                current = current[int(part)]
            else:
                current = getattr(current, part)
        return current
    except (KeyError, IndexError, AttributeError):
        if default is not NO_DEFAULT:
            return default
        raise


def _write_field(value: Any, path: str, new_value: Any) -> None:
    parts = path.split(".")
    if not parts or any(not part or part.startswith("_") for part in parts):
        raise ValueError("component field names cannot be empty or private")
    current = value
    for part in parts[:-1]:
        if isinstance(current, Mapping):
            current = current[part]
        elif isinstance(current, list) and part.isdigit():
            current = current[int(part)]
        else:
            current = getattr(current, part)
    last = parts[-1]
    if isinstance(current, MutableMapping):
        current[last] = new_value
    elif isinstance(current, list) and last.isdigit():
        current[int(last)] = new_value
    else:
        setattr(current, last, new_value)


def _event_ready(context: GraphContext, node: GraphNode, inputs: Mapping[str, Any]) -> NodeResult:
    return NodeResult({"entity": context.entity_id}, ("out",))


def _event_tick(context: GraphContext, node: GraphNode, inputs: Mapping[str, Any]) -> NodeResult:
    return NodeResult({"dt": context.dt, "tick": int(getattr(context.world, "tick", 0)), "entity": context.entity_id}, ("out",))


def _event_input_pressed(context: GraphContext, node: GraphNode, inputs: Mapping[str, Any]) -> NodeResult:
    action = str(inputs["action"])
    frame = context.input_frame
    value = 0.0 if frame is None else float(frame.value(action)) if hasattr(frame, "value") else float(getattr(frame, "values", {}).get(action, 0.0))
    if frame is not None and hasattr(frame, "pressed"):
        active = bool(frame.pressed(action))
    else:
        active = context.event_name == "input_pressed" and context.payload.get("action", action) == action
    return NodeResult({"action": action, "value": value, "entity": context.entity_id}, ("out",) if active else ())


def _event_trigger(context: GraphContext, node: GraphNode, inputs: Mapping[str, Any]) -> NodeResult:
    return NodeResult(
        {
            "sensor": context.payload.get("sensor"),
            "player": context.payload.get("player"),
            "entity": context.entity_id,
        },
        ("out",),
    )


def _branch(context: GraphContext, node: GraphNode, inputs: Mapping[str, Any]) -> NodeResult:
    return NodeResult(flow=("true",) if inputs["condition"] else ("false",))


def _constant(context: GraphContext, node: GraphNode, inputs: Mapping[str, Any]) -> NodeResult:
    return NodeResult({"value": _thaw(node.properties.get("value", 0))})


def _state(context: GraphContext, node: GraphNode, inputs: Mapping[str, Any]) -> NodeResult:
    key = str(inputs["key"])
    default = inputs.get("default")
    return NodeResult({"value": getattr(context.world, "state", {}).get(key, default)})


def _component(context: GraphContext, node: GraphNode, inputs: Mapping[str, Any]) -> NodeResult:
    entity_id = _entity_id(context, inputs.get("entity"))
    component_name = str(inputs["component"])
    component = context.world.get(entity_id, component_name)
    default = inputs.get("default")
    if component is None:
        return NodeResult({"value": default})
    return NodeResult({"value": _read_field(component, str(inputs.get("field") or ""), default)})


def _math(operation: str) -> NodeExecutor:
    def execute(context: GraphContext, node: GraphNode, inputs: Mapping[str, Any]) -> NodeResult:
        a, b = inputs["a"], inputs["b"]
        if operation == "add":
            value = a + b
        elif operation == "subtract":
            value = a - b
        elif operation == "multiply":
            value = a * b
        else:
            if b == 0:
                raise ZeroDivisionError("cannot divide by zero")
            value = a / b
        if not math.isfinite(float(value)):
            raise ArithmeticError("math result is not finite")
        return NodeResult({"result": value})

    return execute


def _compare(context: GraphContext, node: GraphNode, inputs: Mapping[str, Any]) -> NodeResult:
    operation = str(inputs.get("operator", "equal")).lower().replace(" ", "_")
    a, b = inputs["a"], inputs["b"]
    operations: dict[str, Callable[[Any, Any], bool]] = {
        "equal": lambda left, right: left == right,
        "eq": lambda left, right: left == right,
        "==": lambda left, right: left == right,
        "not_equal": lambda left, right: left != right,
        "ne": lambda left, right: left != right,
        "!=": lambda left, right: left != right,
        "less": lambda left, right: left < right,
        "lt": lambda left, right: left < right,
        "<": lambda left, right: left < right,
        "less_equal": lambda left, right: left <= right,
        "lte": lambda left, right: left <= right,
        "<=": lambda left, right: left <= right,
        "greater": lambda left, right: left > right,
        "gt": lambda left, right: left > right,
        ">": lambda left, right: left > right,
        "greater_equal": lambda left, right: left >= right,
        "gte": lambda left, right: left >= right,
        ">=": lambda left, right: left >= right,
    }
    if operation not in operations:
        raise ValueError(f"unknown comparison {operation!r}; use equal, not_equal, less, less_equal, greater or greater_equal")
    return NodeResult({"result": bool(operations[operation](a, b))})


def _set_state(context: GraphContext, node: GraphNode, inputs: Mapping[str, Any]) -> NodeResult:
    key = str(inputs["key"])
    if not key:
        raise ValueError("state key cannot be empty")
    context.world.state[key] = copy.deepcopy(_thaw(inputs["value"]))
    return NodeResult(flow=("out",))


def _set_component(context: GraphContext, node: GraphNode, inputs: Mapping[str, Any]) -> NodeResult:
    entity_id = _entity_id(context, inputs.get("entity"))
    component_name = str(inputs["component"])
    field_path = str(inputs.get("field") or "")
    new_value = copy.deepcopy(_thaw(inputs["value"]))
    if not field_path:
        context.world.add_component(entity_id, new_value, component_name, replace_existing=True)
    else:
        component = context.world.require(entity_id, component_name)
        updated = copy.deepcopy(component)
        _write_field(updated, field_path, new_value)
        validate = getattr(updated, "validate", None)
        if callable(validate):
            validate()
        context.world.add_component(entity_id, updated, component_name, replace_existing=True)
    return NodeResult(flow=("out",))


def _emit_event(context: GraphContext, node: GraphNode, inputs: Mapping[str, Any]) -> NodeResult:
    source = context.entity_id if inputs.get("source") in (None, "") else str(inputs["source"])
    target = None if inputs.get("target") in (None, "") else str(inputs["target"])
    payload = inputs.get("payload") or {}
    if not isinstance(payload, Mapping):
        raise TypeError("event payload must be a mapping")
    event = context.world.emit(str(inputs["kind"]), source=source, target=target, payload=_thaw(payload))
    return NodeResult({"event": event}, ("out",))


def _apply_force(context: GraphContext, node: GraphNode, inputs: Mapping[str, Any]) -> NodeResult:
    context.world.apply_force(_entity_id(context, inputs.get("entity")), inputs["force"])
    return NodeResult(flow=("out",))


def _set_active(context: GraphContext, node: GraphNode, inputs: Mapping[str, Any]) -> NodeResult:
    context.world.entities[_entity_id(context, inputs.get("entity"))].active = bool(inputs["active"])
    return NodeResult(flow=("out",))


def _despawn(context: GraphContext, node: GraphNode, inputs: Mapping[str, Any]) -> NodeResult:
    context.world.despawn(_entity_id(context, inputs.get("entity")))
    return NodeResult(flow=("out",))


def create_builtin_registry() -> NodeRegistry:
    """Create a fresh registry containing the dependency-free core node set."""

    flow_action_ports = (_in_flow(), _out_flow())
    definitions = [
        NodeDefinition(
            "event.ready", "Ready", "Events", "Runs once when this graph binding is attached.",
            (_out_flow(), _out_data("entity", "entity", "The bound entity id, if any.")), _event_ready, event="ready",
        ),
        NodeDefinition(
            "event.tick", "Tick", "Events", "Runs on every fixed GameWorld update.",
            (_out_flow(), _out_data("dt", "number", "Fixed step seconds."), _out_data("tick", "number"), _out_data("entity", "entity")),
            _event_tick, event="tick",
        ),
        NodeDefinition(
            "event.input_pressed", "Input Pressed", "Events", "Runs on the frame an input action crosses its pressed threshold.",
            (_in_data("action", "string", required=True), _out_flow(), _out_data("action", "string"), _out_data("value", "number"), _out_data("entity", "entity")),
            _event_input_pressed, {"action": "accept"}, event="input_pressed",
        ),
        NodeDefinition(
            "event.trigger_enter", "Trigger Enter", "Events", "Runs once when the active player enters this sensor area.",
            (_out_flow(), _out_data("sensor", "entity", "The sensor area."), _out_data("player", "entity", "The active player."), _out_data("entity", "entity", "The graph's bound sensor, if any.")),
            _event_trigger, event="trigger_enter",
        ),
        NodeDefinition(
            "event.trigger_exit", "Trigger Exit", "Events", "Runs once when the active player leaves this sensor area.",
            (_out_flow(), _out_data("sensor", "entity", "The sensor area."), _out_data("player", "entity", "The active player."), _out_data("entity", "entity", "The graph's bound sensor, if any.")),
            _event_trigger, event="trigger_exit",
        ),
        NodeDefinition(
            "flow.branch", "Branch", "Flow", "Continues through True or False based on a boolean condition.",
            (_in_flow(), _in_data("condition", "boolean", required=True), _out_flow("true"), _out_flow("false")), _branch, {"condition": True},
        ),
        NodeDefinition(
            "value.constant", "Constant", "Values", "Provides a saved literal value.",
            (_out_data("value"),), _constant, {"value": 0},
        ),
        NodeDefinition(
            "value.state", "World State", "Values", "Reads a key from GameWorld.state.",
            (_in_data("key", "string", required=True), _in_data("default"), _out_data("value")), _state, {"key": "score", "default": None},
        ),
        NodeDefinition(
            "value.component", "Component Value", "Values", "Reads a component or a dotted component field from an entity.",
            (_in_data("entity", "entity"), _in_data("component", "string", required=True), _in_data("field", "string"), _in_data("default"), _out_data("value")),
            _component, {"entity": None, "component": "transform", "field": "position", "default": None},
        ),
        NodeDefinition(
            "math.add", "Add", "Math", "Adds two numbers.",
            (_in_data("a", "number", required=True), _in_data("b", "number", required=True), _out_data("result", "number")), _math("add"), {"a": 0, "b": 0},
        ),
        NodeDefinition(
            "math.subtract", "Subtract", "Math", "Subtracts B from A.",
            (_in_data("a", "number", required=True), _in_data("b", "number", required=True), _out_data("result", "number")), _math("subtract"), {"a": 0, "b": 0},
        ),
        NodeDefinition(
            "math.multiply", "Multiply", "Math", "Multiplies two numbers.",
            (_in_data("a", "number", required=True), _in_data("b", "number", required=True), _out_data("result", "number")), _math("multiply"), {"a": 1, "b": 1},
        ),
        NodeDefinition(
            "math.divide", "Divide", "Math", "Divides A by B and reports division by zero clearly.",
            (_in_data("a", "number", required=True), _in_data("b", "number", required=True), _out_data("result", "number")), _math("divide"), {"a": 0, "b": 1},
        ),
        NodeDefinition(
            "compare", "Compare", "Logic", "Compares A and B using the selected operator.",
            (_in_data("a", required=True), _in_data("b", required=True), _in_data("operator", "string"), _out_data("result", "boolean")),
            _compare, {"a": 0, "b": 0, "operator": "equal"},
        ),
        NodeDefinition(
            "action.set_state", "Set World State", "Actions", "Stores a value in GameWorld.state.",
            flow_action_ports + (_in_data("key", "string", required=True), _in_data("value", required=True)), _set_state, {"key": "score", "value": 0},
        ),
        NodeDefinition(
            "action.set_component", "Set Component", "Actions", "Replaces a component or updates one dotted field on a copied component.",
            flow_action_ports + (_in_data("entity", "entity"), _in_data("component", "string", required=True), _in_data("field", "string"), _in_data("value", required=True)),
            _set_component, {"entity": None, "component": "transform", "field": "position", "value": [0, 0]},
        ),
        NodeDefinition(
            "action.emit_event", "Emit Event", "Actions", "Emits a normal GameWorld event for audio, UI or gameplay listeners.",
            flow_action_ports + (_in_data("kind", "string", required=True), _in_data("source", "entity"), _in_data("target", "entity"), _in_data("payload", "mapping"), _out_data("event")),
            _emit_event, {"kind": "graph_event", "source": None, "target": None, "payload": {}},
        ),
        NodeDefinition(
            "action.apply_force", "Apply Force", "Physics", "Pushes a 2D body in XY or a 3D body across its XZ ground plane.",
            flow_action_ports + (_in_data("entity", "entity"), _in_data("force", "vector2", required=True)), _apply_force, {"entity": None, "force": [0, 0]},
        ),
        NodeDefinition(
            "action.set_active", "Set Active", "Actions", "Enables or disables an entity for queries and simulation systems.",
            flow_action_ports + (_in_data("entity", "entity"), _in_data("active", "boolean", required=True)), _set_active, {"entity": None, "active": True},
        ),
        NodeDefinition(
            "action.despawn", "Despawn", "Actions", "Removes the chosen entity (deferred safely while GameWorld is stepping).",
            flow_action_ports + (_in_data("entity", "entity"),), _despawn, {"entity": None},
        ),
    ]
    return NodeRegistry(definitions)


BUILTIN_NODE_REGISTRY = create_builtin_registry()
DEFAULT_NODE_REGISTRY = BUILTIN_NODE_REGISTRY


__all__ = [
    "BUILTIN_NODE_REGISTRY",
    "DEFAULT_NODE_REGISTRY",
    "ExecutionResult",
    "FrozenDict",
    "GraphBinding",
    "GraphContext",
    "GraphCycleError",
    "GraphExecutionError",
    "GraphLink",
    "GraphNode",
    "GraphNodeExecutionError",
    "GraphRuntime",
    "GraphStepLimitError",
    "GraphValidationError",
    "GraphValidationIssue",
    "NO_DEFAULT",
    "NodeDefinition",
    "NodeRegistry",
    "NodeResult",
    "PortDefinition",
    "PortDirection",
    "PortKind",
    "TraceEntry",
    "VisualGraph",
    "attach_graph",
    "create_builtin_registry",
]
