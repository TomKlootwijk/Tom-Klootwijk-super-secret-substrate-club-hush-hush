# UGTS-KC 3.9.2 — K-Kij-T / Grove

Creation-engine release focused on a learnable desktop workflow and a compact native Mali-G720 MC7
result, with adaptive fallbacks for general Android phones.

## What is actually in this release

- Dockable PySide6 UGTS Studio with 2D/3D scene authoring, undo/redo, picture/shape/material choices,
  real preview, readable checks and direct build targets.
- A 22-block visual-logic vocabulary shared by desktop, retained 2D HTML5 and native Android,
  including append-only opcode 22 **Find Nearby Object** with deterministic nearest-tag sensing.
- Selection-owned Logic Blocks: unbound 2D/3D objects start blank, first edit binds atomically with
  Undo, multiple bindings have a chooser, and Populate Area prototypes cannot own graphs.
- A four-graph Mobile 3D First Steps project whose **World Logic → Find the Goal** lesson explicitly
  searches from Player for Goal within 9 m and stores `nearby_goal`.
- ECS composition plus two-word packed log-polar pose/motion components and shared binary16 LUTs.
- Native Android Studio/Gradle project with a GLES3 renderer, dynamic internal resolution,
  pointer-ID-aware two-thumb controls and adaptive Poco/general-device profiles.
- Full-screen Grove juice/post pass with glow, flash, chromatic separation, vignette,
  saturation/contrast response and pickup/goal shockwave.
- KC3D392 scene packs, glTF interchange and all retained 3.9/3.9.1 2D, browser and 3D APIs.
- GUI **Check Phone** (`Ctrl+Shift+P`) and CLI `profile-android` for a nonblocking default 30-second
  observation of a running deployed game with its screen on, covering frame cadence, memory, GPU
  temperature when exposed by Android, and crash warnings without injected input or setting edits.

## PCG

General gameplay PCG remains a future TODO. Grove ships only bounded decorative **Populate Area**:
static render-only copies with explicit caps and no independent collider, movement, gameplay or
Logic Block identity.

## Build boundary

The local Android SDK/NDK compiles the current child-friendly project into the v2-signed, ARM64-only
`build/UGTS-First-Steps-3.9.2-Poco-X7-Pro-debug.apk` (1,441,929 bytes; SHA-256
`7F3080834EDB56EAAB0BFE8AEA1B1AD2D634C1AA7C4EB314C5B614760E48454F`). Package inspection verifies
minimum SDK 26, target SDK 36, GLES3 and package
`org.ugts.games.my_mobile_3d_game.pocox7pro`.

An earlier 3.9.2 APK was installed, hash-matched and profiled on the physical Poco, producing the
retained 64.9-second idle baseline. The current APK has also been installed, cold-launched and
hash-matched; its fresh 30-second baseline measured 120.23 effective FPS, 10.118 ms p95,
132,590–138,573 KiB PSS, 44.634–45.511 °C reported GPU temperature, thermal status 0 and no crash
lines or warnings. That short baseline does not replace interaction-heavy/touch, unplugged,
long-duration thermal or 60/90 Hz/lower-tier fallback evidence. Vulkan and a full AAA asset/content
pipeline remain future work.
