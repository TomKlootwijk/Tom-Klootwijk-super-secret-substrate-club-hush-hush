# Release Notes — 3.9.2

**K-Kij-T / Grove**

3.9.2 is an additive creation-engine upgrade of 3.9.1 focused on a learnable desktop workflow and a
compact Mali-G720 MC7 Android result. It adds UGTS Studio, typed Logic Blocks, ECS composition,
log-polar packed kinematics, direct Poco APK tooling, the Grove juice controller, GLES post composite,
shockwave/flash/bloom response, device tuning and KC3D392 assets.

The beginner editor supports undoable object creation, copying, deletion and existing picture,
shape and material assignment, plus bounded undoable Wavefront OBJ import. Logic-block creation is
re-entrancy safe and finite properties use contextual child-facing choices. Logic Blocks now follows
the selected 2D/3D owner: an unbound object shows a blank graph, its first meaningful edit creates and
binds it in one undoable operation, and an intentional multi-binding exposes an exact chooser.
Undo restores the unbound state, while Populate Area prototypes are refused as graph owners. A
one-click Windows launcher and a prominent ADB **Deploy to Phone** action remove command-line steps.
Deploy now pins the
sole authorized device, builds below `.ugts-studio/deploy`, installs, reads Gradle's exact flavor-aware
`applicationId`, and opens `android.app.NativeActivity` on that same device. Its messages distinguish
build, install and launch failures. On Android, touch roles are tracked by pointer ID so a left
movement thumb and right dash/look thumb work together without being swapped by pointer ordering.

With a deployed game already running and the screen on, GUI **Check Phone** (`Ctrl+Shift+P`) performs
a nonblocking 30-second ADB observation. It reports SurfaceFlinger frame cadence, process PSS,
GPU temperature when Android exposes it and app crash-buffer warnings without injecting input or
changing project/game/device settings. The CLI exposes the same bounded operation as
`profile-android` and retains additional available RSS/battery/thermal fields in JSON; only
SurfaceFlinger's diagnostic latency history is cleared between windows.

The Mobile 3D Inspector adds child-readable **Off**, **Orbit**, **Spiral Out** and **Spiral In** movement
presets with radius, turn speed and start angle controls. The generated ECS data remains compact: two
unsigned 64-bit log-polar words per mover, a shared binary16 UGLUT2 per profile, and one exact 24-byte
sparse Android record per moving node. Dynamic nodes are guarded because their transforms belong to
physics.

KCVG001 now carries sparse world graphs as well as entity graphs, and desktop, retained HTML5 and
native Android execute the full current 22-block vocabulary. Append-only opcode 21 is **Repeatable
Random Number**. Opcode 22 is the new **Find Nearby Object** Sensing block: it starts from an explicit
or bound origin, accepts only Player/Collectible/Goal/Decorative/Hazard, uses an inclusive radius,
filters the origin plus dead/inactive candidates, selects the nearest match and breaks an exact tie
by deterministic object ID. Sensor entry/exit has matching desktop/native sphere/box overlap,
non-physical transitions, sensor/player/entity graph context, world-or-matching-sensor dispatch and
explicit sensor/dispatch caps.

Desktop Preview now exposes a read-only Logic Trail. Numbered block badges and the Last Run list show
execution order, values, chosen flow and errors without mutating or serializing the project; the latest
trail remains visible after Stop and adds zero export bytes.

The child-facing Trigger Area3D workflow is included: **+ Trigger Area** adds a ready-made sensor, and
the Inspector's **Use as Trigger** control offers Sphere/Radius or Box/Size X/Y/Z. The Scene Tree and
Resources panel identify Trigger Areas, and edits support Undo/Redo and save/load.

Grove's phone player is native C++/GLES rather than an HTML wrapper. The retained 2D project model
still exports HTML5, and its bounded browser VM executes the same current 22-block vocabulary,
including Repeatable Random Number, Find Nearby Object, one-shot Trigger Enter/Exit lifecycle and
sensor/player context. The Android exporter
currently consumes the separate Mobile3D project model.

The first-steps Mobile 3D project also ships **World Logic → Find the Goal**. Its explicit Player
origin searches for Goal through an inclusive 9 m radius and stores `found` as `nearby_goal`, keeping
the world graph independent of an implicit object owner. It also ships Crystal Garden and bounded
Populate Area recipes. One
authored safe static prototype can represent 2–256 deterministic display objects; projects are capped
at 64 groups and 1,024 objects. A group costs 36 bytes under one shared 24-byte `KCSP392` header,
glTF bakes the copies, and native GLES regenerates the same ordered prefix for instanced drawing.
Generated copies deliberately have no gameplay, collider, movement or Logic Block identity. This is
compact decorative population, not a general gameplay-PCG system; overlap avoidance, per-copy culling,
LOD and a Mobile 3D browser runtime are not claimed.

Current source verification covers 455 tests and the four-graph, 823-byte `KCVG001` First Steps
sidecar. The current 1,441,929-byte opcode-22 APK was installed, cold-launched and hash-matched on the
Poco; its fresh 30-second baseline records 120.23 effective FPS, 10.118 ms p95, thermal status 0 and
no crash lines or warnings. The retained 64.9-second idle baseline belongs to the preceding APK, so
interaction-heavy/touch, unplugged, long-duration thermal, explicit 60/90 Hz fallback and lower-tier
device runs remain open.
