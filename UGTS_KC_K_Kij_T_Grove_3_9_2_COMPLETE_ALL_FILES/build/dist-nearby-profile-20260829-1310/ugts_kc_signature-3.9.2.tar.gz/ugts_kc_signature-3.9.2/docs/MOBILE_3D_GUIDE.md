# Mobile 3D Creation Guide

Create and inspect a project:

```bash
PYTHONPATH=src python -m ugts_kc3 new-3d my_arena   --template signature-arena --author "Tom Klootwijk" --android
PYTHONPATH=src python -m ugts_kc3 validate-3d my_arena/project.json
PYTHONPATH=src python -m ugts_kc3 simulate-3d my_arena/project.json   --steps 480 --move-z -1 --json
PYTHONPATH=src python -m ugts_kc3 pack-3d my_arena/project.json   my_arena/signature_scene.kc3d --inspect
PYTHONPATH=src python -m ugts_kc3 export-gltf3d my_arena/project.json   my_arena/signature_scene.gltf
```

Author meshes and materials with stable IDs, then reference them from nodes. Gameplay tags currently
recognized by the oracle and native demo are `player`, `collectible`, `goal`, `hazard` and
`decorative`. Those are also the five portable choices in **Find Nearby Object**: choose an explicit
or bound origin and inclusive radius to receive the nearest active/alive match, with deterministic ID
ties. First Steps demonstrates the block in **World Logic → Find the Goal** using Player, Goal, 9 m
and `nearby_goal`.

Logic Blocks follows the selected node. An unbound node shows a blank graph until its first edit
creates and binds one undoably; multi-bindings have an exact chooser. A Populate Area prototype
cannot own Logic Blocks. Use simple sphere/box colliders for mobile-friendly broad behavior.

Quality tiers are ordered from most expensive to safest. Android profiles choose a starting tier;
the runtime may descend under sustained low FPS or thermal pressure and recover conservatively.
