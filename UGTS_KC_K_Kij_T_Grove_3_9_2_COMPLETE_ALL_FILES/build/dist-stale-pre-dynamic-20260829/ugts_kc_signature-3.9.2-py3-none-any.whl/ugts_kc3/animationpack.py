"""Sparse deterministic KCAN transform-animation asset for Android."""

from __future__ import annotations

import hashlib
import math
from pathlib import Path
import struct
from typing import Any

from .animation3d import (
    ANIMATION_EASINGS,
    ANIMATION_LOOP_MODES,
    MAX_ANIMATED_NODES,
    MAX_ANIMATION_CLIPS_PER_NODE,
    MAX_ANIMATION_CLIPS_TOTAL,
    MAX_ANIMATION_DURATION,
    MAX_ANIMATION_KEYS_PER_NODE,
    MAX_ANIMATION_KEYS_TOTAL,
    MAX_ANIMATION_SCALE,
    MAX_ANIMATION_TRANSLATION,
    MIN_ANIMATION_SCALE,
    TransformAnimationError,
    collect_transform_animation_spec,
)


ANIMATION_PACK_ASSET = "transform_animations.kcan"
ANIMATION_PACK_MAGIC = b"KCAN392\0"
ANIMATION_PACK_ENDIAN = 0x01020304
LEGACY_ANIMATION_PACK_VERSION = 1
ANIMATION_PACK_VERSION = 2
LEGACY_ANIMATION_BINDING_BYTES = 16
ANIMATION_BINDING_BYTES = 24
ANIMATION_KEY_BYTES = 24
MAX_ANIMATION_PACK_BYTES = 128 * 1024


class AnimationPackError(TransformAnimationError):
    """Malformed KCAN bytes or animation data that cannot be packed."""


def _key_bytes(key: Any, duration: float) -> bytes:
    time_code = int(round(key.time / duration * 65535.0))
    packed_rotation = key.packed_rotation or key.rotation
    try:
        easing_code = ANIMATION_EASINGS.index(key.easing)
        return struct.pack(
            "<HBB10e",
            time_code,
            easing_code,
            0,
            *key.translation,
            *packed_rotation,
            *key.scale,
        )
    except (OverflowError, struct.error, ValueError) as exc:
        raise AnimationPackError(
            "animation key cannot use the compact phone format"
        ) from exc


def compile_animation_pack_bytes(project: Any) -> bytes:
    """Compile placed node animations; unused projects return no asset."""

    project.validate()
    spec = collect_transform_animation_spec(project)
    if not spec.bindings:
        return b""

    legacy = bool(spec.legacy)
    version = LEGACY_ANIMATION_PACK_VERSION if legacy else ANIMATION_PACK_VERSION
    ordered = sorted(
        spec.bindings,
        key=lambda binding: (binding.node_index, binding.clip_hash),
    )
    if list(spec.bindings) != ordered:
        raise AnimationPackError("animation bindings are not canonical")
    pairs = [(binding.node_index, binding.clip_hash) for binding in ordered]
    if len(pairs) != len(set(pairs)):
        raise AnimationPackError("animation bindings contain a clip-hash collision")
    if legacy and len({binding.node_index for binding in ordered}) != len(ordered):
        raise AnimationPackError("legacy animation packs allow one clip per scene node")

    packed_keys = bytearray()
    binding_records: list[bytes] = []
    for binding in ordered:
        animation = binding.animation
        payload = b"".join(
            _key_bytes(key, animation.duration) for key in animation.keys
        )
        first_key = len(packed_keys) // ANIMATION_KEY_BYTES
        packed_keys.extend(payload)
        if legacy:
            binding_records.append(
                struct.pack(
                    "<IfIHBB",
                    binding.node_index,
                    animation.duration,
                    first_key,
                    len(animation.keys),
                    ANIMATION_LOOP_MODES.index(animation.loop_mode),
                    0,
                )
            )
        else:
            flags = 1 if binding.autoplay else 0
            binding_records.append(
                struct.pack(
                    "<IQfIHBB",
                    binding.node_index,
                    binding.clip_hash,
                    animation.duration,
                    first_key,
                    len(animation.keys),
                    ANIMATION_LOOP_MODES.index(animation.loop_mode),
                    flags,
                )
            )

    packed_key_count = len(packed_keys) // ANIMATION_KEY_BYTES
    if packed_key_count > MAX_ANIMATION_KEYS_TOTAL:
        raise AnimationPackError("animation pack exceeds its key limit")
    result = b"".join(
        (
            ANIMATION_PACK_MAGIC,
            struct.pack(
                "<IIHHI",
                ANIMATION_PACK_ENDIAN,
                version,
                len(binding_records),
                0,
                packed_key_count,
            ),
            *binding_records,
            bytes(packed_keys),
        )
    )
    if len(result) > MAX_ANIMATION_PACK_BYTES:
        raise AnimationPackError(
            f"animation pack is {len(result)} bytes; limit is {MAX_ANIMATION_PACK_BYTES}"
        )
    inspect_animation_pack(result, node_count=len(getattr(project, "nodes", ())))
    return result


def write_animation_pack(project: Any, path: str | Path) -> Path | None:
    data = compile_animation_pack_bytes(project)
    if not data:
        return None
    result = Path(path)
    result.parent.mkdir(parents=True, exist_ok=True)
    result.write_bytes(data)
    return result


def _require_finite(values: tuple[float, ...], label: str) -> None:
    if not all(math.isfinite(value) for value in values):
        raise AnimationPackError(f"{label} contains a non-finite value")


def inspect_animation_pack(
    data_or_path: bytes | str | Path, *, node_count: int | None = None
) -> dict[str, Any]:
    """Strictly parse every record and return compact build diagnostics."""

    data = (
        Path(data_or_path).read_bytes()
        if isinstance(data_or_path, (str, Path))
        else bytes(data_or_path)
    )
    if len(data) > MAX_ANIMATION_PACK_BYTES:
        raise AnimationPackError("animation asset exceeds its byte limit")
    if len(data) < 24:
        raise AnimationPackError("truncated animation asset")
    if data[:8] != ANIMATION_PACK_MAGIC:
        raise AnimationPackError("animation magic mismatch")
    endian, version, binding_count, reserved, key_count = struct.unpack_from(
        "<IIHHI", data, 8
    )
    if endian != ANIMATION_PACK_ENDIAN:
        raise AnimationPackError("animation endian marker mismatch")
    if version not in (LEGACY_ANIMATION_PACK_VERSION, ANIMATION_PACK_VERSION):
        raise AnimationPackError("unsupported animation version")
    if reserved:
        raise AnimationPackError("animation header reserved field is nonzero")
    max_bindings = (
        MAX_ANIMATED_NODES
        if version == LEGACY_ANIMATION_PACK_VERSION
        else MAX_ANIMATION_CLIPS_TOTAL
    )
    if not 1 <= binding_count <= max_bindings:
        raise AnimationPackError("animation binding count is invalid")
    if not 1 <= key_count <= MAX_ANIMATION_KEYS_TOTAL:
        raise AnimationPackError("animation packed key count is invalid")
    binding_bytes = (
        LEGACY_ANIMATION_BINDING_BYTES
        if version == LEGACY_ANIMATION_PACK_VERSION
        else ANIMATION_BINDING_BYTES
    )
    expected = 24 + binding_count * binding_bytes + key_count * ANIMATION_KEY_BYTES
    if len(data) < expected:
        raise AnimationPackError("truncated animation record")
    if len(data) > expected:
        raise AnimationPackError(
            f"animation asset has {len(data) - expected} trailing bytes"
        )

    bindings: list[dict[str, Any]] = []
    next_key = 0
    previous_pair: tuple[int, int] | None = None
    autoplay_nodes: set[int] = set()
    clips_per_node: dict[int, int] = {}
    offset = 24
    for _ in range(binding_count):
        clip_hash: int | None = None
        autoplay = True
        if version == LEGACY_ANIMATION_PACK_VERSION:
            node_index, duration, first_key, count, loop_mode, binding_reserved = (
                struct.unpack_from("<IfIHBB", data, offset)
            )
            if binding_reserved:
                raise AnimationPackError("animation binding reserved field is nonzero")
            pair = (node_index, 0)
        else:
            node_index, clip_hash, duration, first_key, count, loop_mode, flags = (
                struct.unpack_from("<IQfIHBB", data, offset)
            )
            if flags & ~1:
                raise AnimationPackError(
                    "animation binding flags contain unsupported bits"
                )
            autoplay = bool(flags & 1)
            pair = (node_index, clip_hash)
            if autoplay:
                if node_index in autoplay_nodes:
                    raise AnimationPackError(
                        "animation node has more than one autoplay clip"
                    )
                autoplay_nodes.add(node_index)
        offset += binding_bytes
        if previous_pair is not None and pair <= previous_pair:
            raise AnimationPackError("animation bindings are not sparse-canonical")
        if node_count is not None and node_index >= node_count:
            raise AnimationPackError(
                "animation binding has an invalid scene node index"
            )
        clips_per_node[node_index] = clips_per_node.get(node_index, 0) + 1
        if clips_per_node[node_index] > MAX_ANIMATION_CLIPS_PER_NODE:
            raise AnimationPackError("animation node has too many clips")
        if len(clips_per_node) > MAX_ANIMATED_NODES:
            raise AnimationPackError(
                "animation asset has too many animated scene nodes"
            )
        if (
            not math.isfinite(duration)
            or duration < 1.0 / 60.0
            or duration > MAX_ANIMATION_DURATION
        ):
            raise AnimationPackError("animation binding length is invalid")
        if not 1 <= count <= MAX_ANIMATION_KEYS_PER_NODE:
            raise AnimationPackError("animation binding key count is invalid")
        if first_key != next_key or first_key + count > key_count:
            raise AnimationPackError("animation binding key range is invalid")
        if loop_mode >= len(ANIMATION_LOOP_MODES):
            raise AnimationPackError("animation binding repeat mode is invalid")
        previous_pair = pair
        next_key += count
        binding = {
            "node_index": node_index,
            "duration": duration,
            "first_key": first_key,
            "key_count": count,
            "loop_mode": ANIMATION_LOOP_MODES[loop_mode],
        }
        if version == ANIMATION_PACK_VERSION:
            binding["clip_hash"] = clip_hash
            binding["autoplay"] = autoplay
        bindings.append(binding)

    if next_key != key_count:
        raise AnimationPackError("animation asset contains unreferenced key records")

    keys: list[dict[str, Any]] = []
    for index in range(key_count):
        record_offset = offset + index * ANIMATION_KEY_BYTES
        unpacked = struct.unpack_from("<HBB10e", data, record_offset)
        time_code, easing_code, key_reserved = unpacked[:3]
        values = tuple(float(value) for value in unpacked[3:])
        if key_reserved:
            raise AnimationPackError("animation key reserved field is nonzero")
        if easing_code >= len(ANIMATION_EASINGS):
            raise AnimationPackError("animation key easing is invalid")
        _require_finite(values, "animation key")
        if any(abs(value) > MAX_ANIMATION_TRANSLATION for value in values[:3]):
            raise AnimationPackError("animation key position exceeds its compact range")
        rotation = values[3:7]
        rotation_length = math.sqrt(sum(value * value for value in rotation))
        if rotation_length <= 1.0e-8:
            raise AnimationPackError("animation key turn is a zero quaternion")
        scale = values[7:10]
        if any(
            value < MIN_ANIMATION_SCALE or value > MAX_ANIMATION_SCALE
            for value in scale
        ):
            raise AnimationPackError("animation key size exceeds its compact range")
        keys.append(
            {
                "time_code": time_code,
                "easing": ANIMATION_EASINGS[easing_code],
                "translation": list(values[:3]),
                "rotation": list(rotation),
                "scale": list(scale),
            }
        )

    for binding in bindings:
        first_key = int(binding["first_key"])
        count = int(binding["key_count"])
        clip_keys = keys[first_key : first_key + count]
        if clip_keys[0]["time_code"] != 0:
            raise AnimationPackError("animation clip first key is not at time zero")
        times = [int(key["time_code"]) for key in clip_keys]
        if times != sorted(times) or len(times) != len(set(times)):
            raise AnimationPackError(
                "animation clip key times are not strictly increasing"
            )
        first = clip_keys[0]
        if (
            first["translation"] != [0.0, 0.0, 0.0]
            or first["rotation"] != [1.0, 0.0, 0.0, 0.0]
            or first["scale"] != [1.0, 1.0, 1.0]
        ):
            raise AnimationPackError(
                "animation clip first key is not the identity pose"
            )
        easing_upper = {"back_out": 1.101, "elastic_out": 1.374}
        for left, right in zip(clip_keys, clip_keys[1:]):
            upper = easing_upper.get(str(right["easing"]), 1.0)
            for first_scale, second_scale in zip(left["scale"], right["scale"]):
                extreme = (
                    float(first_scale)
                    + (float(second_scale) - float(first_scale)) * upper
                )
                if not math.isfinite(extreme) or extreme < MIN_ANIMATION_SCALE:
                    raise AnimationPackError(
                        "animation easing would make an object's size too close to zero"
                    )

    authored_key_count = sum(int(binding["key_count"]) for binding in bindings)
    return {
        "schema": "ugts-kc-native-transform-animation-inspection-3.9.2",
        "format_version": version,
        "byte_length": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "binding_count": binding_count,
        "authored_key_count": authored_key_count,
        "packed_key_count": key_count,
        "deduplicated_key_count": 0,
        "bindings": bindings,
        "keys": keys,
    }


__all__ = [
    "ANIMATION_BINDING_BYTES",
    "ANIMATION_KEY_BYTES",
    "ANIMATION_PACK_ASSET",
    "ANIMATION_PACK_ENDIAN",
    "ANIMATION_PACK_MAGIC",
    "ANIMATION_PACK_VERSION",
    "AnimationPackError",
    "LEGACY_ANIMATION_BINDING_BYTES",
    "LEGACY_ANIMATION_PACK_VERSION",
    "MAX_ANIMATION_PACK_BYTES",
    "compile_animation_pack_bytes",
    "inspect_animation_pack",
    "write_animation_pack",
]
