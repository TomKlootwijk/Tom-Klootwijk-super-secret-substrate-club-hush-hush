# UGTS Engine worklog

This is an append-only factual worklog.  Planned work belongs in
`UGTS_ENGINE_TODO.md`; this file records decisions, implementation, verification,
and failed approaches.  Performance statements apply only to the named build
and workload.

## 2026-08-29 — Baseline inherited and verified

- Confirmed the repository already contained a substantial 2D/3D engine layer,
  PySide6 editor, typed Logic Blocks, native Android GLES3 player, compact scene
  packs, packed polar kinematics, deterministic seeded populations, animations,
  triggers, body physics, and device tooling.
- Retained the existing dirty worktree and unrelated user artifacts; no reset or
  broad cleanup was performed.
- Completed the dark editor presentation and one-click `RUN_UGTS_STUDIO.cmd`
  launcher flow.
- Completed a bounded editable 3D transform hierarchy.  Ordinary nodes can be
  attached/detached with world-pose preservation and Undo/Redo.  Desktop,
  native KCHI, glTF, editor viewport, and Saved Scene boundaries were covered.
- Full source suite after the hierarchy slice: **627 passed, 145 subtests
  passed in 150.12 seconds**.

## 2026-08-29 — First exact-device hierarchy baseline

- Built `UGTS-Parent-Child-Hierarchy-3.9.2-Poco-X7-Pro-debug.apk`:
  1,565,171 bytes, SHA-256
  `813D290E2B89973FE4C429BF58FAD7F50BFB156C42EACB665A7ABB1B4BF36E20`.
- Installed and cold-launched it on authorized device `XOVSTSHYNREMZ5D6`, model
  `2412DPC0AG` / `rodin`, with a 448 ms reported launch time.
- Captured and visually inspected the device screenshot.  The five-node scene
  rendered the cyan carrier, amber arm, violet mast, lime beacon, and floor.
- Bounded 15-second profile observed 120.15 effective SurfaceFlinger cadence,
  8.376 ms p50, 9.959 ms p95, 10.473 ms p99, zero intervals above 1.5 display
  periods, roughly 138–143 MiB PSS, thermal status 0, and no crash-buffer lines.
- Evidence boundary: this was a tiny five-node, roughly 60-triangle baseline.
  It did not contain KCPK polar assets and does not prove a polar renderer,
  large-game performance, sustained thermals, or AAA output.

## 2026-08-29 — Substrate-use correction

- User clarified that the log-encoded polar LUT must participate in rendering,
  and that a Bayer matrix should be the final output projection.
- Audited the present path.  KCPK/UGLUT2 currently decodes on the CPU and writes
  ordinary `NodeData` transforms.  The renderer receives only matrices; the LUT
  never reaches GLES.  Therefore GPU LUT rendering was **not implemented** at
  this point.
- Audited sibling sources in the parent repository:
  - SCLP 3.6.2 supplies bounded log-polar charts, derivatives, packing, and
    explicit error/singularity rules.
  - UGTS 4.1 supplies deterministic SplitMix64 lineage useful for random-access
    seeded generation.
  - UGTS Foundation 5.0 supplies content-addressed packed operator ideas.
  - the GPU Native Addendum supplies evidence that LUT performance depends on
    locality, line pressure, and address span; a LUT is not automatically faster
    than direct math.
  - Bayer Direct 3.9.4 supplies the exact 8x8 threshold permutation and a clear
    rule that Bayer is a presentation stage, not authoritative state.
- Corrected the architecture target to:
  `seed + compact operator recipe + packed ECS state -> shared log-encoded polar
  LUT -> procedural/instanced GPU rendering -> Bayer output`.
- Recorded a critical honesty finding: the small APK mainly reflects a lean
  ARM64 native runtime today.  The engine has not yet achieved whole-scene
  substrate reconstruction from seeds and operator recipes.

## 2026-08-29 — Active implementation

- Started a semantic `polar_movement` ECS adapter for desktop and Android Logic
  Blocks.  Planned child-facing fields are radius, angle, facing, turns per
  second, grow/shrink speed, and both accelerations.  Raw 64-bit words remain an
  internal storage detail.
- Started native graph access that preserves the existing KCPK/KCVG binary
  layouts and immediately recomposes a polar transform after a semantic write.
- Designed the next renderer slice: keep CPU ECS/fixed-step state authoritative,
  group compatible polar entities by profile/mesh/material, upload one LUT per
  profile, bit-decode packed poses in the vertex shader, and issue instanced
  draws.  CPU matrix fallback and a GPU direct-math mode are required for fair
  comparison.
- Designed the Bayer integration as a configurable final GLES post stage with
  Off, Gentle, and limited-palette modes.  It will be tested for banding and
  visible patterns; it will not be described as animation or geometry
  smoothing.

## 2026-08-29 — Semantic polar ECS slice completed

- Added the virtual child-facing `polar_movement` component on desktop.  Its
  seven numeric fields decode from and re-encode to the existing KCPK words;
  snapshots and Android assets do not duplicate the friendly view.
- Added the same seven-field bridge to the native Graph VM.  Writes are finite,
  profile-bounded, binary32-canonical, preserve every untouched field and tick
  bit, and immediately publish the recomposed transform.
- Hid raw pose/motion words from beginner Logic Block choices and added friendly
  field names and help.  KCPK and KCVG versions did not change.
- Added native startup evidence for profile/component counts and active graph
  access.
- Full Python/editor suite reported by the implementation pass: **636 passed,
  145 subtests passed in 122.63 seconds**.  Native semantic host, existing Graph
  VM, polar ECS, and template-copy checks also passed.
- Corrected a remaining physics parity gap: desktop 3D composition now publishes
  X/Z velocity from the same packed log-polar state while preserving Y.  The
  added focused assertion and the complete semantic-polar file pass: **8
  passed**.  The native equivalent is included in the current renderer/native
  integration pass and is not yet claimed as device-proven.

## 2026-08-29 — Compact render-settings record completed

- Added optional `render_substrate.kcrp`, an exact 32-byte little-endian KCRP392
  record.  It carries one uint64 seed, requested polar mode (Auto, LUT, Direct,
  or CPU), and Bayer mode/levels/strength.
- Projects without `metadata.substrate_render` emit no sidecar and retain legacy
  behavior.  Opted-in records reject unknown keys, invalid modes, non-finite or
  out-of-range values, corruption, and trailing bytes.
- Android source builds now package the runtime record and include its parsed
  values, byte count, and SHA-256 in `build-report.json`.
- Default opted-in record SHA-256:
  `82811b7c5bd6d787b35942a1edf37f9783b2e2f239ef4da8e1055795df2f0610`.
- Verification: **7 tests and 30 subtests** for the format; **28 tests and 13
  subtests** across adjacent Android exporter/polar/animation/population paths;
  Ruff and diff checks passed.
- Evidence boundary: the record is now portable, but native GPU consumption and
  child-facing project settings UI were still in progress at this entry.

## 2026-08-29 — Child-facing render settings completed

- Added a Render tab to the Project dock for mobile 3D projects.  Learners can
  choose Auto/shared-LUT/direct/CPU packed movement and Off/Subtle/Retro colour
  projection without editing JSON or matrix values.
- The tab explains that ECS movement stays authoritative and that the output
  choice changes drawing only.  It shows the exact 32-byte Android recipe and
  deterministic seed when enabled.
- Changes are validated, undoable, redoable, and preserve advanced custom
  values until a beginner preset is deliberately chosen.
- Verification: the new editor tests pass **2/2**; the render-settings,
  movement-pattern, beginner-lesson, and KCRP group passes **16 tests and 30
  subtests**.

## 2026-08-29 — Editable packed-polar lab completed

- Added `examples/packed_polar_gpu_lab_3d/project.json` with 64 genuine static
  ECS mover nodes.  There are no scatter copies.  All movers share one
  five-vertex/six-triangle mesh, one material, a shared 256-entry log-encoded
  polar LUT/profile, and one four-node owner-relative Logic Blocks definition.
- The shared graph reads each owner's semantic Turns per second every second,
  multiplies it by -1, and writes it back.  The graph definition is stored once;
  KCVG contains 64, 256, or 1024 compact owner bindings.
- Added a deterministic SplitMix64-style generator for exact 64/256/1024
  variants and Auto/LUT/Direct/CPU plus Off/Subtle/Retro/Custom output modes.
- Verified KCPK sizes of **3,202**, **7,810**, and **26,242 bytes**.  Each added
  ECS mover changes the pack by exactly **24 bytes**; every workload keeps one
  shared LUT.
- Desktop proof reached tick 120, reversed all 64 semantic turn speeds, returned
  64 entities from string and typed ECS queries, and preserved authored Y.
- Independent rerun: example verifier `PASS`; focused CI example test **1/1**.
- Evidence boundary: this proves authored ECS/graph/pack composition, not GPU
  execution or POCO performance.  Those require the native build and device
  evidence still in progress.

## 2026-08-29 — Native Direct/LUT/Bayer substrate source completed

- Added strict native KCRP parsing plus CPU, direct-GPU, and shared-LUT GPU
  execution modes. Compatible packed movers are grouped by profile, mesh, and
  material and drawn through bounded 32-byte instance records.
- The LUT texture uploads the authored binary16 lanes directly. A review found
  and corrected an axis inversion before device measurement: texture R is now
  cosine/world X, G is sine/world Z, and B is normalized log-radius.
- Previous/current packed poses interpolate only for display. The CPU ECS
  remains authoritative, and hierarchy-linked or animation-owned movers fail
  back to CPU so children cannot detach from a GPU-interpolated parent.
- Added explicit packed ownership rejection for Player control, authored spin,
  generic X/Z or rotation writes, and symbolic or numeric field aliases. Y,
  uniform scale, and Y velocity remain ordinary authored state.
- Added the canonical top-origin 8x8 Bayer threshold stage. Off retains the
  legacy blit when post-processing is off; enabled modes clamp the source,
  quantize it, and blend with bounded strength at physical output pixels.
- Focused evidence reported by the native pass: **31 tests and 33 subtests**,
  all direct/LUT/Bayer shader variants linked with `glslangValidator`, and a
  fresh 36-task `assemblePocoX7ProDebug` build succeeded.
- Built APK: **1,664,323 bytes**, SHA-256
  `348BB30405B9284E7B3509270C7FF30ECF68C57B20DA2AFF09371A168F81A2DB`.
  It contains KCPK, KCRP, `polar_scene.vert`, and the Bayer post shader.
- Evidence boundary: ADB listed no attached device during this build. The APK
  was not installed or visually/timing-verified on Mali, so this entry proves
  source, host, shader-link, and Android compilation—not phone performance.

## 2026-08-29 — Metrics and compact recipe integration active

- Extended phone profiles with `/proc` scheduler-delta CPU sampling. Reports
  now distinguish one-core-equivalent work from percentage of the entire
  phone, alongside frame cadence, memory, temperatures, battery, thermals, and
  crash evidence. Focused profiler/harness/editor verification: **24 passed**;
  Ruff and diff checks passed.
- Added a resumable A/B harness choice for the real-ECS workload or a compact
  recipe workload. The recipe lab keeps five environment nodes plus one real
  packed ECS prototype while requesting 64, 256, or 1024 display instances;
  KCPK stays byte-identical as the display count grows.
- Added and tested a KCPR392 content-addressed recipe draft with Ring, Spiral,
  and Polar Field operators. Review rejected an initial `log/exp` generation
  schedule because different desktop/Android math libraries could invalidate
  a bit-exact claim.
- Review also found that Direct mode's `r0 * exp(rho)` can overflow its
  intermediate for a valid tiny-`r0` profile even when the final radius is
  representable. Passing precomputed `log(r0)` and evaluating one bounded
  exponent is part of the active native correction; no affected-profile claim
  is made before that lands.
- The replacement in progress stores binary32 log-radius offsets directly,
  uses a bounded rational spiral, and adds periodic offsets in theta18 and
  heading12 code space. This deliberately keeps transcendental reconstruction
  in the shared LUT/render path rather than authoritative recipe generation.

## 2026-08-29 — KCPR392 Python contract frozen

- Completed a strict optional content-addressed polar display-recipe asset:
  32-byte header, minimal sorted 16-byte operator meanings, and one 128-byte
  sparse recipe per real packed ECS prototype. Ring/Polar Field are 240 bytes
  total for one recipe; Spiral is 256 bytes because it adds one operator.
- The deployed operator parameters now contain exact binary32 log-radius
  offsets. Runtime member derivation uses SplitMix64 lineage, staged binary32
  basic arithmetic, rational spiral saturation, and direct theta18/heading12
  code addition. No runtime `log`, `exp`, sine, or cosine participates in the
  authoritative recipe result.
- Full 128-bit content addresses include count and every consumed dependency.
  Separate 128-bit lineage namespaces exclude count only, so 64 -> 256 -> 1024
  preserves the existing member prefix. Mesh/material addresses hash the exact
  f32/u32/u8 lanes visible in KC3D rather than authoring-only JSON precision.
- Generated members remain display values. A 1024-member recipe still creates
  exactly one real ECS prototype; it does not invent 1023 selectable entities,
  colliders, tags, or graph owners. The editor viewport derives at most 64
  random-access preview copies instead of allocating the full population.
- Stable count-64 fixtures: Ring **240 bytes** / SHA-256
  `019C33DC2CDB7278540B4E69509EB062CE1DED7183629481DB3C374D7C10F568`;
  Spiral **256 bytes** /
  `6B5358DCC568E7F23561C1F52B949CE5C753B5332A58329E3E1C9DDCCAEBEE55`;
  Polar Field **240 bytes** /
  `FFCF6CA9A2A49F95F895BB5EE7616DE07662CA95F1BB0D2FB6D65E6AD9BCAD59`.
- Implementation pass evidence: **22 tests and 38 subtests**, Ruff clean.
  Independent focused rerun with the compact recipe lab and native graph
  ownership test: **20 tests and 16 subtests**, Ruff clean.
- Evidence boundary: this entry freezes the Python/export/desktop/viewport
  contract. Native KCPR parsing/render consumption and POCO measurement remain
  active and are not claimed here.

## 2026-08-29 — Native KCPR, bounded Make Many, and timer source completed

- Added strict optional `polar_populations.kcpr` consumption in
  `polar_populations.hpp/.cpp`. Native parsing validates the canonical header
  and operator meanings, KCRP/root-seed agreement, bounds, profile/prototype/
  mesh/material dependency addresses, full 128-bit content addresses, and
  count-stable lineage namespaces. The maximal host parity case reported
  `PASS native KCPR392 polar populations generated=16380 tested=64`.
- Generated members remain render data, not `NodeData` ECS rows. The runtime
  retains only bounded recipe metadata/ranges for the total population and
  materializes visible members while drawing under `maxVisibleNodes`;
  visible-copy staging and the GLES instance buffer are capped by that limit
  rather than total recipe count.
  CPU/fallback paths compose Cartesian data only for visible members, while
  Direct/LUT use packed instance words. Runtime logs separate requested total,
  visible, GPU, CPU, materialized, and Cartesian-composed counts.
- Native KCPR now supplies the existing Direct/LUT instancing and final Bayer
  source paths, with explicit fallback logging. This is source/host evidence,
  not a claim that the current Android APK or target-device path has run.
- Added the child-facing Make Many Inspector with Off, Ring, Spiral, and Polar
  Field choices; uint64 seed and friendly labels instead of raw math by default;
  exact KCPR byte-count and full-address readout; stock Goal-spin/Movement
  ownership handoff; and validated undo/redo. Generated preview copies cannot
  be selected instead of their real prototype, and the preview budget is at
  most 64 across all active recipes.
- Tightened benchmark runtime proof to fail closed on the exact requested and
  effective polar mode, instance/profile/batch counts, any unintended fallback,
  recipe GPU/CPU counts, Bayer configuration, and visible/materialized/
  Cartesian-composed counts. A fallback invalidates a requested GPU case.
- Added a nonblocking `GL_EXT_disjoint_timer_query` implementation with four
  reusable query slots. It polls `GL_QUERY_RESULT_AVAILABLE_EXT` on later
  frames, discards disjoint intervals, never calls `glFinish` or a client wait,
  and reports support, counter bits, samples, total/mean/max/last time,
  disjoint intervals, and pending queries. The Android profiler parses those
  fields or reports unsupported/runtime-failure state explicitly.
- Focused verification command:
  `python -m pytest -q tests/test_polar_population_recipe.py
  tests/test_android_polar_population_native.py
  tests/test_android_render_substrate_native.py tests/test_android_profile.py
  tests/test_polar_render_benchmark_harness.py` with `QT_QPA_PLATFORM=offscreen`,
  `PYTHONPATH=src`, and bytecode writes disabled: **43 passed, 19 subtests
  passed in 20.91s**.
- Fresh-build boundary: benchmark run
  `build/poco-polar-render-benchmarks/20260829T213228Z-seed-5eed3920c0dec0de`
  stopped on its first `polar-1024-direct-off` case during CMake compiler-ABI
  `try_compile`. The deeply nested Windows build path could not create/set the
  `CMakeTmp` working directory (`No such file or directory`), so no fresh APK
  containing the current KCPR renderer and timer source is proven. Earlier APK
  evidence remains historical evidence for that earlier source state only.
- No ADB device was available. There is no current install, screenshot, runtime
  proof, GPU timer sample, Direct/LUT/Bayer A/B result, Mali timing, power, or
  thermal claim.

## 2026-08-30 — Short-path matrix and shared polar conformance completed

- Fixed the Windows build-transport blocker without deleting its evidence.
  Benchmark Android source is now generated and built in a short system
  temporary workspace such as `C:\Users\Tom\AppData\Local\Temp\kc392-*`, then
  exact evidence is copied back while the disposable Gradle tree is removed.
  Each case keeps append-only `build-attempt-NNN` records, including partial
  artifacts and errors, so a retry cannot rewrite a failed attempt.
- The first short-path smoke built an APK but exposed a harness proof bug: it
  compared the build report's base ID directly with the Poco flavor ID. Preserved
  attempt 001 records `build report and APK metadata application ids differ`
  and its partial 1,786,658-byte APK SHA-256
  `37F9CBB19734C71435C3A18E9B9EE5D969BA49E1CD00FE1E33A92765A4E12B53`.
  The check now requires the actual AGP ID to equal the base ID plus
  `.pocox7pro`; attempt 002 completed append-only, with final APK SHA-256
  `15CCD87D2ABFEFF4B6E53C31DEB31974E6A6C7899CCF71680136A64DE816A12B`.
- Reproducibility was tested rather than assumed. Explicit
  `-Wl,--build-id=sha1` alone was insufficient: two clean 1,786,718-byte APKs
  differed at SHA-256
  `C29FB69181C4D104177EF3B650A18A5E574824A5D0147D961B20FC2983CDB4D3`
  and
  `66A5B7990199E7324E99434788382C54B6570594D27A662FC9F83776041F55EB`.
  After applying `-fdebug-prefix-map` to normalize the independent source and
  build directories to stable DWARF paths, both clean builds produced the same
  APK SHA-256
  `B417EE9E303BCE3ABBE7FE709A77433D04E426E47CAD1B8880E17130CB6B335B`.
  Their embedded 1,756,032-byte `libugts_kc_native.so` files both have SHA-256
  `5EE54BD46375EBE9EE45847131755642F8B37270F9691E66697C954E5510254C`
  and GNU build ID `8A4D75726438F50328566565391A4EEAB5AD9D39`.
- Added `src/ugts_kc3/conformance/polar_substrate_vectors.tsv`, one 4,994-byte
  canonical seven-case artifact with SHA-256
  `CDF8B4A20869C2BC35C4330C35DC7E43C33459CE40F37FD63139C0A41B01DB57`.
  Python and the native host executable consume the same fixed expectations for
  the explicit core, radius clamps, theta/heading seams, LUT interpolation,
  Direct/LUT position/velocity/acceleration/heading, and packed next state.
  Shader snippets are checked against `polar_scene.vert`, but the artifact marks
  that evidence `shader_source_formula_only_no_gpu_execution`.
- LUT rendering now obtains packed heading from the same seam-safe log-encoded
  polar LUT direction lookup used for angular direction. Direct mode retains
  `sin`/`cos` as the independent comparison path. Focused evidence reported
  **66 tests and 69 subtests passed**, Ruff clean, native host conformance
  `PASS ... vectors=7 source_formula_only=true`, and successful Direct/LUT
  shader linking. A fresh 1,789,411-byte current-source Poco debug APK built with
  zero native stderr; SHA-256
  `6348E44A6B75281C469135AFF3C9A17A37739701673AE14F36B17001D1A165C3`.
- The post-fix full `python -m pytest -q` run completed with exit 0:
  **701 passed and 236 subtests passed in 165.86 seconds**, with no warning
  summary/output. Its first run's sole failure was a stale source-slicing
  assertion in
  `test_renderer_uploads_camera_and_every_packed_material_field`; the assertion
  was corrected to follow `drawOrdinaryNode`, passed isolated, and then passed
  in the complete run.
- Ran `python validation/benchmark_polar_render_poco.py` with
  `--workload recipe --include-cpu --build-only`. Run
  `build/poco-polar-render-benchmarks/20260829T215836Z-seed-5eed3920c0dec0de`
  completed all **15** short-workspace cases: 64/256/1024 CPU Off and
  Direct/LUT with Bayer Off/Subtle. All 15 numbered attempts are complete and
  use `org.ugts.games.packed_polar_recipe_lab_3d.pocox7pro`.
- The 3,317-byte `run-manifest.json` has SHA-256
  `0104FF9C2B0B2B7916F99580DA8A89AFEE8693CDA14C07D767E3AC8677E1B337`;
  the 11,076-byte `comparison-summary.json` has SHA-256
  `9A3B4443EA6F4A1125C0463428EB884B2857EE13795AD0A21DD0BB30C0E8B05A`.
  The summary says `built_only` for every case, null FPS/p95 values, and zero
  available comparisons. These hashes prove preserved build evidence, not
  physical rendering or relative performance.
- No ADB device was available. None of these results proves POCO/Mali runtime,
  screenshots, GPU timer support or samples, FPS, Direct/LUT/Bayer performance,
  power, or thermal behavior.

## Worklog rules for subsequent entries

- Record exact files and formats changed.
- Record exact commands and test counts.
- Record artifact byte sizes and SHA-256 hashes.
- Record device serial/model, application id, run duration, workload, and
  environmental caveats for every phone result.
- Record regressions and abandoned approaches, not only successes.
- Never turn an intended optimization into a performance claim before an A/B
  measurement on the target device.
