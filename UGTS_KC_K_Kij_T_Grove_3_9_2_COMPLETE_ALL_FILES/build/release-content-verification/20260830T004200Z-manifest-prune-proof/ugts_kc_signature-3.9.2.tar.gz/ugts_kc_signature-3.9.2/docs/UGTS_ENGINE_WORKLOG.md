# UGTS Engine worklog

This is an append-only factual worklog.  Planned work belongs in
`UGTS_ENGINE_TODO.md`; this file records decisions, implementation, verification,
and failed approaches.  Performance statements apply only to the named build
and workload.

## 2026-08-29 — Baseline inherited and verified

- Confirmed the repository already contained a substantial 2D/3D engine layer,
  PySide6 editor, typed Logic Blocks, native Android GLES3 player, compact scene
  packs, packed polar kinematics, deterministic seeded populations, animations,
  triggers, body physics, and device tooling.
- Retained the existing dirty worktree and unrelated user artifacts; no reset or
  broad cleanup was performed.
- Completed the dark editor presentation and one-click `RUN_UGTS_STUDIO.cmd`
  launcher flow.
- Completed a bounded editable 3D transform hierarchy.  Ordinary nodes can be
  attached/detached with world-pose preservation and Undo/Redo.  Desktop,
  native KCHI, glTF, editor viewport, and Saved Scene boundaries were covered.
- Full source suite after the hierarchy slice: **627 passed, 145 subtests
  passed in 150.12 seconds**.

## 2026-08-29 — First exact-device hierarchy baseline

- Built `UGTS-Parent-Child-Hierarchy-3.9.2-Poco-X7-Pro-debug.apk`:
  1,565,171 bytes, SHA-256
  `813D290E2B89973FE4C429BF58FAD7F50BFB156C42EACB665A7ABB1B4BF36E20`.
- Installed and cold-launched it on authorized device `XOVSTSHYNREMZ5D6`, model
  `2412DPC0AG` / `rodin`, with a 448 ms reported launch time.
- Captured and visually inspected the device screenshot.  The five-node scene
  rendered the cyan carrier, amber arm, violet mast, lime beacon, and floor.
- Bounded 15-second profile observed 120.15 effective SurfaceFlinger cadence,
  8.376 ms p50, 9.959 ms p95, 10.473 ms p99, zero intervals above 1.5 display
  periods, roughly 138–143 MiB PSS, thermal status 0, and no crash-buffer lines.
- Evidence boundary: this was a tiny five-node, roughly 60-triangle baseline.
  It did not contain KCPK polar assets and does not prove a polar renderer,
  large-game performance, sustained thermals, or AAA output.

## 2026-08-29 — Substrate-use correction

- User clarified that the log-encoded polar LUT must participate in rendering,
  and that a Bayer matrix should be the final output projection.
- Audited the present path.  KCPK/UGLUT2 currently decodes on the CPU and writes
  ordinary `NodeData` transforms.  The renderer receives only matrices; the LUT
  never reaches GLES.  Therefore GPU LUT rendering was **not implemented** at
  this point.
- Audited sibling sources in the parent repository:
  - SCLP 3.6.2 supplies bounded log-radius polar charts, derivatives, packing, and
    explicit error/singularity rules.
  - UGTS 4.1 supplies deterministic SplitMix64 lineage useful for random-access
    seeded generation.
  - UGTS Foundation 5.0 supplies content-addressed packed operator ideas.
  - the GPU Native Addendum supplies evidence that LUT performance depends on
    locality, line pressure, and address span; a LUT is not automatically faster
    than direct math.
  - Bayer Direct 3.9.4 supplies the exact 8x8 threshold permutation and a clear
    rule that Bayer is a presentation stage, not authoritative state.
- Corrected the architecture target to:
  `seed + compact operator recipe + packed ECS state -> shared log-encoded polar
  LUT -> procedural/instanced GPU rendering -> Bayer output`.
- Recorded a critical honesty finding: the small APK mainly reflects a lean
  ARM64 native runtime today.  The engine has not yet achieved whole-scene
  substrate reconstruction from seeds and operator recipes.

## 2026-08-29 — Active implementation

- Started a semantic `polar_movement` ECS adapter for desktop and Android Logic
  Blocks.  Planned child-facing fields are radius, angle, facing, turns per
  second, grow/shrink speed, and both accelerations.  Raw 64-bit words remain an
  internal storage detail.
- Started native graph access that preserves the existing KCPK/KCVG binary
  layouts and immediately recomposes a polar transform after a semantic write.
- Designed the next renderer slice: keep CPU ECS/fixed-step state authoritative,
  group compatible polar entities by profile/mesh/material, upload one LUT per
  profile, bit-decode packed poses in the vertex shader, and issue instanced
  draws.  CPU matrix fallback and a GPU direct-math mode are required for fair
  comparison.
- Designed the Bayer integration as a configurable final GLES post stage with
  Off, Gentle, and limited-palette modes.  It will be tested for banding and
  visible patterns; it will not be described as animation or geometry
  smoothing.

## 2026-08-29 — Semantic polar ECS slice completed

- Added the virtual child-facing `polar_movement` component on desktop.  Its
  seven numeric fields decode from and re-encode to the existing KCPK words;
  snapshots and Android assets do not duplicate the friendly view.
- Added the same seven-field bridge to the native Graph VM.  Writes are finite,
  profile-bounded, binary32-canonical, preserve every untouched field and tick
  bit, and immediately publish the recomposed transform.
- Hid raw pose/motion words from beginner Logic Block choices and added friendly
  field names and help.  KCPK and KCVG versions did not change.
- Added native startup evidence for profile/component counts and active graph
  access.
- Full Python/editor suite reported by the implementation pass: **636 passed,
  145 subtests passed in 122.63 seconds**.  Native semantic host, existing Graph
  VM, polar ECS, and template-copy checks also passed.
- Corrected a remaining physics parity gap: desktop 3D composition now publishes
  X/Z velocity from the same packed polar state while preserving Y.  The
  added focused assertion and the complete semantic-polar file pass: **8
  passed**.  The native equivalent is included in the current renderer/native
  integration pass and is not yet claimed as device-proven.

## 2026-08-29 — Compact render-settings record completed

- Added optional `render_substrate.kcrp`, an exact 32-byte little-endian KCRP392
  record.  It carries one uint64 seed, requested polar mode (Auto, LUT, Direct,
  or CPU), and Bayer mode/levels/strength.
- Projects without `metadata.substrate_render` emit no sidecar and retain legacy
  behavior.  Opted-in records reject unknown keys, invalid modes, non-finite or
  out-of-range values, corruption, and trailing bytes.
- Android source builds now package the runtime record and include its parsed
  values, byte count, and SHA-256 in `build-report.json`.
- Default opted-in record SHA-256:
  `82811b7c5bd6d787b35942a1edf37f9783b2e2f239ef4da8e1055795df2f0610`.
- Verification: **7 tests and 30 subtests** for the format; **28 tests and 13
  subtests** across adjacent Android exporter/polar/animation/population paths;
  Ruff and diff checks passed.
- Evidence boundary: the record is now portable, but native GPU consumption and
  child-facing project settings UI were still in progress at this entry.

## 2026-08-29 — Child-facing render settings completed

- Added a Render tab to the Project dock for mobile 3D projects.  Learners can
  choose Auto/shared-LUT/direct/CPU packed movement and Off/Subtle/Retro colour
  projection without editing JSON or matrix values.
- The tab explains that ECS movement stays authoritative and that the output
  choice changes drawing only.  It shows the exact 32-byte Android recipe and
  deterministic seed when enabled.
- Changes are validated, undoable, redoable, and preserve advanced custom
  values until a beginner preset is deliberately chosen.
- Verification: the new editor tests pass **2/2**; the render-settings,
  movement-pattern, beginner-lesson, and KCRP group passes **16 tests and 30
  subtests**.

## 2026-08-29 — Editable packed-polar lab completed

- Added `examples/packed_polar_gpu_lab_3d/project.json` with 64 genuine static
  ECS mover nodes.  There are no scatter copies.  All movers share one
  five-vertex/six-triangle mesh, one material, a shared 256-entry log-encoded
  polar LUT/profile, and one four-node owner-relative Logic Blocks definition.
- The shared graph reads each owner's semantic Turns per second every second,
  multiplies it by -1, and writes it back.  The graph definition is stored once;
  KCVG contains 64, 256, or 1024 compact owner bindings.
- Added a deterministic SplitMix64-style generator for exact 64/256/1024
  variants and Auto/LUT/Direct/CPU plus Off/Subtle/Retro/Custom output modes.
- Verified KCPK sizes of **3,202**, **7,810**, and **26,242 bytes**.  Each added
  ECS mover changes the pack by exactly **24 bytes**; every workload keeps one
  shared LUT.
- Desktop proof reached tick 120, reversed all 64 semantic turn speeds, returned
  64 entities from string and typed ECS queries, and preserved authored Y.
- Independent rerun: example verifier `PASS`; focused CI example test **1/1**.
- Evidence boundary: this proves authored ECS/graph/pack composition, not GPU
  execution or POCO performance.  Those require the native build and device
  evidence still in progress.

## 2026-08-29 — Native Direct/LUT/Bayer substrate source completed

- Added strict native KCRP parsing plus CPU, direct-GPU, and shared-LUT GPU
  execution modes. Compatible packed movers are grouped by profile, mesh, and
  material and drawn through bounded 32-byte instance records.
- The LUT texture uploads the authored binary16 lanes directly. A review found
  and corrected an axis inversion before device measurement: texture R is now
  cosine/world X, G is sine/world Z, and B is normalized log-radius.
- Previous/current packed poses interpolate only for display. The CPU ECS
  remains authoritative, and hierarchy-linked or animation-owned movers fail
  back to CPU so children cannot detach from a GPU-interpolated parent.
- Added explicit packed ownership rejection for Player control, authored spin,
  generic X/Z or rotation writes, and symbolic or numeric field aliases. Y,
  uniform scale, and Y velocity remain ordinary authored state.
- Added the canonical top-origin 8x8 Bayer threshold stage. Off retains the
  legacy blit when post-processing is off; enabled modes clamp the source,
  quantize it, and blend with bounded strength at physical output pixels.
- Focused evidence reported by the native pass: **31 tests and 33 subtests**,
  all direct/LUT/Bayer shader variants linked with `glslangValidator`, and a
  fresh 36-task `assemblePocoX7ProDebug` build succeeded.
- Built APK: **1,664,323 bytes**, SHA-256
  `348BB30405B9284E7B3509270C7FF30ECF68C57B20DA2AFF09371A168F81A2DB`.
  It contains KCPK, KCRP, `polar_scene.vert`, and the Bayer post shader.
- Evidence boundary: ADB listed no attached device during this build. The APK
  was not installed or visually/timing-verified on Mali, so this entry proves
  source, host, shader-link, and Android compilation—not phone performance.

## 2026-08-29 — Metrics and compact recipe integration active

- Extended phone profiles with `/proc` scheduler-delta CPU sampling. Reports
  now distinguish one-core-equivalent work from percentage of the entire
  phone, alongside frame cadence, memory, temperatures, battery, thermals, and
  crash evidence. Focused profiler/harness/editor verification: **24 passed**;
  Ruff and diff checks passed.
- Added a resumable A/B harness choice for the real-ECS workload or a compact
  recipe workload. The recipe lab keeps five environment nodes plus one real
  packed ECS prototype while requesting 64, 256, or 1024 display instances;
  KCPK stays byte-identical as the display count grows.
- Added and tested a KCPR392 content-addressed recipe draft with Ring, Spiral,
  and Polar Field operators. Review rejected an initial `log/exp` generation
  schedule because different desktop/Android math libraries could invalidate
  a bit-exact claim.
- Review also found that Direct mode's `r0 * exp(rho)` can overflow its
  intermediate for a valid tiny-`r0` profile even when the final radius is
  representable. Passing precomputed `log(r0)` and evaluating one bounded
  exponent is part of the active native correction; no affected-profile claim
  is made before that lands.
- The replacement in progress stores binary32 log-radius offsets directly,
  uses a bounded rational spiral, and adds periodic offsets in theta18 and
  heading12 code space. This deliberately keeps transcendental reconstruction
  in the shared LUT/render path rather than authoritative recipe generation.

## 2026-08-29 — KCPR392 Python contract frozen

- Completed a strict optional content-addressed polar display-recipe asset:
  32-byte header, minimal sorted 16-byte operator meanings, and one 128-byte
  sparse recipe per real packed ECS prototype. Ring/Polar Field are 240 bytes
  total for one recipe; Spiral is 256 bytes because it adds one operator.
- The deployed operator parameters now contain exact binary32 log-radius
  offsets. Runtime member derivation uses SplitMix64 lineage, staged binary32
  basic arithmetic, rational spiral saturation, and direct theta18/heading12
  code addition. No runtime `log`, `exp`, sine, or cosine participates in the
  authoritative recipe result.
- Full 128-bit content addresses include count and every consumed dependency.
  Separate 128-bit lineage namespaces exclude count only, so 64 -> 256 -> 1024
  preserves the existing member prefix. Mesh/material addresses hash the exact
  f32/u32/u8 lanes visible in KC3D rather than authoring-only JSON precision.
- Generated members remain display values. A 1024-member recipe still creates
  exactly one real ECS prototype; it does not invent 1023 selectable entities,
  colliders, tags, or graph owners. The editor viewport derives at most 64
  random-access preview copies instead of allocating the full population.
- Stable count-64 fixtures: Ring **240 bytes** / SHA-256
  `019C33DC2CDB7278540B4E69509EB062CE1DED7183629481DB3C374D7C10F568`;
  Spiral **256 bytes** /
  `6B5358DCC568E7F23561C1F52B949CE5C753B5332A58329E3E1C9DDCCAEBEE55`;
  Polar Field **240 bytes** /
  `FFCF6CA9A2A49F95F895BB5EE7616DE07662CA95F1BB0D2FB6D65E6AD9BCAD59`.
- Implementation pass evidence: **22 tests and 38 subtests**, Ruff clean.
  Independent focused rerun with the compact recipe lab and native graph
  ownership test: **20 tests and 16 subtests**, Ruff clean.
- Evidence boundary: this entry freezes the Python/export/desktop/viewport
  contract. Native KCPR parsing/render consumption and POCO measurement remain
  active and are not claimed here.

## 2026-08-29 — Native KCPR, bounded Make Many, and timer source completed

- Added strict optional `polar_populations.kcpr` consumption in
  `polar_populations.hpp/.cpp`. Native parsing validates the canonical header
  and operator meanings, KCRP/root-seed agreement, bounds, profile/prototype/
  mesh/material dependency addresses, full 128-bit content addresses, and
  count-stable lineage namespaces. The maximal host parity case reported
  `PASS native KCPR392 polar populations generated=16380 tested=64`.
- Generated members remain render data, not `NodeData` ECS rows. The runtime
  retains only bounded recipe metadata/ranges for the total population and
  materializes visible members while drawing under `maxVisibleNodes`;
  visible-copy staging and the GLES instance buffer are capped by that limit
  rather than total recipe count.
  CPU/fallback paths compose Cartesian data only for visible members, while
  Direct/LUT use packed instance words. Runtime logs separate requested total,
  visible, GPU, CPU, materialized, and Cartesian-composed counts.
- Native KCPR now supplies the existing Direct/LUT instancing and final Bayer
  source paths, with explicit fallback logging. This is source/host evidence,
  not a claim that the current Android APK or target-device path has run.
- Added the child-facing Make Many Inspector with Off, Ring, Spiral, and Polar
  Field choices; uint64 seed and friendly labels instead of raw math by default;
  exact KCPR byte-count and full-address readout; stock Goal-spin/Movement
  ownership handoff; and validated undo/redo. Generated preview copies cannot
  be selected instead of their real prototype, and the preview budget is at
  most 64 across all active recipes.
- Tightened benchmark runtime proof to fail closed on the exact requested and
  effective polar mode, instance/profile/batch counts, any unintended fallback,
  recipe GPU/CPU counts, Bayer configuration, and visible/materialized/
  Cartesian-composed counts. A fallback invalidates a requested GPU case.
- Added a nonblocking `GL_EXT_disjoint_timer_query` implementation with four
  reusable query slots. It polls `GL_QUERY_RESULT_AVAILABLE_EXT` on later
  frames, discards disjoint intervals, never calls `glFinish` or a client wait,
  and reports support, counter bits, samples, total/mean/max/last time,
  disjoint intervals, and pending queries. The Android profiler parses those
  fields or reports unsupported/runtime-failure state explicitly.
- Focused verification command:
  `python -m pytest -q tests/test_polar_population_recipe.py
  tests/test_android_polar_population_native.py
  tests/test_android_render_substrate_native.py tests/test_android_profile.py
  tests/test_polar_render_benchmark_harness.py` with `QT_QPA_PLATFORM=offscreen`,
  `PYTHONPATH=src`, and bytecode writes disabled: **43 passed, 19 subtests
  passed in 20.91s**.
- Fresh-build boundary: benchmark run
  `build/poco-polar-render-benchmarks/20260829T213228Z-seed-5eed3920c0dec0de`
  stopped on its first `polar-1024-direct-off` case during CMake compiler-ABI
  `try_compile`. The deeply nested Windows build path could not create/set the
  `CMakeTmp` working directory (`No such file or directory`), so no fresh APK
  containing the current KCPR renderer and timer source is proven. Earlier APK
  evidence remains historical evidence for that earlier source state only.
- No ADB device was available. There is no current install, screenshot, runtime
  proof, GPU timer sample, Direct/LUT/Bayer A/B result, Mali timing, power, or
  thermal claim.

## 2026-08-30 — Short-path matrix and shared polar conformance completed

- Fixed the Windows build-transport blocker without deleting its evidence.
  Benchmark Android source is now generated and built in a short system
  temporary workspace such as `C:\Users\Tom\AppData\Local\Temp\kc392-*`, then
  exact evidence is copied back while the disposable Gradle tree is removed.
  Each case keeps append-only `build-attempt-NNN` records, including partial
  artifacts and errors, so a retry cannot rewrite a failed attempt.
- The first short-path smoke built an APK but exposed a harness proof bug: it
  compared the build report's base ID directly with the Poco flavor ID. Preserved
  attempt 001 records `build report and APK metadata application ids differ`
  and its partial 1,786,658-byte APK SHA-256
  `37F9CBB19734C71435C3A18E9B9EE5D969BA49E1CD00FE1E33A92765A4E12B53`.
  The check now requires the actual AGP ID to equal the base ID plus
  `.pocox7pro`; attempt 002 completed append-only, with final APK SHA-256
  `15CCD87D2ABFEFF4B6E53C31DEB31974E6A6C7899CCF71680136A64DE816A12B`.
- Reproducibility was tested rather than assumed. Explicit
  `-Wl,--build-id=sha1` alone was insufficient: two clean 1,786,718-byte APKs
  differed at SHA-256
  `C29FB69181C4D104177EF3B650A18A5E574824A5D0147D961B20FC2983CDB4D3`
  and
  `66A5B7990199E7324E99434788382C54B6570594D27A662FC9F83776041F55EB`.
  After applying `-fdebug-prefix-map` to normalize the independent source and
  build directories to stable DWARF paths, both clean builds produced the same
  APK SHA-256
  `B417EE9E303BCE3ABBE7FE709A77433D04E426E47CAD1B8880E17130CB6B335B`.
  Their embedded 1,756,032-byte `libugts_kc_native.so` files both have SHA-256
  `5EE54BD46375EBE9EE45847131755642F8B37270F9691E66697C954E5510254C`
  and GNU build ID `8A4D75726438F50328566565391A4EEAB5AD9D39`.
- Added `src/ugts_kc3/conformance/polar_substrate_vectors.tsv`, one 4,994-byte
  canonical seven-case artifact with SHA-256
  `CDF8B4A20869C2BC35C4330C35DC7E43C33459CE40F37FD63139C0A41B01DB57`.
  Python and the native host executable consume the same fixed expectations for
  the explicit core, radius clamps, theta/heading seams, LUT interpolation,
  Direct/LUT position/velocity/acceleration/heading, and packed next state.
  Shader snippets are checked against `polar_scene.vert`, but the artifact marks
  that evidence `shader_source_formula_only_no_gpu_execution`.
- LUT rendering now obtains packed heading from the same seam-safe log-encoded
  polar LUT direction lookup used for angular direction. Direct mode retains
  `sin`/`cos` as the independent comparison path. Focused evidence reported
  **66 tests and 69 subtests passed**, Ruff clean, native host conformance
  `PASS ... vectors=7 source_formula_only=true`, and successful Direct/LUT
  shader linking. A fresh 1,789,411-byte current-source Poco debug APK built with
  zero native stderr; SHA-256
  `6348E44A6B75281C469135AFF3C9A17A37739701673AE14F36B17001D1A165C3`.
- The post-fix full `python -m pytest -q` run completed with exit 0:
  **701 passed and 236 subtests passed in 165.86 seconds**, with no warning
  summary/output. Its first run's sole failure was a stale source-slicing
  assertion in
  `test_renderer_uploads_camera_and_every_packed_material_field`; the assertion
  was corrected to follow `drawOrdinaryNode`, passed isolated, and then passed
  in the complete run.
- Ran `python validation/benchmark_polar_render_poco.py` with
  `--workload recipe --include-cpu --build-only`. Run
  `build/poco-polar-render-benchmarks/20260829T215836Z-seed-5eed3920c0dec0de`
  completed all **15** short-workspace cases: 64/256/1024 CPU Off and
  Direct/LUT with Bayer Off/Subtle. All 15 numbered attempts are complete and
  use `org.ugts.games.packed_polar_recipe_lab_3d.pocox7pro`.
- The 3,317-byte `run-manifest.json` has SHA-256
  `0104FF9C2B0B2B7916F99580DA8A89AFEE8693CDA14C07D767E3AC8677E1B337`;
  the 11,076-byte `comparison-summary.json` has SHA-256
  `9A3B4443EA6F4A1125C0463428EB884B2857EE13795AD0A21DD0BB30C0E8B05A`.
  The summary says `built_only` for every case, null FPS/p95 values, and zero
  available comparisons. These hashes prove preserved build evidence, not
  physical rendering or relative performance.
- No ADB device was available. None of these results proves POCO/Mali runtime,
  screenshots, GPU timer support or samples, FPS, Direct/LUT/Bayer performance,
  power, or thermal behavior.

## 2026-08-30 — Release-content verification completed

- Built a wheel and source distribution from a frozen workspace snapshot under
  `build/release-content-verification/20260829T221517Z-final-package-go`; the
  snapshot SHA-256 is
  `948CD26FD532B36FFF0DB31E88F9AAF29FA305BCF0B82358AB3334904863D5DA`.
- The 534,168-byte wheel has SHA-256
  `494962E7AABB7ED199CEA57D23C6DB85DCE5B8A3884F29B8F1DCEA83E00E76E9`;
  the 621,456-byte source distribution has SHA-256
  `7D197636619B01154CA4C6C7573EE0D2FDCBE2527E4FB88868528C88C26C8E49`.
- Verified all 25 required conformance and Android-template paths in both
  archives, byte-for-byte against the frozen snapshot. This includes the shared
  TSV, `gpu_timer_query.*`, `polar_populations.*`, `polar_scene.vert`, and their
  runtime/template dependencies. Neither archive contains Python bytecode.
- Installed the wheel locally with `pip --no-index --no-deps` in a fresh Python
  3.12 virtual environment. Package imports, resource reads, distribution/version
  `3.9.2`, and isolated `python -I -m ugts_kc3 --help` all exited successfully.
- This proves release contents and isolated Python installation only. It does
  not add physical Android execution or Mali performance evidence.

## 2026-08-30 — Semantic Movement blocks completed

- Expanded the built-in Mobile 3D/native registry from 27 to **29** blocks;
  the portable desktop/retained-web/native subset remains **25**.
- Added append-only opcode 28 **Read Movement** (`value.polar_movement`) and
  opcode 29 **Change Movement** (`action.set_polar_movement`). Both hardcode the
  semantic virtual `polar_movement` component and expose only an entity, one of
  its seven friendly numeric fields, and a numeric fallback or new value.
- The dedicated blocks preserve Python/native packed-word and composed-transform
  parity. In the fixed four-node comparison their KCVG is **239 bytes / 8
  inputs**, versus **268 bytes / 10 inputs** for generic component blocks: 29
  bytes smaller with no `polar_movement` string. The retained browser exporter
  rejects both as Mobile-3D-only rather than silently omitting them.
- Broad graph coverage passed **141 tests and 53 subtests**. The combined
  semantic-movement/ECS/hierarchy/animation selection passed **139 tests and 47
  subtests**.

## 2026-08-30 — Desktop sparse optional-component queries completed

- Moved optional `GameWorld3D` components into world-owned sparse pools. A
  spawned entity's `extra_components` becomes a live dict-compatible
  `MutableMapping`, so assignment, replacement, deletion and normal bulk
  mutators update the same pool authority.
- Added cached canonical query plans: component-name permutations deduplicate
  to one shape, execution chooses the smallest required sparse pool, then
  evaluates mutable tag/alive/active filters and emits lexicographically ordered
  entities. Virtual `polar_movement` membership maps to `packed_kinematic`.
- Saved project JSON, runtime snapshots and state hashes remain unchanged.
  Built-in transform/body/collider/render storage remains in the compatibility
  record; full archetypes plus tag/spatial/graph-binding/render-batch indexes
  remain TODO.
- The **4** focused pool/query-plan tests pass. The wider scoped regression
  passed **152 tests and 60 subtests**; targeted Ruff and Python compilation
  also pass.

## 2026-08-30 — Device Look reference and opcode-29 Poco build completed

- Added `editor/device_look.py` and an opt-in **Device Look (reference)**
  viewport control. The editor keeps its exact binary16 UGLUT2 CPU composition,
  copies the completed authoring viewport into RGBA8, and runs the packaged
  `grove_post.vert` / `grove_post.frag` Bayer branch through an OpenGL widget.
  Desktop core GLSL changes only the ES preamble; the canonical 64-entry matrix,
  top-origin physical-pixel phase, threshold, quantization, and mix remain in
  the shared native shader source.
- The visible active state says `CPU LUT + <mode> Bayer`, including when the
  phone profile asks for Direct. Bayer Off performs no GL copy or clamp. Invalid
  settings, headless Qt, an unavailable context, or a post failure preserve the
  raster viewport and selection/zoom state. The tooltip states that the grid
  and gizmos are included and that this is not Android GPU/performance parity.
- Formula/source/fallback and adjacent editor/polar verification passed **50
  tests and 66 subtests**; targeted Ruff passed. A live Windows OpenGL check at
  device-pixel ratio 1.5 allocated the exact Qt physical size **959 x 629**,
  ran the packaged shader without a GL failure, and restored QWidget/Smart
  updates when disabled. Headless CI intentionally proves only formula, source,
  and fallback behavior.
- Updated the checked-in 64/256/1024 packed-polar lab to use dedicated opcodes
  28/29. Its 64-binding KCVG is **752 bytes** with 10 inputs and no
  `polar_movement` string, versus **781 bytes** and 12 inputs through generic
  blocks. The deterministic lab verifier and focused tests passed.
- Fresh short-path `poco-debug` generation and native compilation produced
  `build/op29-poco-build-20260830T005625/UGTS-Packed-Polar-Op29-Poco-debug.apk`:
  **1,804,539 bytes**, SHA-256
  `78A195491B8D46D6946EA3B8C08FB86B3452B66D02105DD7F9A2D8AA51F386B9`.
  It is v2-signed, min SDK 26 / target SDK 36, application ID
  `org.ugts.games.packed_polar_gpu_lab_3d.pocox7pro`, and embeds the exact
  752-byte KCVG, 3,202-byte KCPK, and 32-byte KCRP recorded in `evidence.json`.
  `adb devices -l` was empty, so this is build/package evidence only: it was not
  installed, launched, screenshotted, timed, or profiled on the POCO/Mali GPU.

## 2026-08-30 — Live desktop Make Many Play preview completed

- `EditorDocument.step_play()` now carries each live Mobile 3D object's
  translation, rotation, scale, velocity and active state plus a transient
  packed-movement view containing the previous/current pose words, motion word
  and profile id. The transient previous word is not serialized into project
  JSON or runtime snapshots.
- The Scene viewport updates only its already-created global maximum of 64
  KCPR display items in place through the existing authored recipe, LUT and
  random-access lineage. It creates no generated ECS rows or per-copy runtime
  state. Runtime height, scale and vertical velocity compound with the packed
  prototype pose.
- Dead or inactive prototypes hide the real mesh and its copies; reactivation
  restores the prototype and reuses the same retained copy objects. Malformed
  transient packed or transform data hides the affected rendering for that
  frame instead of crashing Play. Stop intentionally rebuilds the authored
  preview.
- The focused polar-recipe/Device-Look rerun passed **33 tests and 19
  subtests**; the wider editor/viewport/Play selection passed **93 tests and 28
  subtests**, and hierarchy/Saved Scene coverage passed **29 tests and 10
  subtests**. Targeted Ruff passed.
- This is current-endpoint rendering only. The editor has no real accumulator
  alpha and therefore does not yet match Android's previous/current packed-pose
  presentation interpolation.

## 2026-08-30 — First child-facing Make Many runtime block completed

- Expanded the Mobile 3D/native registry from 29 to **30** blocks while the
  portable desktop/web/native subset remains 25. Append-only opcode 30 is
  `action.set_polar_population_visible` / **Show or Hide Extra Copies** with a
  literal Make Many object, linked-or-literal Boolean, no data output and one
  `out` flow.
- Desktop owns copy visibility in `PolarPopulationRuntimeState`, outside
  `world.state`, sparse ECS component pools, project JSON, snapshots and hashes.
  Native owns the same meaning in one safe `uint64_t` mask for all 64 bounded
  recipe slots. Both initialize visible before Ready and reset with a new
  runtime.
- Hiding extra copies leaves the real prototype alive, active, visible and
  selectable. The common native CPU/Direct/LUT recipe loop skips the hidden
  recipe before prototype lookup, materialization or visible-budget use.
  KCPR/KCPK bytes, content addresses, counts and deterministic prefixes remain
  unchanged.
- The frozen Ready-plus-action graph is **121 bytes**, SHA-256
  `DCA7CF42A184CE9F50C0B90646756A90ED4E782EA8EB2697553525880B4E529C`,
  versus **92 bytes** for Ready alone: an exact 29-byte increment.
- Focused Python/editor/pack/browser coverage passed **6 tests and 2 subtests**;
  the broad graph/pack/editor/web/population selection passed **137 tests and
  74 subtests**, and Mobile ECS/Saved Scene/animation regressions passed **33
  tests and 8 subtests**. Native KCPR/VM and graph regressions passed, and the
  Android ARM64 CMake target built successfully. The raw ungenerated template's
  full APK link still rejects its intentional `__APPLICATION_ID__` placeholder;
  this is not a generated-project build failure.

## 2026-08-30 — Radial Burst loop and build-only matrix completed

- Added **Make Many → Radial Burst (loops)** as a bounded looping display effect
  around one real packed ECS prototype. Its local packed displacement compounds
  with the prototype anchor through log-encoded polar LUT semantics. It is not a
  one-shot gameplay event and creates no generated ECS identities.
- KCPR remains byte-identical v1 for legacy-only Ring, Spiral and Polar Field
  assets, including their prior golden hashes. A pack selects v2 only when it
  contains Burst. The controlled profile-core-start and positive-start one-Burst
  packs are each **240 bytes**, with SHA-256
  `2F6717F35D90033A8476EAC20E74A625FE6DD74CF39B159172BBC7ED6A6BF807`
  and `F9BF55A78D94EDFBE6731FE886F1A1EE1F6AC85DB70CB157C489BF18F8D3ECBD`.
  Each contains a 32-byte header, five 16-byte operator meanings and one
  128-byte recipe.
- Burst limits are 512 instances per recipe, 16 recipes and 2,048 instances per
  project. The desktop keeps only its existing global maximum of 64 preview
  items; native work also obeys maximum-visible and the remaining particle
  budget. Opcode 30 hides the extra copies only and leaves the real prototype
  visible.
- Stopped desktop authoring displays the deterministic loop midpoint. Play
  passes the real post-step fixed world tick and draws the fixed endpoint with
  no invented interpolation alpha. Direct is the native baseline, LUT uses the
  shared profile path, and Bayer remains the final presentation pass.
- Core plus legacy recipe coverage passed **32 tests and 25 subtests**; the
  related Python/editor/conformance selection passed **57 tests and 102
  subtests**. Native exact-vector execution passed **1 test and 2 subtests** at
  ticks 0, 1, 4, 7 and 8, and the native wiring/render/conformance selection
  passed **10 tests and 23 subtests**. The ARM64 native CMake target built
  successfully in 16 seconds.
- Executed and preserved the separate **18-case** build matrix: 32/128/384 instances across
  CPU/Direct/LUT and Bayer Off/subtle:

  ```powershell
  python validation/benchmark_polar_render_poco.py --workload burst --include-cpu --build-only
  ```

  Run `build/poco-polar-render-benchmarks/20260830T000848Z-seed-5eed3920c0dec0de`
  finished `built_only`, 18/18, in 272 seconds. Every case records a 1,690-byte
  KCPK, 240-byte KCPR and 32-byte KCRP; APKs range from 1,804,558 to 1,804,566
  bytes. No APK was installed or run through GLES/Mali, so the matrix is not
  POCO visual or performance evidence.
- The final full suite passed **739 tests and 252 subtests** in 274.18 seconds,
  with no failures or skips. Ruff is green for the focused changed/new paths.
  Global Ruff still reports 895 pre-existing legacy violations in 31 files,
  none in the Radial Burst or validation files changed here.

## Worklog rules for subsequent entries

- Record exact files and formats changed.
- Record exact commands and test counts.
- Record artifact byte sizes and SHA-256 hashes.
- Record device serial/model, application id, run duration, workload, and
  environmental caveats for every phone result.
- Record regressions and abandoned approaches, not only successes.
- Never turn an intended optimization into a performance claim before an A/B
  measurement on the target device.
