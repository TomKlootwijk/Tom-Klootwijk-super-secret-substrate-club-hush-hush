"""Bounded content-addressed display populations in packed polar space.

``polar_population`` is deliberately a render recipe attached to one real ECS
prototype.  Its generated members are :class:`PolarDisplayInstance` values;
they are never inserted into :class:`~ugts_kc3.mobile3d.GameWorld3D` and do not
receive colliders, tags, graphs, or gameplay identity.

Every member is random-access through the retained UGTS SplitMix64 lineage
schedule.  Cardinality is excluded only from the lineage namespace, so growing
64 -> 256 -> 1024 preserves the complete earlier prefix.  The separate recipe
content address includes cardinality and every recorded recipe input.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import math
from numbers import Integral, Real
import struct
from typing import Any, Mapping

from .math3d import quat_from_axis_angle
from .packed_kinematics import (
    PackedKinematicComponent,
    PolarLookupTable,
    PolarPose,
)
from .polarpack import (
    PolarComponentSpec,
    PolarProfileSpec,
    collect_polar_project_spec,
    profile_lut_bytes,
    quantized_profile_lut,
)
from .renderpack import render_substrate_config_from_project
from .scatter import combine_seed, hash64, seed_unit_float, stable_id


POLAR_POPULATION_METADATA_KEY = "polar_population"
POLAR_POPULATION_PRESETS = ("ring", "spiral", "polar_field")
POLAR_POPULATION_PRESET_LABELS = {
    "ring": "Ring",
    "spiral": "Spiral",
    "polar_field": "Polar Field",
}

MAX_POLAR_POPULATION_RECIPES = 64
MAX_POLAR_POPULATION_INSTANCES_PER_RECIPE = 4096
MAX_POLAR_POPULATION_TOTAL_INSTANCES = 16384

_MASK64 = (1 << 64) - 1
_RHO_BITS = 20
_THETA_BITS = 18
_TICK_BITS = 14
_HEADING_BITS = 12
_HEADING_SHIFT = 0
_TICK_SHIFT = _HEADING_BITS
_THETA_SHIFT = _TICK_SHIFT + _TICK_BITS
_RHO_SHIFT = _THETA_SHIFT + _THETA_BITS
_GOLDEN_ANGLE_TURNS = 0.3819660112501051
_PARAMETER_STRUCT = struct.Struct("<8f")
_ADDRESS_BYTES = 16
POLAR_POPULATION_MATH_SCHEDULE = (
    "v2: KCPR stores exact binary32 log-radius offsets; SplitMix lanes are exact "
    "24-bit binary32; each add/subtract/multiply/divide is rounded to binary32; "
    "spiral saturation is x/(1+x); fractional turns are added directly to extracted "
    "theta18/heading12 integer codes; the shared profile clamps and packs rho20"
)


class PolarPopulationError(ValueError):
    """Invalid polar-population authoring data or prototype ownership."""


@dataclass(frozen=True)
class PolarPopulationOperator:
    """One immutable operator meaning advertised by the compact sidecar."""

    code: int
    slot: int
    arity: int
    name: str
    meaning: str

    @property
    def meaning_hash(self) -> int:
        return hash64(self.meaning)

    @property
    def mask(self) -> int:
        return 1 << self.slot


POLAR_POPULATION_OPERATORS = (
    PolarPopulationOperator(
        0x0001,
        0,
        3,
        "splitmix64_lineage",
        "ugts.kc392.polar-population.splitmix64-lineage(seed,namespace,index).v1",
    ),
    PolarPopulationOperator(
        0x0010,
        1,
        3,
        "log_radius_multiplier",
        "ugts.kc392.polar-population.binary32-rho+=lerp(serialized-log-min,serialized-log-max,u);profile-clamp+pack20.v2",
    ),
    PolarPopulationOperator(
        0x0011,
        2,
        2,
        "saturating_spiral",
        "ugts.kc392.polar-population.binary32-spiral-x=index*radial-rate;u=x/(1+x).v2",
    ),
    PolarPopulationOperator(
        0x0020,
        3,
        3,
        "periodic_angle",
        "ugts.kc392.polar-population.binary32-turns=seeded-phase+index*step+seeded-jitter;theta18+heading12+=floor(frac(turns)*2^bits).v2",
    ),
    PolarPopulationOperator(
        0x0030,
        4,
        2,
        "seeded_height",
        "ugts.kc392.polar-population.binary32-y+=centered-seeded-unit*height-span.v1",
    ),
    PolarPopulationOperator(
        0x0040,
        5,
        3,
        "uniform_scale",
        "ugts.kc392.polar-population.binary32-scale*=lerp(scale-min,scale-max,seeded-unit).v1",
    ),
)

_OPERATOR_BY_CODE = {operator.code: operator for operator in POLAR_POPULATION_OPERATORS}
_OPERATOR_BY_NAME = {operator.name: operator for operator in POLAR_POPULATION_OPERATORS}
_COMMON_OPERATOR_NAMES = (
    "splitmix64_lineage",
    "log_radius_multiplier",
    "periodic_angle",
    "seeded_height",
    "uniform_scale",
)
_PRESET_OPERATOR_NAMES = {
    "ring": _COMMON_OPERATOR_NAMES,
    "spiral": (
        "splitmix64_lineage",
        "log_radius_multiplier",
        "saturating_spiral",
        "periodic_angle",
        "seeded_height",
        "uniform_scale",
    ),
    "polar_field": _COMMON_OPERATOR_NAMES,
}

_PRESET_DEFAULTS: dict[str, dict[str, float]] = {
    "ring": {
        "radius_min": 1.0,
        "radius_max": 1.0,
        "radial_rate": 0.0,
        "angle_step_turns": _GOLDEN_ANGLE_TURNS,
        "angle_jitter_turns": 0.0,
        "height_spread": 0.0,
        "scale_min": 1.0,
        "scale_max": 1.0,
    },
    "spiral": {
        "radius_min": 1.0,
        "radius_max": 8.0,
        "radial_rate": 0.01,
        "angle_step_turns": 0.0625,
        "angle_jitter_turns": 0.005,
        "height_spread": 0.5,
        "scale_min": 0.85,
        "scale_max": 1.15,
    },
    "polar_field": {
        "radius_min": 0.125,
        "radius_max": 16.0,
        "radial_rate": 0.0,
        "angle_step_turns": _GOLDEN_ANGLE_TURNS,
        "angle_jitter_turns": 0.5,
        "height_spread": 2.0,
        "scale_min": 0.5,
        "scale_max": 1.5,
    },
}
_ALLOWED_KEYS = frozenset(
    {
        "preset",
        "instance_count",
        "seed",
        "radius_min",
        "radius_max",
        "radial_rate",
        "angle_step_turns",
        "angle_jitter_turns",
        "height_spread",
        "scale_min",
        "scale_max",
    }
)


def _f32(value: Any, label: str) -> float:
    if isinstance(value, bool) or not isinstance(value, Real):
        raise PolarPopulationError(f"{label} must be a finite number")
    try:
        result = struct.unpack("<f", struct.pack("<f", float(value)))[0]
    except (OverflowError, struct.error) as error:
        raise PolarPopulationError(f"{label} must fit a finite 32-bit number") from error
    if not math.isfinite(result):
        raise PolarPopulationError(f"{label} must fit a finite 32-bit number")
    # IEEE-754 has two zero encodings, but polar recipe operators give them
    # identical meaning.  Canonical authoring therefore always emits +0 so
    # behaviorally identical inputs cannot acquire different KCPR addresses.
    if result == 0.0:
        return 0.0
    return result


def _integer(value: Any, label: str, minimum: int, maximum: int) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise PolarPopulationError(f"{label} must be a whole number")
    result = int(value)
    if not minimum <= result <= maximum:
        raise PolarPopulationError(f"{label} must be between {minimum} and {maximum}")
    return result


def operator_mask_for_preset(preset: str) -> int:
    try:
        names = _PRESET_OPERATOR_NAMES[preset]
    except KeyError as error:
        labels = ", ".join(POLAR_POPULATION_PRESET_LABELS.values())
        raise PolarPopulationError(f"Pattern must be one of: {labels}") from error
    result = 0
    for name in names:
        result |= _OPERATOR_BY_NAME[name].mask
    return result


@dataclass(frozen=True)
class PolarPopulationRecipe:
    """One bounded recipe; ``instance_count`` includes the authored prototype."""

    preset: str = "ring"
    instance_count: int = 64
    seed: int = 1
    radius_min: float = 1.0
    radius_max: float = 1.0
    radial_rate: float = 0.0
    angle_step_turns: float = _GOLDEN_ANGLE_TURNS
    angle_jitter_turns: float = 0.0
    height_spread: float = 0.0
    scale_min: float = 1.0
    scale_max: float = 1.0

    def __post_init__(self) -> None:
        # Direct dataclass construction is a supported authoring path.  Enter
        # the exact serialized binary32 domain immediately so preview,
        # addresses, KCPR bytes, and a future native consumer cannot diverge.
        if not isinstance(self.preset, str) or self.preset not in POLAR_POPULATION_PRESETS:
            labels = ", ".join(POLAR_POPULATION_PRESET_LABELS.values())
            raise PolarPopulationError(f"Pattern must be one of: {labels}")
        object.__setattr__(
            self,
            "instance_count",
            _integer(
                self.instance_count,
                "Objects in polar group",
                2,
                MAX_POLAR_POPULATION_INSTANCES_PER_RECIPE,
            ),
        )
        object.__setattr__(
            self, "seed", _integer(self.seed, "World number", 0, _MASK64)
        )
        labels = (
            "Smallest radius multiplier",
            "Largest radius multiplier",
            "Spiral growth rate",
            "Turn step",
            "Turn variation",
            "Height spread",
            "Smallest size",
            "Largest size",
        )
        for name, label in zip(
            (
                "radius_min",
                "radius_max",
                "radial_rate",
                "angle_step_turns",
                "angle_jitter_turns",
                "height_spread",
                "scale_min",
                "scale_max",
            ),
            labels,
        ):
            object.__setattr__(self, name, _f32(getattr(self, name), label))
        self.validate()

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "PolarPopulationRecipe":
        if not isinstance(value, Mapping):
            raise PolarPopulationError("metadata.polar_population must be an object")
        unknown = sorted(str(key) for key in value if key not in _ALLOWED_KEYS)
        if unknown:
            raise PolarPopulationError(
                "polar_population has unknown field(s): " + ", ".join(unknown)
            )
        preset = value.get("preset", "ring")
        if not isinstance(preset, str) or preset not in POLAR_POPULATION_PRESETS:
            labels = ", ".join(POLAR_POPULATION_PRESET_LABELS.values())
            raise PolarPopulationError(f"Pattern must be one of: {labels}")
        defaults = _PRESET_DEFAULTS[preset]
        result = cls(
            preset=preset,
            instance_count=_integer(
                value.get("instance_count", 64),
                "Objects in polar group",
                2,
                MAX_POLAR_POPULATION_INSTANCES_PER_RECIPE,
            ),
            seed=_integer(value.get("seed", 1), "World number", 0, _MASK64),
            radius_min=_f32(
                value.get("radius_min", defaults["radius_min"]),
                "Smallest radius multiplier",
            ),
            radius_max=_f32(
                value.get("radius_max", defaults["radius_max"]),
                "Largest radius multiplier",
            ),
            radial_rate=_f32(
                value.get("radial_rate", defaults["radial_rate"]),
                "Spiral growth rate",
            ),
            angle_step_turns=_f32(
                value.get("angle_step_turns", defaults["angle_step_turns"]),
                "Turn step",
            ),
            angle_jitter_turns=_f32(
                value.get("angle_jitter_turns", defaults["angle_jitter_turns"]),
                "Turn variation",
            ),
            height_spread=_f32(
                value.get("height_spread", defaults["height_spread"]),
                "Height spread",
            ),
            scale_min=_f32(
                value.get("scale_min", defaults["scale_min"]),
                "Smallest size",
            ),
            scale_max=_f32(
                value.get("scale_max", defaults["scale_max"]),
                "Largest size",
            ),
        )
        result.validate()
        return result

    @property
    def operator_mask(self) -> int:
        return operator_mask_for_preset(self.preset)

    @property
    def parameters(self) -> tuple[float, ...]:
        """Return the child-facing multiplier parameters used by project JSON."""

        return (
            self.radius_min,
            self.radius_max,
            self.radial_rate,
            self.angle_step_turns,
            self.angle_jitter_turns,
            self.height_spread,
            self.scale_min,
            self.scale_max,
        )

    @property
    def operator_parameters(self) -> tuple[float, ...]:
        """Return exact runtime fields; slots 0/1 are log-radius offsets."""

        return polar_population_operator_parameters(self)

    def validate(self) -> None:
        operator_mask_for_preset(self.preset)
        _integer(
            self.instance_count,
            "Objects in polar group",
            2,
            MAX_POLAR_POPULATION_INSTANCES_PER_RECIPE,
        )
        _integer(self.seed, "World number", 0, _MASK64)
        parameters = tuple(
            _f32(value, label)
            for value, label in zip(
                self.parameters,
                (
                    "Smallest radius multiplier",
                    "Largest radius multiplier",
                    "Spiral growth rate",
                    "Turn step",
                    "Turn variation",
                    "Height spread",
                    "Smallest size",
                    "Largest size",
                ),
            )
        )
        (
            radius_min,
            radius_max,
            radial_rate,
            angle_step,
            angle_jitter,
            height_spread,
            scale_min,
            scale_max,
        ) = parameters
        if not 1.0 / 256.0 <= radius_min <= radius_max <= 256.0:
            raise PolarPopulationError(
                "Radius multipliers must stay between 1/256 and 256 (smallest <= largest)"
            )
        if not -4.0 <= angle_step <= 4.0:
            raise PolarPopulationError("Turn step must stay between -4 and 4 turns")
        if not 0.0 <= angle_jitter <= 1.0:
            raise PolarPopulationError("Turn variation must stay between 0 and 1 turn")
        if not 0.0 <= height_spread <= 1024.0:
            raise PolarPopulationError("Height spread must stay between 0 and 1024")
        if not 0.05 <= scale_min <= scale_max <= 8.0:
            raise PolarPopulationError(
                "Size range must stay between 0.05 and 8 (smallest <= largest)"
            )
        if self.preset == "spiral":
            if not 0.000001 <= radial_rate <= 1.0:
                raise PolarPopulationError(
                    "Spiral growth rate must stay between 0.000001 and 1"
                )
        elif radial_rate != 0.0:
            raise PolarPopulationError(
                f"{POLAR_POPULATION_PRESET_LABELS[self.preset]} keeps Spiral growth rate at 0"
            )

    def to_dict(self) -> dict[str, Any]:
        self.validate()
        return {
            "preset": self.preset,
            "instance_count": self.instance_count,
            "seed": self.seed,
            "radius_min": self.radius_min,
            "radius_max": self.radius_max,
            "radial_rate": self.radial_rate,
            "angle_step_turns": self.angle_step_turns,
            "angle_jitter_turns": self.angle_jitter_turns,
            "height_spread": self.height_spread,
            "scale_min": self.scale_min,
            "scale_max": self.scale_max,
        }


def validate_polar_population_operator_parameters(
    preset: str,
    parameters: tuple[float, ...] | list[float],
) -> tuple[float, ...]:
    """Validate and canonicalize the eight exact binary32 KCPR operator fields."""

    operator_mask_for_preset(preset)
    if len(parameters) != 8:
        raise PolarPopulationError("polar population needs exactly 8 operator parameters")
    labels = (
        "Smallest log radius offset",
        "Largest log radius offset",
        "Spiral growth rate",
        "Turn step",
        "Turn variation",
        "Height spread",
        "Smallest size",
        "Largest size",
    )
    result = tuple(_f32(value, label) for value, label in zip(parameters, labels))
    (
        log_radius_min,
        log_radius_max,
        radial_rate,
        angle_step,
        angle_jitter,
        height_spread,
        scale_min,
        scale_max,
    ) = result
    log_limit = _f32(math.log(256.0), "Log radius limit")
    if not -log_limit <= log_radius_min <= log_radius_max <= log_limit:
        raise PolarPopulationError(
            "Log radius offsets must stay inside log(1/256)..log(256) "
            "(smallest <= largest)"
        )
    if not -4.0 <= angle_step <= 4.0:
        raise PolarPopulationError("Turn step must stay between -4 and 4 turns")
    if not 0.0 <= angle_jitter <= 1.0:
        raise PolarPopulationError("Turn variation must stay between 0 and 1 turn")
    if not 0.0 <= height_spread <= 1024.0:
        raise PolarPopulationError("Height spread must stay between 0 and 1024")
    if not 0.05 <= scale_min <= scale_max <= 8.0:
        raise PolarPopulationError(
            "Size range must stay between 0.05 and 8 (smallest <= largest)"
        )
    if preset == "spiral":
        if not 0.000001 <= radial_rate <= 1.0:
            raise PolarPopulationError(
                "Spiral growth rate must stay between 0.000001 and 1"
            )
    elif radial_rate != 0.0:
        raise PolarPopulationError(
            f"{POLAR_POPULATION_PRESET_LABELS[preset]} keeps Spiral growth rate at 0"
        )
    return result


def polar_population_operator_parameters(
    recipe: PolarPopulationRecipe,
) -> tuple[float, ...]:
    """Compile child-facing radius multipliers into exact no-libm runtime fields."""

    recipe.validate()
    return validate_polar_population_operator_parameters(
        recipe.preset,
        (
            _f32(math.log(recipe.radius_min), "Smallest log radius offset"),
            _f32(math.log(recipe.radius_max), "Largest log radius offset"),
            recipe.radial_rate,
            recipe.angle_step_turns,
            recipe.angle_jitter_turns,
            recipe.height_spread,
            recipe.scale_min,
            recipe.scale_max,
        ),
    )


def polar_population_preset(
    preset: str, *, instance_count: int = 64, seed: int = 1
) -> PolarPopulationRecipe:
    """Return a fully explicit child-facing Ring, Spiral, or Polar Field recipe."""

    return PolarPopulationRecipe.from_mapping(
        {"preset": preset, "instance_count": instance_count, "seed": seed}
    )


@dataclass(frozen=True)
class PolarPopulationGroup:
    prototype_node_index: int
    prototype_id: str
    component: PackedKinematicComponent
    profile: PolarProfileSpec
    recipe: PolarPopulationRecipe
    operator_parameters: tuple[float, ...]
    root_seed: int
    profile_address: bytes
    prototype_address: bytes
    lineage_namespace: bytes
    content_address: bytes


@dataclass(frozen=True)
class PolarPopulationProjectSpec:
    groups: tuple[PolarPopulationGroup, ...]
    root_seed: int = 0

    @property
    def total_instances(self) -> int:
        return sum(group.recipe.instance_count for group in self.groups)

    @property
    def generated_copies(self) -> int:
        return self.total_instances - len(self.groups)


@dataclass(frozen=True)
class PolarDisplayInstance:
    """Derived render data only; this value is intentionally not an ECS entity."""

    prototype_id: str
    index: int
    lineage: int
    profile_id: str
    pose_word: int
    motion_word: int
    translation: tuple[float, float, float]
    rotation: tuple[float, float, float, float]
    scale: tuple[float, float, float]
    velocity: tuple[float, float, float]

    @property
    def display_id(self) -> str:
        return f"{self.prototype_id}__polar_display_{self.lineage:016x}"


def _encoded_text(value: str) -> bytes:
    encoded = str(value).encode("utf-8")
    if not encoded or len(encoded) > 65535:
        raise PolarPopulationError("content-addressed prototype text must use 1..65535 UTF-8 bytes")
    return struct.pack("<H", len(encoded)) + encoded


def polar_profile_semantics_address(profile: PolarProfileSpec) -> bytes:
    """Return the 128-bit address of exact LUT and motion-profile semantics."""

    motion = profile.codec.motion_range
    payload = bytearray(b"KCPR392-profile-semantics-v1\0")
    payload.extend(_encoded_text(profile.id))
    payload.extend(
        struct.pack(
            "<4dI",
            motion.rho_velocity,
            motion.theta_velocity,
            motion.rho_acceleration,
            motion.theta_acceleration,
            profile.lut_resolution,
        )
    )
    try:
        lut = profile_lut_bytes(profile)
    except ValueError as error:
        raise PolarPopulationError(
            f"polar population profile {profile.id!r} is invalid: {error}"
        ) from error
    payload.extend(struct.pack("<I", len(lut)))
    payload.extend(lut)
    return hashlib.sha256(payload).digest()[:_ADDRESS_BYTES]


def polar_prototype_semantics_address(
    node: Any,
    component: PackedKinematicComponent,
    profile_address: bytes,
    mesh_address: bytes,
    material_address: bytes,
) -> bytes:
    """Address authored render/anchor inputs consumed by display generation."""

    if any(
        len(address) != _ADDRESS_BYTES
        for address in (profile_address, mesh_address, material_address)
    ):
        raise PolarPopulationError("prototype dependency addresses must contain 16 bytes")
    transform = getattr(node, "transform", None)
    if transform is None:
        raise PolarPopulationError(f"prototype {getattr(node, 'id', '')!r} has no transform")
    # Packed polar owns X/Z and facing, so ignored authored X/Z/rotation must
    # not churn identity.  Generated display members consume only authored Y,
    # scale, and Y velocity from the ordinary node transform/body.
    values = (
        transform.translation[1],
        *transform.scale,
        getattr(node, "velocity", (0.0, 0.0, 0.0))[1],
    )
    canonical_values = tuple(_f32(value, "Prototype transform") for value in values)
    payload = bytearray(b"KCPR392-prototype-semantics-v1\0")
    payload.extend(_encoded_text(str(getattr(node, "id", ""))))
    payload.extend(profile_address)
    payload.extend(mesh_address)
    payload.extend(material_address)
    payload.extend(
        struct.pack(
            "<QQ5f", component.pose_word, component.motion_word, *canonical_values
        )
    )
    return hashlib.sha256(payload).digest()[:_ADDRESS_BYTES]


def polar_asset_semantics_address(asset: Any, kind: str) -> bytes:
    """Address the exact canonical f32/u32 render lanes visible in KC3D392."""

    if kind == "mesh" and all(
        hasattr(asset, name) for name in ("vertices", "triangles", "resolved_normals")
    ):
        payload = bytearray(b"KCPR392-mesh-semantics-v1\0")
        vertices = tuple(asset.vertices)
        triangles = tuple(asset.triangles)
        normals = tuple(asset.resolved_normals())
        if len(normals) != len(vertices):
            raise PolarPopulationError(
                "polar population mesh normals must match its vertices"
            )
        payload.extend(struct.pack("<III", len(vertices), len(triangles), len(normals)))
        for vertex in vertices:
            payload.extend(
                struct.pack("<3f", *(_f32(value, "Mesh vertex") for value in vertex))
            )
        for triangle in triangles:
            if len(triangle) != 3 or any(
                isinstance(value, bool) or not isinstance(value, Integral)
                for value in triangle
            ):
                raise PolarPopulationError("polar population mesh triangle is invalid")
            try:
                payload.extend(struct.pack("<3I", *(int(value) for value in triangle)))
            except struct.error as error:
                raise PolarPopulationError(
                    "polar population mesh indices must fit unsigned 32-bit lanes"
                ) from error
        for normal in normals:
            payload.extend(
                struct.pack("<3f", *(_f32(value, "Mesh normal") for value in normal))
            )
    elif kind == "material" and all(
        hasattr(asset, name)
        for name in (
            "base_color",
            "metallic",
            "roughness",
            "emissive",
            "double_sided",
        )
    ):
        payload = bytearray(b"KCPR392-material-semantics-v1\0")
        values = (
            *asset.base_color,
            asset.metallic,
            asset.roughness,
            *asset.emissive,
        )
        payload.extend(
            struct.pack(
                "<9fB",
                *(_f32(value, "Material value") for value in values),
                1 if bool(asset.double_sided) else 0,
            )
        )
    else:
        raise PolarPopulationError(
            f"polar population {kind!r} has no canonical KC3D392 byte schedule"
        )
    return hashlib.sha256(payload).digest()[:_ADDRESS_BYTES]


def _operator_semantics_bytes(operator_mask: int) -> bytes:
    result = bytearray()
    for operator in POLAR_POPULATION_OPERATORS:
        if operator_mask & operator.mask:
            result.extend(struct.pack("<HQ", operator.code, operator.meaning_hash))
    return bytes(result)


def polar_recipe_record_addresses(
    *,
    preset: str,
    instance_count: int,
    recipe_seed: int,
    operator_parameters: tuple[float, ...] | list[float],
    profile_address: bytes,
    prototype_address: bytes,
    root_seed: int = 0,
) -> tuple[bytes, bytes]:
    """Address one exact KCPR record without reconstructing UI multipliers.

    The first excludes only ``instance_count``.  The second includes it.
    Both include operator meanings, seed, profile/prototype semantics, and all
    eight canonical binary32 parameters.
    """

    operator_mask = operator_mask_for_preset(preset)
    instance_count = _integer(
        instance_count,
        "Objects in polar group",
        2,
        MAX_POLAR_POPULATION_INSTANCES_PER_RECIPE,
    )
    recipe_seed = _integer(recipe_seed, "World number", 0, _MASK64)
    parameters = validate_polar_population_operator_parameters(
        preset, operator_parameters
    )
    root_seed = _integer(root_seed, "Render root seed", 0, _MASK64)
    if len(profile_address) != _ADDRESS_BYTES or len(prototype_address) != _ADDRESS_BYTES:
        raise PolarPopulationError("recipe dependency addresses must contain 16 bytes")
    preset_code = POLAR_POPULATION_PRESETS.index(preset) + 1
    shared = bytearray(b"KCPR392-lineage-semantics-v1\0")
    shared.extend(
        struct.pack(
            "<HHQQ",
            preset_code,
            operator_mask,
            root_seed,
            recipe_seed,
        )
    )
    shared.extend(profile_address)
    shared.extend(prototype_address)
    shared.extend(_PARAMETER_STRUCT.pack(*parameters))
    shared.extend(_operator_semantics_bytes(operator_mask))
    lineage_namespace = hashlib.sha256(shared).digest()[:_ADDRESS_BYTES]
    content = bytearray(b"KCPR392-full-recipe-content-v1\0")
    content.extend(shared)
    content.extend(struct.pack("<I", instance_count))
    content_address = hashlib.sha256(content).digest()[:_ADDRESS_BYTES]
    return lineage_namespace, content_address


def polar_recipe_addresses(
    recipe: PolarPopulationRecipe,
    profile_address: bytes,
    prototype_address: bytes,
    root_seed: int = 0,
) -> tuple[bytes, bytes]:
    """Return lineage/full addresses for one child-facing authored recipe."""

    recipe.validate()
    return polar_recipe_record_addresses(
        preset=recipe.preset,
        instance_count=recipe.instance_count,
        recipe_seed=recipe.seed,
        operator_parameters=recipe.operator_parameters,
        profile_address=profile_address,
        prototype_address=prototype_address,
        root_seed=root_seed,
    )


def _validated_polar_prototype(node: Any) -> None:
    node_id = str(getattr(node, "id", ""))
    metadata = getattr(node, "metadata", None)
    if not isinstance(metadata, Mapping):
        raise PolarPopulationError(f"node {node_id!r} metadata must be an object")
    if metadata.get("packed_kinematic") is None:
        raise PolarPopulationError(
            f"{node_id!r} needs a Movement Pattern before it can make a polar display population"
        )
    if metadata.get("scatter_population") is not None:
        raise PolarPopulationError(
            f"{node_id!r} cannot combine Populate Area with a polar display population"
        )
    if bool(getattr(node, "dynamic", False)):
        raise PolarPopulationError(
            f"{node_id!r} must be static because its Movement Pattern owns its position"
        )


def collect_polar_population_project_spec(project: Any) -> PolarPopulationProjectSpec:
    """Validate and collect canonical sparse polar render recipes."""

    nodes = tuple(getattr(project, "nodes", ()))
    has_recipe = False
    for node_index, node in enumerate(nodes):
        metadata = getattr(node, "metadata", None)
        if not isinstance(metadata, Mapping):
            raise PolarPopulationError(f"node {node_index} metadata must be an object")
        has_recipe = has_recipe or POLAR_POPULATION_METADATA_KEY in metadata
    if not has_recipe:
        return PolarPopulationProjectSpec((), 0)
    try:
        polar = collect_polar_project_spec(project)
    except ValueError as error:
        raise PolarPopulationError(
            f"invalid packed Movement Pattern dependency: {error}"
        ) from error
    try:
        render_config = render_substrate_config_from_project(project)
    except ValueError as error:
        raise PolarPopulationError(f"invalid Render root seed: {error}") from error
    root_seed = 0 if render_config is None else render_config.seed
    component_by_node = {item.node_index: item for item in polar.components}
    profile_by_id = {profile.id: profile for profile in polar.profiles}
    groups: list[PolarPopulationGroup] = []
    for node_index, node in enumerate(nodes):
        metadata = getattr(node, "metadata", None)
        if not isinstance(metadata, Mapping):
            raise PolarPopulationError(f"node {node_index} metadata must be an object")
        raw = metadata.get(POLAR_POPULATION_METADATA_KEY)
        if raw is None:
            continue
        if len(groups) >= MAX_POLAR_POPULATION_RECIPES:
            raise PolarPopulationError(
                f"projects support at most {MAX_POLAR_POPULATION_RECIPES} polar populations"
            )
        _validated_polar_prototype(node)
        component_spec: PolarComponentSpec | None = component_by_node.get(node_index)
        if component_spec is None:
            raise PolarPopulationError(
                f"{node.id!r} has no valid packed Movement Pattern component"
            )
        recipe = (
            PolarPopulationRecipe.from_mapping(raw.to_dict())
            if isinstance(raw, PolarPopulationRecipe)
            else PolarPopulationRecipe.from_mapping(raw)
        )
        recipe.validate()
        operator_parameters = recipe.operator_parameters
        profile = profile_by_id[component_spec.component.profile_id]
        profile_address = polar_profile_semantics_address(profile)
        meshes = getattr(project, "meshes", {})
        materials = getattr(project, "materials", {})
        try:
            mesh = meshes[node.mesh_id]
            material = materials[node.material_id]
        except (KeyError, TypeError) as error:
            raise PolarPopulationError(
                f"{node.id!r} references missing render content"
            ) from error
        mesh_address = polar_asset_semantics_address(mesh, "mesh")
        material_address = polar_asset_semantics_address(material, "material")
        prototype_address = polar_prototype_semantics_address(
            node,
            component_spec.component,
            profile_address,
            mesh_address,
            material_address,
        )
        lineage_namespace, content_address = polar_recipe_addresses(
            recipe, profile_address, prototype_address, root_seed
        )
        groups.append(
            PolarPopulationGroup(
                node_index,
                str(node.id),
                component_spec.component,
                profile,
                recipe,
                operator_parameters,
                root_seed,
                profile_address,
                prototype_address,
                lineage_namespace,
                content_address,
            )
        )
    result = PolarPopulationProjectSpec(tuple(groups), root_seed)
    if result.total_instances > MAX_POLAR_POPULATION_TOTAL_INSTANCES:
        raise PolarPopulationError(
            f"polar populations contain {result.total_instances} display instances; "
            f"project limit is {MAX_POLAR_POPULATION_TOTAL_INSTANCES}"
        )
    return result


def _namespace_u64(address: bytes) -> int:
    if len(address) != _ADDRESS_BYTES:
        raise PolarPopulationError("lineage namespace must contain 16 bytes")
    return combine_seed(
        int.from_bytes(address[:8], "little"),
        int.from_bytes(address[8:], "little"),
    )


def _lane(lineage: int, lane: int) -> float:
    return seed_unit_float(combine_seed(lineage, lane))


def _add32(left: float, right: float, label: str) -> float:
    return _f32(_f32(left, label) + _f32(right, label), label)


def _sub32(left: float, right: float, label: str) -> float:
    return _f32(_f32(left, label) - _f32(right, label), label)


def _mul32(left: float, right: float, label: str) -> float:
    return _f32(_f32(left, label) * _f32(right, label), label)


def _div32(left: float, right: float, label: str) -> float:
    denominator = _f32(right, label)
    if denominator == 0.0:
        raise PolarPopulationError(f"{label} cannot divide by zero")
    return _f32(_f32(left, label) / denominator, label)


def _periodic_turn_code(turns: float, bits: int) -> int:
    """Quantize staged-f32 fractional turns without radians or libm trig."""

    value = _f32(turns, "Generated turn")
    whole = math.floor(value)
    fraction = _sub32(value, float(whole), "Fractional generated turn")
    scaled = _mul32(fraction, float(1 << bits), "Generated turn code")
    return int(math.floor(scaled)) & ((1 << bits) - 1)


def polar_population_instance(
    node: Any,
    group: PolarPopulationGroup,
    index: int,
    *,
    component: PackedKinematicComponent | None = None,
    lut: PolarLookupTable | None = None,
) -> PolarDisplayInstance:
    """Generate one independent display member; index zero is the ECS prototype."""

    recipe = group.recipe
    if not 1 <= index < recipe.instance_count:
        raise PolarPopulationError("polar display index is outside its generated range")
    source = component or group.component
    if source.profile_id != group.profile.id:
        raise PolarPopulationError("polar display component changed to an incompatible profile")
    codec = group.profile.codec
    base_pose = codec.unpack_pose(source.pose_word)
    (
        log_min,
        log_max,
        radial_rate,
        angle_step_turns,
        angle_jitter_turns,
        height_spread,
        scale_min,
        scale_max,
    ) = validate_polar_population_operator_parameters(
        recipe.preset, group.operator_parameters
    )
    session_seed = combine_seed(group.root_seed, recipe.seed)
    namespace = _namespace_u64(group.lineage_namespace)
    lineage = stable_id(session_seed, namespace, index)

    if recipe.preset == "spiral":
        spiral_x = _mul32(float(index), radial_rate, "Spiral x")
        radial_unit = _div32(
            spiral_x,
            _add32(1.0, spiral_x, "Spiral denominator"),
            "Spiral radial unit",
        )
    else:
        radial_unit = _lane(lineage, 1)
    log_span = _sub32(log_max, log_min, "Log radius span")
    log_multiplier = _add32(
        log_min,
        _mul32(log_span, radial_unit, "Log radius interpolation"),
        "Log radius multiplier",
    )
    rho = _add32(base_pose.rho, log_multiplier, "Generated log radius")

    phase_lineage = stable_id(session_seed, namespace, 0)
    seeded_phase = _lane(phase_lineage, 0)
    turn_jitter = _mul32(
        _sub32(_lane(lineage, 2), 0.5, "Centered turn lane"),
        angle_jitter_turns,
        "Turn variation",
    )
    stepped_turn = _mul32(float(index), angle_step_turns, "Turn step")
    turns = _add32(
        _add32(seeded_phase, stepped_turn, "Seeded stepped turn"),
        turn_jitter,
        "Generated turn",
    )
    theta_mask = (1 << _THETA_BITS) - 1
    heading_mask = (1 << _HEADING_BITS) - 1
    base_theta_code = (source.pose_word >> _THETA_SHIFT) & theta_mask
    base_heading_code = (source.pose_word >> _HEADING_SHIFT) & heading_mask
    theta_code = (
        base_theta_code + _periodic_turn_code(turns, _THETA_BITS)
    ) & theta_mask
    heading_code = (
        base_heading_code + _periodic_turn_code(turns, _HEADING_BITS)
    ) & heading_mask
    packed_rho = codec.pack_pose(PolarPose(rho, 0.0, 0, 0))
    rho_mask = ((1 << _RHO_BITS) - 1) << _RHO_SHIFT
    tick_mask = ((1 << _TICK_BITS) - 1) << _TICK_SHIFT
    pose_word = (
        (packed_rho & rho_mask)
        | (theta_code << _THETA_SHIFT)
        | (source.pose_word & tick_mask)
        | (heading_code << _HEADING_SHIFT)
    )
    display_component = PackedKinematicComponent(
        pose_word, source.motion_word, source.profile_id
    )
    selected_lut = lut or quantized_profile_lut(group.profile)
    state = codec.cartesian_state(display_component, selected_lut)
    x, z = state["position"]
    velocity_x, velocity_z = state["velocity"]
    base_y = _f32(getattr(node, "transform").translation[1], "Prototype height")
    height = _add32(
        base_y,
        _mul32(
            _sub32(_lane(lineage, 3), 0.5, "Centered height lane"),
            height_spread,
            "Height variation",
        ),
        "Generated height",
    )
    scalar = _add32(
        scale_min,
        _mul32(
            _lane(lineage, 4),
            _sub32(scale_max, scale_min, "Size span"),
            "Size interpolation",
        ),
        "Generated size",
    )
    authored_scale = tuple(
        _f32(value, "Prototype scale") for value in getattr(node, "transform").scale
    )
    scale = tuple(
        _mul32(value, scalar, "Generated scale") for value in authored_scale
    )
    pose = state["pose"]
    rotation = tuple(
        _f32(value, "Generated facing")
        for value in quat_from_axis_angle((0.0, 1.0, 0.0), pose.heading)
    )
    source_y_velocity = _f32(getattr(node, "velocity", (0.0, 0.0, 0.0))[1], "Prototype Y velocity")
    return PolarDisplayInstance(
        prototype_id=group.prototype_id,
        index=index,
        lineage=lineage,
        profile_id=source.profile_id,
        pose_word=pose_word,
        motion_word=source.motion_word,
        translation=(_f32(x, "Generated X"), height, _f32(z, "Generated Z")),
        rotation=rotation,
        scale=scale,  # type: ignore[arg-type]
        velocity=(
            _f32(velocity_x, "Generated X velocity"),
            source_y_velocity,
            _f32(velocity_z, "Generated Z velocity"),
        ),
    )


def polar_population_instances(
    node: Any,
    group: PolarPopulationGroup,
    *,
    component: PackedKinematicComponent | None = None,
) -> tuple[PolarDisplayInstance, ...]:
    """Generate copies 2..N as render data without touching the ECS world."""

    lut = quantized_profile_lut(group.profile)
    return tuple(
        polar_population_instance(
            node, group, index, component=component, lut=lut
        )
        for index in range(1, group.recipe.instance_count)
    )


def operators_for_mask(mask: int) -> tuple[PolarPopulationOperator, ...]:
    supported = sum(operator.mask for operator in POLAR_POPULATION_OPERATORS)
    if mask & ~supported:
        raise PolarPopulationError("polar population operator mask has unsupported bits")
    return tuple(
        operator for operator in POLAR_POPULATION_OPERATORS if mask & operator.mask
    )


__all__ = [
    "MAX_POLAR_POPULATION_INSTANCES_PER_RECIPE",
    "MAX_POLAR_POPULATION_RECIPES",
    "MAX_POLAR_POPULATION_TOTAL_INSTANCES",
    "POLAR_POPULATION_METADATA_KEY",
    "POLAR_POPULATION_MATH_SCHEDULE",
    "POLAR_POPULATION_OPERATORS",
    "POLAR_POPULATION_PRESETS",
    "POLAR_POPULATION_PRESET_LABELS",
    "PolarDisplayInstance",
    "PolarPopulationError",
    "PolarPopulationGroup",
    "PolarPopulationOperator",
    "PolarPopulationProjectSpec",
    "PolarPopulationRecipe",
    "collect_polar_population_project_spec",
    "operator_mask_for_preset",
    "operators_for_mask",
    "polar_population_instance",
    "polar_population_instances",
    "polar_population_operator_parameters",
    "polar_population_preset",
    "polar_asset_semantics_address",
    "polar_profile_semantics_address",
    "polar_prototype_semantics_address",
    "polar_recipe_addresses",
    "polar_recipe_record_addresses",
    "validate_polar_population_operator_parameters",
]
