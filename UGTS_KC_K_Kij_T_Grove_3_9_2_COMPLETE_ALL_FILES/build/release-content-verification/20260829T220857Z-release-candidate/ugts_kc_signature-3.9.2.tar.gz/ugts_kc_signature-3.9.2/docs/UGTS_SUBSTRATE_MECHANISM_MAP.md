# UGTS source-to-engine mechanism map

Updated: 2026-08-29

This map answers a deliberately strict question: is a UGTS mechanism actually
used by the engine, merely planned, or inappropriate for this workload?  A
feature is not marked retained just because a similarly named class exists.

Status vocabulary:

- **Retained**: the source meaning and bounded representation are present and
  verified in an engine runtime.
- **Translated**: the source idea is used through a different representation
  suited to this engine, with the translation stated explicitly.
- **Active**: implementation exists in the worktree but final integration or
  target-device evidence is still running.
- **Deferred**: useful and in scope, but not implemented yet.
- **Rejected here**: forcing the mechanism into this application would make the
  engine less correct, less compact, or less usable.

| Source mechanism | Status | Engine application | Boundary / next evidence |
| --- | --- | --- | --- |
| SCLP bounded log-radius chart with an explicit core | **Retained** | `LogPolarProfile`, KCPK validation, and UGLUT2 use bounded rho and a positive core radius. | Shared Python/native/shader conformance vectors still need to be published. |
| Periodic polar angle and heading | **Retained** | theta18 and heading12 wrap canonically; desktop and native semantic fields expose degrees without exposing bits. | GPU periodic interpolation is active and must survive the LUT seam on the POCO. |
| Packed pose and derivatives | **Retained** | One 64-bit pose plus one 64-bit motion word; sparse KCPK records cost 24 bytes including node/profile references. | APK inspection and 64/256/1024 asset-size deltas remain to be recorded. |
| Shared binary16 polar reconstruction table | **Retained on CPU/host; Active on the GPU target** | UGLUT2 is generated once per profile and used by desktop/native CPU composition. GLES source uploads each referenced RGBA16F profile once, and the Direct/LUT shader variants pass host link checks. | The current timer-inclusive source still needs a fresh APK and identical-work Direct/LUT device timing; no automatic speed claim. |
| Analytic Cartesian velocity/acceleration from rho/theta derivatives | **Retained / Active device parity** | Python and native host evidence cover the packed composition, and desktop 3D publishes X/Z velocity while preserving authored Y. | Add target-device collision proof with a moving packed body. |
| Metric, gradient, and exact radial differential operators | **Deferred** | Suitable for polar fields, materials, steering, collision gradients, and procedural effects. | Define typed operator contracts before exposing beginner blocks. |
| Topological wrap and chart transition rules | **Partly retained** | Periodic angle wrap is retained; general multi-chart/topological transitions are not. | Needed before using the substrate for worlds that cross more than one bounded chart. |
| Morton/spatial address packing | **Deferred** | A candidate for spatial queries, streaming, field tiles, and recipe cache locality. | Do not mix it into pose packing until an actual query/streaming benchmark needs it. |
| UGTS 4.1 SplitMix64 random-access lineage | **Retained in bounded generators** | Populate Area, repeatable random Logic Blocks, and native KCPR Ring/Spiral/Polar Field members use random-access lineage. Count is excluded only from the lineage namespace, so increasing a recipe count preserves its existing prefix. | Publish broader cross-runtime vectors before reusing the scheme for other recipe families. |
| Foundation 5.0 content-addressed operators | **Retained for bounded KCPR; deferred generally** | KCPR392 stores a minimal canonical operator table plus full 128-bit recipe, profile, prototype, mesh, material, and dependency addresses rather than per-copy graph blobs. | General render/field operator schemas, migrations, and reusable Saved Object/Scene recipes remain deferred. |
| GPU Native Addendum locality/line-pressure evidence | **Translated into strict acceptance gates** | Direct and LUT share batching; runtime proof now rejects wrong modes/counts, unintended fallback, wrong Bayer settings, and unbounded materialization. A bounded nonblocking disjoint-query source path records only later-available, non-disjoint samples. | Build the current source, then record vertex-texture support and Direct/LUT/Bayer device timings. Reject LUT-by-default if it loses materially. |
| Bayer Direct 3.9.4 canonical 8x8 threshold order | **Active translation** | The final full-color GLES ordered-dither source path and shader-link checks use the canonical top-origin order at physical output pixels. | A prior APK contains the path, but the current KCPR/timer-inclusive APK and device Off/preset screenshots, cost, and temporal stability remain unproven. |
| Bayer Direct CPU ANativeWindow RGB565/four-level hot path | **Rejected here** | The 3D engine keeps its GLES PBR/post path; only the threshold order and presentation-only authority rule are portable. | A Retro preset may deliberately reduce levels, but it must not be mislabeled RGB565. |
| Polar encoding for arbitrary topology, text, UI, and ordinary object metadata | **Rejected here** | Those domains retain representations that match their actual structure. | Use log-polar data for radial geometry, kinematics, fields, particles, materials, and scale-space operations where composition is real. |

## Required compact render chain

The target chain is:

`seed + bounded operator recipe + packed ECS state -> shared log-encoded polar
LUT -> instanced/procedural GPU work -> final Bayer projection`

The source and host evidence now cover packed ECS state, CPU LUT reconstruction,
semantic graph access, the 32-byte seed/render-settings record, strict native
KCPR parsing/random access, and total-count-independent bounded visible staging.
KCPR feeds the Direct/LUT instancing and Bayer source paths, and the editor's
Make Many Inspector exposes Off, Ring, Spiral, and Polar Field without making
generated members selectable ECS entities.  Its preview is globally capped at
64 generated copies.

That is not current device proof.  The latest fresh Android build stopped before
NDK compilation when the deeply nested Windows build path could not create the
CMake `try_compile` working directory.  With no ADB device, the current APK,
runtime timer support, Direct/LUT/Bayer A/B results, Mali timings, power, and
thermal behavior remain unproven.  General content-addressed operator systems
beyond bounded KCPR also remain deferred; KCRP settings alone do not reconstruct
an entire scene.

## Acceptance rule

A mechanism moves to **Retained** only when its serialized meaning, desktop
behavior, native behavior, failure bounds, and evidence are all named.  Smaller
files alone do not prove substrate use, and visual similarity alone does not
prove deterministic parity.
