# UGTS Engine implementation TODO

Updated: 2026-08-29

This is the authoritative implementation checklist for turning the current
UGTS-KC 3.9.2 codebase into a child-first, Godot-like desktop game engine with
compact Android deployment.  A checked item means the behavior exists and has
direct evidence.  It does not mean the larger section is finished.

## Non-negotiable outcome

- [ ] A child can create, connect, run, inspect, and deploy a small game without
  editing JSON or packed words.
- [ ] Desktop preview and native Android execute the same bounded ECS and Logic
  Block semantics.
- [ ] The compact render path is genuinely substrate-driven:
  `seed + operator recipe + packed ECS state -> shared log-encoded polar LUT ->
  procedural/instanced GPU rendering -> Bayer output projection`.
- [ ] The exact POCO X7 Pro / Mali-G720 build is installed, visually checked,
  profiled, and compared with honest baselines.
- [ ] Size, speed, determinism, and visual-quality claims are backed by named
  artifacts and reproducible commands.

## 1. Preserve and audit the UGTS substrate

- [x] Search the parent repository for the SCLP 3.6.2 log-polar definitions,
  UGTS 4.1 seed lineage, UGTS Foundation 5.0 packed operators, GPU-native LUT
  evidence, and Bayer Direct 3.9.4.
- [x] Keep the explicit log-radius singular core, bounded quantization domains,
  deterministic rounding, and binary validation.
- [x] Create a source-to-engine mechanism map: retained, translated, deferred,
  or rejected, with the reason for every imported mechanism.
- [x] Add content-addressed operator definitions so saved recipes refer to
  canonical meaning rather than duplicated blobs.
- [ ] Add conformance vectors shared by Python, desktop preview, C++ Android,
  and shaders.

## 2. ECS composition

- [x] Desktop 2D component dictionaries, deterministic queries, ordered system
  phases, events, snapshots, and hashes.
- [x] Desktop 3D compatibility ECS facade with component aliases, queries,
  ordered phases, Logic Block systems, packed motion, animation, hierarchy,
  triggers, and bounded physics.
- [x] Android sparse specialized sidecars for packed polar motion, graphs,
  animations, hierarchy, populations, and body physics.
- [x] Finish the semantic `polar_movement` adapter so Logic Blocks edit radius,
  angle, facing, turn speed, radial growth, and both accelerations instead of
  raw 64-bit words.
- [x] Prove semantic polar reads/writes produce matching packed words and
  transforms on desktop and native Android.
- [x] Compose X/Z velocity from the same packed polar state while preserving
  authored/gameplay Y velocity, so collision math sees the motion it renders.
- [ ] Replace the 3D monolithic compatibility record with explicit component
  pools/archetype views without breaking project compatibility.
- [ ] Add safe runtime add/remove component operations and corresponding
  child-readable Logic Blocks.
- [ ] Add compact iteration/query plans for shared graph bindings, tags,
  spatial queries, and render batches.
- [ ] Define ownership/conflict rules for every transform writer.

## 3. Log-encoded polar LUT as a render substrate

- [x] Two-u64 pose/motion component with rho20, theta18, tick14, heading12 and
  four signed 16-bit derivative fields.
- [x] Shared UGLUT2 binary16 sine/cosine/radius reconstruction table with scaled
  radius storage, strict parsing, and deterministic desktop/native CPU use.
- [x] Sparse KCPK records: 24 bytes per referenced scene node plus shared
  profiles; unused projects emit no KCPK asset.
- [x] Preserve raw half samples and radius scale for exact GPU upload.
- [x] Upload each referenced LUT profile once to GLES3.
- [x] Decode packed rho/theta/heading in the vertex shader.
- [x] Batch compatible polar ECS entities by profile, mesh, and material and
  render them with `glDrawElementsInstanced`.
- [x] Interpolate previous/current packed poses for display without changing
  deterministic fixed-step simulation.
- [x] Keep CPU ECS state authoritative for Logic Blocks, physics, triggers,
  hierarchy, snapshots, and replay.
- [x] Provide three comparable modes: CPU transform fallback, GPU direct math,
  and GPU LUT decode.
- [x] Log the selected mode, profile count, instance count, batch count, and
  fallback reason on the device.
- [ ] Extend suitable uses beyond orbit placement: radial particles, procedural
  material coordinates, field/effect sampling, scale-space LOD, and seeded
  polar geometry.  Do not force polar coordinates onto arbitrary topology,
  text, or ordinary UI data.

## 4. Seeded compact operator recipes

- [x] UGTS 4.1-compatible SplitMix64 lineage and deterministic Populate Area.
- [x] Repeatable Random Number Logic Block with desktop/web/native agreement.
- [x] Add an optional strict 32-byte KCRP render-settings record carrying the
  render seed, polar execution mode, and Bayer projection parameters.
- [x] Define a compact bounded render-recipe asset containing seed, operator
  graph identity, profile references, limits, and error contract.
- [x] Generate many visual instances from one seed and recipe as render data,
  without copied ECS nodes or resident per-copy matrices; visible staging and
  the GL instance buffer are bounded by the configured visible-node cap rather
  than the recipe's total count.
- [x] Implement bounded Ring, Spiral, and Polar Field display recipes through
  canonical typed operators with strict limits and dependency addresses.
- [ ] Extend the bounded recipe vocabulary to sweeps, branches, particles, and
  material variations where those operators have a demonstrated use.
- [x] Make every generated item random-access by lineage so changing a count
  preserves the existing prefix.
- [x] Expose Off, Ring, Spiral, and Polar Field through the child-readable Make
  Many Inspector, with friendly controls, validated undo/redo, movement/spin
  ownership handoff, exact compactness/address inspection, prototype-only
  selection, and a global preview cap of 64 generated copies.
- [ ] Add reusable Saved Object/Scene recipe presets without duplicating the
  canonical operator meanings.
- [x] Keep gameplay-promoted instances explicit; render-only generated members
  must never pretend to be independent ECS entities.

## 5. Bayer output projection

- [x] Locate and audit the sibling Bayer Direct 3.9.4 8x8 threshold definition
  and its evidence boundary.
- [x] Add an 8x8 ordered-dither stage at the end of the GLES post pass.
- [x] Offer Off, Gentle gradient smoothing, and intentional limited-palette
  modes with bounded strength/levels.
- [x] Apply Bayer only to presentation; it must never alter gameplay, ECS,
  topology, picking, or deterministic state.
- [x] Make the output mode editable in project settings and portable in a tiny
  validated render-profile asset.
- [x] Implement the portable record as optional `render_substrate.kcrp` and add
  child-facing Packed movement and Colour smoothing choices to the Render tab.
- [ ] Verify output-resolution anchoring, rotation/orientation stability,
  screenshot determinism where applicable, and absence of accidental crawling.
- [ ] Compare Bayer off/on for banding, visible patterning, GPU time, power, and
  thermal cost.  Do not call it motion or geometry smoothing.

## 6. Node graph coding and child-first authoring

- [x] Serializable typed Logic Blocks, portable Android VM, messages, timers,
  triggers, spatial sensing, animation actions, trace view, and bounded limits.
- [ ] Add dedicated child-facing Movement/Render recipe blocks that hide
  component names when a simpler noun is possible.
- [ ] Add reusable subgraphs/functions with typed inputs and outputs.
- [ ] Add graph variables, arrays/collections, spawn/component actions, and
  explicit error paths without unbounded execution.
- [ ] Add recipe presets such as Orbit, Spiral, Ring, Seeded Grove, Burst, and
  Bayer Palette, all editable after creation.
- [ ] Improve inline help, examples, undo/redo, keyboard navigation, color-blind
  cues, and readable error recovery for first-time learners.

## 7. Editor and desktop runtime

- [x] One-click Windows launcher, dark theme, Scene Tree, Inspector, viewport,
  Logic Blocks, animation timeline, build, deploy, and phone profiling actions.
- [x] Editable ordinary parent/child hierarchy with local Inspector and
  world-space viewport transforms.
- [ ] Replace the projected authoring viewport with the same GPU render path
  used by the game, including polar LUT and Bayer preview modes.
- [x] Add child-facing project render settings and the Make Many seeded-recipe
  preview, including static file-byte/address compactness inspection.
- [ ] Add a clearer general component panel and live measured performance
  inspector; static recipe size is not a substitute for runtime profiling.
- [ ] Add docking/layout persistence, command search, asset import pipeline,
  multi-scene workflow, and stable crash recovery.
- [ ] Add a true desktop packaged player/export path independent of the editor.

## 8. Android / POCO proof and performance gates

- [x] Historical baseline: build, install, cold-launch, screenshot, and profile
  an earlier ARM64 GLES3 APK on the connected POCO X7 Pro / Mali-G720.
- [x] Historical five-node baseline: about 1.57 MB APK, 120 Hz compositor
  cadence, no observed large intervals or crashes in the bounded 15-second run.
- [x] Build an editable packed-polar GPU lab with 64, 256, and 1024 mover
  workloads sharing one recipe/LUT where limits permit.
- [ ] Capture identical-work A/B runs for CPU fallback, GPU direct math, and GPU
  LUT, then Bayer off/on.
- [ ] Record warm-up, duration, frame p50/p95/p99, missed intervals, CPU, PSS,
  GPU/battery temperature, battery level, thermal status, crashes, exact APK
  hash, and exact asset sizes.
- [x] Implement a nonblocking `GL_EXT_disjoint_timer_query` source path with a
  bounded query ring, later-frame availability polling, disjoint invalidation,
  and explicit unsupported/runtime-failure reporting; never wait on the GPU.
- [x] Make the benchmark harness fail closed unless runtime logs prove the exact
  requested/effective mode and counts, zero unintended fallback, bounded
  materialization/Cartesian composition, and the requested Bayer settings.
- [ ] Produce a fresh Android APK from the current KCPR/timer-inclusive source.
  The latest attempt stopped in CMake compiler-ABI `try_compile` because the
  deeply nested Windows build path could not create its `CMakeTmp` directory.
- [ ] Prove timer-query support or its clean absence on the target device and
  capture valid Direct/LUT/Bayer A/B samples; there is currently no ADB device.
- [ ] Run sustained 10-minute and 30-minute thermal tests before any broad
  performance or battery claim.
- [ ] Stress collisions, graphs, hierarchy, messages, seeded generation, and
  render batching together rather than profiling only an idle visual scene.

## 9. Packaging and release discipline

- [x] Current source test baseline: 627 passed and 145 subtests passed before
  the semantic-polar/GPU-render work began.
- [x] Re-run the focused native/Python/editor tests for the KCPR, strict proof,
  profiler, and benchmark-harness slice.
- [ ] Re-run the complete suite after integration.
- [ ] Rebuild and smoke-install wheel and sdist only after the new source and
  documentation settle.
- [ ] Archive exact source packs, APKs, screenshots, profiles, hashes, and
  inspection reports without overwriting evidence from earlier builds.
- [ ] Keep claims explicitly bounded: compactness is measurable; “AAA” requires
  content, rendering, tooling, sustained performance, and production evidence
  that do not yet exist.
