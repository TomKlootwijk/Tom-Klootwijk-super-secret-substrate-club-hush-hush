# UGTS source-to-engine mechanism map

Updated: 2026-08-30

This map answers a deliberately strict question: is a UGTS mechanism actually
used by the engine, merely planned, or inappropriate for this workload?  A
feature is not marked retained just because a similarly named class exists.

Status vocabulary:

- **Retained**: the source meaning and bounded representation are present and
  verified in an engine runtime.
- **Translated**: the source idea is used through a different representation
  suited to this engine, with the translation stated explicitly.
- **Active**: implementation exists in the worktree but final integration or
  target-device evidence is still running.
- **Deferred**: useful and in scope, but not implemented yet.
- **Rejected here**: forcing the mechanism into this application would make the
  engine less correct, less compact, or less usable.

| Source mechanism | Status | Engine application | Boundary / next evidence |
| --- | --- | --- | --- |
| SCLP bounded log-radius chart with an explicit core | **Retained** | `LogPolarProfile`, KCPK validation, UGLUT2, and one shared seven-case Python/native artifact cover the explicit core plus lower/middle/upper radius cases. | Shader formulas are source-checked only; run the same evidence through a physical GLES driver. |
| Periodic polar angle and heading | **Retained on CPU/native host; Active on the GPU target** | theta18 and heading12 wrap canonically. Shared vectors cover both seams, and LUT shader source now reuses the same seam-safe log-encoded polar LUT direction lookup for packed heading while Direct keeps its trig baseline. | Host source/link checks do not prove Mali interpolation or seam appearance. |
| Packed pose and derivatives | **Retained** | One 64-bit pose plus one 64-bit motion word; sparse KCPK records cost 24 bytes including node/profile references. The vectors also freeze packed next-pose/next-motion evolution. | The 15-case build matrix records exact compact assets and APKs; target-device resident memory and execution remain unmeasured. |
| Shared binary16 log-encoded polar LUT | **Retained on CPU/host; Active on the GPU target** | UGLUT2 is generated once per profile and used by desktop/native CPU composition. GLES source uploads each referenced RGBA16F profile once and reuses its direction samples for theta and heading; Direct/LUT shader variants pass host link checks and build in all matrix cases. | Compare identical workloads on the POCO; build success makes no LUT speed or driver claim. |
| Analytic Cartesian velocity/acceleration from rho/theta derivatives | **Retained / Active device parity** | The shared seven-vector Python/native pass covers Direct/LUT position, velocity, acceleration, heading, clamps, seams, and fixed-step evolution; desktop 3D preserves authored Y. | Shader formula parity is source-only. Add physical target rendering and moving-body collision proof. |
| Metric, gradient, and exact radial differential operators | **Deferred** | Suitable for polar fields, materials, steering, collision gradients, and procedural effects. | Define typed operator contracts before exposing beginner blocks. |
| Topological wrap and chart transition rules | **Partly retained** | Periodic angle wrap is retained; general multi-chart/topological transitions are not. | Needed before using the substrate for worlds that cross more than one bounded chart. |
| Morton/spatial address packing | **Deferred** | A candidate for spatial queries, streaming, field tiles, and recipe cache locality. | Do not mix it into pose packing until an actual query/streaming benchmark needs it. |
| UGTS 4.1 SplitMix64 random-access lineage | **Retained in bounded generators** | Populate Area, repeatable random Logic Blocks, and native KCPR Ring/Spiral/Polar Field/Radial Burst members use random-access lineage. Count is excluded only from the lineage namespace, so increasing a recipe count preserves its existing prefix. | Publish broader cross-runtime vectors before reusing the scheme for other recipe families. |
| Foundation 5.0 content-addressed operators | **Retained for bounded KCPR; deferred generally** | KCPR392 stores a minimal canonical operator table plus full 128-bit recipe, profile, prototype, mesh, material, and dependency addresses rather than per-copy graph blobs. Legacy-only recipes remain byte-identical v1; Radial Burst opts the asset into v2. | General render/field operator schemas, migrations, and reusable Saved Object/Scene recipes remain deferred. |
| GPU Native Addendum locality/line-pressure evidence | **Translated into strict acceptance gates** | Direct and LUT share batching; runtime proof rejects wrong modes/counts, fallback, wrong Bayer settings, and unbounded materialization. The nonblocking timer source is present, and a short-path harness built all 15 CPU/Direct/LUT+Bayer cases with append-only evidence. | Every comparison is unavailable until physical profiles exist. Record vertex-texture support and Direct/LUT/Bayer POCO timings; reject LUT-by-default if it loses materially. |
| Bayer Direct 3.9.4 canonical 8x8 threshold order | **Active translation** | The final full-color GLES ordered-dither source and host shader-link checks use the canonical top-origin order. Bayer Off/Subtle compile in the unified build-only matrix. | No current physical screenshot, output-orientation check, GPU cost, or temporal-stability result exists. |
| Bayer Direct CPU ANativeWindow RGB565/four-level hot path | **Rejected here** | The 3D engine keeps its GLES PBR/post path; only the threshold order and presentation-only authority rule are portable. | A Retro preset may deliberately reduce levels, but it must not be mislabeled RGB565. |
| Polar encoding for arbitrary topology, text, UI, and ordinary object metadata | **Rejected here** | Those domains retain representations that match their actual structure. | Use log-radius polar data for radial geometry, kinematics, fields, particles, materials, and scale-space operations where composition is real. |

## Required compact render chain

The target chain is:

`seed + bounded operator recipe + packed ECS state -> shared log-encoded polar
LUT -> instanced/procedural GPU work -> final Bayer projection`

The source and host evidence now cover packed ECS state, CPU log-encoded polar
LUT reconstruction, semantic graph access, the 32-byte seed/render-settings record, strict native
KCPR parsing/random access, and total-count-independent bounded visible staging.
KCPR feeds the Direct/LUT instancing and Bayer source paths, and the editor's
Make Many Inspector exposes Off, Ring, Spiral, Polar Field, and **Radial Burst
(loops)** without making
generated members selectable ECS entities. Its preview is globally capped at
64 generated copies and now follows the real packed prototype during desktop
Play by regenerating only those retained random-access items. It does not add
desktop interpolation or generated ECS state.

Radial Burst is bounded looping display data around one real ECS prototype,
not a one-shot gameplay event. Its local packed displacement compounds with
the prototype's packed anchor through log-encoded polar LUT semantics. Stopped
desktop authoring shows the deterministic midpoint; Play uses the real
post-step world tick and fixed endpoint without a synthetic alpha. Direct is
the baseline reconstruction path, LUT shares the profile upload, and Bayer is
still the final presentation pass. Burst limits are 512 instances per recipe,
16 recipes and 2,048 instances per project; native materialization is also
bounded by maximum-visible and the remaining particle budget. Opcode 30 hides
only the extra display copies.

Runtime copy visibility is a separate bounded control layer: opcode 30 changes
one bit in an eight-byte native mask and an equivalent desktop sidecar. It skips
a hidden KCPR recipe before random-access materialization while preserving its
content address, lineage, prefix and active ECS prototype.

The original nested-workspace CMake failure remains preserved evidence. The
benchmark harness now builds in a short system-temporary workspace, preserves
numbered attempts and exact outputs, and validates the flavor-suffixed AGP
application ID. Explicit SHA-1 build IDs plus normalized DWARF prefixes produced
byte-identical APK/native artifacts in two independent clean workspaces. The
current source also completed a unified 15-case 64/256/1024 CPU/Direct/LUT and
Bayer Off/Subtle build-only matrix.

A separate Burst matrix is defined as 32/128/384 × CPU/Direct/LUT × Bayer
Off/subtle, for 18 cases:

```powershell
python validation/benchmark_polar_render_poco.py --workload burst --include-cpu --build-only
```

The preserved `built_only` run at
`build/poco-polar-render-benchmarks/20260830T000848Z-seed-5eed3920c0dec0de`
completed all 18 cases in 272 seconds. Each case records a 1,690-byte KCPK,
240-byte KCPR and 32-byte KCRP; APKs range from 1,804,558 to 1,804,566 bytes.
None was installed or executed on POCO/Mali, so physical rendering and all
performance comparisons remain unavailable.

That is still not device proof. All 15 cases have null FPS/profile fields and
all 12 comparisons are unavailable. With no ADB device, physical POCO/Mali
rendering, screenshots, timer-query support and samples, Direct/LUT/Bayer
timings, frame rate, power, and thermal behavior remain unproven. General
content-addressed operator systems beyond bounded KCPR also remain deferred;
KCRP settings alone do not reconstruct an entire scene.

## Acceptance rule

A mechanism moves to **Retained** only when its serialized meaning, desktop
behavior, native behavior, failure bounds, and evidence are all named.  Smaller
files alone do not prove substrate use, and visual similarity alone does not
prove deterministic parity.
