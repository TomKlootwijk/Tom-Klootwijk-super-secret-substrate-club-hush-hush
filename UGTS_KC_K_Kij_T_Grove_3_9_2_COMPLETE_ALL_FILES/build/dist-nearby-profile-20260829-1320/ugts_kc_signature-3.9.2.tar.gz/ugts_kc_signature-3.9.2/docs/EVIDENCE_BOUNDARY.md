# Evidence Boundary — K-Kij-T / Grove 3.9.2

## Demonstrated by the current source and build

- All 455 Python regression tests pass in 35.669 seconds, including offscreen editor, retained browser
  VM, graph-pack and native-host parity coverage.
- Logic Blocks authoring is selection-owned: unbound 2D/3D objects remain absent from project data
  until their first edit creates and binds a graph, exact Undo removes both, ordered multi-bindings
  remain explicit choices, and Populate Area prototypes refuse ownership.
- The complete current vocabulary contains 22 blocks. **Find Nearby Object** is compact `KCVG001`
  opcode 22 and has golden-tested desktop/browser/native behavior for origin, five portable tags,
  inclusive radius, active/alive filtering, nearest selection and deterministic object-ID ties.
- First Steps emits four graphs, 18 graph nodes and four bindings including one world binding. Its
  823-byte KCVG pack has SHA-256
  `8021e70d5dbe09cc25c3c31bc8c88e11bafd1f33b7e9d31fbdc61a1e023e551d`; KCVG, KCPK and KCSP
  sidecars total 1,797 bytes.
- The current `build/UGTS-First-Steps-3.9.2-Poco-X7-Pro-debug.apk` is 1,441,929 bytes with SHA-256
  `7F3080834EDB56EAAB0BFE8AEA1B1AD2D634C1AA7C4EB314C5B614760E48454F`. Local inspection verifies APK
  Signature Scheme v2, a debug certificate, ARM64-only native code, minimum SDK 26, target SDK 36,
  GLES3 and package `org.ugts.games.my_mobile_3d_game.pocox7pro`.
- The current wheel and source archive build successfully. A no-dependency wheel install into a fresh
  target ran the offscreen editor smoke and generated a current 51-file Android source tree; this
  verifies package contents, not dependency installation on an otherwise empty machine.

## Physical Android boundary

An earlier 3.9.2 APK was installed, cold-launched, hash-matched and visually smoke-checked on the
authorized Xiaomi `2412DPC0AG` / `rodin`. Its retained 64.9-second idle profile measured frame
cadence, process memory, available GPU temperature, Android thermal status and crash-buffer state;
the exact workload and limitations are recorded in
`validation/poco_x7_pro_idle_profile_2026_08_29.json`.

The current APK is also installed, cold-launched and hash-matched byte-for-byte on that Poco. Its
fresh 30.0-second profile collected 756 intervals at 120.23 effective FPS with 8.298/10.118/11.872 ms
p50/p95/p99 and two intervals over 1.5 display periods. PSS was 132,590–138,573 KiB, RSS
250,478–257,854 KiB, available GPU temperature 44.634–45.511 °C, battery 37 °C / 78% unchanged,
maximum thermal status 0, crash buffer empty and warnings empty. The exact current result is
`validation/poco_x7_pro_current_profile_2026_08_29.json`.

Both captures are short baselines for their exact APK/workload, not general phone guarantees.
Interaction-heavy/touch, unplugged battery, long-duration thermal equilibrium, explicit 60/90 Hz
fallback and representative lower-tier-device runs remain open. Play Store submission, release
signing and certification are not claimed.

## Broader non-claims

- Vulkan rendering (optional interface/manifest hook only).
- 4D runtime, 4D physics or 4D interchange (design TODO only).
- General certified rigid-body dynamics, joints, deformables or robust CCD.
- General gameplay PCG beyond bounded decorative Populate Area, plus skeletal animation/retargeting,
  production multiplayer, anti-cheat, OpenXR and console platform SDKs.
- Independent verification of requester identity, attribution or ownership assertions.

## Determinism scope

Canonical state/project hashes normalize numerically equivalent integral values. Determinism is
expected for the same runtime version, project, fixed step and input sequence. Repeatable Random
Number (opcode 21) and Find Nearby Object (opcode 22) have explicit binary32 cross-language parity
fixtures. Those narrow guarantees do not imply bit-identical rendering or unrestricted
cross-language floating-point identity for every subsystem.
