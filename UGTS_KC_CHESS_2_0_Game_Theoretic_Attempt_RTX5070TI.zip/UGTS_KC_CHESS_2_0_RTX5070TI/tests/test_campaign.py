from __future__ import annotations

import hashlib
import json
import tempfile
import unittest
from pathlib import Path

from ugts_chess.campaign import (
    campaign_status,
    export_campaign,
    init_campaign,
    lease_next,
    mark_verified,
    record_candidate,
    verify_campaign,
)


class CampaignTests(unittest.TestCase):
    def test_01_initial_campaign_is_complete_and_unknown(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            db = root / "campaign.sqlite3"
            meta = init_campaign(db, root / "shards")
            self.assertEqual(meta["obligation_count"], 20)
            status = campaign_status(db)
            self.assertEqual(status["root_wdl"], "unknown")
            self.assertFalse(status["game_solved"])
            audit = verify_campaign(db)
            self.assertTrue(audit["valid"], audit["errors"])

    def test_02_candidate_requires_independent_checker_record(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            db = root / "campaign.sqlite3"
            init_campaign(db, root / "shards")
            job = lease_next(db, "worker-a")
            self.assertIsNotNone(job)
            assert job is not None
            certificate = root / "candidate.json"
            certificate.write_text('{"candidate":true}\n', encoding="utf-8")
            candidate = record_candidate(db, job["obligation_id"], "loss", certificate, worker="worker-a")
            cert_hash = hashlib.sha256(certificate.read_bytes()).hexdigest()
            checker = root / "checker.json"
            checker.write_text(
                json.dumps(
                    {
                        "schema": "ugts-chess-independent-check-2.0",
                        "valid": True,
                        "obligation_id": job["obligation_id"],
                        "wdl": "loss",
                        "certificate_sha256": cert_hash,
                        "child_game_state_sha256": candidate["child_game_state_sha256"],
                        "verifier": "independent-test-oracle",
                    },
                    sort_keys=True,
                ) + "\n",
                encoding="utf-8",
            )
            mark_verified(db, job["obligation_id"], verifier="independent-test-oracle", checker_record=checker)
            status = campaign_status(db)
            # One verified child LOSS is already a root WIN witness.  This tests
            # aggregation mechanics, not the truth of the arbitrary fixture.
            self.assertEqual(status["root_wdl"], "win")
            audit = verify_campaign(db)
            self.assertTrue(audit["valid"], audit["errors"])
            exported = export_campaign(db, root / "checkpoint.json")
            self.assertEqual(exported["jobs"], 20)


if __name__ == "__main__":
    unittest.main()
