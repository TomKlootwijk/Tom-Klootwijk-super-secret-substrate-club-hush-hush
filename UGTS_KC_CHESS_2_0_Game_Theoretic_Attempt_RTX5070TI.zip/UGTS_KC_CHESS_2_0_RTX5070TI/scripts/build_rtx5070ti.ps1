$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
Set-Location $Root
New-Item -ItemType Directory -Force -Path "validation/device" | Out-Null

Write-Host "[1/7] Capturing NVIDIA and build environment"
try { nvidia-smi | Tee-Object -FilePath "validation/device/nvidia-smi.txt" } catch { throw "nvidia-smi failed: $_" }
try { nvcc --version | Tee-Object -FilePath "validation/device/nvcc-version.txt" } catch { throw "CUDA nvcc 12.8 or newer is required for the SM120 preset: $_" }
cmake --version | Tee-Object -FilePath "validation/device/cmake-version.txt"

Write-Host "[2/7] Configuring the SM120 CUDA build"
if (Test-Path "cpp/build/rtx5070ti-release") { Remove-Item -Recurse -Force "cpp/build/rtx5070ti-release" }
Push-Location "cpp"
try {
    cmake --preset rtx5070ti-release
    Write-Host "[3/7] Building"
    cmake --build --preset rtx5070ti-release --parallel
    Write-Host "[4/7] Running native tests"
    ctest --preset rtx5070ti-release --output-on-failure 2>&1 | Tee-Object -FilePath "$Root/validation/device/ctest-rtx5070ti.txt"
}
finally { Pop-Location }

Write-Host "[5/7] Inspecting the physical device"
& "cpp/build/rtx5070ti-release/ugts-chess-gpu.exe" device-info | Tee-Object -FilePath "validation/device/device-info.json"
& "cpp/build/rtx5070ti-release/ugts-chess2.exe" info | Tee-Object -FilePath "validation/device/native-info.json"

Write-Host "[6/7] Running the Python differential suite"
$env:PYTHONPATH = "src"
$env:UGTS_GPU_HOST_EXE = "cpp/build/rtx5070ti-release/ugts-chess-gpu.exe"
python -m unittest discover -s tests -v 2>&1 | Tee-Object -FilePath "validation/device/python-tests.txt"

Write-Host "[7/7] Device build complete"
Write-Host "The build is not a chess solution or a performance claim. Run scripts/run_codex_campaign.ps1 and retain long-run telemetry."
